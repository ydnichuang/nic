#ifndef _LINUX_H
#define _LINUX_H

#include <linux/io.h>

#define yib_writel writel
#define yib_readl readl

#endif

