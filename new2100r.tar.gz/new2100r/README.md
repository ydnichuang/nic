# new2100r

## yusur rdma驱动项目拉取说明
- 本项目包含子模块 rdma-header
- 拉取本项目时需要同时拉取子模块代码
- 可通过递归方式同时拉取主项目和子模块(需指定拉取带有子模块的分支)

~~~ shell
> git clone http://192.168.2.114/PRD/DSPG/RAPT/new2100r.git -b branch-name --recurse-submodules
~~~

- 或在拉取主项目后，切换至带有子模块的分支
- 在当前主项目中执行指令再单独拉取子模块

~~~ shell
> git clone http://192.168.2.114/PRD/DSPG/RAPT/new2100r.git
> cd new2100r
> git checkout -b branch-name origin/branch-name
> git submodule init
> git submodule update
~~~

## yusur rdma驱动使用说明
### 1. 配置驱动编译参数
- 根据需求修改new2100r/drivers/Makefile
- 参数 `PRJ_INDEPENDENT_MODEL_DRV` 用于选择是否单独编译yusur_model驱动, 0表示不单独编译
- 参数 `PRJ_RDMA_NP_DRIVER` 用于选择是否编译rdma_np驱动
- 参数 `PRJ_PEER_MEMORY` 用于选择是否使用peer memory
- `PRJ_INDEPENDENT_MODEL_DRV`默认为1，其他两个参数默认为0
- 如果配置 `PRJ_INDEPENDENT_MODEL_DRV = 1` 编译时会将所有该类型pcie驱动编译出来

~~~ conf
export PRJ_INDEPENDENT_MODEL_DRV = 0
export PRJ_RDMA_NP_DRIVER = 0
export PRJ_PEER_MEMORY = 0
~~~

### 2. 编译驱动

- 需要提前安装automake

~~~ shell
> cd new2100r/drivers
> make
~~~

### 3. 加载驱动

- 根据第一步配置, 选择要加载的驱动
- 加载rdma驱动前请务必确保网卡驱动已正确加载
- 如果配置 `PRJ_INDEPENDENT_MODEL_DRV = 1` 则先加载yusur_model.ko, 否则直接加载pcie驱动
- pcie驱动根据需求进行选择
- 如果配置 `PRJ_PEER_MEMORY = 1` 则加载yusur_peer.ko，否则不加载

~~~ shell
> insmod yusur_model.ko
> insmod r2100_pci.ko / insmod swtest_pci.ko / insmod hadep_pci.ko / insmod np_pci.ko
> modprobe rdma_ucm
> insmod yusur_peer.ko
> insmod yusur_rdma.ko
~~~
