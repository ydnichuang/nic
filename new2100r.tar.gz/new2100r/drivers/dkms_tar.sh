#!/bin/sh

VER="0.2.2"

rm /usr/src/yrdmadrv* -Rf
mkdir -p /usr/src/yrdmadrv-${VER}
cp ./* /usr/src/yrdmadrv-${VER}/ -Rf
dkms uninstall yrdmadrv/${VER}
dkms remove yrdmadrv/${VER} --all
dkms add -m yrdmadrv -v ${VER}
dkms install yrdmadrv/${VER}
dkms mktarball yrdmadrv/${VER} --binaries-only

