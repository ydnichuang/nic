/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.ac by autoheader.  */

/* BUS_TYPE_UEVENT_NEED_CONST */
#define BUS_TYPE_UEVENT_NEED_CONST 0

/* COUNTER_STAT_DESC */
#define COUNTER_STAT_DESC 0

/* DEV_HAS_PMD_ATTACH */
#define DEV_HAS_PMD_ATTACH 1

/* HAS_ASM_SET_MEMORY */
#define HAS_ASM_SET_MEMORY 0

/* HAS_IB_UMEM_NUM_DMA_BLOCKS */
#define HAS_IB_UMEM_NUM_DMA_BLOCKS 1

/* HAS_PCI_SET_DMA_MASK */
#define HAS_PCI_SET_DMA_MASK 1

/* HAS_RDMA_AH_INIT_ATTR */
#define HAS_RDMA_AH_INIT_ATTR 1

/* HAS_USER_AH_CREATE */
#define HAS_USER_AH_CREATE 1

/* atomic_pinned_vm is defined */
#define HAVE_ATOMIC_PINNED_VM 1

/* struct ib_umem has ibdev */
#define HAVE_IB_DEVICE 1

/* mm is defined */
/* #undef HAVE_MM_FIELD */

/* HAVE_NETDEV_LAN_HASH */
#define HAVE_NETDEV_LAN_HASH 1

/* pinned_vm is defined */
/* #undef HAVE_PINNED_VM */

/* page shift is defined */
/* #undef HAVE_UMEM_PAGE_SHIFT */

/* xz_array is defined */
#define HAVE_XARRAY 1

/* HW_STAT_FOR_PORT */
#define HW_STAT_FOR_PORT 1

/* IBDEV_ALLOC_OEN_ARG */
#define IBDEV_ALLOC_OEN_ARG 0

/* IBDEV_NO_OPS */
#define IBDEV_NO_OPS 0

/* IBDEV_NO_REF */
#define IBDEV_NO_REF 0

/* IBDEV_REGIST_NEED2PARAM */
#define IBDEV_REGIST_NEED2PARAM 0

/* IB_ADD_GID_HAVE_GID */
#define IB_ADD_GID_HAVE_GID 0

/* IB_ALLOC_MR_NEED_UDATA */
#define IB_ALLOC_MR_NEED_UDATA 0

/* IB_DESTROY_NO_RETURN */
#define IB_DESTROY_NO_RETURN 0

/* IB_DESTROY_NO_UDATA */
#define IB_DESTROY_NO_UDATA 0

/* IB_DEV_HAS_DRIVERID */
#define IB_DEV_HAS_DRIVERID 1

/* IB_DEV_HAS_NETDEV */
#define IB_DEV_HAS_NETDEV 1

/* IB_DEV_HAS_SEND_SGE */
#define IB_DEV_HAS_SEND_SGE 1

/* IB_DEV_HAS_SYS */
#define IB_DEV_HAS_SYS 1

/* IB_HAS_BIND_MW */
#define IB_HAS_BIND_MW 1

/* IB_HAS_KERNEL_CAP */
#define IB_HAS_KERNEL_CAP 0

/* IB_HAS_READ_GID_L2_FIELDS */
#define IB_HAS_READ_GID_L2_FIELDS 1

/* IB_HAS_SYS_GROUP */
#define IB_HAS_SYS_GROUP 1

/* IB_LAYER_ALLOC_AH */
#define IB_LAYER_ALLOC_AH 1

/* IB_LAYER_ALLOC_CQ */
#define IB_LAYER_ALLOC_CQ 1

/* IB_LAYER_ALLOC_MW */
#define IB_LAYER_ALLOC_MW 1

/* IB_LAYER_ALLOC_PD */
#define IB_LAYER_ALLOC_PD 1

/* IB_LAYER_ALLOC_QP */
#define IB_LAYER_ALLOC_QP 1

/* IB_LAYER_ALLOC_SRQ */
#define IB_LAYER_ALLOC_SRQ 1

/* IB_LAYER_ALLOC_UD */
#define IB_LAYER_ALLOC_UD 1

/* IB_LAYER_ALLOC_XRCD */
#define IB_LAYER_ALLOC_XRCD 1

/* IB_MODIFY_QP_NEED_DEV_TYPE */
#define IB_MODIFY_QP_NEED_DEV_TYPE 0

/* IB_PORT_NUM_TYPE */
#define IB_PORT_NUM_TYPE 1

/* IB_POST_NONEED_CONST */
/* #undef IB_POST_NONEED_CONST */

/* IB_QPT_DRIVER */
/* #undef IB_QPT_DRIVER */

/* IB_SGID_ATTR_NOTHAS_SGID */
/* #undef IB_SGID_ATTR_NOTHAS_SGID */

/* if ib_umem_get_peer is defined */
#define IB_UMEM_GET_PEER_DEFINED 1

/* IB_UMEM_GET_VERSION */
#define IB_UMEM_GET_VERSION 2

/* IB_UMEM_SGITER */
#define IB_UMEM_SGITER 1

/* IB_UMEM_SGNUM */
#define IB_UMEM_SGNUM 0

/* NET_NOTIFY_ONE_ARG */
#define NET_NOTIFY_ONE_ARG 1

/* Name of package */

/* Define to the address where bug reports for this package should be sent. */

/* Define to the full name of this package. */

/* Define to the full name and version of this package. */

/* Define to the one symbol short name of this package. */

/* Define to the home page for this package. */

/* Define to the version of this package. */

/* PCI_BUS_FIND_CONST */
#define PCI_BUS_FIND_CONST 1

/* TASKLET_NO_SETUP */
#define TASKLET_NO_SETUP 0

/* Version number of package */

/* : YRDMA_BUS_REMOVE_VOID */
#define YRDMA_BUS_REMOVE_VOID 1

#define MMAP_MEM_SET_UC 1

#ifdef IB_POST_NONEED_CONST
#define const_
#else
#define const_ const
#endif

#if IB_PORT_NUM_TYPE == 0
typedef unsigned char tPortInt;
#else
typedef unsigned int tPortInt;
#endif

