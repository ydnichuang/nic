#include "../include/basic.h"
#include "../include/os_api.h"
#include "../include/os_ds.h"
#include "../include/mem.h"
#include "../include/queue.h"
#include "../include/host.h"
#include "../include/verbs.h"
#include "hostpriv.h"

#ifdef HAS_NP_HOST_DRIVER
#define YIB_MAX_HOST_TYPES 3
#else
#define YIB_MAX_HOST_TYPES 2
#endif
static struct yib_hw_ops yib_global_host_ops[YIB_MAX_HOST_TYPES];
static int yib_global_host_cnt = 0;

#define ECN_OR_COST(class)	TC_PRIO_##class
u8 yusur_ip_tos2prio[16] = {
	TC_PRIO_BESTEFFORT,
	ECN_OR_COST(BESTEFFORT),
	TC_PRIO_BESTEFFORT,
	ECN_OR_COST(BESTEFFORT),
	TC_PRIO_BULK,
	ECN_OR_COST(BULK),
	TC_PRIO_BULK,
	ECN_OR_COST(BULK),
	TC_PRIO_INTERACTIVE,
	ECN_OR_COST(INTERACTIVE),
	TC_PRIO_INTERACTIVE,
	ECN_OR_COST(INTERACTIVE),
	TC_PRIO_INTERACTIVE_BULK,
	ECN_OR_COST(INTERACTIVE_BULK),
	TC_PRIO_INTERACTIVE_BULK,
	ECN_OR_COST(INTERACTIVE_BULK)
};
/*
	This function is called at first of module init to init device operations
*/
void yusur_hw_host_register(void)
{
	memcpy(&yib_global_host_ops[yib_global_host_cnt], swtest_get_host_ops(), sizeof(struct yib_hw_ops));
	yib_global_host_cnt++;
	memcpy(&yib_global_host_ops[yib_global_host_cnt], r2100_get_host_ops(), sizeof(struct yib_hw_ops));
	yib_global_host_cnt++;
#ifdef HAS_NP_HOST_DRIVER
	memcpy(&yib_global_host_ops[yib_global_host_cnt], np_get_host_ops(), sizeof(struct yib_hw_ops));
	yib_global_host_cnt++;
#endif
}

/*
    This function is used to get host register operations according to host type
*/
int yusur_hw_host_find(struct yib_hw_ops *ops, enum yrdma_host_type host_type)
{
	int i = 0;
	for (i = 0; i < yib_global_host_cnt; i++) {
		if (yib_global_host_ops[i].host_type == host_type) {
			memcpy(ops, &yib_global_host_ops[i], sizeof(struct yib_hw_ops));
			return 0;
		}
	}
	return -ENODEV;
}

static void yusur_hw_mactbl_item_del(struct yib_hw_host *hw, u8 *mac, int index, u8 port_num)
{
	struct yib_mac_tbl_item *mac_tbl_item = &hw->mac_tbl.mac_tbl_item[index];
	struct yib_sf *sf = &hw->sf;

	memset(mac_tbl_item, 0, sizeof(struct yib_mac_tbl_item));
	sf->sf_ops->modify_mac(sf, mac, index, port_num, true);
}

static void yusur_hw_mactbl_item_add(struct yib_hw_host *hw, u8 *mac, int index, u8 port_num, u8 is_init)
{
	struct yib_mac_tbl_item *mac_tbl_item = &hw->mac_tbl.mac_tbl_item[index];
	struct yib_sf *sf = &hw->sf;

	memcpy(mac_tbl_item->mac, mac, ETH_ALEN);
	mac_tbl_item->ref_cnt = 1;
	mac_tbl_item->port_num = port_num;
	mac_tbl_item->is_init = is_init;
	sf->sf_ops->add_mac(sf, mac, index, port_num);
}

//仅用于netdev notify CHANGEADDR 事件
void yusur_hw_mactbl_item_change(struct yib_hw_host *hw, u8 *mac, int index, u8 port_num)
{
	struct yib_mac_tbl_item *mac_tbl_item = &hw->mac_tbl.mac_tbl_item[index];
	struct yib_sf *sf = &hw->sf;

	if (mac_tbl_item->is_init == 1) {
		memcpy(mac_tbl_item->mac, mac, ETH_ALEN);
		sf->sf_ops->modify_mac(sf, mac, index, port_num, false);
	}
}

static int yusur_hw_mactbl_add(struct yib_hw_host *hw, u8 *mac, u8 port_num, u8 is_init)
{
	int i = 0;
	bool b_empty = false;
	struct yib_mac_tbl *mac_tbl = &hw->mac_tbl;

	for (i = 0; i < YIB_MAX_MAC_TBL_LEN; i++) {
		if (mac_tbl->mac_tbl_item[i].ref_cnt == 0) {
			b_empty = true;
			break;
		}
	}

	if (b_empty) {
		yusur_hw_mactbl_item_add(hw, mac, i, port_num, is_init);
		return 0;
	}
	return -ENOMEM;
}

int yusur_hw_mactbl_search(struct yib_hw_host *hw, u8 *mac, u8 port_num, bool b_add)
{
	int i = 0;
	int ret = 0;
	bool b_search = false;
	struct yib_mac_tbl *mac_tbl = &hw->mac_tbl;

	for (i = 0; i < YIB_MAX_MAC_TBL_LEN; i++) {
		if (!memcmp(mac, mac_tbl->mac_tbl_item[i].mac, ETH_ALEN)) {
			b_search = true;
			break;
		}
	}

	if (b_add) {
		if (b_search) {
			if (mac_tbl->mac_tbl_item[i].is_init == 0)
				mac_tbl->mac_tbl_item[i].ref_cnt++;
		} else {
			ret = yusur_hw_mactbl_add(hw, mac, port_num, 0);
		}
	} else {
		if (b_search) {
			if (mac_tbl->mac_tbl_item[i].is_init == 0) {
				mac_tbl->mac_tbl_item[i].ref_cnt--;
				if (mac_tbl->mac_tbl_item[i].ref_cnt == 0) {
					yusur_hw_mactbl_item_del(hw, mac, i, port_num);
				}
			}
		} else {
			ret = -ENOENT;
		}
	}

	return ret;
}

int yusur_dev_update_mtu(struct yib_hw_host *host, struct net_device *ndev, int port_num)
{
	host->ndev_info[port_num -1].cur_max_mtu = os_get_ib_mtu(ndev);
	return 0;
}

static void yusur_free_prio_array(struct yib_hw_host *hw)
{
	if (hw->prio_array.dma_addr != 0) {
		os_free_coherent_dma(hw->sf.pdev, &hw->prio_array);
	}
}

static int yusur_init_prio_array(struct yib_hw_host *hw)
{
	int i = 0;
	void *array_va = NULL;

	hw->prio_array = os_alloc_coherent_dma(hw->sf.pdev, 4096UL, hw->sf.num_node, hw->sf.host_mutex);
	if (hw->prio_array.dma_addr == 0) {
		os_printe(hw->dev, "host dscp_array alloc failed");
		return -ENOMEM;
	}

	for (i = 0; i < YIB_PCP_ARRAY_SIZE; i++) {
		array_va = hw->prio_array.vaddr + YIB_DSCP_ARRAY_SIZE * sizeof(u32) + i * sizeof(u32);
		writel(yusur_ip_tos2prio[i], array_va);
	}
	return 0;
}

static void yusur_free_db_frag(struct yib_hw_host *hw)
{
	struct yib_db_frag * frag = &hw->db_frag;
	if (frag->cq_info) {
		yib_frag_free_node(&hw->sf, frag->cq_info);
		frag->cq_info = NULL;
	}
	if (frag->sq_info) {
		yib_frag_free_node(&hw->sf, frag->sq_info);
		frag->sq_info = NULL;
	}
	if (frag->rq_info) {
		yib_frag_free_node(&hw->sf, frag->rq_info);
		frag->rq_info = NULL;
	}
}

static int yusur_init_db_frag(struct yib_hw_host *hw)
{
	struct yib_db_frag * frag = &hw->db_frag;
	u64 size = 0;

	size = os_align_up(sizeof(struct yib_queue_info) * hw->caps.num_cqs, 4096UL);
	frag->cq_info = yib_frag_buf_alloc_node(&hw->sf, size, true);
	if (frag->cq_info == NULL) {
		os_printe(hw->dev, "host cq_db buf mem not enough");
		return -ENOMEM;
	}

	size = os_align_up(sizeof(struct yib_queue_info) * hw->caps.num_qps, 4096UL);
	frag->sq_info = yib_frag_buf_alloc_node(&hw->sf, size, true);
	if (frag->sq_info == NULL) {
		os_printe(hw->dev, "host sq_db buf mem not enough");
		return -ENOMEM;
	}

	size = os_align_up(sizeof(struct yib_queue_info) * hw->caps.num_qps, 4096UL);
	frag->rq_info = yib_frag_buf_alloc_node(&hw->sf, size, true);
	if (frag->rq_info == NULL) {
		os_printe(hw->dev, "host rq_db buf mem not enough");
		return -ENOMEM;
	}

	return 0;
}

void yusur_hw_host_uinit(struct yib_hw_host *host)
{
	yusur_free_prio_array(host);
	yusur_free_db_frag(host);
}

static int yusur_hw_ops_verify(struct yib_hw_ops *ops)
{
	u64 addr = (u64)&ops->global_reset;
	u64 end = (u64)&ops->queue_ops;
	u64 i = 0;
	u64 *ptr;
	int j = 1;

	for (i = addr; i <= end; i+=8 ) {
		ptr = (u64*)i;
		if (*ptr == 0)
			return -j;
		j++;
	}	

	return 0;
}

int yusur_hw_cap_verify(struct yib_roce_caps *caps)
{
	u64 addr = (u64)&caps->num_ports;
	u64 end = (u64)&caps->max_ah;
	u64 i = 0;
	u32 *ptr;
	int j = 3;

	if (caps->max_mr_size == 0) {
		yib_dbg_err("max mr size is zero\n");
		return -1;
	}

	for (i = addr; i <= end; i+=4 ) {
		ptr = (u32*)i;
		if (*ptr == 0)
			return -j;
		j++;
	}

	return 0;
}

static int yusur_queue_ops_verify(struct yib_queue_ops *queue_ops)
{
	u64 addr = (u64)&queue_ops->cqe_isize;
	u64 end = (u64)&queue_ops->cq_ci_db_update;
	u64 i;
	u64 *ptr;
	int j = 1;

	for (i = addr; i <= end; i+=8 ) {
		ptr = (u64*)i;
		if (*ptr == 0)
			return -j;
		j++;
	}

	return 0;
}

static int yusur_eq_ops_verify(struct yib_eq_ops *eq_ops)
{
	u64 addr = (u64)&eq_ops->get_eq_intr_num;
	u64 end = (u64)&eq_ops->eq_ci_db_update;
	u64 i;
	u64 *ptr;
	int j = 2;

	for (i = addr; i <= end; i+=8 ) {
		ptr = (u64*)i;
		if (*ptr == 0)
			return -j;
		j++;
	}

	return 0;
}

static int yusur_sf_ops_verify(struct yib_sf_ops *sf_ops)
{
	u64 addr = (u64)&sf_ops->host_type;
	u64 end = (u64)&sf_ops->sf_debugfs;
	u64 i;
	u64 *ptr;
	int j = 1;

	for (i = addr; i <= end; i+=8 ) {
		ptr = (u64*)i;
		if (*ptr == 0)
			return -j;
		j++;
	}

	return 0;
}

static int yusur_host_ops_verify(struct yib_hw_host *hw)
{
	int ret = 0;
	ret = yusur_hw_ops_verify(&hw->hw_ops);
	if (ret != 0) {
		os_printe(hw->dev,"yusur hw ops is invalid at:%d\n", ret);
		return ret;
	}

	ret = yusur_queue_ops_verify(hw->hw_ops.queue_ops);
	if (ret != 0) {
		os_printe(hw->dev,"yusur queue ops is invalid at:%d\n", ret);
		return ret;	
	}

	ret = yusur_sf_ops_verify(hw->hw_ops.sf_ops);
	if (ret != 0) {
		os_printe(hw->dev,"yusur sf ops is invalid at:%d\n", ret);
		return ret;	
	}

	ret = yusur_eq_ops_verify(hw->hw_ops.eq_ops);
	if (ret != 0) {
		os_printe(hw->dev,"yusur eq ops is invalid at:%d\n", ret);
		return ret;	
	}
	return 0;
}

int yusur_hw_host_pre_init(struct yib_hw_host *host)
{
	int ret = 0;

	if (host->hw_ops.priv_size) {
		host->hw_priv = os_zalloc(host->hw_ops.priv_size);
		if (host->hw_priv == NULL) {
			os_printe(host->dev, "yusur rdma host init no mem");
			return -ENOMEM;
		}
	}

	ret = yusur_host_ops_verify(host);
	if (ret != 0) {
		os_printe(host->dev, "Host ops Verify failed");
		ret = -EINVAL;
		goto err;
	}

	host->hw_ops.global_reset(host);
	return 0;

err:
	if (host->hw_priv) {
		os_free(host->hw_priv);
		host->hw_priv = NULL;
	}
	return ret;
}

int yusur_hw_host_init(struct yib_hw_host *host)
{
	u8 mac[6];
	int i;
	int ret;

	ret = yusur_init_db_frag(host);
	if (ret) {
		os_printe(host->dev, "host init db frag failed:%d\n", ret);
		goto end;
	}

	ret = yusur_init_prio_array(host);
	if (ret) {
        os_printe(host->dev, "host init prio array failed:%d\n", ret);
        goto end;
    }

	for (i = 0; i < YIB_MAX_DEV_PORTS; i++) {
		if (host->net_dev[i] != NULL) {
			host->ndev_info[i].netdev = host->net_dev[i];
			host->ndev_info[i].link_down = 0;
			yusur_dev_update_mtu(host, host->net_dev[i], i + 1);
			host->ndev_info[i].port_id = i + 1;

			os_get_netdev_mac(host->net_dev[i], mac);
			yusur_hw_mactbl_add(host, mac, i + 1, 1);
		}
	}

end:
	if (ret != 0) {
		os_printe(host->dev, "uninit host for init failed:%d\n", ret);
		yusur_hw_host_uinit(host);
	}
	return ret;
}

u64 yusur_hw_get_bar_pa_by_off(struct yib_hw_host *hw, int bar_idx, u32 offset)
{
	u64 start_pa = os_get_pci_bar_start(hw->sf.pdev, bar_idx);
	u64 end_pa   = os_get_pci_bar_end(hw->sf.pdev, bar_idx) + hw->sf.bar_size[bar_idx];//所有sf bar_size一样

	if (start_pa + offset > end_pa)
		return 0;
	else
		return start_pa + offset;
}

u64 yusur_hw_get_bar_va_by_off(struct yib_hw_host *hw, int bar_idx, u32 offset)
{
	u64 start_va = (u64)(hw->sf.reg_base[bar_idx]);
	u64 end_va   = (u64)(hw->sf.reg_base[bar_idx] + hw->sf.bar_size[bar_idx]);//所有sf bar_size一样

	if (start_va + offset > end_va)
		return 0;
	else
		return start_va + offset;
}

u32 yib_get_rq_sw_idx(struct yib_rq *yrq)
{
	return yrq->entry.index;
}

u32 yib_get_cq_sw_idx(struct yib_cq *ycq)
{
	return ycq->entry.index;
}

//qpc_index is the index in ddr qpc table, entry_index is index of qp sw table
u32 yib_get_qp_sw_idx(struct yib_qp *yqp)
{
	return yqp->entry.index;
}

u32 yib_get_mr_sw_idx(struct yib_mr *ymr)
{
	return ymr->entry.index;
}

u32 yib_get_dscp_by_index(struct yib_hw_host *hw, u32 index)
{
	void *array_va = NULL;
	array_va = hw->prio_array.vaddr + index * sizeof(u32);
	return readl(array_va);
}

u32 yib_get_pcp_by_index(struct yib_hw_host *hw, u32 index)
{
	void *array_va = NULL;
	array_va = hw->prio_array.vaddr + YIB_DSCP_ARRAY_SIZE * sizeof(u32) + index * sizeof(u32);
	return readl(array_va);
}