#include "r2100_cfg.h"
#include "../../include/basic.h"
#include "../../include/os_api.h"
#include "../../include/os_ds.h"
#include "../../include/mem.h"
#include "../../include/queue.h"
#include "../../include/host.h"
#include "../../include/verbs.h"
#include "../../include/yusur_ib.h"
#include "../../include/user.h"
#include "../hostpriv.h"
#include "../hwcomn.h"
#include "rdma-header/include/yib_inc_hw.h"
#include "rdma-header/include/yib_inc_fw.h"
#include "rdma-header/include/yib_inc_base.h"
#include "r2100_sf.h"
#include "r2100_res.h"


void r2100_dbg_print_channel(struct yib_sf *sf)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_2100r_resource *hw_res = &r2100_sf->hw_res;

	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "######### channel dbg_print BEGIN #######\n");
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "qpc_ba = 0x%llx\n", hw_res->hwqueues.root_pa >> 12);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "qpc_indir_lvls = 0x%x\n", hw_res->hwqueues.levels);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "qpc_pbl_pg_size = 0x%x\n", 
					r2100_size_to_n(hw_res->hwqueues.pbl_pg_size));
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "qpc_pg_size = 0x%x\n", hw_res->hwqueues.pg_size);

	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "rpc_ba = 0x%llx\n", hw_res->rqcs.root_pa >> 12);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "rpc_indir_lvls = 0x%x\n", hw_res->rqcs.levels);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "rpc_pbl_pg_size = 0x%x\n", 
					r2100_size_to_n(hw_res->rqcs.pbl_pg_size));
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "rpc_pg_size = 0x%x\n", hw_res->rqcs.pg_size);

	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "cpc_ba = 0x%llx\n", hw_res->cqcs.root_pa >> 12);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "cpc_indir_lvls = 0x%x\n", hw_res->cqcs.levels);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "cpc_pbl_pg_size = 0x%x\n", 
					r2100_size_to_n(hw_res->cqcs.pbl_pg_size));
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "cpc_pg_size = 0x%x\n", hw_res->cqcs.pg_size);

	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "npc_ba = 0x%llx\n", hw_res->nqcs.root_pa >> 12);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "npc_indir_lvls = 0x%x\n", hw_res->nqcs.levels);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "npc_pbl_pg_size = 0x%x\n", 
					r2100_size_to_n(hw_res->nqcs.pbl_pg_size));
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "npc_pg_size = 0x%x\n", hw_res->nqcs.pg_size);

	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "mpt_ba = 0x%llx\n", hw_res->mpts.root_pa >> 12);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "mpt_indir_lvls = 0x%x\n", hw_res->mpts.levels);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "mpt_pbl_pg_size = 0x%x\n", 
					r2100_size_to_n(hw_res->mpts.pbl_pg_size));
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "mpt_pg_size = 0x%x\n", hw_res->mpts.pg_size);

	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "smac_ba = 0x%llx\n", hw_res->smacs.root_pa >> 12);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "smac_indir_lvls = 0x%x\n", hw_res->smacs.levels);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "smac_pbl_pg_size = 0x%x\n", 
					r2100_size_to_n(hw_res->smacs.pbl_pg_size));
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "smac_pg_size = 0x%x\n", hw_res->smacs.pg_size);

	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "sgid_ba = 0x%llx\n", hw_res->sgids.root_pa >> 12);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "sgid_indir_lvls = 0x%x\n", hw_res->sgids.levels);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "sgid_pbl_pg_size = 0x%x\n", 
					r2100_size_to_n(hw_res->sgids.pbl_pg_size));
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "sgid_pg_size = 0x%x\n", hw_res->sgids.pg_size);

	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "client_flow_num = 0x%x\n", hw_res->qp_cnt);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "server_flow_num = 0x%x\n", hw_res->qp_cnt);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "common_num = 0x%x\n", hw_res->qp_cnt);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "sqc_num = 0x%x\n", hw_res->qp_cnt);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "rqc_num = 0x%x\n", hw_res->rq_cnt);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "cqc_num = 0x%x\n", hw_res->cq_cnt);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "nqc_num = 0x%x\n", hw_res->nq_cnt);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "mpt_num = 0x%x\n", hw_res->mpt_cnt);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "smac_num = 0x%x\n", hw_res->smac_len);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "sgid_num = 0x%x\n", hw_res->sgid_len);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "msix_entry_idx = 0x%x\n", sf->irq_vector);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "port_id = 0x%x\n", R2100_CHANNEL_PORT_ID);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "host_id = 0x%x\n", R2100_CHANNEL_HOST_ID);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "bdf = 0x%x\n", R2100_CHANNEL_BDF);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "valid = 0x%x\n", R2100_CHANNEL_VALID);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "halt = 0x%x\n", R2100_CHANNEL_HALT);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "done = 0x%x\n", R2100_CHANNEL_DONE);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "######### channel dbg_print END #######\n");
}

void r2100_dbg_print_cflow(void *buf, bool bdebug)
{
	int i = 0;
	char buffer[128];
	int buf_pos = 0;
	int offset = 0;
	u8 *cflow = (u8 *)buf;
	int n = sizeof (struct yib_hw_cflow) / 4;

	if (bdebug) {
		pr_info("######### debugfs CLIENT FLOW print BEGIN #######\n");
	} else {
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_QUERY, "######### debugfs CLIENT FLOW print BEGIN #######\n");
	}
	for (i = 0; i < n; i++) {
		if (i % 4 == 0) {
			buf_pos = 0;
			memset(buffer, 0, sizeof(buffer));
			buf_pos = snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%04x:  ", offset);
			offset += 16;
		}
		buf_pos += snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%08x  ", yib_hwres_read32(cflow));
		cflow += 4;
		if ((i + 1) % 4 == 0) {
			if (bdebug) {
				pr_info("%s\n", buffer);
			} else {
				yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_QUERY, "%s\n", buffer);
			}
		}
	}
	if (bdebug) {
		pr_info("######### debugfs CLIENT FLOW print END #######\n");
	} else {
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_QUERY, "######### debugfs CLIENT FLOW print END #######\n");
	}
}

void r2100_dbg_print_sflow(void *buf, bool bdebug)
{
	int i = 0;
	char buffer[128];
	int buf_pos = 0;
	int offset = 0;
	u8 *sflow = (u8 *)buf;
	int n = sizeof (struct yib_hw_sflow) / 4;

	if (bdebug) {
		pr_info("######### debugfs SERVER FLOW print BEGIN #######\n");
	} else {
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_QUERY, "######### debugfs SERVER FLOW print BEGIN #######\n");
	}
	for (i = 0; i < n; i++) {
		if (i % 4 == 0) {
			buf_pos = 0;
			memset(buffer, 0, sizeof(buffer));
			buf_pos = snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%04x:  ", offset);
			offset += 16;
		}
		buf_pos += snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%08x  ", yib_hwres_read32(sflow));
		sflow += 4;
		if ((i + 1) % 4 == 0) {
			if (bdebug) {
				pr_info("%s\n", buffer);
			} else {
				yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_QUERY, "%s\n", buffer);
			}
		}
	}
	if (bdebug) {
		pr_info("######### debugfs SERVER FLOW print END #######\n");
	} else {
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_QUERY, "######### debugfs SERVER FLOW print END #######\n");
	}
}

void r2100_dbg_print_common_flow(void *buf, bool bdebug)
{
	int i = 0;
	char buffer[128];
	int buf_pos = 0;
	int offset = 0;
	u8 *qpc_entry = (u8 *)buf;
	int n = sizeof (struct yib_hw_qpc_entry) / 4;

	if (bdebug) {
		pr_info("######### debugfs COMMON FLOW print BEGIN #######\n");
	} else {
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_QUERY, "######### debugfs COMMON FLOW print BEGIN #######\n");
	}
	for (i = 0; i < n; i++) {
		if (i % 4 == 0) {
			buf_pos = 0;
			memset(buffer, 0, sizeof(buffer));
			buf_pos = snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%04x:  ", offset);
			offset += 16;
		}
		buf_pos += snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%08x  ", yib_hwres_read32(qpc_entry));
		qpc_entry += 4;
		if ((i + 1) % 4 == 0) {
			if (bdebug) {
				pr_info("%s\n", buffer);
			} else {
				yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_QUERY, "%s\n", buffer);
			}
		}
	}
	if (bdebug) {
		pr_info("######### debugfs COMMON FLOW print END #######\n");
	} else {
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_QUERY, "######### debugfs COMMON FLOW print END #######\n");
	}
}

void r2100_dbg_print_sqc(void *buf, bool bdebug)
{
	int i = 0;
	char buffer[128];
	int buf_pos = 0;
	int offset = 0;
	u8 *sqc_entry = (u8 *)buf;
	int n = sizeof (struct yib_hw_sqc_entry) / 4;

	if (bdebug) {
		pr_info("######### debugfs SQC print BEGIN #######\n");
	} else {
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_QUERY, "######### debugfs SQC print BEGIN #######\n");
	}
	for (i = 0; i < n; i++) {
		if (i % 4 == 0) {
			buf_pos = 0;
			memset(buffer, 0, sizeof(buffer));
			buf_pos = snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%04x:  ", offset);
			offset += 16;
		}
		buf_pos += snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%08x  ", yib_hwres_read32(sqc_entry));
		sqc_entry += 4;
		if ((i + 1) % 4 == 0) {
			if (bdebug) {
				pr_info("%s\n", buffer);
			} else {
				yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_QUERY, "%s\n", buffer);
			}
		}
	}
	if (bdebug) {
		pr_info("######### debugfs SQC print END #######\n");
	} else {
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_QUERY, "######### debugfs SQC print END #######\n");
	}
}

void r2100_debugfs_print_qpc(struct yib_sf *sf, struct yib_qp *yqp, bool bdbg)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_2100r_resource *hw_res = &r2100_sf->hw_res;
	struct yib_hw_cflow *cflow;
	struct yib_hw_sflow *sflow;
	struct yib_hw_qpc_entry *qpc_entry;
	struct yib_hw_sqc_entry *sqc_entry;
	u32 index = yib_get_qp_sw_idx(yqp);
	
	cflow = (struct yib_hw_cflow *)r2100_get_hwres_va(hw_res, index, R2100_TYPE_CLIENT_FLOW);
	sflow = (struct yib_hw_sflow *)r2100_get_hwres_va(hw_res, index, R2100_TYPE_SERVER_FLOW);
	qpc_entry = (struct yib_hw_qpc_entry *)r2100_get_hwres_va(hw_res, index, R2100_TYPE_QPC_COMMON);
	sqc_entry = (struct yib_hw_sqc_entry *)r2100_get_hwres_va(hw_res, index, R2100_TYPE_SQC);

	r2100_dbg_print_cflow(cflow, bdbg);
	r2100_dbg_print_sflow(sflow, bdbg);
	r2100_dbg_print_common_flow(qpc_entry, bdbg);
	r2100_dbg_print_sqc(sqc_entry, bdbg);
}

void r2100_debugfs_print_rqc(void *buf, bool bdebug)
{
	int i = 0;
	char buffer[128];
	int buf_pos = 0;
	int offset = 0;
	u8 *rqc_entry = (u8 *)buf;
	int n = sizeof (struct yib_hw_rqc_entry) / 4;

	if (bdebug) {
		pr_info("######### debugfs RQC print BEGIN #######\n");
	} else {
		yib_dbg_info(YUSUR_IB_M_RQ, YUSUR_IB_DBG_QUERY, "######### debugfs RQC print BEGIN #######\n");
	}
	for (i = 0; i < n; i++) {
		if (i % 4 == 0) {
			buf_pos = 0;
			memset(buffer, 0, sizeof(buffer));
			buf_pos = snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%04x:  ", offset);
			offset += 16;
		}
		buf_pos += snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%08x  ", yib_hwres_read32(rqc_entry));
		rqc_entry += 4;
		if ((i + 1) % 4 == 0) {
			if (bdebug) {
				pr_info("%s\n", buffer);
			} else {
				yib_dbg_info(YUSUR_IB_M_RQ, YUSUR_IB_DBG_QUERY, "%s\n", buffer);
			}
		}
	}
	if (bdebug) {
		pr_info("######### debugfs RQC print END #######\n");
	} else {
		yib_dbg_info(YUSUR_IB_M_RQ, YUSUR_IB_DBG_QUERY, "######### debugfs RQC print END #######\n");
	}
}

void r2100_debugfs_print_cqc(void *buf, bool bdebug)
{
	int i = 0;
	char buffer[128];
	int buf_pos = 0;
	int offset = 0;
	u8 *cqc_entry = (u8 *)buf;
	int n = sizeof (struct yib_hw_cqc_entry) / 4;

	if (bdebug) {
		pr_info("######### debugfs CQC print BEGIN #######\n");
	} else {
		yib_dbg_info(YUSUR_IB_M_CQ, YUSUR_IB_DBG_QUERY, "######### debugfs CQC print BEGIN #######\n");
	}
	for (i = 0; i < n; i++) {
		if (i % 4 == 0) {
			buf_pos = 0;
			memset(buffer, 0, sizeof(buffer));
			buf_pos = snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%04x:  ", offset);
			offset += 16;
		}
		buf_pos += snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%08x  ", yib_hwres_read32(cqc_entry));
		cqc_entry += 4;
		if ((i + 1) % 4 == 0) {
			if (bdebug) {
				pr_info("%s\n", buffer);
			} else {
				yib_dbg_info(YUSUR_IB_M_CQ, YUSUR_IB_DBG_QUERY, "%s\n", buffer);
			}
		}
	}
	if (bdebug) {
		pr_info("######### debugfs CQC print END #######\n");
	} else {
		yib_dbg_info(YUSUR_IB_M_CQ, YUSUR_IB_DBG_QUERY, "######### debugfs CQC print END #######\n");
	}
}

void r2100_debugfs_print_mpt(void *buf, bool bdebug)
{
	int i = 0;
	char buffer[128];
	int buf_pos = 0;
	int offset = 0;
	u8 *mpt_entry = (u8 *)buf;
	int n = sizeof (struct yib_hw_mpt_entry) / 4;

	if (bdebug) {
		pr_info("######### debugfs MPT print BEGIN #######\n");
	} else {
		yib_dbg_info(YUSUR_IB_M_MR, YUSUR_IB_DBG_QUERY, "######### debugfs MPT print BEGIN #######\n");
	}
	for (i = 0; i < n; i++) {
		if (i % 4 == 0) {
			buf_pos = 0;
			memset(buffer, 0, sizeof(buffer));
			buf_pos = snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%04x:  ", offset);
			offset += 16;
		}
		buf_pos += snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%08x  ", yib_hwres_read32(mpt_entry));
		mpt_entry += 4;
		if ((i + 1) % 4 == 0) {
			if (bdebug) {
				pr_info("%s\n", buffer);
			} else {
				yib_dbg_info(YUSUR_IB_M_MR, YUSUR_IB_DBG_QUERY, "%s\n", buffer);
			}
		}
	}
	if (bdebug) {
		pr_info("######### debugfs MPT print END #######\n");
	} else {
		yib_dbg_info(YUSUR_IB_M_MR, YUSUR_IB_DBG_QUERY, "######### debugfs MPT print END #######\n");
	}
}

void r2100_debugfs_print_nqc(void *buf, bool bdebug)
{
	int i = 0;
	char buffer[128];
	int buf_pos = 0;
	int offset = 0;
	u8 *nqc_entry = (u8 *)buf;
	int n = sizeof (struct yib_hw_nqc_entry) / 4;

	if (bdebug) {
		pr_info("######### debugfs NQC print BEGIN #######\n");
	} else {
		yib_dbg_info(YUSUR_IB_M_EQ, YUSUR_IB_DBG_QUERY, "######### debugfs NQC print BEGIN #######\n");
	}
	for (i = 0; i < n; i++) {
		if (i % 4 == 0) {
			buf_pos = 0;
			memset(buffer, 0, sizeof(buffer));
			buf_pos = snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%04x:  ", offset);
			offset += 16;
		}
		buf_pos += snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%08x  ", yib_hwres_read32(nqc_entry));
		nqc_entry += 4;
		if ((i + 1) % 4 == 0) {
			if (bdebug) {
				pr_info("%s\n", buffer);
			} else {
				yib_dbg_info(YUSUR_IB_M_EQ, YUSUR_IB_DBG_QUERY, "%s\n", buffer);
			}
		}
	}
	if (bdebug) {
		pr_info("######### debugfs NQC print END #######\n");
	} else {
		yib_dbg_info(YUSUR_IB_M_EQ, YUSUR_IB_DBG_QUERY, "######### debugfs NQC print END #######\n");
	}
}

void r2100_debugfs_print_channel(struct yib_sf *sf)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_2100r_resource *hw_res = &r2100_sf->hw_res;

	pr_info("######### debugfs channel print BEGIN #######\n");
	pr_info("qpc_ba = 0x%llx\n", hw_res->hwqueues.root_pa >> 12);
	pr_info("qpc_indir_lvls = 0x%x\n", hw_res->hwqueues.levels);
	pr_info("qpc_pbl_pg_size = 0x%x\n", r2100_size_to_n(hw_res->hwqueues.pbl_pg_size));
	pr_info("qpc_pg_size = 0x%x\n", hw_res->hwqueues.pg_size);

	pr_info("rpc_ba = 0x%llx\n", hw_res->rqcs.root_pa >> 12);
	pr_info("rpc_indir_lvls = 0x%x\n", hw_res->rqcs.levels);
	pr_info("rpc_pbl_pg_size = 0x%x\n", r2100_size_to_n(hw_res->rqcs.pbl_pg_size));
	pr_info("rpc_pg_size = 0x%x\n", hw_res->rqcs.pg_size);

	pr_info("cpc_ba = 0x%llx\n", hw_res->cqcs.root_pa >> 12);
	pr_info("cpc_indir_lvls = 0x%x\n", hw_res->cqcs.levels);
	pr_info("cpc_pbl_pg_size = 0x%x\n", r2100_size_to_n(hw_res->cqcs.pbl_pg_size));
	pr_info("cpc_pg_size = 0x%x\n", hw_res->cqcs.pg_size);

	pr_info("npc_ba = 0x%llx\n", hw_res->nqcs.root_pa >> 12);
	pr_info("npc_indir_lvls = 0x%x\n", hw_res->nqcs.levels);
	pr_info("npc_pbl_pg_size = 0x%x\n", r2100_size_to_n(hw_res->nqcs.pbl_pg_size));
	pr_info("npc_pg_size = 0x%x\n", hw_res->nqcs.pg_size);

	pr_info("mpt_ba = 0x%llx\n", hw_res->mpts.root_pa >> 12);
	pr_info("mpt_indir_lvls = 0x%x\n", hw_res->mpts.levels);
	pr_info("mpt_pbl_pg_size = 0x%x\n", r2100_size_to_n(hw_res->mpts.pbl_pg_size));
	pr_info("mpt_pg_size = 0x%x\n", hw_res->mpts.pg_size);

	pr_info("smac_ba = 0x%llx\n", hw_res->smacs.root_pa >> 12);
	pr_info("smac_indir_lvls = 0x%x\n", hw_res->smacs.levels);
	pr_info("smac_pbl_pg_size = 0x%x\n", r2100_size_to_n(hw_res->smacs.pbl_pg_size));
	pr_info("smac_pg_size = 0x%x\n", hw_res->smacs.pg_size);

	pr_info("sgid_ba = 0x%llx\n", hw_res->sgids.root_pa >> 12);
	pr_info("sgid_indir_lvls = 0x%x\n", hw_res->sgids.levels);
	pr_info("sgid_pbl_pg_size = 0x%x\n", r2100_size_to_n(hw_res->sgids.pbl_pg_size));
	pr_info("sgid_pg_size = 0x%x\n", hw_res->sgids.pg_size);

	pr_info("client_flow_num = 0x%x\n", hw_res->qp_cnt);
	pr_info("server_flow_num = 0x%x\n", hw_res->qp_cnt);
	pr_info("common_num = 0x%x\n", hw_res->qp_cnt);
	pr_info("sqc_num = 0x%x\n", hw_res->qp_cnt);
	pr_info("rqc_num = 0x%x\n", hw_res->rq_cnt);
	pr_info("cqc_num = 0x%x\n", hw_res->cq_cnt);
	pr_info("nqc_num = 0x%x\n", hw_res->nq_cnt);
	pr_info("mpt_num = 0x%x\n", hw_res->mpt_cnt);
	pr_info("smac_num = 0x%x\n", hw_res->smac_len);
	pr_info("sgid_num = 0x%x\n", hw_res->sgid_len);
	pr_info("msix_entry_idx = 0x%x\n", sf->irq_vector);
	pr_info("port_id = 0x%x\n", R2100_CHANNEL_PORT_ID);
	pr_info("host_id = 0x%x\n", R2100_CHANNEL_HOST_ID);
	pr_info("bdf = 0x%x\n", R2100_CHANNEL_BDF);
	pr_info("valid = 0x%x\n", R2100_CHANNEL_VALID);
	pr_info("halt = 0x%x\n", R2100_CHANNEL_HALT);
	pr_info("done = 0x%x\n", R2100_CHANNEL_DONE);
	pr_info("######### debugfs channel print END #######\n");
}

void r2100_debugfs_print_smac(struct yib_hw_host *hw)
{
	struct r2100_yib_sf *r2100_sf = hw->sf.sf_priv;
	struct yib_2100r_resource *hw_res = &r2100_sf->hw_res;
	u8 *smac;
	int i = 0;
	
	pr_info("######### debugfs smac print BEGIN #######\n");
	for (i = 0; i < hw_res->smac_len; i++) {
		smac = r2100_get_hwres_va(hw_res, i, R2100_TYPE_SMAC_TBL);
		pr_info("smac[%d]: %02x:%02x:%02x:%02x:%02x:%02x\n", i, smac[5], 
				smac[4], smac[3], smac[2], smac[1], smac[0]);	
	}
	pr_info("######### debugfs smac print END #######\n");
}

void r2100_debugfs_print_sgid(struct yib_hw_host *hw)
{
	struct r2100_yib_sf *r2100_sf = hw->sf.sf_priv;
	struct yib_2100r_resource *hw_res = &r2100_sf->hw_res;
	u8 *sgid;
	int i = 0;
	
	pr_info("######### debugfs sgid print BEGIN #######\n");
	for (i = 0; i < hw_res->sgid_len; i++) {
		sgid = r2100_get_hwres_va(hw_res, i, R2100_TYPE_SGID_TBL);
		pr_info("sgid[%d]: %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x\n", 
				i, sgid[0], sgid[1], sgid[2], sgid[3], sgid[4], sgid[5], sgid[6], sgid[7], sgid[8], sgid[9], 
				sgid[10], sgid[11], sgid[12], sgid[13], sgid[14], sgid[15]);
	}
	pr_info("######### debugfs sgid print END #######\n");
}

void r2100_debugfs_print_bar(void *buf, u32 size)
{
	int i = 0;
	char buffer[128];
	int buf_pos = 0;
	int offset = 0;
	u8 *dat = (u8 *)buf;

	pr_info("######### debugfs bar print BEGIN #######\n");
	for (i = 0; i < size / 4; i++) {
		if (i % 4 == 0) {
			buf_pos = 0;
			memset(buffer, 0, sizeof(buffer));
			buf_pos = snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%04x:  ", offset);
			offset += 16;
		}
		buf_pos += snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%08x  ", yib_hwres_read32(dat));
		dat += 4;
		if ((i + 1) % 4 == 0) {
			pr_info("%s\n", buffer);
		}
	}
	pr_info("######### debugfs bar print END #######\n");
}

void r2100_debugfs_print_mem(u64 addr, u32 len)
{
	int i = 0;
	char buffer[128];
	int buf_pos = 0;
	int offset = 0;
	u8 *dat = (u8 *)addr;

	pr_info("######### debugfs mem addr: 0x%llx len: 0x%x print BEGIN #######\n", addr, len);
	for (i = 0; i < len / 4; i++) {
		if (i % 4 == 0) {
			buf_pos = 0;
			memset(buffer, 0, sizeof(buffer));
			buf_pos = snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%04x:  ", offset);
			offset += 16;
		}
		buf_pos += snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%08x  ", yib_hwres_read32(dat));
		dat += 4;
		if ((i + 1) % 4 == 0) {
			pr_info("%s\n", buffer);
		}
	}
	pr_info("######### debugfs mem print END #######\n");
}

void r2100_dbg_print_fw_cmd(struct yib_fw_req *req)
{
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_FWCMD, "byte0 = 0x%x\n", req->byte0);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_FWCMD, "byte4 = 0x%x\n", req->byte4);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_FWCMD, "byte8 = 0x%x\n", req->byte8);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_FWCMD, "byte12 = 0x%x\n", req->byte12);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_FWCMD, "byte16 = 0x%x\n", req->byte16);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_FWCMD, "byte20 = 0x%x\n", req->byte20);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_FWCMD, "byte24 = 0x%x\n", req->byte24);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_FWCMD, "byte28 = 0x%x\n", req->byte28);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_FWCMD, "byte32 = 0x%x\n", req->byte32);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_FWCMD, "byte36 = 0x%x\n", req->byte36);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_FWCMD, "byte40 = 0x%x\n", req->byte40);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_FWCMD, "byte44 = 0x%x\n", req->byte44);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_FWCMD, "byte48 = 0x%x\n", req->byte48);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_FWCMD, "byte52 = 0x%x\n", req->byte52);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_FWCMD, "byte56 = 0x%x\n", req->byte56);
}


