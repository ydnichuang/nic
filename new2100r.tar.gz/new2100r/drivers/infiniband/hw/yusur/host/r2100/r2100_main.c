#include "r2100_cfg.h"
#include "../../include/basic.h"
#include "../../include/os_api.h"
#include "../../include/os_ds.h"
#include "../../include/mem.h"
#include "../../include/queue.h"
#include "../../include/host.h"
#include "../../include/verbs.h"
#include "../../include/yusur_ib.h"
#include "../../include/user.h"
#include "../hostpriv.h"
#include "../hwcomn.h"
#include "rdma-header/include/yib_inc_hw.h"
#include "rdma-header/include/yib_inc_fw.h"
#include "rdma-header/include/yib_inc_base.h"
#include "r2100_sf.h"
#include "r2100_host.h"
#include "r2100_io.h"
#include "r2100_eq.h"

static int r2100_user_def_hw_debugfs(struct yib_hw_host *hw, u8 *buf)
{
	return 0;
}

static int r2100_uio_post_send(struct yib_hw_host *hw, struct yib_qp *qp, const void* wr, bool db_only)
{
	return 0;
}

static int r2100_uio_post_recv(struct yib_hw_host *hw, struct yib_rq *rq, const void* wr, bool db_only)
{
	return 0;
}

static int r2100_uio_poll_cq(struct yib_hw_host *hw, struct yib_cq *cq, int num, void *wc, bool db_only)
{
	return 0;
}

static void r2100_init_av(struct yib_sf *sf, struct yib_av *av, int index, bool b_del)
{

}

struct yib_uio_ops r2100_uio_ops = {
	.uio_post_send = r2100_uio_post_send,
	.uio_post_recv = r2100_uio_post_recv,
	.uio_poll_cq = r2100_uio_poll_cq,
};

struct yib_queue_ops r2100_queue_ops = {
	.cqe_isize = 32,
	.fill_rqe = r2100_fill_rqe,
	.fill_srqe = r2100_fill_srqe,
	.fill_wqe = r2100_fill_wqe,
	.fill_cqe = r2100_fill_cqe,
	.sw_fill_cqe = r2100_sw_fill_cqe,

	.check_sq_full = r2100_check_sq_full,
	.check_rq_full = r2100_check_rq_full,
	.check_srq_full = r2100_check_srq_full,
	.check_cq_empty = r2100_check_cq_empty,

	.get_sq_item_size = r2100_get_sq_item_size,
	.get_rq_item_size = r2100_get_rq_item_size,

	.sq_pi_db_update = r2100_sq_pi_db_update,
	.rq_pi_db_update = r2100_rq_pi_db_update,
	.srq_pi_db_update = r2100_srq_pi_db_update,
	.cq_ci_db_update = r2100_cq_ci_db_update,
};

struct yib_eq_ops r2100_eq_ops = {
	.intr_enable = true,
	.priv_size = sizeof(r2100_eq_priv_t),
	.get_eq_intr_num = r2100_get_eq_intr_num,
	.eq_info_init = r2100_eq_info_init,
	.eq_debugfs = r2100_eq_debugfs,
	.check_eq_empty = r2100_check_eq_empty,
	.eq_sw_handler = r2100_eq_sw_handler,
	.eq_handler = r2100_eq_handler,
	.eq_ci_db_update = r2100_eq_ci_db_update,
};

struct yib_sf_ops r2100_sf_ops = {
	.host_type = YRDMA_TYPE_R2100,
	.priv_size = sizeof(struct r2100_yib_sf),

	.sf_pre_init = r2100_sf_pre_init,
	.sf_init = r2100_sf_init,

	.start_sf = r2100_start_sf,
	.stop_sf = r2100_stop_sf,

	//mac
	.add_mac = r2100_add_mac,
	.modify_mac = r2100_modify_mac,

	.set_gid = r2100_set_gid,

	//av
	.init_av = r2100_init_av,

	//mr
	.mrw_alloc = r2100_mrw_alloc,
	.mrw_destroy = r2100_mrw_destroy,
	.mr_mtt_init = r2100_mr_mtt_init,
	.mr_mpt_update = r2100_mr_mpt_update,
	.mr_debugfs = r2100_mr_debugfs,

	//cq
	.cq_info_init = r2100_cq_info_init,
	.cq_notify_update = r2100_cq_notify_update,
	.cq_debugfs = r2100_cq_debugfs,

	//qp
	.qp_info_init = r2100_qp_info_init,
	.qp_info_update = r2100_qp_info_update,
	.qp_query = r2100_qp_query,
	.qp_debugfs = r2100_qp_debugfs,

	//rq
	.rq_info_init = r2100_rq_info_init,
	.srq_debugfs = r2100_srq_debugfs,

	.sf_debugfs = r2100_sf_debugfs,
};

static const struct yib_hw_ops r2100_hwops = {
	.host_type = YRDMA_TYPE_R2100,
	.host_name = "R2100",
	.priv_size = sizeof(r2100_priv_t),

	.init_caps =  r2100_init_caps,
	.global_reset = r2100_global_reset,

	.start_host = r2100_start_host,
	.stop_host = r2100_stop_host,
	.shutdown_host = r2100_shutdown_host,

	.set_qos = r2100_set_qos,
	.set_rx_buf_size = r2100_set_rx_buf_size,
	.get_hw_counter = r2100_get_hw_counter,
	.host_reg_mmap = r2100_host_reg_mmap,
	.host_def_mmap = r2100_host_def_mmap,
	.get_counter_info = r2100_get_counter_info,

	.get_usable_channels = r2100_get_usable_channels,
	.get_queue_user_info = r2100_get_queue_user_info,
	.host_debugfs_reg = r2100_host_debugfs_reg,
	.host_debugfs_mem = r2100_host_debugfs_mem,
	.user_def_hw_debugfs = r2100_user_def_hw_debugfs,
	.smac_debugfs = r2100_smac_debugfs,
	.sgid_debugfs = r2100_sgid_debugfs,

	.sf_ops = &r2100_sf_ops,
	.eq_ops = &r2100_eq_ops,
	.queue_ops = &r2100_queue_ops,
	.uio_ops = &r2100_uio_ops,
};

const struct yib_hw_ops *r2100_get_host_ops(void)
{
	return &r2100_hwops;
}


