#ifndef _YUSUR_IB_R2100_EQ_H_
#define _YUSUR_IB_R2100_EQ_H_

typedef struct
{
	struct yib_queue_mem *queue;
	bool baeq;
}r2100_eq_priv_t;

int r2100_get_eq_intr_num(struct yib_sf *sf);
int r2100_eq_info_init(struct yib_sf *sf, struct yib_eq *eq, int depth, bool b_del);
bool r2100_check_eq_empty(struct yib_sf *sf, struct yib_eq *eq);
void r2100_eq_sw_handler(struct yib_sf *sf, struct yib_eq *eq, u8 *buf);
void r2100_eq_handler(struct yib_sf *sf, struct yib_eq *eq, struct yib_evts_occurs *evts_occurs);
void r2100_eq_ci_db_update(struct yib_sf *sf, struct yib_eq *eq, int io_cnt);
int r2100_eq_debugfs(struct yib_sf *sf, struct yib_eq *yeq);


#endif


