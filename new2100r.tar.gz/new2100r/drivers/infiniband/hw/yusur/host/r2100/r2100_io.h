#ifndef _YUSUR_IB_R2100_IO_H_
#define _YUSUR_IB_R2100_IO_H_

int r2100_get_sq_item_size(int *inline_len, int *max_sg, bool is_ud);
int r2100_get_rq_item_size(int *max_sg);
bool r2100_check_cq_empty(struct yib_hw_host *hw, struct yib_cq *ycq, u8 *cqe);
bool r2100_check_rq_full(struct yib_hw_host *hw, struct yib_rq *yrq);
bool r2100_check_srq_full(struct yib_hw_host *hw, struct yib_srq *ysrq, int *pos);
bool r2100_check_sq_full(struct yib_hw_host *hw, struct yib_sq *ysq);
void r2100_cq_ci_db_update(struct yib_hw_host *hw, struct yib_cq *cq, int poll_cnt);
void r2100_rq_pi_db_update(struct yib_hw_host *hw, struct yib_rq *rq, int io_cnt);
void r2100_srq_pi_db_update(struct yib_hw_host *hw, struct yib_srq *srq, int pos);
void r2100_sq_pi_db_update(struct yib_hw_host *hw, struct yib_qp *qp, int io_cnt);
void r2100_fill_cqe(struct yib_hw_host *hw, struct yib_cq *cq, struct yib_qp **qp_cache, void *os_cq, u8 *buf);
int r2100_sw_fill_cqe(struct yib_hw_host *hw, struct yib_cq *cq, void *os_cq);
int r2100_fill_rqe(struct yib_hw_host *hw, struct yib_rq *rq, const void *os_wq, u8 *buf, u32 length);
int r2100_fill_srqe(struct yib_hw_host *hw, struct yib_rq *rq, const void *os_wq, u8 *buf, u32 length, int pos);
int r2100_fill_wqe(struct yib_hw_host *hw, struct yib_qp *qp, const void *os_wq, u8 *buf, u32 length, u32 mask);






#endif


