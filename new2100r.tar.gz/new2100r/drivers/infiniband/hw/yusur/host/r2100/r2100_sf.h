#ifndef _YUSUR_IB_R2100_SF_H_
#define _YUSUR_IB_R2100_SF_H_



#define r2100_to_u64(a, b)	((u64)((a) | ((u64)(b) << 32)))

static inline int r2100_size_to_n(int size)
{
    int n = 0;
    size = size / 4096; // 除以4096，使得size变成2的n次方
    while (size > 1) {
        size >>= 1;
        n++;
    }
    return n;
}

struct yib_fw_req {
	__le32 byte0;
	__le32 byte4;
	__le32 byte8;
	__le32 byte12;
	__le32 byte16;
	__le32 byte20;
	__le32 byte24;
	__le32 byte28;
	__le32 byte32;
	__le32 byte36;
	__le32 byte40;
	__le32 byte44;
	__le32 byte48;
	__le32 byte52;
	__le32 byte56;
	__le32 byte60;
	os_cdma_t dma_buf; //用于内部命令的dma缓冲区
};
#define R2100_FW_REQ_SIZE 64  //sizeof(yib_fw_req)-sizeof(dma_buf)

struct r2100_fw
{
	struct yib_fw_req fw_req;
	os_cdma_t cplq;
	os_atomic ci;
};

typedef struct
{
	os_cdma_t bar;
}r2100_priv_t;

struct yib_2100r_resource {
	struct yib_page_tbl	hwqueues;
	struct yib_frag_buf	*hwqueues_dat;
	struct yib_page_tbl	rqcs;
	struct yib_frag_buf	*rqcs_dat;
	struct yib_page_tbl	cqcs;
	struct yib_frag_buf	*cqcs_dat;
	struct yib_page_tbl	nqcs;
	struct yib_frag_buf	*nqcs_dat;
	struct yib_page_tbl	smacs;
	struct yib_frag_buf	*smacs_dat;
	struct yib_page_tbl	sgids;
	struct yib_frag_buf	*sgids_dat;
	struct yib_page_tbl	mpts;
	struct yib_frag_buf	*mpts_dat;
	int qp_cnt;
	u32 qp_server_offset;
	u32 qp_common_offset;
	u32 sq_offset;
	int rq_cnt;
	int cq_cnt;
	int nq_cnt;
	int  mpt_cnt;
	int sgid_len;
	int smac_len;
};

struct r2100_yib_sf
{
	struct yib_2100r_resource hw_res;
	struct r2100_fw fw;
	u32 channel_id;
	u32 pci_info;
	bool started;
	os_mutex_t fw_mutex;
	os_atomic executing;
	struct cplq_entry  cmd_result;
	u64 counter_val[512];
	u64 get_couter_tick;
};

struct r2100_hwres_pa {
	u64 cflow_pa;
	u64 sflow_pa;
	u64 qpc_pa;
	u64 sqc_pa;
};

#define R2100_MAX_STATES		7
#define R2100_MAX_QP_TYPES		5

#define r2100_read_reg32(reg_base, offset) yib_read32(reg_base, offset)
#define r2100_read_reg64(reg_base, offset) yib_read64(reg_base, offset)

#if(!R2100_SW_DEBUG_ON)
#define r2100_write_reg32(reg_base, offset, val) yib_write32(reg_base, offset, val)
#define r2100_write_reg64(reg_base, offset, val) yib_write64(reg_base, offset, val)
#else
#define r2100_write_reg32(reg_base, offset, val) do {} while(0)
#define r2100_write_reg64(reg_base, offset, val) do {} while(0)
#endif

int r2100_sf_pre_init(struct yib_sf *sf);
int r2100_sf_init(struct yib_sf *sf, bool b_del);
int r2100_start_sf(struct yib_sf *sf);
void r2100_stop_sf(struct yib_sf *sf, bool is_shutdown);
void r2100_add_mac(struct yib_sf *sf, u8 *mac, int index, u8 port_num);
void r2100_modify_mac(struct yib_sf *sf, u8 *mac, int index, u8 port_num, bool bdel);
void r2100_set_gid(struct yib_sf *sf, bool brocev2, bool bipv4, int index, u8 *raw, bool bdel);
int r2100_mrw_alloc(struct yib_sf *sf, struct yib_mr *mr, u32 *lkey, u32 *rkey);
void r2100_mrw_destroy(struct yib_sf *sf, struct yib_mr *mr);
int r2100_mr_mtt_init(struct yib_sf *sf, struct yib_mr *mr, struct scatterlist *sg,
				int npages, u32 page_size, u64 pa0);
int r2100_mr_mpt_update(struct yib_sf *sf, struct yib_mr *ymr);
int r2100_mr_debugfs(struct yib_sf *sf, struct yib_mr *mr);
int r2100_cq_info_init(struct yib_sf *sf, struct yib_cq *cq, bool enable);
void r2100_cq_notify_update(struct yib_sf *sf, struct yib_cq *cq, u32 solicited_only);
int r2100_cq_debugfs(struct yib_sf *sf, struct yib_cq *ycq);
int r2100_rq_info_init(struct yib_sf *sf, struct yib_rq *yrq, bool enable, bool bsrq);
int r2100_srq_debugfs(struct yib_sf *sf, struct yib_srq *ysrq);
int r2100_qp_info_init(struct yib_sf *sf, struct yib_qp *yqp, bool enable);
bool r2100_qp_info_update(struct yib_sf *sf, struct yib_qp *qp, u32 mask, bool state_chg);
int r2100_qp_query(struct yib_sf *sf, struct yib_qp *qp, os_qp_attr *attr, int mask, bool bdebug);
int r2100_qp_debugfs(struct yib_sf *sf, struct yib_qp *qp);
void r2100_sf_debugfs(struct yib_sf *sf);
void r2100_fill_av(struct yib_hw_av *hw_av, struct yib_av *av);
u32 to_hw_mr_access(u32 flags);

#endif


