#ifndef _YUSUR_IB_R2100_FW_CMD_H_
#define _YUSUR_IB_R2100_FW_CMD_H_


int yib_fw_cmd_query_device(struct yib_sf *sf, struct r2100_fw *fw, struct yib_fw_roce_caps *caps);
int yib_fw_cmd_alloc_channel(struct yib_sf *sf, struct r2100_fw *fw);
int yib_fw_cmd_start_channel(struct yib_sf *sf, struct r2100_fw *fw);
int yib_fw_cmd_destroy_channel(struct yib_sf *sf, struct r2100_fw *fw);
int yib_fw_cmd_query_left_channels(struct yib_sf *sf, struct r2100_fw *fw);
int yib_fw_cmd_set_smac(struct yib_sf *sf, struct r2100_fw *fw, int index, u8 *mac);
int yib_fw_cmd_modify_smac(struct yib_sf *sf, struct r2100_fw *fw, int index, u8 *mac, bool bdel);
int yib_fw_cmd_add_sgid(struct yib_sf *sf, struct r2100_fw *fw, int index, u8 *raw, bool bipv4);
int yib_fw_cmd_del_sgid(struct yib_sf *sf, struct r2100_fw *fw, int index);
int yib_fw_cmd_reg_mr(struct yib_sf *sf, struct r2100_fw *fw, u32 index, u64 pa, bool bupdate);
int yib_fw_cmd_dereg_mr(struct yib_sf *sf, struct r2100_fw *fw, u32 index, u64 pa);
int yib_fw_cmd_query_mr(struct yib_sf *sf, struct r2100_fw *fw, u32 index, u64 pa);
int yib_fw_cmd_create_cq(struct yib_sf *sf, struct r2100_fw *fw, u32 index, u64 pa);
int yib_fw_cmd_query_cq(struct yib_sf *sf, struct r2100_fw *fw, u32 index, u64 pa);
int yib_fw_cmd_destroy_cq(struct yib_sf *sf, struct r2100_fw *fw, u32 index, u64 pa);
int yib_fw_cmd_create_rq(struct yib_sf *sf, struct r2100_fw *fw, u32 index, u64 pa, bool bsrq);
int yib_fw_cmd_query_rq(struct yib_sf *sf, struct r2100_fw *fw, u32 index, u64 pa);
int yib_fw_cmd_destroy_rq(struct yib_sf *sf, struct r2100_fw *fw, u32 index, u64 pa);
int yib_fw_cmd_create_qp(struct yib_sf *sf, struct r2100_fw *fw, u32 index, 
				u32 send_cqn, u32 recv_cqn, struct r2100_hwres_pa *hwres_pa);
int yib_fw_cmd_modify_qp(struct yib_sf *sf, struct r2100_fw *fw, u32 index, struct yib_fw_modify_qp_ctx *ctx);
int yib_fw_cmd_query_qp(struct yib_sf *sf, struct r2100_fw *fw, u32 index, 
				struct yib_fw_query_qp_ctx *ctx, bool bdebug);
int yib_fw_cmd_destroy_qp(struct yib_sf *sf, struct r2100_fw *fw, u32 index, 
				struct r2100_hwres_pa *hwres_pa);
int yib_fw_cmd_set_qos(struct yib_sf *sf, struct r2100_fw *fw, struct yib_rdma_qos_info *qos_info);
int yib_fw_cmd_update_ci(struct yib_sf *sf, struct r2100_fw *fw);
int yib_fw_cmd_get_stats(struct yib_sf *sf, struct r2100_fw *fw, u8 *buf, u32 *length);


#endif


