#ifndef __RDMA_HEADER_QEMU_H__
#define __RDMA_HEADER_QEMU_H__

#include <unistd.h>
#include <linux/types.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stddef.h>
#include <endian.h>

typedef unsigned char u8;
typedef unsigned int u32;

#define MAKE_WRITE(_NAME_, _SZ_)                                               \
	static inline void _NAME_##_be(void *addr, __be##_SZ_ value)           \
	{                                                                      \
		atomic_store_explicit((_Atomic(uint##_SZ_##_t) *)addr,         \
				      ( uint##_SZ_##_t)value,           \
				      memory_order_relaxed);                   \
	}                                                                      \
	static inline void _NAME_##_le(void *addr, __le##_SZ_ value)           \
	{                                                                      \
		atomic_store_explicit((_Atomic(uint##_SZ_##_t) *)addr,         \
				      ( uint##_SZ_##_t)value,           \
				      memory_order_relaxed);                   \
	}
#define MAKE_READ(_NAME_, _SZ_)                                                \
	static inline __be##_SZ_ _NAME_##_be(const void *addr)                 \
	{                                                                      \
		return ( __be##_SZ_)atomic_load_explicit(               \
		    (_Atomic(uint##_SZ_##_t) *)addr, memory_order_relaxed);    \
	}                                                                      \
	static inline __le##_SZ_ _NAME_##_le(const void *addr)                 \
	{                                                                      \
		return ( __le##_SZ_)atomic_load_explicit(               \
		    (_Atomic(uint##_SZ_##_t) *)addr, memory_order_relaxed);    \
	}

MAKE_WRITE(yib_mmio_write32, 32)
MAKE_READ(yib_mmio_read32, 32)

#undef MAKE_WRITE
#undef MAKE_READ

/* Now we can define the host endian versions of the operator, this just includes
   a call to htole.
*/
#define MAKE_WRITE(_NAME_, _SZ_)                                               \
	static inline void _NAME_(void *addr, uint##_SZ_##_t value)            \
	{                                                                      \
		_NAME_##_le(addr, htole##_SZ_(value));                         \
	}
#define MAKE_READ(_NAME_, _SZ_)                                                \
	static inline uint##_SZ_##_t _NAME_(const void *addr)                  \
	{                                                                      \
		return le##_SZ_##toh(_NAME_##_le(addr));                       \
	}

MAKE_WRITE(yib_mmio_write32, 32)
MAKE_READ(yib_mmio_read32, 32)

#undef MAKE_WRITE
#undef MAKE_READ

static inline void yib_writel(uint32_t val, volatile void* ptr) {
    yib_mmio_write32((void *)ptr, val);
}

static inline uint32_t yib_readl(const volatile void *ptr) {
    return yib_mmio_read32((const void *)ptr);
}

#endif // !__RDMA_HEADER_QEMU_H__


