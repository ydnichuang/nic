#include "r2100_cfg.h"
#include "../../include/basic.h"
#include "../../include/os_api.h"
#include "../../include/os_ds.h"
#include "../../include/mem.h"
#include "../../include/queue.h"
#include "../../include/host.h"
#include "../../include/verbs.h"
#include "../../include/yusur_ib.h"
#include "../../include/user.h"
#include "../hostpriv.h"
#include "../hwcomn.h"
#include "rdma-header/include/yib_inc_hw.h"
#include "rdma-header/include/yib_inc_fw.h"
#include "rdma-header/include/yib_inc_base.h"
#include "r2100_sf.h"
#include "r2100_res.h"



static int r2100_get_hwqueue_total_size(struct yib_roce_caps *caps)
{
	int size = 0, ret = 0;

	size = sizeof(struct yib_hw_cflow) * caps->num_qps;
	ret += os_align_up(size, 64);
	
	size = sizeof(struct yib_hw_sflow) * caps->num_qps;
	ret += os_align_up(size, 64);

	size = sizeof(struct yib_hw_qpc_entry) * caps->num_qps;
	ret += os_align_up(size, 64);

	size = sizeof(struct yib_hw_sqc_entry) * caps->num_qps;
	ret += os_align_up(size, 64);

	return ret;
}

static int r2100_hw_res_tbl_init(struct yib_sf *sf, struct yib_2100r_resource *hw_res)
{
	struct yib_roce_caps *caps = &sf->hw->caps;
	int ret = 0, size = 0;

	size = os_align_any_up(r2100_get_hwqueue_total_size(caps), PAGE_SIZE);

	hw_res->hwqueues_dat = yib_frag_buf_alloc_node(sf, size, true);	//对应cflow, sflow, common flow, sqc
	if (hw_res->hwqueues_dat == NULL) {
		os_printe(sf->hw->dev, "Failed to alloc hwqueues_dat res memory");
		goto err7;
	}

	ret = yib_create_page_table_by_frag(sf, &hw_res->hwqueues, hw_res->hwqueues_dat, 0);
	if (ret) {
		os_printe(sf->hw->dev, "Failed to alloc hwqueues tbl memory");
		goto err7;
	}

	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "hwqueues tbl levels: %d, page_size: %d, root_pa: 0x%08X, pbl_page_size: %d\n",
		hw_res->hwqueues.levels, hw_res->hwqueues.pg_size, hw_res->hwqueues.root_pa, hw_res->hwqueues.pbl_pg_size);

	size = yib_queue_get_page_cnt(sizeof(struct yib_hw_rqc_entry), caps->max_rqs) * PAGE_SIZE;

	hw_res->rqcs_dat = yib_frag_buf_alloc_node(sf, size, true);
	if (hw_res->rqcs_dat == NULL) {
		os_printe(sf->hw->dev, "Failed to alloc rqcs_dat res memory");
		goto err6;
	}

	ret = yib_create_page_table_by_frag(sf, &hw_res->rqcs, hw_res->rqcs_dat, 0);
	if (ret) {
		os_printe(sf->hw->dev, "Failed to alloc rqcs tbl memory");
		goto err6;
	}

	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "rqcs tbl levels: %d, page_size: %d, root_pa: 0x%08X, pbl_page_size: %d\n",
		hw_res->rqcs.levels, hw_res->rqcs.pg_size, hw_res->rqcs.root_pa, hw_res->rqcs.pbl_pg_size);

	size = yib_queue_get_page_cnt(sizeof(struct yib_hw_cqc_entry), caps->num_cqs) * PAGE_SIZE;

	hw_res->cqcs_dat = yib_frag_buf_alloc_node(sf, size, true);
	if (hw_res->cqcs_dat == NULL) {
		os_printe(sf->hw->dev, "Failed to alloc cqcs_dat res memory");
		goto err5;
	}

	ret = yib_create_page_table_by_frag(sf, &hw_res->cqcs, hw_res->cqcs_dat, 0);
	if (ret) {
		os_printe(sf->hw->dev, "Failed to alloc cqcs tbl memory");
		goto err5;
	}

	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "cqcs tbl levels: %d, page_size: %d, root_pa: 0x%08X, pbl_page_size: %d\n",
		hw_res->cqcs.levels, hw_res->cqcs.pg_size, hw_res->cqcs.root_pa, hw_res->cqcs.pbl_pg_size);

	size = yib_queue_get_page_cnt(sizeof(struct yib_hw_nqc_entry), caps->num_comp_vector) * PAGE_SIZE;

	hw_res->nqcs_dat = yib_frag_buf_alloc_node(sf, size, true);
	if (hw_res->nqcs_dat == NULL) {
		os_printe(sf->hw->dev, "Failed to alloc nqcs_dat res memory");
		goto err4;
	}

	ret = yib_create_page_table_by_frag(sf, &hw_res->nqcs, hw_res->nqcs_dat, 0);
	if (ret) {
		os_printe(sf->hw->dev, "Failed to alloc nqcs tbl memory");
		goto err4;
	}

	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "nqcs tbl levels: %d, page_size: %d, root_pa: 0x%08X, pbl_page_size: %d\n",
		hw_res->nqcs.levels, hw_res->nqcs.pg_size, hw_res->nqcs.root_pa, hw_res->nqcs.pbl_pg_size);

	size = yib_queue_get_page_cnt(sizeof(struct yib_hw_smac_entry), R2100_MAX_SMACS) * PAGE_SIZE;

	hw_res->smacs_dat = yib_frag_buf_alloc_node(sf, size, true);
	if (hw_res->smacs_dat == NULL) {
		os_printe(sf->hw->dev, "Failed to alloc smacs_dat res memory");
		goto err3;
	}

	ret = yib_create_page_table_by_frag(sf, &hw_res->smacs, hw_res->smacs_dat, 0);
	if (ret) {
		os_printe(sf->hw->dev, "Failed to alloc smacs tbl memory");
		goto err3;
	}

	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "smacs tbl levels: %d, page_size: %d, root_pa: 0x%08X, pbl_page_size: %d\n",
		hw_res->smacs.levels, hw_res->smacs.pg_size, hw_res->smacs.root_pa, hw_res->smacs.pbl_pg_size);

	size = yib_queue_get_page_cnt(sizeof(struct yib_hw_sgid_entry), R2100_MAX_SGIDS) * PAGE_SIZE;

	hw_res->sgids_dat = yib_frag_buf_alloc_node(sf, size, true);
	if (hw_res->sgids_dat == NULL) {
		os_printe(sf->hw->dev, "Failed to alloc sgids_dat res memory");
		goto err2;
	}

	ret = yib_create_page_table_by_frag(sf, &hw_res->sgids, hw_res->sgids_dat, 0);
	if (ret) {
		os_printe(sf->hw->dev, "Failed to alloc sgids tbl memory");
		goto err2;
	}

	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "sgids tbl levels: %d, page_size: %d, root_pa: 0x%08X, pbl_page_size: %d\n",
		hw_res->sgids.levels, hw_res->sgids.pg_size, hw_res->sgids.root_pa, hw_res->sgids.pbl_pg_size);

	size = yib_queue_get_page_cnt(sizeof(struct yib_hw_mpt_entry), caps->max_mr) * PAGE_SIZE;

	hw_res->mpts_dat = yib_frag_buf_alloc_node(sf, size, true);
	if (hw_res->mpts_dat == NULL) {
		os_printe(sf->hw->dev, "Failed to alloc mpts_dat res memory");
		goto err1;
	}

	ret = yib_create_page_table_by_frag(sf, &hw_res->mpts, hw_res->mpts_dat, 0);
	if (ret) {
		os_printe(sf->hw->dev, "Failed to alloc mpts tbl memory");
		goto err1;
	}

	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "mpts tbl levels: %d, page_size: %d, root_pa: 0x%08X, pbl_page_size: %d\n",
		hw_res->mpts.levels, hw_res->mpts.pg_size, hw_res->mpts.root_pa, hw_res->mpts.pbl_pg_size);
	
	return 0;

err1:
	yib_destroy_page_table(sf, &hw_res->mpts);
	if (hw_res->mpts_dat) {
		yib_frag_free_node(sf, hw_res->mpts_dat);
		hw_res->mpts_dat = NULL;
	}

err2:
	yib_destroy_page_table(sf, &hw_res->sgids);
	if (hw_res->sgids_dat) {
		yib_frag_free_node(sf, hw_res->sgids_dat);
		hw_res->sgids_dat = NULL;
	}

err3:
	yib_destroy_page_table(sf, &hw_res->smacs);
	if (hw_res->smacs_dat) {
		yib_frag_free_node(sf, hw_res->smacs_dat);
		hw_res->smacs_dat = NULL;
	}

err4:
	yib_destroy_page_table(sf, &hw_res->nqcs);
	if (hw_res->nqcs_dat) {
		yib_frag_free_node(sf, hw_res->nqcs_dat);
		hw_res->nqcs_dat = NULL;
	}

err5:
	yib_destroy_page_table(sf, &hw_res->cqcs);
	if (hw_res->cqcs_dat) {
		yib_frag_free_node(sf, hw_res->cqcs_dat);
		hw_res->cqcs_dat = NULL;
	}

err6:
	yib_destroy_page_table(sf, &hw_res->rqcs);
	if (hw_res->rqcs_dat) {
		yib_frag_free_node(sf, hw_res->rqcs_dat);
		hw_res->rqcs_dat = NULL;
	}

err7:
	yib_destroy_page_table(sf, &hw_res->hwqueues);
	if (hw_res->hwqueues_dat) {
		yib_frag_free_node(sf, hw_res->hwqueues_dat);
		hw_res->hwqueues_dat = NULL;
	}

	return -ENOMEM;
}

int r2100_hw_res_init(struct yib_sf *sf, struct yib_2100r_resource *hw_res)
{
	struct yib_roce_caps *caps = &sf->hw->caps;
	int ret = 0, size = 0;

	memset(hw_res, 0, sizeof(*hw_res));

	ret = r2100_hw_res_tbl_init(sf, hw_res);//cflow,sflow,qpc,sqc都是64字节，如果后续硬件变更，可能需要调整。
	if (ret) {
		os_printe(sf->hw->dev, "res tbl init failed");
		return -ENOMEM;
	}

	hw_res->qp_cnt = caps->num_qps;
	hw_res->rq_cnt = caps->max_rqs;
	hw_res->cq_cnt = caps->num_cqs;
	hw_res->nq_cnt = caps->num_comp_vector;
	hw_res->mpt_cnt = caps->max_mr;
	hw_res->sgid_len = R2100_MAX_SGIDS;
	hw_res->smac_len = R2100_MAX_SMACS;

	size = os_align_up(hw_res->qp_cnt * sizeof(struct yib_hw_cflow), 64);
	hw_res->qp_server_offset = size;
	
	size = os_align_up(hw_res->qp_cnt * sizeof(struct yib_hw_sflow), 64);
	hw_res->qp_common_offset = hw_res->qp_server_offset + size;

	size = os_align_up(hw_res->qp_cnt * sizeof(struct yib_hw_qpc_entry), 64);
	hw_res->sq_offset = hw_res->qp_common_offset + size;

	return 0;
}

void r2100_hw_res_exit(struct yib_sf *sf, struct yib_2100r_resource *hw_res)
{
	yib_destroy_page_table(sf, &hw_res->mpts);
	if (hw_res->mpts_dat) {
		yib_frag_free_node(sf, hw_res->mpts_dat);
		hw_res->mpts_dat = NULL;
	}

	yib_destroy_page_table(sf, &hw_res->sgids);
	if (hw_res->sgids_dat) {
		yib_frag_free_node(sf, hw_res->sgids_dat);
		hw_res->sgids_dat = NULL;
	}

	yib_destroy_page_table(sf, &hw_res->smacs);
	if (hw_res->smacs_dat) {
		yib_frag_free_node(sf, hw_res->smacs_dat);
		hw_res->smacs_dat = NULL;
	}

	yib_destroy_page_table(sf, &hw_res->nqcs);
	if (hw_res->nqcs_dat) {
		yib_frag_free_node(sf, hw_res->nqcs_dat);
		hw_res->nqcs_dat = NULL;
	}

	yib_destroy_page_table(sf, &hw_res->cqcs);
	if (hw_res->cqcs_dat) {
		yib_frag_free_node(sf, hw_res->cqcs_dat);
		hw_res->cqcs_dat = NULL;
	}

	yib_destroy_page_table(sf, &hw_res->rqcs);
	if (hw_res->rqcs_dat) {
		yib_frag_free_node(sf, hw_res->rqcs_dat);
		hw_res->rqcs_dat = NULL;
	}

	yib_destroy_page_table(sf, &hw_res->hwqueues);
	if (hw_res->hwqueues_dat) {
		yib_frag_free_node(sf, hw_res->hwqueues_dat);
		hw_res->hwqueues_dat = NULL;
	}
}

void *r2100_get_hwres_va(struct yib_2100r_resource *hwres, int index, int type)
{
	void *va = NULL;
	u32 offset = 0;
	
	switch (type) {
		case R2100_TYPE_CLIENT_FLOW:
			va = yib_frag_get_vaddr(hwres->hwqueues_dat, sizeof(struct yib_hw_cflow), index);
			return va;
		case R2100_TYPE_SERVER_FLOW:
			offset = hwres->qp_server_offset;
			va = yib_frag_get_vaddr_with_offset(hwres->hwqueues_dat, sizeof(struct yib_hw_sflow), index, offset);
			return va;
		case R2100_TYPE_QPC_COMMON:
			offset = hwres->qp_common_offset;
			va = yib_frag_get_vaddr_with_offset(hwres->hwqueues_dat, sizeof(struct yib_hw_qpc_entry), index, offset);
			return va;
		case R2100_TYPE_SQC:
			offset = hwres->sq_offset;
			va = yib_frag_get_vaddr_with_offset(hwres->hwqueues_dat, sizeof(struct yib_hw_sqc_entry), index, offset);
			return va;
		case R2100_TYPE_RQC:
			va = yib_frag_get_vaddr(hwres->rqcs_dat, sizeof(struct yib_hw_rqc_entry), index);
			return va;
		case R2100_TYPE_CQC:
			va = yib_frag_get_vaddr(hwres->cqcs_dat, sizeof(struct yib_hw_cqc_entry), index);
			return va;
		case R2100_TYPE_NQC:
			va = yib_frag_get_vaddr(hwres->nqcs_dat, sizeof(struct yib_hw_nqc_entry), index);
			return va;
		case R2100_TYPE_SGID_TBL:
			va = yib_frag_get_vaddr(hwres->sgids_dat, sizeof(struct yib_hw_sgid_entry), index);
			return va;
		case R2100_TYPE_SMAC_TBL:
			va = yib_frag_get_vaddr(hwres->smacs_dat, sizeof(struct yib_hw_smac_entry), index);
			return va;
		case R2100_TYPE_MPT:
			va = yib_frag_get_vaddr(hwres->mpts_dat, sizeof(struct yib_hw_mpt_entry), index);
			return va;

		default:
			return NULL;
	}
}

u64 r2100_get_hwres_pa(struct yib_2100r_resource *hwres, int index, int type)
{
	u64 pa = 0;
	u32 offset = 0;
	
	switch (type) {
		case R2100_TYPE_CLIENT_FLOW:
			pa = yib_frag_get_paddr(hwres->hwqueues_dat, sizeof(struct yib_hw_cflow), index);
			return pa;
		case R2100_TYPE_SERVER_FLOW:
			offset = hwres->qp_server_offset;
			pa = yib_frag_get_paddr_with_offset(hwres->hwqueues_dat, sizeof(struct yib_hw_sflow), index, offset);
			return pa;
		case R2100_TYPE_QPC_COMMON:
			offset = hwres->qp_common_offset;
			pa = yib_frag_get_paddr_with_offset(hwres->hwqueues_dat, sizeof(struct yib_hw_qpc_entry), index, offset);
			return pa;
		case R2100_TYPE_SQC:
			offset = hwres->sq_offset;
			pa = yib_frag_get_paddr_with_offset(hwres->hwqueues_dat, sizeof(struct yib_hw_sqc_entry), index, offset);
			return pa;
		case R2100_TYPE_RQC:
			pa = yib_frag_get_paddr(hwres->rqcs_dat, sizeof(struct yib_hw_rqc_entry), index);
			return pa;
		case R2100_TYPE_CQC:
			pa = yib_frag_get_paddr(hwres->cqcs_dat, sizeof(struct yib_hw_cqc_entry), index);
			return pa;
		case R2100_TYPE_NQC:
			pa = yib_frag_get_paddr(hwres->nqcs_dat, sizeof(struct yib_hw_nqc_entry), index);
			return pa;
		case R2100_TYPE_SGID_TBL:
			pa = yib_frag_get_paddr(hwres->sgids_dat, sizeof(struct yib_hw_sgid_entry), index);
			return pa;
		case R2100_TYPE_SMAC_TBL:
			pa = yib_frag_get_paddr(hwres->smacs_dat, sizeof(struct yib_hw_smac_entry), index);
			return pa;
		case R2100_TYPE_MPT:
			pa = yib_frag_get_paddr(hwres->mpts_dat, sizeof(struct yib_hw_mpt_entry), index);
			return pa;

		default:
			break;
	}
	return 0;
}


