#include "r2100_cfg.h"
#include "../../include/basic.h"
#include "../../include/os_api.h"
#include "../../include/os_ds.h"
#include "../../include/mem.h"
#include "../../include/queue.h"
#include "../../include/host.h"
#include "../../include/verbs.h"
#include "../../include/yusur_ib.h"
#include "../../include/user.h"
#include "../hostpriv.h"
#include "../hwcomn.h"
#include "rdma-header/include/yib_inc_hw.h"
#include "rdma-header/include/yib_inc_fw.h"
#include "rdma-header/include/yib_inc_base.h"
#include "../../linux/priv.h"
#include "r2100_sf.h"



static enum yib_wqe_type to_hw_wr_opcode(enum ib_wr_opcode opcode)
{
	switch (opcode) {
		case IB_WR_SEND:			
			return YIB_WQE_SEND;
		case IB_WR_SEND_WITH_IMM:		
			return YIB_WQE_SEND_WITH_IMM;
		case IB_WR_SEND_WITH_INV:
			return YIB_WQE_SEND_WITH_INV;
		case IB_WR_RDMA_WRITE:		
			return YIB_WQE_RDMA_WRITE;
		case IB_WR_RDMA_WRITE_WITH_IMM:			
			return YIB_WQE_RDMA_WRITE_WITH_IMM;
		case IB_WR_RDMA_READ:			
			return YIB_WQE_READ;
		case IB_WR_ATOMIC_CMP_AND_SWP:			
			return YIB_WQE_ATOMIC_CAS;
		case IB_WR_ATOMIC_FETCH_AND_ADD:			
			return YIB_WQE_ATOMIC_FETCH_ADD;
		case IB_WR_LOCAL_INV:			
			return YIB_WQE_LOCAL_INV;
		case IB_WR_REG_MR:			
			return YIB_WQE_FR_PMR;
#ifdef IB_HAS_BIND_MW
		case IB_WR_BIND_MW:			
			return YIB_WQE_MEM_BIND;
#endif

		default:
			return 0xff;
	}
}

int r2100_get_sq_item_size(int *inline_len, int *max_sg, bool is_ud)
{
	int isize = 0;
	int input = max(*inline_len, *max_sg * 16);
	int len = 0, sg_num = 0;
	if (is_ud) {
		if (input <= 16) {
			isize = 64;
			len = 16;
		} else if (input > 16 && input <= 80) {
			isize = 128;
			len = 80;
		} else if (input > 80) {
			isize = 256;
			len = 208;
		}
		sg_num = len / 16;
	} else {
		if (input <= 32) {
			isize = 64;
			len = 32;
		} else if (input > 32 && input <= 96) {
			isize = 128;
			len = 96;
		} else if (input > 96) {
			isize = 256;
			len = 224;
		}
		sg_num = len / 16;
	}

	*inline_len = len;
	*max_sg = sg_num;
	return isize;
}

int r2100_get_rq_item_size(int *max_sg)
{	
	*max_sg = 3;	
	return 64;
}

void r2100_set_mr_state(struct yib_hw_host *hw, struct yib_hw_cqe *cqe, enum yib_mr_state state)
{
	struct yib_mr *ymr;
	
	if (hw->chip_subtype == YRDMA_SUB_R2100_HADEP_1)
		return;
	ymr = (struct yib_mr *)r2100_to_u64(yib_hwres_read(cqe, YIB_CQE_MR_HANDLE_LSB), 
					yib_hwres_read(cqe, YIB_CQE_MR_HANDLE_MSB));
	if (!ymr->type.is_user) {
		ymr->state = state;
	}
}

bool r2100_check_cq_empty(struct yib_hw_host *hw, struct yib_cq *ycq, u8 *cqe)
{
	struct yusur_ib_dev *yib = to_yib(ycq->ib_cq.device);
	struct yib_hw_cqe *hw_cqe = (struct yib_hw_cqe *)cqe;
	u32 toggle;
	u32 ci_toggle;
	u32 cqe_type;
	u64 handle;
	u32 handle_lsb;
	u64 handle_msb;
	u32 index;
	int ret = 0;
	struct yib_qp *yqp;

	ci_toggle = ycq->queue->info->ci_toggle;
	toggle = yib_hwres_read(hw_cqe, YIB_CQE_TOGGLE);
	if (toggle == ci_toggle)
		return true;

	cqe_type = yib_hwres_read(hw_cqe, YIB_CQE_CQE_TYPE);
	handle_lsb = yib_hwres_read(hw_cqe, YIB_CQE_QP_HANDLE_LSB);
	handle_msb = yib_hwres_read(hw_cqe, YIB_CQE_QP_HANDLE_MSB);
	handle = handle_lsb | (handle_msb << 32);
	index = yib_hwres_read(hw_cqe, YIB_CQE_WQE_IDX);
	yqp = (struct yib_qp *)handle;

	// yib_dbg_info(YUSUR_IB_M_CQ, YUSUR_IB_DBG_POLL, 
	// 	"check_cq_empty: toggle=%d handle=0x%llx cqe=%llx cqe_type=%d ci=%d index=%d\n", 
	// 	toggle, handle, (u64)cqe, cqe_type, os_atomic_read(&ycq->queue->info->ci), index);
	if (cqe_type == YIB_CQE_SQ) {
		ret = yib_sq_check_cqe(yib, yqp, index, false);
	} else if (cqe_type == YIB_CQE_RQ) {
		ret = yib_rq_check_hwcqe(yib, yqp->type.yrq, index);
	}
	if(ret)
		return true;

	return false;
}

bool r2100_check_rq_full(struct yib_hw_host *hw, struct yib_rq *yrq)
{
	struct yib_queue_info *info = yrq->queue->info;
	u32 pi, ci, pi_toggle, ci_toggle;

	pi = os_atomic_read(&info->pi);
	ci = os_atomic_read(&info->ci);
	pi_toggle = info->pi_toggle;
	ci_toggle = info->ci_toggle;

	return (pi == ci) && (pi_toggle != ci_toggle);
}

bool r2100_check_srq_full(struct yib_hw_host *hw, struct yib_srq *ysrq, int *pos)
{
	int ret = 0;
	ret = yib_srq_find_useable_pos(ysrq);
	if (ret == -ENOMEM)
		return true;

	*pos = ret;
	return false;
}

bool r2100_check_sq_full(struct yib_hw_host *hw, struct yib_sq *ysq)
{
	struct yib_queue_info *info = ysq->queue->info;
	u32 pi, ci, pi_toggle, ci_toggle;

	pi = os_atomic_read(&info->pi);
	ci = os_atomic_read(&info->ci);
	pi_toggle = info->pi_toggle;
	ci_toggle = info->ci_toggle;

	return (pi == ci) && (pi_toggle != ci_toggle);
}

void r2100_cq_ci_db_update(struct yib_hw_host *hw, struct yib_cq *cq, int poll_cnt)
{
	struct yib_queue_info *info = cq->queue->info;
	u64 val = 0;
	u32 val_lsb;
	u64 val_msb;
	u32 cq_idx;
	u16 index, epoch, resize_toggle;
	u16 path, valid, debug_trace, type;
	
	index = os_atomic_read(&info->ci) & 0xFFFF;
	epoch = info->ci_toggle & 0x01;
	resize_toggle = 0;
	cq_idx = cq->entry.index;
	path = 0;
	valid =0;
	debug_trace = 0;
	type = YIB_DB_CQ;

	val_lsb = index | (epoch << 16) | (resize_toggle << 17);
	val_msb = cq_idx | (path << 23) | (valid << 25) | (debug_trace << 26) | (type << 27);
	val = val_lsb | (val_msb << 32);
	yib_dbg_info(YUSUR_IB_M_CQ, YUSUR_IB_DBG_DB, "cq db: cqn=%d ci=0x%x epoch=%d\n", cq_idx, index, epoch);
	r2100_write_reg64(hw->sf.reg_base[0], R2100_DB64_REG, val);
}

void r2100_rq_pi_db_update(struct yib_hw_host *hw, struct yib_rq *rq, int io_cnt)
{
	struct yib_queue_info *info = rq->queue->info;
	u64 val = 0;
	u32 val_lsb;
	u64 val_msb;
	u32 index;
	u16 epoch, resize_toggle;
	u16 path, valid, debug_trace, type;
	
	index = os_atomic_read(&info->pi) & 0xFFFF;
	epoch = info->pi_toggle & 0x01;
	resize_toggle = 0;
	path = 0;
	valid =0;
	debug_trace = 0;
	type = YIB_DB_RQ;

	val_lsb = index | (epoch << 16) | (resize_toggle << 17);
	val_msb = rq->entry.index | (path << 23) | (valid << 25) | (debug_trace << 26) | (type << 27);
	val = val_lsb | (val_msb << 32);
	yib_dbg_info(YUSUR_IB_M_RQ, YUSUR_IB_DBG_DB, "rq db: rqn=%d pi=0x%x epoch=%d\n", rq->entry.index, index, epoch);
	r2100_write_reg64(hw->sf.reg_base[0], R2100_DB64_REG, val);
}

void r2100_srq_pi_db_update(struct yib_hw_host *hw, struct yib_srq *srq, int pos)
{
	bool bdb = false;
	u64 val = 0;
	u32 val_lsb;
	u64 val_msb;
	u32 index;
	u16 epoch, resize_toggle;
	u16 path, valid, debug_trace, type;
	u16 srq_toggle;

	bdb = yib_srq_db_helper(srq, pos);
	if (!bdb)
		return;
	
	index = queue_index_inc(pos, srq->yrq->queue->depth);

	srq_toggle = srq->toggle? 1: 0;
	epoch = srq_toggle & 0x01;
	resize_toggle = 0;
	path = 0;
	valid =0;
	debug_trace = 0;
	type = YIB_DB_SRQ;

	val_lsb = index | (epoch << 16) | (resize_toggle << 17);
	val_msb = srq->yrq->entry.index | (path << 23) | (valid << 25) | (debug_trace << 26) | (type << 27);
	val = val_lsb | (val_msb << 32);
	yib_dbg_info(YUSUR_IB_M_RQ, YUSUR_IB_DBG_DB, "srq db: index=%d epoch=%d\n", index, epoch);
	r2100_write_reg64(hw->sf.reg_base[0], R2100_DB64_REG, val);
}

void r2100_sq_pi_db_update(struct yib_hw_host *hw, struct yib_qp *qp, int io_cnt)
{
	struct yib_queue_info *info = qp->ysq.queue->info;
	u64 val = 0;
	u32 val_lsb;
	u64 val_msb;
	u32 index;
	u16 epoch, resize_toggle;
	u16 path, valid, debug_trace, type;
	
	index = os_atomic_read(&info->pi) & 0xFFFF;
	epoch = info->pi_toggle & 0x01;
	resize_toggle = 0;
	path = 0;
	valid =0;
	debug_trace = 0;
	type = YIB_DB_SQ;

	val_lsb = index | (epoch << 16) | (resize_toggle << 17);
	val_msb = qp->entry.index | (path << 23) | (valid << 25) | (debug_trace << 26) | (type << 27);
	val = val_lsb | (val_msb << 32);
	yib_dbg_info(YUSUR_IB_M_SQ, YUSUR_IB_DBG_DB, "sq db: qpn=%d pi=0x%x epoch=%d\n", qp->entry.index, index, epoch);
	r2100_write_reg64(hw->sf.reg_base[0], R2100_DB64_REG, val);
}

void r2100_fill_cqe(struct yib_hw_host *hw, struct yib_cq *cq, struct yib_qp **qp_cache, void *os_cq, u8 *buf)
{
	struct yusur_ib_dev *yib = to_yib(cq->ib_cq.device);
	struct yib_hw_cqe *cqe = (struct yib_hw_cqe *)buf;
	os_ib_wc *wc = os_cq;
	struct yib_qp *yqp = NULL;
	struct yib_rq *yrq = NULL;
	u32 opcode;
	u32 immdata_or_invkey;
	u32 cqe_type;
	u64 handle;
	u32 handle_lsb;
	u64 handle_msb;
	int qid = 0;
	u32 wqe_idx;
	u8 network_type;
	
	opcode = yib_hwres_read(cqe, YIB_CQE_OPCODE);
	immdata_or_invkey = yib_hwres_read(cqe, YIB_CQE_IMMDATA_OR_INVKEY);
	cqe_type = yib_hwres_read(cqe, YIB_CQE_CQE_TYPE);
	handle_lsb = yib_hwres_read(cqe, YIB_CQE_QP_HANDLE_LSB);
	handle_msb = yib_hwres_read(cqe, YIB_CQE_QP_HANDLE_MSB);
	handle = handle_lsb | (handle_msb << 32);
	wqe_idx = yib_hwres_read(cqe, YIB_CQE_WQE_IDX);
	network_type = yib_hwres_read(cqe, YIB_CQE_NETWORK_TYPE);
	
    wc->wc_flags = 0;
	wc->byte_len = yib_hwres_read(cqe, YIB_CQE_BYTE_LEN);
	wc->status = yib_hwres_read(cqe, YIB_CQE_STATUS);
    switch (opcode) {
            case YIB_WQE_RDMA_WRITE:
                    wc->opcode = IB_WC_RDMA_WRITE;
                    break;
            case YIB_WQE_RDMA_WRITE_WITH_IMM:
                    wc->opcode = IB_WC_RDMA_WRITE;
                    wc->ex.imm_data = immdata_or_invkey;//字节序toverify
                    wc->wc_flags |= IB_WC_WITH_IMM;
                    break;
            case YIB_WQE_SEND:
					if (cqe_type == YIB_CQE_SQ) {
                    	wc->opcode = IB_WC_SEND;
					} else {
						wc->opcode = IB_WC_RECV;				
					}
                    break;
            case YIB_WQE_SEND_WITH_IMM:
					if (cqe_type == YIB_CQE_SQ) {
	                    wc->opcode = IB_WC_SEND;
	                    wc->ex.imm_data = immdata_or_invkey;//字节序toverify
	                    wc->wc_flags |= IB_WC_WITH_IMM;
					} else {
						wc->opcode = IB_WC_RECV_RDMA_WITH_IMM;
	                    wc->ex.imm_data = immdata_or_invkey;//字节序toverify
	                    wc->wc_flags |= IB_WC_WITH_IMM;
					}
                    break;
            case YIB_WQE_SEND_WITH_INV:
					if (cqe_type == YIB_CQE_SQ) {
	                    wc->opcode = IB_WC_SEND;
	                    wc->ex.invalidate_rkey = immdata_or_invkey;
	                    wc->wc_flags |= IB_WC_WITH_INVALIDATE;
					} else {
						wc->opcode = IB_WC_RECV;
	                    wc->ex.invalidate_rkey = immdata_or_invkey;
	                    wc->wc_flags |= IB_WC_WITH_INVALIDATE;
					}
                    break;
            case YIB_WQE_READ:
                    wc->opcode = IB_WC_RDMA_READ;
                    break;
            case YIB_WQE_LOCAL_INV:
                    wc->opcode = IB_WC_LOCAL_INV;
					r2100_set_mr_state(hw, cqe, YIB_MR_FREE);
					break;
            case YIB_WQE_FR_PMR:
                    wc->opcode = IB_WC_REG_MR;
					r2100_set_mr_state(hw, cqe, YIB_MR_VALID);
					break;
			case YIB_WQE_ATOMIC_FETCH_ADD:
                    wc->opcode = IB_WC_FETCH_ADD;
					break;
			case YIB_WQE_ATOMIC_CAS:
                    wc->opcode = IB_WC_COMP_SWAP;
					break;
            default:
                    yib_pr_warn("unknow opcode");
                    break;
    }

	if (wc->opcode == IB_WC_RECV) {
		if (network_type == 0) {
			wc->network_hdr_type = RDMA_NETWORK_IPV4;
		} else if (network_type == 1) {
			wc->network_hdr_type = RDMA_NETWORK_IPV6;
		}
		wc->wc_flags |= IB_WC_WITH_NETWORK_HDR_TYPE;
	}
	yib_dbg_info(YUSUR_IB_M_CQ, YUSUR_IB_DBG_POLL, 
		"fill_cqe: byte_len=%d opcode=%d wc->opcode=%d cqe_type=%d handle=0x%llx wqe_idx=%d status=%d\n", 
		wc->byte_len, opcode, wc->opcode, cqe_type, handle, wqe_idx, wc->status);
	yqp = (struct yib_qp *)handle;
	if (yqp)
		qid = yqp->entry.index;
	if (yqp == NULL || qid >= hw->caps.num_qps) {
		yib_dbg_err("can't find qp id=%d\n", qid);
		wc->qp = NULL;
		wc->status = IB_WC_BAD_RESP_ERR;
		goto end;
	}
	wc->qp = yib_os_qp(yqp);
	if (yqp->qp_type == IB_QPT_UD || yqp->qp_type == IB_QPT_GSI) {
		    wc->pkey_index = 0;
		    wc->src_qp = yib_hwres_read(cqe, YIB_CQE_SRC_QPN);
		    wc->wc_flags |= IB_WC_GRH; 
    }
	if (cqe_type == YIB_CQE_SQ) {
		wc->wr_id = yqp->ysq.sw_cmds[wqe_idx].wrid;
    	yib_sq_swcmd_done(yib, yqp, wqe_idx, 0);
	} else if (cqe_type == YIB_CQE_RQ) {
		yrq = yqp->type.yrq;
		if (yrq == NULL) {
			yib_dbg_err("yrq is NULL\n");
			wc->status = IB_WC_BAD_RESP_ERR;
			goto end;
		}
		wc->wr_id = yrq->sw_cmds[wqe_idx].wrid;
    	yib_rq_swcmd_done(yib, yrq, wqe_idx);
	} else if (cqe_type == YIB_CQE_SRQ) {
		struct yib_srq *ysrq = NULL;
		ysrq = yqp->type.ysrq;
		if (ysrq == NULL) {
			yib_dbg_err("ysrq is NULL\n");
			wc->status = IB_WC_BAD_RESP_ERR;
			goto end;
		}
		yrq = ysrq->yrq;
		wc->wr_id = yrq->sw_cmds[wqe_idx].wrid;
    	yib_srq_swcmd_done(yib, ysrq, wqe_idx);
	}
end:
	return;	
}

int r2100_sw_fill_cqe(struct yib_hw_host *hw, struct yib_cq *cq, void *os_cq)
{
	struct yusur_ib_dev *yib = to_yib(cq->ib_cq.device);
	struct yib_sw_cqe *cqe = cq->cur_sw_cqe;
	os_ib_wc *wc = os_cq;
	struct yib_qp *yqp = NULL;
	bool bsw = false;
	int ret = 0;
	u32 cqe_type = cqe->type;
	u64 handle = cqe->handler;
	u32 index = cqe->start_pos;

	yqp = (struct yib_qp *)handle;
	if (yqp == NULL) {
		yib_dbg_err("yqp is NULL\n");
		wc->status = IB_WC_BAD_RESP_ERR;
		return -EINVAL;
	}

	wc->status = cqe->status;
	wc->qp = yib_os_qp(yqp);
	
	if (cqe_type == YIB_CQE_SQ) {
		ret = yib_sq_check_cqe(yib, yqp, index, true);
		if (ret)
			return ret;
		if(yqp->ysq.sw_posted[index] == 0) {
			wc->opcode = yqp->ysq.sw_cmds[index].opcode;
			wc->wr_id = yqp->ysq.sw_cmds[index].wrid;
		} else {
			wc->opcode = cqe->sw_opcode;
			wc->wr_id = cqe->sw_wr_id;
			bsw = true;
		}
		yib_sq_swcmd_done(yib, yqp, index, bsw);
	} else if (cqe_type == YIB_CQE_RQ) {
		struct yib_rq *yrq = yqp->type.yrq;
		wc->opcode = yrq->sw_cmds[index].opcode;
		wc->wr_id = yrq->sw_cmds[index].wrid;
		yib_rq_swcmd_done(yib, yrq, index);
	} else if (cqe_type == YIB_CQE_SRQ) {
		struct yib_srq *ysrq = yqp->type.ysrq;
		wc->opcode = ysrq->yrq->sw_cmds[index].opcode;
		wc->wr_id = ysrq->yrq->sw_cmds[index].wrid;
		yib_srq_swcmd_done(yib, ysrq, index);
	}
	
	return 0;
}

int r2100_fill_rqe(struct yib_hw_host *hw, struct yib_rq *rq, const void *os_wq, u8 *buf, u32 length)
{
	os_ib_recv_wr *wr = (os_ib_recv_wr *)os_wq;
	u8 *dst_buf = buf + sizeof(struct yib_hw_rq_wqe);
	struct yib_hw_rq_wqe * rqe = (struct yib_hw_rq_wqe *)buf;	
	int i = 0;
	int size = 0;

	size = wr->num_sge * sizeof(struct yib_hw_sge) + sizeof(struct yib_hw_rq_wqe);
	memset(rqe, 0, size);
	yib_hwres_write(rqe, YIB_RQ_WQE_TYPE, YIB_WQE_RECV);
	yib_hwres_write(rqe, YIB_RQ_WQE_RQE_INDEX, os_atomic_read(&rq->queue->info->pi) & 0x7FFFFFFF);
	yib_hwres_write(rqe, YIB_RQ_WQE_LENGTH, length);
	yib_hwres_write(rqe, YIB_RQ_WQE_SIZE, size / 16);
	
	for (i = 0; i < wr->num_sge; i++) {
		yib_hwres_write32(dst_buf, u64_lsb(wr->sg_list[i].addr));
		dst_buf += 4;
		yib_hwres_write32(dst_buf, u64_msb(wr->sg_list[i].addr));
		dst_buf += 4;
		yib_hwres_write32(dst_buf, wr->sg_list[i].lkey);
		dst_buf += 4;
		yib_hwres_write32(dst_buf, wr->sg_list[i].length);
		dst_buf += 4;
	}

	return 0;
}

int r2100_fill_srqe(struct yib_hw_host *hw, struct yib_rq *rq, const void *os_wq, u8 *buf, u32 length, int pos)
{
	os_ib_recv_wr *wr = (os_ib_recv_wr *)os_wq;
	u8 *dst_buf = buf + sizeof(struct yib_hw_rq_wqe);
	struct yib_hw_rq_wqe * rqe = (struct yib_hw_rq_wqe *)buf;	
	int i = 0;
	int size = 0;

	size = wr->num_sge * sizeof(struct yib_hw_sge) + sizeof(struct yib_hw_rq_wqe);
	memset(rqe, 0, size);
	yib_hwres_write(rqe, YIB_RQ_WQE_TYPE, YIB_WQE_RECV);
	yib_hwres_write(rqe, YIB_RQ_WQE_RQE_INDEX, pos & 0x7FFFFFFF);
	yib_hwres_write(rqe, YIB_RQ_WQE_LENGTH, length);
	yib_hwres_write(rqe, YIB_RQ_WQE_SIZE, size / 16);
	
	for (i = 0; i < wr->num_sge; i++) {
		yib_hwres_write32(dst_buf, u64_lsb(wr->sg_list[i].addr));
		dst_buf += 4;
		yib_hwres_write32(dst_buf, u64_msb(wr->sg_list[i].addr));
		dst_buf += 4;
		yib_hwres_write32(dst_buf, wr->sg_list[i].lkey);
		dst_buf += 4;
		yib_hwres_write32(dst_buf, wr->sg_list[i].length);
		dst_buf += 4;
	}

	return 0;
}

static int r2100_fill_ud_wqe(struct yib_hw_host *hw, struct yib_qp *qp, const void *os_wq, u8 *buf, 
				u32 length, u32 mask, enum yib_wqe_type opcode)
{
	u8 *dst_buf = buf + sizeof(struct yib_hw_ud_wqe);
	struct yib_hw_ud_wqe *ud_wqe =(struct yib_hw_ud_wqe *)buf;
	struct ib_ud_wr *ud_wr = (struct ib_ud_wr *)os_wq;
	struct yib_hw_av *hw_av = &ud_wqe->av;
	struct yib_ah *ah = to_yib_ah(ud_wr->ah);
	u8 signal_comp = 0;
	u8 se_flag = 0;
	u8 inline_flag = 0;
	u32 imm_data = 0;
	int i = 0;

	if ((ud_wr->wr.send_flags & IB_SEND_SIGNALED) || (qp->sq_sig_type == IB_SIGNAL_ALL_WR))
		signal_comp = 1;
			
	if (ud_wr->wr.send_flags & IB_SEND_SOLICITED)
		se_flag = 1;
	
	if (ud_wr->wr.send_flags & IB_SEND_INLINE) {
		inline_flag = 1;
	}

	if (opcode == YIB_WQE_SEND_WITH_IMM || opcode == YIB_WQE_RDMA_WRITE_WITH_IMM)
		imm_data = ud_wr->wr.ex.imm_data;//字节序toverify
	
	memset(ud_wqe, 0, sizeof(struct yib_hw_ud_wqe));
	yib_hwres_write(ud_wqe, YIB_UD_WQE_TYPE, opcode);
	yib_hwres_write(ud_wqe, YIB_UD_WQE_SIGNAL_COMP, signal_comp);
	yib_hwres_write(ud_wqe, YIB_UD_WQE_SE_FLAG, se_flag);
	yib_hwres_write(ud_wqe, YIB_UD_WQE_INLINE_FLAG, inline_flag);
	
	yib_hwres_write(ud_wqe, YIB_UD_WQE_DEST_QPN, ud_wr->remote_qpn);
	yib_hwres_write(ud_wqe, YIB_UD_WQE_LENGTH, length);
	yib_hwres_write(ud_wqe, YIB_UD_WQE_IMM_DATA, imm_data);
	yib_hwres_write(ud_wqe, YIB_UD_WQE_Q_KEY, ud_wr->remote_qkey);

	r2100_fill_av(hw_av, &ah->av);

	if (ud_wr->wr.send_flags & IB_SEND_INLINE) {
		yib_hwres_write(ud_wqe, YIB_UD_WQE_SIZE,
			(length + 15 + sizeof(struct yib_hw_ud_wqe)) / 16);	
		for (i = 0; i < ud_wr->wr.num_sge; i++) {
			memcpy(dst_buf, (u8 *)ud_wr->wr.sg_list[i].addr, ud_wr->wr.sg_list[i].length);
			dst_buf += ud_wr->wr.sg_list[i].length;
		}
	} else {
		yib_hwres_write(ud_wqe, YIB_UD_WQE_SIZE, (ud_wr->wr.num_sge * sizeof(struct yib_hw_sge) + 
				sizeof(struct yib_hw_ud_wqe)) / 16);
		for (i = 0; i < ud_wr->wr.num_sge; i++) {
			yib_hwres_write32(dst_buf, u64_lsb(ud_wr->wr.sg_list[i].addr));
			dst_buf += 4;
			yib_hwres_write32(dst_buf, u64_msb(ud_wr->wr.sg_list[i].addr));
			dst_buf += 4;
			yib_hwres_write32(dst_buf, ud_wr->wr.sg_list[i].lkey);
			dst_buf += 4;
			yib_hwres_write32(dst_buf, ud_wr->wr.sg_list[i].length);
			dst_buf += 4;
		}
	}
	return 0;
}

static int r2100_fill_fmr_bind(struct yib_hw_host *hw, struct yib_qp *qp, const void *os_wq, u8 *buf, 
				u32 length, u32 mask, enum yib_wqe_type opcode)
{
	struct yib_hw_fmr_bind *fmr_bind =(struct yib_hw_fmr_bind *)buf;
	os_ib_send_wr *wr = (os_ib_send_wr *)os_wq;
	u8 signal_comp = 0;

	if (opcode == YIB_WQE_MEM_BIND) 
		return -EINVAL;

	if ((wr->send_flags & IB_SEND_SIGNALED) || (qp->sq_sig_type == IB_SIGNAL_ALL_WR))
    	signal_comp = 1;

	memset(fmr_bind, 0, sizeof(struct yib_hw_fmr_bind));
	yib_hwres_write(fmr_bind, YIB_FMR_BIND_WQE_TYPE, opcode);
	yib_hwres_write(fmr_bind, YIB_FMR_BIND_SIGNAL_COMP, signal_comp);
	yib_hwres_write(fmr_bind, YIB_FMR_BIND_UC_FENCE_FLAG, 1);
	yib_hwres_write(fmr_bind, YIB_FMR_BIND_WQE_SIZE, 64 / 16);
	
	if (opcode == YIB_WQE_FR_PMR) {
		struct ib_reg_wr *wr = (struct ib_reg_wr *)os_wq;
		struct yib_mr *ymr = to_yib_mr(wr->mr);
		u64 pa1, pbl_ba;
		u64 *descs;
		if (!ymr->type.is_fast) {
			return -EINVAL;
		}
		descs = (u64 *)ymr->priv.fmr->descs;
		pa1 = descs[1];
		pa1 = pa1 >> 12;
		pbl_ba = ymr->priv.fmr->desc_map;
		pbl_ba = pbl_ba >> 12;
		yib_hwres_write(fmr_bind, YIB_FMR_BIND_ACCESS_RIGHT, to_hw_mr_access(wr->access) | R2100_ACCESS_INVALID);
		yib_hwres_write(fmr_bind, YIB_FMR_BIND_PA0_LSB, u64_lsb(ymr->priv.fmr->pa));
		yib_hwres_write(fmr_bind, YIB_FMR_BIND_PA0_MSB, u64_msb(ymr->priv.fmr->pa));
		yib_hwres_write(fmr_bind, YIB_FMR_BIND_PA1_LSB, u64_lsb(pa1));
		yib_hwres_write(fmr_bind, YIB_FMR_BIND_PA1_MSB, u64_msb(pa1));
		yib_hwres_write(fmr_bind, YIB_FMR_BIND_VA_LSB, u64_lsb(wr->mr->iova));
		yib_hwres_write(fmr_bind, YIB_FMR_BIND_VA_MSB, u64_msb(wr->mr->iova));
		yib_hwres_write(fmr_bind, YIB_FMR_BIND_SIZE_LSB, u64_lsb(wr->mr->length));
		yib_hwres_write(fmr_bind, YIB_FMR_BIND_SIZE_MSB, u64_msb(wr->mr->length));
		yib_hwres_write(fmr_bind, YIB_FMR_BIND_KEY, wr->key);
		yib_hwres_write(fmr_bind, YIB_FMR_BIND_STATE, R2100_MR_VALID);
		yib_hwres_write(fmr_bind, YIB_FMR_BIND_PBL_BA_LSB, u64_lsb(pbl_ba));
		yib_hwres_write(fmr_bind, YIB_FMR_BIND_PBL_BA_MSB, u64_msb(pbl_ba));
	} else if (opcode == YIB_WQE_LOCAL_INV) {
		os_ib_send_wr *wr = (os_ib_send_wr *)os_wq;
		yib_hwres_write(fmr_bind, YIB_FMR_BIND_STATE, R2100_MR_FREE);
		yib_hwres_write(fmr_bind, YIB_FMR_BIND_KEY, wr->ex.invalidate_rkey);
	}
	return 0;
}

static void r2100_fill_atomic(const void *os_wq, u8 *buf, enum yib_wqe_type opcode)
{
	struct ib_atomic_wr *atomic_wr = (struct ib_atomic_wr *)os_wq;
	struct yib_hw_rc_wqe *wqe = (struct yib_hw_rc_wqe *)buf;

	yib_hwres_write(wqe, YIB_RC_WQE_REMOTE_VA_LSB, u64_lsb(atomic_wr->remote_addr));
	yib_hwres_write(wqe, YIB_RC_WQE_REMOTE_VA_MSB, u64_msb(atomic_wr->remote_addr));
	yib_hwres_write(wqe, YIB_RC_WQE_REMOTE_KEY, atomic_wr->rkey);

	if (opcode == YIB_WQE_ATOMIC_CAS) {
		yib_hwres_write(wqe, YIB_RC_WQE_COM_DATA_LSB, u64_lsb(atomic_wr->compare_add));
		yib_hwres_write(wqe, YIB_RC_WQE_COM_DATA_MSB, u64_msb(atomic_wr->compare_add));
		yib_hwres_write(wqe, YIB_RC_WQE_LENGTH_OR_SWAP_DATA_OR_ADD_DATA, u64_lsb(atomic_wr->swap));
		yib_hwres_write(wqe, YIB_RC_WQE_INVKEY_OR_IMMDATA_OR_SWAP_DATA_OR_ADD_DATA, u64_msb(atomic_wr->swap));
	} else if (opcode == YIB_WQE_ATOMIC_FETCH_ADD) {
		yib_hwres_write(wqe, YIB_RC_WQE_LENGTH_OR_SWAP_DATA_OR_ADD_DATA, u64_lsb(atomic_wr->compare_add));
		yib_hwres_write(wqe, YIB_RC_WQE_INVKEY_OR_IMMDATA_OR_SWAP_DATA_OR_ADD_DATA, u64_msb(atomic_wr->compare_add));
	}
}

static int r2100_fill_rc_wqe(struct yib_hw_host *hw, struct yib_qp *qp, const void *os_wq, u8 *buf, 
				u32 length, u32 mask, enum yib_wqe_type opcode)
{
	u8 *dst_buf = buf + sizeof(struct yib_hw_rc_wqe);
	struct yib_hw_rc_wqe *wqe = (struct yib_hw_rc_wqe *)buf;
	os_ib_send_wr *wr = (os_ib_send_wr *)os_wq;
	int i = 0;
	u8 signal_comp = 0;
	u8 rd_or_atomic_fence_flag = 0;
	u8 se_flag = 0;
	u8 inline_flag = 0;

	if ((wr->send_flags & IB_SEND_SIGNALED) || (qp->sq_sig_type == IB_SIGNAL_ALL_WR))
    	signal_comp = 1;
        
    if (wr->send_flags & IB_SEND_SOLICITED)
		se_flag = 1;
    
    if (wr->send_flags & IB_SEND_FENCE)
		rd_or_atomic_fence_flag = 1;

	if (wr->send_flags & IB_SEND_INLINE) {
		inline_flag = 1;
	}

	memset(wqe, 0, sizeof(struct yib_hw_rc_wqe));
	yib_hwres_write(wqe, YIB_RC_WQE_TYPE, opcode);
	yib_hwres_write(wqe, YIB_RC_WQE_SIGNAL_COMP, signal_comp);
	yib_hwres_write(wqe, YIB_RC_WQE_RD_OR_ATOMIC_FENCE_FLAG, rd_or_atomic_fence_flag);
	yib_hwres_write(wqe, YIB_RC_WQE_SE_FLAG, se_flag);
	yib_hwres_write(wqe, YIB_RC_WQE_INLINE_FLAG, inline_flag);

	if (mask & WR_READ_OR_WRITE_MASK) {
	    const struct ib_rdma_wr *rdma = rdma_wr((os_ib_send_wr*)os_wq);
		yib_hwres_write(wqe, YIB_RC_WQE_REMOTE_VA_LSB, u64_lsb(rdma->remote_addr));
		yib_hwres_write(wqe, YIB_RC_WQE_REMOTE_VA_MSB, u64_msb(rdma->remote_addr));
		yib_hwres_write(wqe, YIB_RC_WQE_REMOTE_KEY, rdma->rkey);
	}

	if (mask & WR_ATOMIC_MASK) {
		yib_hwres_write(wqe, YIB_RC_WQE_WQE_SIZE, sizeof(struct yib_hw_rc_wqe) / 16);
		r2100_fill_atomic(os_wq, buf, opcode);
	} else {
		yib_hwres_write(wqe, YIB_RC_WQE_LENGTH_OR_SWAP_DATA_OR_ADD_DATA, length);
		if (opcode == YIB_WQE_SEND_WITH_IMM || opcode == YIB_WQE_RDMA_WRITE_WITH_IMM) {
			yib_hwres_write(wqe, YIB_RC_WQE_INVKEY_OR_IMMDATA_OR_SWAP_DATA_OR_ADD_DATA, wr->ex.imm_data);//toverify
		} else if (opcode == YIB_WQE_SEND_WITH_INV) {
			yib_hwres_write(wqe, YIB_RC_WQE_INVKEY_OR_IMMDATA_OR_SWAP_DATA_OR_ADD_DATA, wr->ex.invalidate_rkey);
		}
	}
	
	if (wr->send_flags & IB_SEND_INLINE) {
		yib_hwres_write(wqe, YIB_RC_WQE_WQE_SIZE,
			(length + 15 + sizeof(struct yib_hw_rc_wqe)) / 16);
		for (i = 0; i < wr->num_sge; i++) {
			memcpy(dst_buf, (u8 *)wr->sg_list[i].addr, wr->sg_list[i].length);
			dst_buf += wr->sg_list[i].length;
		}
	} else {
		yib_hwres_write(wqe, YIB_RC_WQE_WQE_SIZE,
			(wr->num_sge * sizeof(struct yib_hw_sge) + sizeof(struct yib_hw_rc_wqe)) / 16);
		for (i = 0; i < wr->num_sge; i++) {
			yib_hwres_write32(dst_buf, u64_lsb(wr->sg_list[i].addr));
			dst_buf += 4;
			yib_hwres_write32(dst_buf, u64_msb(wr->sg_list[i].addr));
			dst_buf += 4;
			yib_hwres_write32(dst_buf, wr->sg_list[i].lkey);
			dst_buf += 4;
			yib_hwres_write32(dst_buf, wr->sg_list[i].length);
			dst_buf += 4;
		}
	}

	
	return 0;
}

int r2100_fill_wqe(struct yib_hw_host *hw, struct yib_qp *qp, const void *os_wq, u8 *buf, u32 length, u32 mask)
{
	os_ib_send_wr *wr = (os_ib_send_wr *)os_wq;
	u32 opcode = to_hw_wr_opcode(wr->opcode);
	int ret = 0;

	if (qp->qp_type == IB_QPT_UD || qp->qp_type == IB_QPT_GSI) {
		ret = r2100_fill_ud_wqe(hw, qp, os_wq, buf, length, mask, opcode);
	} else if (opcode == YIB_WQE_MEM_BIND || opcode == YIB_WQE_FR_PMR || opcode == YIB_WQE_LOCAL_INV) {
		ret = r2100_fill_fmr_bind(hw, qp, os_wq, buf, length, mask, opcode);
	} else if (qp->qp_type == IB_QPT_RC) {
		ret = r2100_fill_rc_wqe(hw, qp, os_wq, buf, length, mask, opcode);
	} else {
		os_printe(hw->dev, "fill wqe with unsupported qp type: %d\n", qp->qp_type);
	}
	
	return ret;
}











