#ifndef _YUSUR_IB_R2100_RES_H_
#define _YUSUR_IB_R2100_RES_H_

enum r2100_hwres_type
{
	R2100_TYPE_CLIENT_FLOW,
	R2100_TYPE_SERVER_FLOW,
	R2100_TYPE_QPC_COMMON,
	R2100_TYPE_SQC,
	R2100_TYPE_RQC,
	R2100_TYPE_CQC,
	R2100_TYPE_NQC,
	R2100_TYPE_SGID_TBL,
	R2100_TYPE_SMAC_TBL,
	R2100_TYPE_MPT,
};


int r2100_hw_res_init(struct yib_sf *sf, struct yib_2100r_resource *hw_res);
void r2100_hw_res_exit(struct yib_sf *sf, struct yib_2100r_resource *hw_res);
void *r2100_get_hwres_va(struct yib_2100r_resource *hwres, int index, int type);
u64 r2100_get_hwres_pa(struct yib_2100r_resource *hwres, int index, int type);


#endif


