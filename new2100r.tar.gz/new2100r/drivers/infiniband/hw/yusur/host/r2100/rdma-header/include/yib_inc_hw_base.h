#ifndef _YIB_INC_HW_BASE_H
#define _YIB_INC_HW_BASE_H


enum r2100_hw_mr_type {
	R2100_HW_MR_NORMAL = 0,
	R2100_HW_MR_PMR,
	R2100_HW_MR_MW_TYPE1,
	R2100_HW_MR_MW_TYPE2A,
	R2100_HW_MR_GLOBAL_KEY,
};

enum r2100_serv_type {
    R2100_QPT_RC = 0,
    R2100_QPT_UD,
    R2100_QPT_XRC,
    R2100_QPT_RAWETH,
    R2100_QPT_QP1,
};

enum r2100_wqe_size_limit {
	R2100_WQE_SIZE_LIMIT_64 = 0,
	R2100_WQE_SIZE_LIMIT_128,
	R2100_WQE_SIZE_LIMIT_256,
	R2100_WQE_SIZE_LIMIT_512,
};

enum r2100_mr_access {
	R2100_ACCESS_REMOTE_READ = 1,
	R2100_ACCESS_REMOTE_WRITE = 1 << 1,
	R2100_ACCESS_REMOTE_ATOMIC = 1 << 2,
	R2100_ACCESS_LOCAL_WRITE = 1 << 3,
	R2100_ACCESS_MW_BIND = 1 << 4,
	R2100_ACCESS_INVALID = 1 << 5,
};

enum r2100_mr_state {
	R2100_MR_INVALID = 0,
	R2100_MR_FREE,
	R2100_MR_VALID,
};

enum r2100_rq_type {
	R2100_RQ_TYPE_RQ = 0,
	R2100_RQ_TYPE_SRQ,
	R2100_RQ_TYPE_XSRQ,
	R2100_RQ_TYPE_RESERVED,
};

struct yib_hw_av {
    __le32 dst_gid_or_ip_0;       //[31:0]dst_gid_or_ip
    __le32 dst_gid_or_ip_1;       //[31:0]dst_gid_or_ip
    __le32 dst_gid_or_ip_2;       //[31:0]dst_gid_or_ip
    __le32 dst_gid_or_ip_3;       //[31:0]dst_gid_or_ip
    __le32 dst_mac_addr_lsb;      //[31:0]dst_mac_addr_lsb
    __le32 tc_srcmacidx;          //[15:0]dst_mac_addr_msb; [23:16]tc; [31:24]src_mac_idx
    __le32 flowlabel_networktype; //[19:0]flow_label; [21:20]network_type; [31:22]src_gid_idx
    __le32 ttl_vlan;     //[11:0]vlan_vid; [14:12]vlan_pri; [15:15]vlan_cfi; [16:16]vlan_enable; [31:24]ttl
};//32字节

#define YIB_AV_FIELD_LOC(h, l) YIB_FIELD_LOC(struct yib_hw_av, h, l)
#define YIB_AV_DST_GID_OR_IP_0    YIB_AV_FIELD_LOC(31, 0)   //ROCEv1的目的GID或ROCEv2的IP地址[31:0]
#define YIB_AV_DST_GID_OR_IP_1    YIB_AV_FIELD_LOC(63, 32)  //ROCEv1的目的GID或ROCEv2的IP地址[63:32]  
#define YIB_AV_DST_GID_OR_IP_2    YIB_AV_FIELD_LOC(95, 64)  //ROCEv1的目的GID或ROCEv2的IP地址[95:64]
#define YIB_AV_DST_GID_OR_IP_3    YIB_AV_FIELD_LOC(127, 96) //ROCEv1的目的GID或ROCEv2的IP地址[127:96] 
#define YIB_AV_DST_MAC_ADDR_LSB    YIB_AV_FIELD_LOC(159, 128)   //L2报头的目的MAC地址[31:0]
#define YIB_AV_DST_MAC_ADDR_MSB    YIB_AV_FIELD_LOC(175, 160)   //L2报头的目的MAC地址[47:32] 
#define YIB_AV_TC    YIB_AV_FIELD_LOC(183, 176)     //traffic class
#define YIB_AV_SRC_MAC_IDX    YIB_AV_FIELD_LOC(191, 184)    //索引smac的偏移      
#define YIB_AV_FLOW_LABEL    YIB_AV_FIELD_LOC(211, 192)     //流标签，标记IP数据包的一个流   
#define YIB_AV_NETWORK_TYPE    YIB_AV_FIELD_LOC(213, 212)     //0:rocev1; 2:rocev2 ipv4; 3:rocev2 ipv6
#define YIB_AV_SRC_GID_IDX    YIB_AV_FIELD_LOC(223, 214)    //索引sgid的偏移 
#define YIB_AV_VLAN_VID    YIB_AV_FIELD_LOC(235, 224)   //LAN ID，长度为12比特，表示该帧所属的VLAN
#define YIB_AV_VLAN_PRI    YIB_AV_FIELD_LOC(238, 236)     //表示帧的优先级, 取值范围为0~7, 值越大优先级越高。
#define YIB_AV_VLAN_CFI    YIB_AV_FIELD_LOC(239, 239)   //表示MC地址是否是经典格式
#define YIB_AV_VLAN_ENABLE    YIB_AV_FIELD_LOC(240, 240)    //vlan使能
#define YIB_AV_TTL    YIB_AV_FIELD_LOC(255, 248)      //Time To Live

#endif

