#include "r2100_cfg.h"
#include "../../include/basic.h"
#include "../../include/os_api.h"
#include "../../include/os_ds.h"
#include "../../include/mem.h"
#include "../../include/queue.h"
#include "../../include/host.h"
#include "../../include/verbs.h"
#include "../../include/yusur_ib.h"
#include "../../include/user.h"
#include "../hostpriv.h"
#include "../hwcomn.h"
#include "rdma-header/include/yib_inc_hw.h"
#include "rdma-header/include/yib_inc_fw.h"
#include "rdma-header/include/yib_inc_base.h"
#include "r2100_sf.h"
#include "r2100_dbg.h"
#include "r2100_fw.h"


void yib_cplq_advance_ci(struct r2100_fw *fw, int diff)
{
	u32 depth = R2100_CPLQ_SIZE/sizeof(struct cplq_entry);
	u32 ci = os_atomic_read(&fw->ci);
	u32 ci_val = ci & 0x7FFFFFFF;
	bool ci_toggle = (ci >> 31) & 0x01;

	if ((ci_val + diff) >= depth) {
		ci_val = ci_val + diff - depth;
		ci_toggle = ci_toggle? 0 : 1;
		ci = (ci_toggle << 31) | ci_val;
		os_atomic_set(&fw->ci, ci);
	} else {
		os_atomic_add(&fw->ci, diff);
	}
}

void* yib_cplq_get_vaddr(struct r2100_fw *fw)
{
	u32 ci = os_atomic_read(&fw->ci) & 0x7FFFFFFF;
	u32 size = sizeof(struct cplq_entry);
	return fw->cplq.vaddr + size * ci;
}

static int yib_fw_send_cmd(struct yib_sf *sf, struct r2100_fw *fw)
{
	struct yib_fw_req *req = &fw->fw_req;
	static u32 seq = 0;
	req->byte56 = os_atomic_read(&fw->ci);

#if(!R2100_SW_DEBUG_ON)
	req->byte0 = seq++;
	yib_write32(sf->reg_base[0], R2100_FW_CMD_REG(0), req->byte0);
	yib_write32(sf->reg_base[0], R2100_FW_CMD_REG(4), req->byte4);
	yib_write32(sf->reg_base[0], R2100_FW_CMD_REG(8), req->byte8);
	yib_write32(sf->reg_base[0], R2100_FW_CMD_REG(12), req->byte12);
	yib_write32(sf->reg_base[0], R2100_FW_CMD_REG(16), req->byte16);
	yib_write32(sf->reg_base[0], R2100_FW_CMD_REG(20), req->byte20);
	yib_write32(sf->reg_base[0], R2100_FW_CMD_REG(24), req->byte24);
	yib_write32(sf->reg_base[0], R2100_FW_CMD_REG(28), req->byte28);
	yib_write32(sf->reg_base[0], R2100_FW_CMD_REG(32), req->byte32);
	yib_write32(sf->reg_base[0], R2100_FW_CMD_REG(36), req->byte36);
	yib_write32(sf->reg_base[0], R2100_FW_CMD_REG(40), req->byte40);
	yib_write32(sf->reg_base[0], R2100_FW_CMD_REG(44), req->byte44);
	yib_write32(sf->reg_base[0], R2100_FW_CMD_REG(48), req->byte48);
	yib_write32(sf->reg_base[0], R2100_FW_CMD_REG(52), req->byte52);
	yib_write32(sf->reg_base[0], R2100_FW_CMD_REG(56), req->byte56);
	os_smp_wmb();
	r2100_dbg_print_fw_cmd(req);
	yib_write32(sf->reg_base[0], R2100_FW_CMD_REG(60), 0);
#endif
	return 0;
}

//wait_time单位: ms
int yib_fw_send_cmd_and_wait_ext(struct yib_sf *sf, struct r2100_fw *fw, struct yib_fw_req *req, 
				struct cplq_entry *entry, bool bcheck, int wait_time, struct yib_fw_cmd_ctl *ctl)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	int ret = 0;

#if(!R2100_SW_DEBUG_ON)
	struct cplq_entry *cplq;
	unsigned long start_time = jiffies;
	unsigned long jiffies_timeout = msecs_to_jiffies(wait_time);
#endif

	os_mutex_lock(&r2100_sf->fw_mutex);
	os_atomic_set(&r2100_sf->executing, 1);
	if (ctl->in_buf_len && ctl->in_buf) {
		memcpy(fw->fw_req.dma_buf.vaddr, ctl->in_buf, ctl->in_buf_len);
	}
	memcpy(&fw->fw_req, req, R2100_FW_REQ_SIZE);
	yib_fw_send_cmd(sf, fw);

#if(!R2100_SW_DEBUG_ON)
	if (wait_time ==0) {
		while(os_atomic_read(&r2100_sf->executing)) {
			os_msleep(1);
		}
	} else {
		while (time_before(jiffies, start_time + jiffies_timeout)) {
		    if (os_atomic_read(&r2100_sf->executing) == 0) {
		        break;
		    }
		    os_msleep(1);
	    }
	}

	if (os_atomic_read(&r2100_sf->executing)) {
		os_printe(sf->hw->dev, "yib_fw_send_cmd_and_wait timeout");
		os_mutex_unlock(&r2100_sf->fw_mutex);
		return -EAGAIN;
	}

	cplq = &r2100_sf->cmd_result;
	if (bcheck && (cplq->byte8 != r2100_sf->channel_id)) {
		os_printe(sf->hw->dev, "channel_id error");
		os_mutex_unlock(&r2100_sf->fw_mutex);
		return -EINVAL;
	}
	if (ctl->out_buf_len && ctl->out_buf) {
		memcpy(ctl->out_buf, fw->fw_req.dma_buf.vaddr, ctl->out_buf_len);
	}
	ret = cplq->ret_val;
	memcpy(entry, cplq, sizeof(*entry));
#else
	memset(entry, 0, sizeof(*entry));
#endif

	os_mutex_unlock(&r2100_sf->fw_mutex);
	return ret;
}

//wait_time单位: ms
int yib_fw_send_cmd_and_wait(struct yib_sf *sf, struct r2100_fw *fw, struct yib_fw_req *req, 
				struct cplq_entry *entry, bool bcheck, int wait_time)
{
	struct yib_fw_cmd_ctl ctl;
	memset(&ctl, 0, sizeof(ctl));
	return yib_fw_send_cmd_and_wait_ext(sf, fw, req, entry, bcheck, wait_time, &ctl);
}

int yib_fw_init(struct yib_sf *sf, struct r2100_fw *fw)
{
	fw->cplq = os_alloc_coherent_dma(sf->pdev, R2100_CPLQ_SIZE, sf->num_node, sf->host_mutex);
	if (fw->cplq.vaddr == 0) {
		os_printe(sf->hw->dev, "r2100_sf->cplq alloc failed");
		return -ENOMEM;
	}
	memset(fw->cplq.vaddr, 0, fw->cplq.size);
	fw->fw_req.dma_buf = os_alloc_coherent_dma(sf->pdev, R2100_DMA_BUF_SIZE, sf->num_node, sf->host_mutex);
	if (fw->fw_req.dma_buf.vaddr == 0) {
		os_printe(sf->hw->dev, "fw_req->dma_buf alloc failed");
		return -ENOMEM;
	}
	memset(fw->fw_req.dma_buf.vaddr, 0, fw->fw_req.dma_buf.size);
	return 0;
}

void yib_fw_exit(struct yib_sf *sf, struct r2100_fw *fw)
{
	if (fw->cplq.vaddr) {
		os_free_coherent_dma(sf->pdev, &fw->cplq);
		fw->cplq.vaddr = 0;
	}
	if (fw->fw_req.dma_buf.vaddr) {
		os_free_coherent_dma(sf->pdev, &fw->fw_req.dma_buf);
		fw->fw_req.dma_buf.vaddr = 0;
	}
}


