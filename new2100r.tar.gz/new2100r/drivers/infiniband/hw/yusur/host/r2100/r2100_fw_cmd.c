#include "r2100_cfg.h"
#include "../../include/basic.h"
#include "../../include/os_api.h"
#include "../../include/os_ds.h"
#include "../../include/mem.h"
#include "../../include/queue.h"
#include "../../include/host.h"
#include "../../include/verbs.h"
#include "../../include/yusur_ib.h"
#include "../../include/user.h"
#include "../hostpriv.h"
#include "../hwcomn.h"
#include "rdma-header/include/yib_inc_hw.h"
#include "rdma-header/include/yib_inc_fw.h"
#include "rdma-header/include/yib_inc_base.h"
#include "r2100_sf.h"
#include "r2100_fw.h"
#include "r2100_dbg.h"
#include "r2100_res.h"



int yib_fw_cmd_query_device(struct yib_sf *sf, struct r2100_fw *fw, struct yib_fw_roce_caps *caps)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_fw_req fw_req;
	struct yib_fw_req *req = &fw_req;
	struct cplq_entry entry;
	int ret = 0;
	struct yib_fw_cmd_ctl ctl;
	
	memset(req, 0, R2100_FW_REQ_SIZE);
	req->byte0 = r2100_sf->pci_info;
	req->byte4 = YIB_FW_CMD_QUERY_DEVICE;
	req->byte8 = u64_lsb(fw->fw_req.dma_buf.dma_addr);
	req->byte12 = u64_msb(fw->fw_req.dma_buf.dma_addr);

	memset(&ctl, 0, sizeof(ctl));
	ctl.out_buf = caps;
	ctl.out_buf_len = sizeof(*caps);

	ret = yib_fw_send_cmd_and_wait_ext(sf, fw, req, &entry, true, R2100_FW_TIMEOUT, &ctl);
	if (ret) {
		os_printe(sf->hw->dev, "yib_fw_send_cmd_and_wait timeout! opcode: %d", req->byte4);
		return -EAGAIN;
	}
	return 0;
}

int yib_fw_cmd_alloc_channel(struct yib_sf *sf, struct r2100_fw *fw)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_fw_req fw_req;
	struct yib_fw_req *req = &fw_req;
	struct cplq_entry entry;
	int ret = 0;

	memset(req, 0, R2100_FW_REQ_SIZE);
	req->byte4 = YIB_FW_CMD_ALLOC_CHANNEL;
	req->byte8 = u64_lsb(fw->cplq.dma_addr);
	req->byte12 = u64_msb(fw->cplq.dma_addr);
	req->byte16 = R2100_CPLQ_SIZE/sizeof(struct cplq_entry);
	req->byte20 = sf->eq_ops->intr_enable;

	ret = yib_fw_send_cmd_and_wait(sf, fw, req, &entry, false, R2100_FW_TIMEOUT);
	if (ret) {
		os_printe(sf->hw->dev, "yib_fw_send_cmd_and_wait timeout! opcode: %d", req->byte4);
		return -EAGAIN;
	}

	r2100_sf->channel_id = entry.byte8;
	r2100_sf->pci_info = entry.byte12;

	return 0;
}
#if(0)
static bool r2100_qpc_check(struct yib_2100r_resource *hw_res)
{
	u32 size = 0;
	int i = 0, j = 0, cnt = 0;
	u32 * buf;
	int tbl_levels = 0;
	int pbl_size = 0;
	int page_size = 0;
	u64 root_pa = 0;

	size = (sizeof(struct yib_hw_cflow) + sizeof(struct yib_hw_sflow) + sizeof(struct yib_hw_qpc_entry) + 
			sizeof(struct yib_hw_sqc_entry)) * hw_res->qp_cnt;
	printk("size = %d\n",size);
	tbl_levels = hw_res->hwqueues.levels;
	root_pa = hw_res->hwqueues.root_pa;
	pbl_size = hw_res->hwqueues.pbl_pg_size;
	page_size = hw_res->hwqueues.pg_size;
	printk("tbl_levels = %d root_pa = 0x%llx pbl_size = %d page_size = %d\n", 
			tbl_levels, root_pa, pbl_size, page_size);
	for(i = 0; i < hw_res->qp_cnt; i++) {
		buf = (u32 *)r2100_get_hwres_va(hw_res, i, R2100_TYPE_CLIENT_FLOW);
		for (j = 0; j < sizeof(struct yib_hw_cflow) / 4; j++) {
			if (buf[j] != cnt) {
				printk("buf[%d] = %d  qpc check fail!\n", cnt, buf[j]);
				return false;
			}
			cnt++;
		}
	}
	for(i = 0; i < hw_res->qp_cnt; i++) {
		buf = (u32 *)r2100_get_hwres_va(hw_res, i, R2100_TYPE_SERVER_FLOW);
		for (j = 0; j < sizeof(struct yib_hw_sflow) / 4; j++) {
			if (buf[j] != cnt) {
				printk("buf[%d] = %d  qpc check fail!\n", cnt, buf[j]);
				return false;
			}
			cnt++;
		}
	}
	for(i = 0; i < hw_res->qp_cnt; i++) {
		buf = (u32 *)r2100_get_hwres_va(hw_res, i, R2100_TYPE_QPC_COMMON);
		for (j = 0; j < sizeof(struct yib_hw_qpc_entry) / 4; j++) {
			if (buf[j] != cnt) {
				printk("buf[%d] = %d  qpc check fail!\n", cnt, buf[j]);
				return false;
			}
			cnt++;
		}
	}
	for(i = 0; i < hw_res->qp_cnt; i++) {
		buf = (u32 *)r2100_get_hwres_va(hw_res, i, R2100_TYPE_SQC);
		for (j = 0; j < sizeof(struct yib_hw_sqc_entry) / 4; j++) {
			if (buf[j] != cnt) {
				printk("buf[%d] = %d  qpc check fail!\n", cnt, buf[j]);
				return false;
			}
			cnt++;
		}
	}
	
	printk("qpc check success!\n");
	return true;
}
#endif

int yib_fw_cmd_start_channel(struct yib_sf *sf, struct r2100_fw *fw)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_fw_req fw_req;
	struct yib_fw_req *req = &fw_req;
	struct yib_2100r_resource *hw_res = &r2100_sf->hw_res;
	struct yib_hw_channel_entry channel;
	struct yib_hw_channel_entry *channel_entry = &channel;
	struct cplq_entry entry;
	u64 qpc_ba, rqc_ba, cqc_ba, nqc_ba, mpt_ba, smac_ba, sgid_ba;
	struct yib_fw_cmd_ctl ctl;

	qpc_ba = hw_res->hwqueues.root_pa;
	qpc_ba = qpc_ba >> 12;
	rqc_ba = hw_res->rqcs.root_pa;
	rqc_ba = rqc_ba >> 12;
	cqc_ba = hw_res->cqcs.root_pa;
	cqc_ba = cqc_ba >> 12;
	nqc_ba = hw_res->nqcs.root_pa;
	nqc_ba = nqc_ba >> 12;
	mpt_ba = hw_res->mpts.root_pa;
	mpt_ba = mpt_ba >> 12;
	smac_ba = hw_res->smacs.root_pa;
	smac_ba = smac_ba >> 12;
	sgid_ba = hw_res->sgids.root_pa;
	sgid_ba = sgid_ba >> 12;

	memset(channel_entry, 0, sizeof(*channel_entry));
	yib_hwres_write(channel_entry, YIB_CHANNEL_QPC_BA_LSB, u64_lsb(qpc_ba));
	yib_hwres_write(channel_entry, YIB_CHANNEL_QPC_BA_MSB, u64_msb(qpc_ba));
	yib_hwres_write(channel_entry, YIB_CHANNEL_QPC_PG_SIZE, r2100_size_to_n(hw_res->hwqueues.pg_size));
	yib_hwres_write(channel_entry, YIB_CHANNEL_QPC_PBL_PG_SIZE, r2100_size_to_n(hw_res->hwqueues.pbl_pg_size));
	yib_hwres_write(channel_entry, YIB_CHANNEL_QPC_INDIR_LVLS, hw_res->hwqueues.levels);

	yib_hwres_write(channel_entry, YIB_CHANNEL_RQC_BA_LSB, u64_lsb(rqc_ba));
	yib_hwres_write(channel_entry, YIB_CHANNEL_RQC_BA_MSB, u64_msb(rqc_ba));
	yib_hwres_write(channel_entry, YIB_CHANNEL_RQC_PG_SIZE, r2100_size_to_n(hw_res->rqcs.pg_size));
	yib_hwres_write(channel_entry, YIB_CHANNEL_RQC_PBL_PG_SIZE, r2100_size_to_n(hw_res->rqcs.pbl_pg_size));
	yib_hwres_write(channel_entry, YIB_CHANNEL_RQC_INDIR_LVLS, hw_res->rqcs.levels);

	yib_hwres_write(channel_entry, YIB_CHANNEL_CQC_BA_LSB, u64_lsb(cqc_ba));
	yib_hwres_write(channel_entry, YIB_CHANNEL_CQC_BA_MSB, u64_msb(cqc_ba));
	yib_hwres_write(channel_entry, YIB_CHANNEL_CQC_PG_SIZE, r2100_size_to_n(hw_res->cqcs.pg_size));
	yib_hwres_write(channel_entry, YIB_CHANNEL_CQC_PBL_PG_SIZE, r2100_size_to_n(hw_res->cqcs.pbl_pg_size));
	yib_hwres_write(channel_entry, YIB_CHANNEL_CQC_INDIR_LVLS, hw_res->cqcs.levels);

	yib_hwres_write(channel_entry, YIB_CHANNEL_NQC_BA_LSB, u64_lsb(nqc_ba));
	yib_hwres_write(channel_entry, YIB_CHANNEL_NQC_BA_MSB, u64_msb(nqc_ba));
	yib_hwres_write(channel_entry, YIB_CHANNEL_NQC_PG_SIZE, r2100_size_to_n(hw_res->nqcs.pg_size));
	yib_hwres_write(channel_entry, YIB_CHANNEL_NQC_PBL_PG_SIZE, r2100_size_to_n(hw_res->nqcs.pbl_pg_size));
	yib_hwres_write(channel_entry, YIB_CHANNEL_NQC_INDIR_LVLS, hw_res->nqcs.levels);
	
	yib_hwres_write(channel_entry, YIB_CHANNEL_MPT_BA_LSB, u64_lsb(mpt_ba));
	yib_hwres_write(channel_entry, YIB_CHANNEL_MPT_BA_MSB, u64_msb(mpt_ba));
	yib_hwres_write(channel_entry, YIB_CHANNEL_MPT_PG_SIZE, r2100_size_to_n(hw_res->mpts.pg_size));
	yib_hwres_write(channel_entry, YIB_CHANNEL_MPT_PBL_PG_SIZE, r2100_size_to_n(hw_res->mpts.pbl_pg_size));
	yib_hwres_write(channel_entry, YIB_CHANNEL_MPT_INDIR_LVLS, hw_res->mpts.levels);

	yib_hwres_write(channel_entry, YIB_CHANNEL_SMAC_BA_LSB, u64_lsb(smac_ba));
	yib_hwres_write(channel_entry, YIB_CHANNEL_SMAC_BA_MSB, u64_msb(smac_ba));
	yib_hwres_write(channel_entry, YIB_CHANNEL_SMAC_PG_SIZE, r2100_size_to_n(hw_res->smacs.pg_size));
	yib_hwres_write(channel_entry, YIB_CHANNEL_SMAC_PBL_PG_SIZE, r2100_size_to_n(hw_res->smacs.pbl_pg_size));
	yib_hwres_write(channel_entry, YIB_CHANNEL_SMAC_INDIR_LVLS, hw_res->smacs.levels);
	
	yib_hwres_write(channel_entry, YIB_CHANNEL_SGID_BA_LSB, u64_lsb(sgid_ba));
	yib_hwres_write(channel_entry, YIB_CHANNEL_SGID_BA_MSB, u64_msb(sgid_ba));
	yib_hwres_write(channel_entry, YIB_CHANNEL_SGID_PG_SIZE, r2100_size_to_n(hw_res->sgids.pg_size));
	yib_hwres_write(channel_entry, YIB_CHANNEL_SGID_PBL_PG_SIZE, r2100_size_to_n(hw_res->sgids.pbl_pg_size));
	yib_hwres_write(channel_entry, YIB_CHANNEL_SGID_INDIR_LVLS, hw_res->sgids.levels);

	yib_hwres_write(channel_entry, YIB_CHANNEL_CLIENT_FLOW_NUM, hw_res->qp_cnt);
	yib_hwres_write(channel_entry, YIB_CHANNEL_SERVER_FLOW_NUM, hw_res->qp_cnt);
	yib_hwres_write(channel_entry, YIB_CHANNEL_COMMON_NUM, hw_res->qp_cnt);
	yib_hwres_write(channel_entry, YIB_CHANNEL_SQC_NUM, hw_res->qp_cnt);
	yib_hwres_write(channel_entry, YIB_CHANNEL_RQC_NUM, hw_res->rq_cnt);
	yib_hwres_write(channel_entry, YIB_CHANNEL_CQC_NUM, hw_res->cq_cnt);
	yib_hwres_write(channel_entry, YIB_CHANNEL_NQC_NUM, hw_res->nq_cnt);
	yib_hwres_write(channel_entry, YIB_CHANNEL_MPT_NUM_LSB, hw_res->mpt_cnt & 0xFFF);
	yib_hwres_write(channel_entry, YIB_CHANNEL_MPT_NUM_MSB, hw_res->mpt_cnt >> 12);
	yib_hwres_write(channel_entry, YIB_CHANNEL_SMAC_NUM, hw_res->smac_len);
	yib_hwres_write(channel_entry, YIB_CHANNEL_SGID_NUM, hw_res->sgid_len);
	
	yib_hwres_write(channel_entry, YIB_CHANNEL_MSIX_ENTRY_IDX, sf->irq_vector);
	yib_hwres_write(channel_entry, YIB_CHANNEL_PORT_ID, R2100_CHANNEL_PORT_ID);
	yib_hwres_write(channel_entry, YIB_CHANNEL_HOST_ID, R2100_CHANNEL_HOST_ID);
	yib_hwres_write(channel_entry, YIB_CHANNEL_BDF, R2100_CHANNEL_BDF);
	yib_hwres_write(channel_entry, YIB_CHANNEL_VALID, R2100_CHANNEL_VALID);
	yib_hwres_write(channel_entry, YIB_CHANNEL_HALT, R2100_CHANNEL_HALT);
	yib_hwres_write(channel_entry, YIB_CHANNEL_DONE, R2100_CHANNEL_DONE);

	r2100_dbg_print_channel(sf);

	memset(req, 0, R2100_FW_REQ_SIZE);
	req->byte0 = r2100_sf->pci_info;
	req->byte4 = YIB_FW_CMD_START_CHANNEL;
	req->byte8 = r2100_sf->channel_id;
	req->byte12 = u64_lsb(fw->fw_req.dma_buf.dma_addr);
	req->byte16 = u64_msb(fw->fw_req.dma_buf.dma_addr);

	memset(&ctl, 0, sizeof(ctl));
	ctl.in_buf = channel_entry;
	ctl.in_buf_len = sizeof(*channel_entry);
	if (yib_fw_send_cmd_and_wait_ext(sf, fw, req, &entry, true, R2100_FW_TIMEOUT, &ctl)) {
		os_printe(sf->hw->dev, "yib_fw_send_cmd_and_wait timeout! opcode: %d", req->byte4);
		return -EAGAIN;
	}
#if(0)
	//用于测试qpc
	if (r2100_qpc_check(hw_res) == false)
		return -EINVAL;
#endif
	return 0;
}

int yib_fw_cmd_destroy_channel(struct yib_sf *sf, struct r2100_fw *fw)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_fw_req fw_req;
	struct yib_fw_req *req = &fw_req;
	struct cplq_entry entry;
	int ret = 0;

	memset(req, 0, R2100_FW_REQ_SIZE);
	req->byte0 = r2100_sf->pci_info;
	req->byte4 = YIB_FW_CMD_DESTROY_CHANNEL;
	req->byte8 = r2100_sf->channel_id;

	ret = yib_fw_send_cmd_and_wait(sf, fw, req, &entry, true, R2100_FW_TIMEOUT);
	if (ret) {
		os_printe(sf->hw->dev, "yib_fw_send_cmd_and_wait timeout! opcode: %d", req->byte4);
		return -EAGAIN;
	}

	return 0;
}

int yib_fw_cmd_query_left_channels(struct yib_sf *sf, struct r2100_fw *fw)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_fw_req fw_req;
	struct yib_fw_req *req = &fw_req;
	struct cplq_entry entry;
	int ret = 0;

	memset(req, 0, R2100_FW_REQ_SIZE);
	req->byte0 = r2100_sf->pci_info;
	req->byte4 = YIB_FW_CMD_QUERY_LEFT_CHANNELS;

	ret = yib_fw_send_cmd_and_wait(sf, fw, req, &entry, false, R2100_FW_TIMEOUT);
	if (ret) {
		os_printe(sf->hw->dev, "yib_fw_send_cmd_and_wait timeout! opcode: %d", req->byte4);
		return -EAGAIN;
	}

	return entry.byte8;
}

int yib_fw_cmd_set_smac(struct yib_sf *sf, struct r2100_fw *fw, int index, u8 *mac)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_fw_req fw_req;
	struct yib_fw_req *req = &fw_req;
	struct cplq_entry entry;
	int ret = 0;

	memset(req, 0, R2100_FW_REQ_SIZE);
	req->byte0 = r2100_sf->pci_info;
	req->byte4 = YIB_FW_CMD_SET_SMAC;
	req->byte8 = r2100_sf->channel_id;
	req->byte12 = index;
	req->byte16 = mac[5] | (mac[4] <<8) | (mac[3] <<16) | (mac[2] <<24);
	req->byte20 = mac[1] | (mac[0] <<8);

	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "%s byte16: 0x%x byte20: 0x%x\n", 
					__func__, req->byte16, req->byte20);

	ret = yib_fw_send_cmd_and_wait(sf, fw, req, &entry, true, R2100_FW_TIMEOUT);
	if (ret) {
		os_printe(sf->hw->dev, "yib_fw_send_cmd_and_wait timeout! opcode: %d", req->byte4);
		return -EAGAIN;
	}

	return 0;
}

int yib_fw_cmd_modify_smac(struct yib_sf *sf, struct r2100_fw *fw, int index, u8 *mac, bool bdel)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_fw_req fw_req;
	struct yib_fw_req *req = &fw_req;
	struct cplq_entry entry;
	int ret = 0;

	memset(req, 0, R2100_FW_REQ_SIZE);
	req->byte0 = r2100_sf->pci_info;
	req->byte4 = YIB_FW_CMD_SET_SMAC;
	req->byte8 = r2100_sf->channel_id;
	req->byte12 = index;
	req->byte16 = bdel;

	if (bdel) {
		req->byte20 = 0;
		req->byte24 = 0;
	} else {
		req->byte20 = mac[5] | (mac[4] <<8) | (mac[3] <<16) | (mac[2] <<24);
		req->byte24 = mac[1] | (mac[0] <<8);
	}

	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_MODIFY, "%s byte20: 0x%x byte24: 0x%x\n", 
					__func__, req->byte20, req->byte24);

	ret = yib_fw_send_cmd_and_wait(sf, fw, req, &entry, true, R2100_FW_TIMEOUT);
	if (ret) {
		os_printe(sf->hw->dev, "yib_fw_send_cmd_and_wait timeout! opcode: %d", req->byte4);
		return -EAGAIN;
	}

	return 0;
}

int yib_fw_cmd_add_sgid(struct yib_sf *sf, struct r2100_fw *fw, int index, u8 *raw, bool bipv4)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_fw_req fw_req;
	struct yib_fw_req *req = &fw_req;
	struct cplq_entry entry;
	int ret = 0;

	memset(req, 0, R2100_FW_REQ_SIZE);
	req->byte0 = r2100_sf->pci_info;
	req->byte4 = YIB_FW_CMD_ADD_SGID;
	req->byte8 = r2100_sf->channel_id;
	req->byte12 = index;
	req->byte16 = bipv4;
	req->byte20 = raw[15] | (raw[14] << 8) | (raw[13] << 16) | (raw[12] << 24);
	req->byte24 = raw[11] | (raw[10] << 8) | (raw[9] << 16) | (raw[8] << 24);
	req->byte28 = raw[7] | (raw[6] << 8) | (raw[5] << 16) | (raw[4] << 24);
	req->byte32 = raw[3] | (raw[2] << 8) | (raw[1] << 16) | (raw[0] << 24);

	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "%s byte20: 0x%x byte24: 0x%x byte28: 0x%x byte32: 0x%x\n", 
					__func__, req->byte20, req->byte24, req->byte28, req->byte32);

	ret = yib_fw_send_cmd_and_wait(sf, fw, req, &entry, true, R2100_FW_TIMEOUT);
	if (ret) {
		os_printe(sf->hw->dev, "yib_fw_send_cmd_and_wait timeout! opcode: %d", req->byte4);
		return -EAGAIN;
	}

	return 0;
}


int yib_fw_cmd_del_sgid(struct yib_sf *sf, struct r2100_fw *fw, int index)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_fw_req fw_req;
	struct yib_fw_req *req = &fw_req;
	struct cplq_entry entry;
	int ret = 0;

	memset(req, 0, R2100_FW_REQ_SIZE);
	req->byte0 = r2100_sf->pci_info;
	req->byte4 = YIB_FW_CMD_DEL_SGID;
	req->byte8 = r2100_sf->channel_id;
	req->byte12 = index;

	ret = yib_fw_send_cmd_and_wait(sf, fw, req, &entry, true, R2100_FW_TIMEOUT);
	if (ret) {
		os_printe(sf->hw->dev, "yib_fw_send_cmd_and_wait timeout! opcode: %d", req->byte4);
		return -EAGAIN;
	}

	return 0;
}

int yib_fw_cmd_reg_mr(struct yib_sf *sf, struct r2100_fw *fw, u32 index, u64 mrw_pa, bool bupdate)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_fw_req fw_req;
	struct yib_fw_req *req = &fw_req;
	struct cplq_entry entry;
	int ret = 0;

	memset(req, 0, R2100_FW_REQ_SIZE);
	req->byte0 = r2100_sf->pci_info;
	req->byte4 = YIB_FW_CMD_REG_MR;
	req->byte8 = r2100_sf->channel_id;
	req->byte12 = u64_lsb(mrw_pa);
	req->byte16 = u64_msb(mrw_pa);
	req->byte20 = index;
	req->byte24 = bupdate;

	ret = yib_fw_send_cmd_and_wait(sf, fw, req, &entry, true, R2100_FW_TIMEOUT);
	if (ret) {
		os_printe(sf->hw->dev, "yib_fw_send_cmd_and_wait timeout! opcode: %d", req->byte4);
		return -EAGAIN;
	}

	return 0;
}

int yib_fw_cmd_dereg_mr(struct yib_sf *sf, struct r2100_fw *fw, u32 index, u64 mrw_pa)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_fw_req fw_req;
	struct yib_fw_req *req = &fw_req;
	struct cplq_entry entry;
	int ret = 0;

	memset(req, 0, R2100_FW_REQ_SIZE);
	req->byte0 = r2100_sf->pci_info;
	req->byte4 = YIB_FW_CMD_DEREG_MR;
	req->byte8 = r2100_sf->channel_id;
	req->byte12 = u64_lsb(mrw_pa);
	req->byte16 = u64_msb(mrw_pa);
	req->byte20 = index;

	ret = yib_fw_send_cmd_and_wait(sf, fw, req, &entry, true, R2100_FW_TIMEOUT);
	if (ret) {
		os_printe(sf->hw->dev, "yib_fw_send_cmd_and_wait timeout! opcode: %d", req->byte4);
		return -EAGAIN;
	}

	return 0;
}

int yib_fw_cmd_query_mr(struct yib_sf *sf, struct r2100_fw *fw, u32 index, u64 pa)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_fw_req fw_req;
	struct yib_fw_req *req = &fw_req;
	struct cplq_entry entry;
	int ret = 0;

	memset(req, 0, R2100_FW_REQ_SIZE);
	req->byte0 = r2100_sf->pci_info;
	req->byte4 = YIB_FW_CMD_QUERY_MR;
	req->byte8 = r2100_sf->channel_id;
	req->byte12 = u64_lsb(pa);
	req->byte16 = u64_msb(pa);
	req->byte20 = index;

	ret = yib_fw_send_cmd_and_wait(sf, fw, req, &entry, true, R2100_FW_TIMEOUT);
	if (ret) {
		os_printe(sf->hw->dev, "yib_fw_send_cmd_and_wait timeout! opcode: %d", req->byte4);
		return -EAGAIN;
	}

	return 0;
}

int yib_fw_cmd_create_cq(struct yib_sf *sf, struct r2100_fw *fw, u32 index, u64 pa)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_fw_req fw_req;
	struct yib_fw_req *req = &fw_req;
	struct cplq_entry entry;
	int ret = 0;

	memset(req, 0, R2100_FW_REQ_SIZE);
	req->byte0 = r2100_sf->pci_info;
	req->byte4 = YIB_FW_CMD_CREATE_CQ;
	req->byte8 = r2100_sf->channel_id;
	req->byte12 = u64_lsb(pa);
	req->byte16 = u64_msb(pa);
	req->byte20 = index;

	ret = yib_fw_send_cmd_and_wait(sf, fw, req, &entry, true, R2100_FW_TIMEOUT);
	if (ret) {
		os_printe(sf->hw->dev, "yib_fw_send_cmd_and_wait timeout! opcode: %d", req->byte4);
		return -EAGAIN;
	}
	
	return 0;
}

int yib_fw_cmd_query_cq(struct yib_sf *sf, struct r2100_fw *fw, u32 index, u64 pa)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_fw_req fw_req;
	struct yib_fw_req *req = &fw_req;
	struct cplq_entry entry;
	int ret = 0;

	memset(req, 0, R2100_FW_REQ_SIZE);
	req->byte0 = r2100_sf->pci_info;
	req->byte4 = YIB_FW_CMD_QUERY_CQ;
	req->byte8 = r2100_sf->channel_id;
	req->byte12 = u64_lsb(pa);
	req->byte16 = u64_msb(pa);
	req->byte20 = index;

	ret = yib_fw_send_cmd_and_wait(sf, fw, req, &entry, true, R2100_FW_TIMEOUT);
	if (ret) {
		os_printe(sf->hw->dev, "yib_fw_send_cmd_and_wait timeout! opcode: %d", req->byte4);
		return -EAGAIN;
	}
	return 0;
}

int yib_fw_cmd_destroy_cq(struct yib_sf *sf, struct r2100_fw *fw, u32 index, u64 pa)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_fw_req fw_req;
	struct yib_fw_req *req = &fw_req;
	struct cplq_entry entry;
	int ret = 0;

	memset(req, 0, R2100_FW_REQ_SIZE);
	req->byte0 = r2100_sf->pci_info;
	req->byte4 = YIB_FW_CMD_DESTROY_CQ;
	req->byte8 = r2100_sf->channel_id;
	req->byte12 = u64_lsb(pa);
	req->byte16 = u64_msb(pa);
	req->byte20 = index;

	ret = yib_fw_send_cmd_and_wait(sf, fw, req, &entry, true, R2100_FW_TIMEOUT);
	if (ret) {
		os_printe(sf->hw->dev, "yib_fw_send_cmd_and_wait timeout! opcode: %d", req->byte4);
		return -EAGAIN;
	}

	return 0;
}

int yib_fw_cmd_create_rq(struct yib_sf *sf, struct r2100_fw *fw, u32 index, u64 pa, bool bsrq)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_fw_req fw_req;
	struct yib_fw_req *req = &fw_req;
	struct cplq_entry entry;
	int ret = 0;

	memset(req, 0, R2100_FW_REQ_SIZE);
	req->byte0 = r2100_sf->pci_info;
	req->byte4 = YIB_FW_CMD_CREATE_SRQ;
	req->byte8 = r2100_sf->channel_id;
	req->byte12 = u64_lsb(pa);
	req->byte16 = u64_msb(pa);
	req->byte20 = index;
	req->byte24 = bsrq;

	ret = yib_fw_send_cmd_and_wait(sf, fw, req, &entry, true, R2100_FW_TIMEOUT);
	if (ret) {
		os_printe(sf->hw->dev, "yib_fw_send_cmd_and_wait timeout! opcode: %d", req->byte4);
		return -EAGAIN;
	}

	return 0;
}

int yib_fw_cmd_query_rq(struct yib_sf *sf, struct r2100_fw *fw, u32 index, u64 pa)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_fw_req fw_req;
	struct yib_fw_req *req = &fw_req;
	struct cplq_entry entry;
	int ret = 0;

	memset(req, 0, R2100_FW_REQ_SIZE);
	req->byte0 = r2100_sf->pci_info;
	req->byte4 = YIB_FW_CMD_QUERY_SRQ;
	req->byte8 = r2100_sf->channel_id;
	req->byte12 = u64_lsb(pa);
	req->byte16 = u64_msb(pa);
	req->byte20 = index;

	ret = yib_fw_send_cmd_and_wait(sf, fw, req, &entry, true, R2100_FW_TIMEOUT);
	if (ret) {
		os_printe(sf->hw->dev, "yib_fw_send_cmd_and_wait timeout! opcode: %d", req->byte4);
		return -EAGAIN;
	}
	return 0;
}

int yib_fw_cmd_destroy_rq(struct yib_sf *sf, struct r2100_fw *fw, u32 index, u64 pa)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_fw_req fw_req;
	struct yib_fw_req *req = &fw_req;
	struct cplq_entry entry;
	int ret = 0;

	memset(req, 0, R2100_FW_REQ_SIZE);
	req->byte0 = r2100_sf->pci_info;
	req->byte4 = YIB_FW_CMD_DESTROY_SRQ;
	req->byte8 = r2100_sf->channel_id;
	req->byte12 = u64_lsb(pa);
	req->byte16 = u64_msb(pa);
	req->byte20 = index;

	ret = yib_fw_send_cmd_and_wait(sf, fw, req, &entry, true, R2100_FW_TIMEOUT);
	if (ret) {
		os_printe(sf->hw->dev, "yib_fw_send_cmd_and_wait timeout! opcode: %d", req->byte4);
		return -EAGAIN;
	}

	return 0;
}

int yib_fw_cmd_create_qp(struct yib_sf *sf, struct r2100_fw *fw, u32 index, 
				u32 send_cqn, u32 recv_cqn, struct r2100_hwres_pa *hwres_pa)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_fw_req fw_req;
	struct yib_fw_req *req = &fw_req;
	struct cplq_entry entry;
	int ret = 0;

	memset(req, 0, R2100_FW_REQ_SIZE);
	req->byte0 = r2100_sf->pci_info;
	req->byte4 = YIB_FW_CMD_CREATE_QP;
	req->byte8 = r2100_sf->channel_id;
	req->byte12 = index;// | (bsrq? BIT(31):0)
	req->byte16 = send_cqn;
	req->byte20 = recv_cqn;
	req->byte24 = u64_lsb(hwres_pa->cflow_pa);
	req->byte28 = u64_msb(hwres_pa->cflow_pa);
	req->byte32 = u64_lsb(hwres_pa->sflow_pa);
	req->byte36 = u64_msb(hwres_pa->sflow_pa);
	req->byte40 = u64_lsb(hwres_pa->qpc_pa);
	req->byte44 = u64_msb(hwres_pa->qpc_pa);
	req->byte48 = u64_lsb(hwres_pa->sqc_pa);
	req->byte52 = u64_msb(hwres_pa->sqc_pa);

	ret = yib_fw_send_cmd_and_wait(sf, fw, req, &entry, true, R2100_FW_TIMEOUT);
	if (ret) {
		os_printe(sf->hw->dev, "yib_fw_send_cmd_and_wait timeout! opcode: %d", req->byte4);
		return -EAGAIN;
	}

	return 0;
}

int yib_fw_cmd_modify_qp(struct yib_sf *sf, struct r2100_fw *fw, u32 index, struct yib_fw_modify_qp_ctx *ctx)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_fw_req fw_req;
	struct yib_fw_req *req = &fw_req;
	struct cplq_entry entry;
	int ret = 0;
	struct yib_fw_cmd_ctl ctl;

	memset(req, 0, R2100_FW_REQ_SIZE);
	req->byte0 = r2100_sf->pci_info;
	req->byte4 = YIB_FW_CMD_MODIFY_QP;
	req->byte8 = r2100_sf->channel_id;
	req->byte12 = u64_lsb(fw->fw_req.dma_buf.dma_addr);
	req->byte16 = u64_msb(fw->fw_req.dma_buf.dma_addr);
	req->byte20 = index;

	memset(&ctl, 0, sizeof(ctl));
	ctl.in_buf = ctx;
	ctl.in_buf_len = sizeof(*ctx);
	ret = yib_fw_send_cmd_and_wait_ext(sf, fw, req, &entry, true, R2100_FW_TIMEOUT, &ctl);
	if (ret) {
		os_printe(sf->hw->dev, "yib_fw_send_cmd_and_wait timeout! opcode: %d", req->byte4);
		return -EAGAIN;
	}

	return 0;
}

int yib_fw_cmd_query_qp(struct yib_sf *sf, struct r2100_fw *fw, u32 index, 
				struct yib_fw_query_qp_ctx *ctx, bool bdebug)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_fw_req fw_req;
	struct yib_fw_req *req = &fw_req;
	struct cplq_entry entry;
	int ret = 0;
	struct yib_fw_cmd_ctl ctl;
	
	memset(req, 0, R2100_FW_REQ_SIZE);
	req->byte0 = r2100_sf->pci_info;
	req->byte4 = YIB_FW_CMD_QUERY_QP;
	req->byte8 = r2100_sf->channel_id;
	req->byte12 = index;
	req->byte16 = u64_lsb(fw->fw_req.dma_buf.dma_addr);
	req->byte20 = u64_msb(fw->fw_req.dma_buf.dma_addr);
	req->byte24 = bdebug;

	memset(&ctl, 0, sizeof(ctl));
	ctl.out_buf = ctx;
	ctl.out_buf_len = sizeof(*ctx);
	ret = yib_fw_send_cmd_and_wait_ext(sf, fw, req, &entry, true, R2100_FW_TIMEOUT, &ctl);
	if (ret) {
		os_printe(sf->hw->dev, "yib_fw_send_cmd_and_wait timeout! opcode: %d", req->byte4);
		return -EAGAIN;
	}
	return 0;
}

int yib_fw_cmd_destroy_qp(struct yib_sf *sf, struct r2100_fw *fw, u32 index, 
				struct r2100_hwres_pa *hwres_pa)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_fw_req fw_req;
	struct yib_fw_req *req = &fw_req;
	struct cplq_entry entry;
	int ret = 0;

	memset(req, 0, R2100_FW_REQ_SIZE);
	req->byte0 = r2100_sf->pci_info;
	req->byte4 = YIB_FW_CMD_DESTROY_QP;
	req->byte8 = r2100_sf->channel_id;
	req->byte12 = index;
	req->byte16 = u64_lsb(hwres_pa->cflow_pa);
	req->byte20 = u64_msb(hwres_pa->cflow_pa);
	req->byte24 = u64_lsb(hwres_pa->sflow_pa);
	req->byte28 = u64_msb(hwres_pa->sflow_pa);
	req->byte32 = u64_lsb(hwres_pa->qpc_pa);
	req->byte36 = u64_msb(hwres_pa->qpc_pa);
	req->byte40 = u64_lsb(hwres_pa->sqc_pa);
	req->byte44 = u64_msb(hwres_pa->sqc_pa);

	ret = yib_fw_send_cmd_and_wait(sf, fw, req, &entry, true, R2100_FW_TIMEOUT);
	if (ret) {
		os_printe(sf->hw->dev, "yib_fw_send_cmd_and_wait timeout! opcode: %d", req->byte4);
		return -EAGAIN;
	}
	
	return 0;
}

int yib_fw_cmd_set_qos(struct yib_sf *sf, struct r2100_fw *fw, struct yib_rdma_qos_info *qos_info)
{
#if 0
	struct yib_fw_req fw_req;
	struct yib_fw_req *req = &fw_req;
	struct cplq_entry entry;
	int ret = 0;
	int host_id = pf_qos_info->host_id;
	int pf_id = pf_qos_info->pf_id;
	int vf_id = pf_qos_info->vf_id;

	memset(req, 0, R2100_FW_REQ_SIZE);
	req->byte0 = host_id | pf_id | vf_id;//todo
	req->byte4 = YIB_FW_CMD_SET_QOS;
	req->byte12 = YIB_QOS_HOST;
	req->byte16 = pf_qos_info->rate_limit;
	req->byte20 = pf_qos_info->max_burst_sz;
	req->byte24 = pf_qos_info->quantnum;
	req->byte28 = pf_qos_info->priority;

	ret = yib_fw_send_cmd_and_wait(sf, fw, req, &entry, true, R2100_FW_TIMEOUT);
	if (ret) {
		os_printe(sf->hw->dev, "yib_fw_send_cmd_and_wait timeout! opcode: %d", req->byte4);
		return -EAGAIN;
	}
#endif
	return 0;
}

int yib_fw_cmd_update_ci(struct yib_sf *sf, struct r2100_fw *fw)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_fw_req fw_req;
	struct yib_fw_req *req = &fw_req;
	struct cplq_entry entry;
	int ret = 0;

	memset(req, 0, R2100_FW_REQ_SIZE);
	req->byte0 = r2100_sf->pci_info;
	req->byte4 = YIB_FW_CMD_UPDATE_CI;
	req->byte8 = r2100_sf->channel_id;

	ret = yib_fw_send_cmd_and_wait(sf, fw, req, &entry, true, R2100_FW_TIMEOUT);
	if (ret) {
		os_printe(sf->hw->dev, "yib_fw_send_cmd_and_wait timeout! opcode: %d", req->byte4);
		return -EAGAIN;
	}

	return 0;
}

int yib_fw_cmd_query_nq(struct yib_sf *sf, struct r2100_fw *fw, u32 index)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_fw_req fw_req;
	struct yib_fw_req *req = &fw_req;
	struct cplq_entry entry;
	int ret = 0;

	memset(req, 0, R2100_FW_REQ_SIZE);
	req->byte0 = r2100_sf->pci_info;
	req->byte4 = YIB_FW_CMD_QUERY_NQ;
	req->byte8 = r2100_sf->channel_id;
	req->byte12 = index;

	ret = yib_fw_send_cmd_and_wait(sf, fw, req, &entry, true, R2100_FW_TIMEOUT);
	if (ret) {
		os_printe(sf->hw->dev, "yib_fw_send_cmd_and_wait timeout! opcode: %d", req->byte4);
		return -EAGAIN;
	}
	return entry.byte12;
}

int yib_fw_cmd_get_stats(struct yib_sf *sf, struct r2100_fw *fw, u8 *buf, u32 *length)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_fw_req fw_req;
	struct yib_fw_req *req = &fw_req;
	struct cplq_entry entry;
	int ret = 0;
	struct yib_fw_cmd_ctl ctl;
	
	memset(req, 0, R2100_FW_REQ_SIZE);
	req->byte0 = r2100_sf->pci_info;
	req->byte4 = YIB_FW_CMD_GET_STAT;
	req->byte8 = r2100_sf->channel_id;
	req->byte12 = u64_lsb(fw->fw_req.dma_buf.dma_addr);
	req->byte16 = u64_msb(fw->fw_req.dma_buf.dma_addr);

	memset(&ctl, 0, sizeof(ctl));
	ctl.out_buf = buf;
	ctl.out_buf_len = R2100_DMA_BUF_SIZE;
	ret = yib_fw_send_cmd_and_wait_ext(sf, fw, req, &entry, true, R2100_FW_TIMEOUT, &ctl);
	if (ret) {
		os_printe(sf->hw->dev, "yib_fw_send_cmd_and_wait timeout! opcode: %d", req->byte4);
		return -EAGAIN;
	}
	*length = entry.byte12;
	return 0;
}
