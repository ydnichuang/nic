#ifndef _RDMA_CORE_H
#define _RDMA_CORE_H

#include <util/util.h>
#include <linux/types.h>

typedef __u8  u8;

#define __iomem
#define yib_writel(val , addr)  mmio_write32(addr , val)
#define yib_readl(addr)         mmio_read32(addr)

#endif