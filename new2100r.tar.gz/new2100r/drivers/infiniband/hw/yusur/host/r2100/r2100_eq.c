#include "r2100_cfg.h"
#include "../../include/basic.h"
#include "../../include/os_api.h"
#include "../../include/os_ds.h"
#include "../../include/mem.h"
#include "../../include/queue.h"
#include "../../include/host.h"
#include "../../include/verbs.h"
#include "../../include/yusur_ib.h"
#include "../../include/user.h"
#include "../hostpriv.h"
#include "../hwcomn.h"
#include "rdma-header/include/yib_inc_hw.h"
#include "rdma-header/include/yib_inc_fw.h"
#include "rdma-header/include/yib_inc_base.h"
#include "r2100_eq.h"
#include "r2100_sf.h"
#include "r2100_fw.h"
#include "r2100_res.h"
#include "r2100_dbg.h"

static int r2100_get_eq_isize(struct yib_sf *sf, r2100_eq_priv_t *eq_priv)
{
	int eq_isize;

	if (eq_priv->baeq)
		eq_isize = sizeof(struct cplq_entry);
	else
		eq_isize = sizeof(struct yib_hw_nqe);

	return eq_isize;
}

static void r2100_nq_mask_db(struct yib_sf *sf, struct yib_eq *eq)
{
	r2100_eq_priv_t *eq_priv = (r2100_eq_priv_t *)eq->priv;
	struct yib_queue_info *info = NULL;
	u64 val = 0;
	u32 val_lsb;
	u64 val_msb;
	u32 nq_idx;
	u16 index, epoch, resize_toggle;
	u16 path, valid, debug_trace, type;

	info = eq_priv->queue->info;		
	index = os_atomic_read(&info->ci) & 0xFFFF;
	epoch = info->ci_toggle & 0x01;
	resize_toggle = 0;
	nq_idx = eq->entry.index;
	path = 0;
	valid =0;
	debug_trace = 0;
	type = YIB_DB_NQ_MASK;

	val_lsb = index | (epoch << 16) | (resize_toggle << 17);
	val_msb = nq_idx | (path << 23) | (valid << 25) | (debug_trace << 26) | (type << 27);
	val = val_lsb | (val_msb << 32);
	yib_dbg_info(YUSUR_IB_M_EQ, YUSUR_IB_DBG_DB, "nq mask db: index=%d epoch=%d type=%d nq_idx=%d\n", 
			index, epoch, type, nq_idx);
	r2100_write_reg64(sf->reg_base[0], R2100_DB64_REG, val);
}

static void r2100_aeq_device_error_handler(struct yib_sf *sf, struct yib_eq *eq, struct cplq_entry *cplq)
{
	u8 opcode;

	opcode = yib_hwres_read(cplq, YIB_CPLQ_OPCODE);
		
	switch (opcode) { //todo
		case YIB_FW_EQ_OVERFLOW:
		case YIB_FW_BUS_RESET:
		case YIB_FW_DEVICE_NOT_WORKING:
		case YIB_FW_OTHER_ERROR:
			os_printw(sf->hw->dev, "opcode: %d", opcode);
			break;
		default:
			os_printe(sf->hw->dev, "unknown opcode: %d", opcode);
			break;
	}
}

static void r2100_aeq_async_event_handler(struct yib_sf *sf, struct yib_eq *eq, struct cplq_entry *cplq, struct yib_evts_occurs *evts_occurs)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	u8 opcode;
	u32 ret_val, channel_id;
	u32 sub_opcode, start_index;
	u32 index;
	bool bdup;

	channel_id = yib_hwres_read(cplq, YIB_CPLQ_CHANNEL_ID);
	if (channel_id != r2100_sf->channel_id) {
		os_printe(sf->hw->dev, "channel_id error");
		return;
	}

	opcode = yib_hwres_read(cplq, YIB_CPLQ_OPCODE);
	ret_val = yib_hwres_read(cplq, YIB_CPLQ_RET_VAL);
	sub_opcode = yib_hwres_read(cplq, YIB_CPLQ_SUB_OPCODE);
	start_index = yib_hwres_read(cplq, YIB_CPLQ_START_INDEX);
	index = yib_hwres_read(cplq, YIB_CPLQ_INDEX);

	switch (opcode) {
		case YIB_EVENT_CQ_ERR:
		{
			struct yib_cq *ycq = NULL;
			if (sub_opcode != YIB_EVENT_SUBOPCODE_CQ) {
				os_printe(sf->hw->dev, "cq err sub_opcode is invalid");
				return;
			}
			ycq = yib_cq_get_from_cqc_index(sf->hw, index, true);
			if (!ycq) {
				os_printe(sf->hw->dev, "ycq is NULL\n");
				return;
			}
			os_printw(sf->hw->dev, "ycq:%d is full", ycq->entry.index);
			bdup = yib_hw_event_add(&sf->cq_err_evts, &ycq->evt_err_node);
	    	if (bdup) {
	    		yib_elem_drop_ref(&ycq->entry);
	   	 	}
			evts_occurs->cq_err_evts_occur++;
			break;
		}
		case YIB_EVENT_QP_FATAL:
		{
			struct yib_qp *yqp = NULL;
			if (sub_opcode != YIB_EVENT_SUBOPCODE_QP) {
				os_printe(sf->hw->dev, "qp fatal sub_opcode is invalid");
				return;
			}
			yqp = yib_qp_get_from_index(sf->hw, index, true);
			if (!yqp) {
				os_printe(sf->hw->dev, "yqp is NULL");
				return;
			}

			yib_dbg_info(YUSUR_IB_M_EQ, YUSUR_IB_DBG_NOTIFY, "qp_fatal  yqp:0x%llx opcode:%d pi:%d start_index:%d\n",
					(u64)yqp, opcode, ret_val, start_index);

			yqp->attr.qp_state = IB_QPS_ERR;
			if (yqp->is_user == false) {
				yib_aeq_generate_sq_sw_cqe(sf, yqp);
				if (!yqp->use_srq) {
					yib_aeq_generate_rq_sw_cqe(sf, yqp);
				}
			}
			bdup = yib_hw_event_add(&sf->qp_fatal_evts, &yqp->evt_fatal_node);
	    	if (bdup) {
	    		yib_elem_drop_ref(&yqp->entry);
	   	 	}
			evts_occurs->qp_fatal_evts_occur++;
			break;
		}
		case YIB_EVENT_SQ_DRAINED:
		{
			struct yib_qp *yqp = NULL;
			if (sub_opcode != YIB_EVENT_SUBOPCODE_QP) {
				os_printe(sf->hw->dev, "sq drained sub_opcode is invalid");
				return;
			}
			yqp = yib_qp_get_from_index(sf->hw, index, true);
			if (!yqp) {
				os_printe(sf->hw->dev, "yqp is NULL");
				return;
			}
			
			yqp->attr.sq_draining = 0;
			if (yqp->ib_qp.event_handler) {
				struct ib_event ev;

				ev.device = yqp->ib_qp.device;
				ev.element.qp = &yqp->ib_qp;
				ev.event = IB_EVENT_SQ_DRAINED;
				yqp->ib_qp.event_handler(&ev, yqp->ib_qp.qp_context);
			}
			break;
		}
		case YIB_EVENT_SRQ_ERR:
		{
			struct yib_rq *yrq = NULL;
			struct yib_srq *ysrq = NULL;
			if (sub_opcode != YIB_EVENT_SUBOPCODE_RQ) {
				os_printe(sf->hw->dev, "srq err sub_opcode is invalid");
				return;
			}
			yrq = yib_rq_get_from_index(sf->hw, index, true);
			if (!yrq) {
				os_printe(sf->hw->dev, "yrq is NULL");
				return;
			}

			ysrq = (struct yib_srq *)yrq->parent;
			bdup = yib_hw_event_add(&sf->srq_err_evts, &ysrq->evt_err_node);
	    	if (bdup) {
	    		yib_elem_drop_ref(&yrq->entry);
	   	 	}
			evts_occurs->srq_err_evts_occur++;
			break;
		}
		case YIB_EVENT_COMM_EST:
		case YIB_EVENT_QP_REQ_ERR:
		case YIB_EVENT_QP_ACCESS_ERR:		
		case YIB_EVENT_SRQ_LIMIT_REACHED:
		case YIB_EVENT_QP_LAST_WQE_REACHED:
			os_printw(sf->hw->dev, "todo event:%d", opcode);
			break;
		default:
			os_printe(sf->hw->dev, "unknown opcode:%d", opcode);
			break;
	}
}

static void r2100_aeq_handler(struct yib_sf *sf, struct yib_eq *eq, struct yib_evts_occurs *evts_occurs)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct cplq_entry *entry;
	struct cplq_entry cplq;
	u8 type;
	int i = 0;
	u32 *buf = (u32 *)&cplq;

	entry = (struct cplq_entry *)yib_cplq_get_vaddr(&r2100_sf->fw);
    memcpy(&cplq, entry, sizeof(struct cplq_entry));
	memset(entry, 0, sizeof(struct cplq_entry));
	yib_cplq_advance_ci(&r2100_sf->fw, 1);
	yib_dbg_info(YUSUR_IB_M_EQ, YUSUR_IB_DBG_NOTIFY, "addr = %llx ci = 0x%x pi = 0x%x\n",
					entry, os_atomic_read(&r2100_sf->fw.ci), cplq.byte24);

	type = yib_hwres_read(&cplq, YIB_CPLQ_TYPE);
		
	if (type == YIB_FW_CMD) {
		memcpy(&r2100_sf->cmd_result, &cplq, sizeof(struct cplq_entry));
		if (os_atomic_read(&r2100_sf->executing) == 0) {
			for(i = 0; i < 8; i++){
				pr_info("buf[%d]: 0x%x\n", i, buf[i]);
			}
		}
		os_atomic_set(&r2100_sf->executing, 0);	
	} else if (type ==YIB_FW_DEVICE_ERROR) {
		r2100_aeq_device_error_handler(sf, eq, &cplq);
	} else if (type ==YIB_FW_ASYNC_EVENT) {
		r2100_aeq_async_event_handler(sf, eq, &cplq, evts_occurs);
	} else {
		os_printe(sf->hw->dev, "unknown type: %d", type);
	}
}

int r2100_get_eq_intr_num(struct yib_sf *sf)
{
	yib_dbg_info(YUSUR_IB_M_EQ, YUSUR_IB_DBG_INIT, "irq_cnt = %d\n", sf->irq_cnt);
	return sf->irq_cnt;
}

int r2100_eq_info_init(struct yib_sf *sf, struct yib_eq *eq, int depth, bool b_del)
{
	r2100_eq_priv_t *eq_priv = (r2100_eq_priv_t *)eq->priv;
	int eq_item_size = 0;

	if (eq->entry.index == 0)
		eq_priv->baeq = true;
	else
		eq_priv->baeq = false;

	if (b_del == false) {
		eq_item_size = r2100_get_eq_isize(sf, eq_priv);
		if (eq_priv->baeq) {
	  		eq_priv->queue = NULL;
	    } else {
	    	if (eq->use_thread) {
				r2100_nq_mask_db(sf, eq);
	    	}
			yib_queue_calc_depth(eq_item_size, &depth);
		    
			yib_dbg_info(YUSUR_IB_M_EQ, YUSUR_IB_DBG_CREATE, "create eq:%d depth=%d isize=%d\n", 
					eq->entry.index, depth, eq_item_size);
			eq_priv->queue = yib_create_queue(sf, depth, eq_item_size, NULL);
			if (eq_priv->queue == NULL) {
				os_printw(&sf->pdev->dev, "alloc eq queue failed\n");
				return -ENOMEM;
			}

			eq_priv->queue->info = kzalloc(sizeof(struct yib_queue_info), GFP_KERNEL);
			if (eq_priv->queue->info == NULL) {
				os_printe(&sf->pdev->dev, "host eq queue info mem not enough");
				yib_destroy_queue(sf, eq_priv->queue);
				eq_priv->queue = NULL;
				return -ENOMEM;
			}
			yib_queue_info_init(eq_priv->queue->info);
	    }
	} else {
		if (eq_priv->queue) {
			if (eq_priv->queue->info)
				kfree(eq_priv->queue->info);
			yib_destroy_queue(sf, eq_priv->queue);
			eq_priv->queue = NULL;
		}
	}

	return 0;
}

bool r2100_check_eq_empty(struct yib_sf *sf, struct yib_eq *eq)
{
	r2100_eq_priv_t *eq_priv = (r2100_eq_priv_t *)eq->priv;

	if (eq_priv->baeq) {
		struct r2100_yib_sf *r2100_sf = sf->sf_priv;
		struct cplq_entry *entry;
		u8 ready;
	
		entry = (struct cplq_entry *)yib_cplq_get_vaddr(&r2100_sf->fw);
		ready = yib_hwres_read(entry, YIB_CPLQ_READY);
		if (ready == 0)
			return true;
	} else {
		struct yib_hw_nqe *nqe = NULL;
		u32 toggle, ci_toggle;
		if (!eq_priv->queue) {
			yib_dbg_err("r2100_check_eq_empty: eq_priv->queue is null\n");
			return true;
		}
		nqe = (struct yib_hw_nqe *)yib_queue_get_ci_vaddr(eq_priv->queue);
		ci_toggle = eq_priv->queue->info->ci_toggle;
		toggle = yib_hwres_read(nqe, YIB_NQE_TOGGLE);
		if (toggle == ci_toggle)
			return true;
	}
	return false;
}

void r2100_eq_sw_handler(struct yib_sf *sf, struct yib_eq *eq, u8 *buf)
{
	return;//todo
}

void r2100_eq_handler(struct yib_sf *sf, struct yib_eq *eq, struct yib_evts_occurs *evts_occurs)
{
	struct yib_hw_nqe *nqe = NULL;
	r2100_eq_priv_t *eq_priv = (r2100_eq_priv_t *)eq->priv;
	struct yib_cq *ycq;
	bool bdup;

	if (eq_priv->baeq)
		return r2100_aeq_handler(sf, eq, evts_occurs);

	nqe = (struct yib_hw_nqe *)yib_queue_get_ci_vaddr(eq_priv->queue);

	ycq = (struct yib_cq *)r2100_to_u64(yib_hwres_read(nqe, YIB_NQE_CQ_HANDLE_LSB), 
					yib_hwres_read(nqe, YIB_NQE_CQ_HANDLE_MSB));
	if (!ycq) {
		yib_dbg_err("r2100_eq_handler: ycq is null\n");
		return;
	}
	yib_dbg_info(YUSUR_IB_M_EQ, YUSUR_IB_DBG_NOTIFY, "eq handler: cqn=%d ycq=%llx ci=%d nqe=%llx\n",
	      ycq->entry.index, (u64)ycq, os_atomic_read(&eq_priv->queue->info->ci), (u64)nqe);

	yib_elem_add_ref(&ycq->entry);
	ycq->int_occur++;
	yib_queue_advance_ci(eq_priv->queue, 1);
	#if(1)
	bdup = yib_hw_event_add(&sf->cq_cmpl_evts, &ycq->evt_comp_node);
    if (bdup) {
		ycq->int_dup++;
    	yib_elem_drop_ref(&ycq->entry);
    }
	evts_occurs->cq_cmpl_evts_occur++;
	#else
	if (ycq->ib_cq.comp_handler) {
		(*ycq->ib_cq.comp_handler)(&ycq->ib_cq, ycq->ib_cq.cq_context);
	}
	yib_elem_drop_ref(&ycq->entry);
	#endif
}

void r2100_eq_ci_db_update(struct yib_sf *sf, struct yib_eq *eq, int io_cnt)
{
	r2100_eq_priv_t *eq_priv = (r2100_eq_priv_t *)eq->priv;
	struct yib_queue_info *info = NULL;
	u64 val = 0;
	u32 val_lsb;
	u64 val_msb;
	u32 nq_idx;
	u16 index, epoch, resize_toggle;
	u16 path, valid, debug_trace, type;

	if (eq_priv->baeq == false) {
		info = eq_priv->queue->info;		
		index = os_atomic_read(&info->ci) & 0xFFFF;
		epoch = info->ci_toggle & 0x01;
		resize_toggle = 0;
		nq_idx = eq->entry.index - 1;
		path = 0;
		valid =0;
		debug_trace = 0;
		type = YIB_DB_NQ_ARM;

		val_lsb = index | (epoch << 16) | (resize_toggle << 17);
		val_msb = nq_idx | (path << 23) | (valid << 25) | (debug_trace << 26) | (type << 27);
		val = val_lsb | (val_msb << 32);
		yib_dbg_info(YUSUR_IB_M_EQ, YUSUR_IB_DBG_DB, "eq db: index=%d epoch=%d type=%d nq_idx=%d\n", 
				index, epoch, type, nq_idx);
		r2100_write_reg64(sf->reg_base[0], R2100_DB64_REG, val);
	}
}

int r2100_eq_debugfs(struct yib_sf *sf, struct yib_eq *yeq)
{
	r2100_eq_priv_t *eq_priv = (r2100_eq_priv_t *)yeq->priv;
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_2100r_resource *hw_res = &r2100_sf->hw_res;
	u32 index = yeq->entry.index;

	if (eq_priv->baeq == false) {
		struct yib_hw_nqc_entry *nqc_entry;
		nqc_entry = (struct yib_hw_nqc_entry *)r2100_get_hwres_va(hw_res, index - 1, R2100_TYPE_NQC);
		pr_info("nq index: %d\n", index - 1);
		r2100_debugfs_print_nqc(nqc_entry, true);
	} else {
		pr_info("aeq index: %d\n", index);
	}
	return 0;
}




