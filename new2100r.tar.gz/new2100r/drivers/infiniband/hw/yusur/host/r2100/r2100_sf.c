#include "r2100_cfg.h"
#include "../../include/basic.h"
#include "../../include/os_api.h"
#include "../../include/os_ds.h"
#include "../../include/mem.h"
#include "../../include/queue.h"
#include "../../include/host.h"
#include "../../include/verbs.h"
#include "../../include/yusur_ib.h"
#include "../../include/user.h"
#include "../hostpriv.h"
#include "../hwcomn.h"
#include "rdma-header/include/yib_inc_hw.h"
#include "rdma-header/include/yib_inc_fw.h"
#include "rdma-header/include/yib_inc_base.h"
#include "r2100_sf.h"
#include "r2100_fw.h"
#include "r2100_fw_cmd.h"
#include "r2100_res.h"
#include <linux/random.h>
#include "r2100_eq.h"
#include "r2100_dbg.h"


u32 r2100_qpc_modify_mask[R2100_MAX_STATES][R2100_MAX_STATES][R2100_MAX_QP_TYPES] = {
    [IB_QPS_RESET] = {
        [IB_QPS_INIT] = {[IB_QPT_RC] = YIB_QP_STATE | YIB_QP_ACCESS_FLAGS | YIB_QP_PKEY_INDEX | YIB_QP_PORT | YIB_QP_AV | 
			                           YIB_QP_PATH_MTU | YIB_QP_TIMEOUT | YIB_QP_RETRY_CNT | YIB_QP_RNR_RETRY |
			                           YIB_QP_RQ_PSN | YIB_QP_MAX_QP_RD_ATOMIC | YIB_QP_MIN_RNR_TIMER | YIB_QP_SQ_PSN | 
			                           YIB_QP_MAX_DEST_RD_ATOMIC | YIB_QP_DEST_QPN,
						 [IB_QPT_UD] = YIB_QP_PKEY_INDEX | YIB_QP_PORT | YIB_QP_ACCESS_FLAGS | YIB_QP_QKEY},
    },
    [IB_QPS_INIT] = {
        [IB_QPS_INIT] = {[IB_QPT_RC] = YIB_QP_STATE | YIB_QP_ACCESS_FLAGS | YIB_QP_PKEY_INDEX | YIB_QP_PORT | YIB_QP_AV | 
			                           YIB_QP_PATH_MTU | YIB_QP_TIMEOUT | YIB_QP_RETRY_CNT | YIB_QP_RNR_RETRY |
			                           YIB_QP_RQ_PSN | YIB_QP_MAX_QP_RD_ATOMIC | YIB_QP_MIN_RNR_TIMER | YIB_QP_SQ_PSN | 
			                           YIB_QP_MAX_DEST_RD_ATOMIC | YIB_QP_DEST_QPN,
					     [IB_QPT_UD] = YIB_QP_PKEY_INDEX | YIB_QP_PORT | YIB_QP_ACCESS_FLAGS | YIB_QP_QKEY},
        [IB_QPS_RTR] = {[IB_QPT_RC] = YIB_QP_PKEY_INDEX | YIB_QP_PORT | YIB_QP_ACCESS_FLAGS | YIB_QP_PATH_MTU | YIB_QP_RQ_PSN | YIB_QP_DEST_QPN | YIB_QP_AV | YIB_QP_MAX_DEST_RD_ATOMIC | YIB_QP_MIN_RNR_TIMER, 
        				[IB_QPT_UD] = YIB_QP_PKEY_INDEX | YIB_QP_PORT | YIB_QP_ACCESS_FLAGS | YIB_QP_PATH_MTU | YIB_QP_QKEY},
    },
    [IB_QPS_RTR] = {
        [IB_QPS_RTR] = {[IB_QPT_RC] = YIB_QP_TIMEOUT | YIB_QP_RETRY_CNT | YIB_QP_RNR_RETRY | YIB_QP_SQ_PSN | 
									  YIB_QP_MAX_QP_RD_ATOMIC | YIB_QP_DEST_QPN,
			            [IB_QPT_UD] = YIB_QP_STATE | YIB_QP_SQ_PSN},
        [IB_QPS_RTS] = {[IB_QPT_RC] = YIB_QP_STATE | YIB_QP_TIMEOUT | YIB_QP_RETRY_CNT | YIB_QP_RNR_RETRY | YIB_QP_SQ_PSN | YIB_QP_MAX_QP_RD_ATOMIC | YIB_QP_DEST_QPN,
        				[IB_QPT_UD] = YIB_QP_STATE | YIB_QP_SQ_PSN},
    },
    [IB_QPS_RTS] = {
        [IB_QPS_RTS] = {[IB_QPT_RC] = 0, [IB_QPT_UD] = 0},
        [IB_QPS_SQD] = {[IB_QPT_RC] = 0, [IB_QPT_UD] = 0},
        [IB_QPS_SQE] = {[IB_QPT_RC] = 0, [IB_QPT_UD] = 0},
    },
    [IB_QPS_SQD] = {
    	[IB_QPS_RTS] = {[IB_QPT_RC] = 0, [IB_QPT_UD] = 0},
        [IB_QPS_SQD] = {[IB_QPT_RC] = 0, [IB_QPT_UD] = 0},
        [IB_QPS_SQE] = {[IB_QPT_RC] = 0, [IB_QPT_UD] = 0},
    },
    [IB_QPS_SQE] = {
        [IB_QPS_RTS] = {[IB_QPT_RC] = 0, [IB_QPT_UD] = YIB_QP_STATE},
        [IB_QPS_SQD] = {[IB_QPT_RC] = 0, [IB_QPT_UD] = 0},
        [IB_QPS_SQE] = {[IB_QPT_RC] = 0, [IB_QPT_UD] = 0},
    },
};

u32 r2100_qpc_warn_mask[R2100_MAX_STATES][R2100_MAX_STATES][R2100_MAX_QP_TYPES] = {
    [IB_QPS_RESET] = {
        [IB_QPS_INIT] = {[IB_QPT_RC] = YIB_QP_QKEY | YIB_QP_PATH_MTU | YIB_QP_RQ_PSN | YIB_QP_DEST_QPN | YIB_QP_AV | 
			                           YIB_QP_MAX_DEST_RD_ATOMIC | YIB_QP_MIN_RNR_TIMER,
			             [IB_QPT_UD] = YIB_QP_TIMEOUT | YIB_QP_RETRY_CNT | YIB_QP_RNR_RETRY | YIB_QP_MAX_QP_RD_ATOMIC | 
			                           YIB_QP_DEST_QPN | YIB_QP_RQ_PSN | YIB_QP_AV | YIB_QP_MAX_DEST_RD_ATOMIC | YIB_QP_PATH_MTU},
    },
    [IB_QPS_INIT] = {
        [IB_QPS_INIT] = {[IB_QPT_RC] = YIB_QP_QKEY | YIB_QP_PATH_MTU | YIB_QP_RQ_PSN | YIB_QP_DEST_QPN | YIB_QP_AV | 
			                           YIB_QP_MAX_DEST_RD_ATOMIC | YIB_QP_MIN_RNR_TIMER,
			             [IB_QPT_UD] = YIB_QP_TIMEOUT | YIB_QP_RETRY_CNT | YIB_QP_RNR_RETRY | YIB_QP_MAX_QP_RD_ATOMIC | 
			                           YIB_QP_DEST_QPN | YIB_QP_RQ_PSN | YIB_QP_AV | YIB_QP_MAX_DEST_RD_ATOMIC | YIB_QP_PATH_MTU},
        [IB_QPS_RTR] = {[IB_QPT_RC] = YIB_QP_QKEY,
        				[IB_QPT_UD] = YIB_QP_TIMEOUT | YIB_QP_RETRY_CNT | YIB_QP_RNR_RETRY | YIB_QP_MAX_QP_RD_ATOMIC | 
			                          YIB_QP_DEST_QPN | YIB_QP_RQ_PSN | YIB_QP_AV | YIB_QP_MAX_DEST_RD_ATOMIC},
    },
    [IB_QPS_RTR] = {
        [IB_QPS_RTR] = {[IB_QPT_RC] = YIB_QP_QKEY,
			            [IB_QPT_UD] = YIB_QP_TIMEOUT | YIB_QP_RETRY_CNT | YIB_QP_RNR_RETRY | YIB_QP_MAX_QP_RD_ATOMIC | 
			                          YIB_QP_DEST_QPN | YIB_QP_RQ_PSN | YIB_QP_AV | YIB_QP_MAX_DEST_RD_ATOMIC},
        [IB_QPS_RTS] = {[IB_QPT_RC] = YIB_QP_QKEY, 
        				[IB_QPT_UD] = YIB_QP_TIMEOUT | YIB_QP_RETRY_CNT | YIB_QP_RNR_RETRY | YIB_QP_MAX_QP_RD_ATOMIC | 
			                          YIB_QP_DEST_QPN | YIB_QP_RQ_PSN | YIB_QP_AV | YIB_QP_MAX_DEST_RD_ATOMIC},
    },
    [IB_QPS_RTS] = {
        [IB_QPS_RTS] = {[IB_QPT_RC] = 0, [IB_QPT_UD] = 0},
        [IB_QPS_SQD] = {[IB_QPT_RC] = 0, [IB_QPT_UD] = 0},
        [IB_QPS_SQE] = {[IB_QPT_RC] = 0, [IB_QPT_UD] = 0},
    },
    [IB_QPS_SQD] = {
    	[IB_QPS_RTS] = {[IB_QPT_RC] = 0, [IB_QPT_UD] = 0},
        [IB_QPS_SQD] = {[IB_QPT_RC] = 0, [IB_QPT_UD] = 0},
        [IB_QPS_SQE] = {[IB_QPT_RC] = 0, [IB_QPT_UD] = 0},
    },
    [IB_QPS_SQE] = {
        [IB_QPS_RTS] = {[IB_QPT_RC] = 0, [IB_QPT_UD] = 0},
        [IB_QPS_SQD] = {[IB_QPT_RC] = 0, [IB_QPT_UD] = 0},
        [IB_QPS_SQE] = {[IB_QPT_RC] = 0, [IB_QPT_UD] = 0},
    },
};

static u32 yib_get_random_u32_inclusive(u32 min, u32 max) {
	u32 range;

	if (min > max)
        return max;

    range = max - min + 1;
    return min + get_random_u32() % range;
}

static enum r2100_serv_type to_hw_serv_type(enum ib_qp_type qp_type)
{
	switch (qp_type) {
		case IB_QPT_RC:			
			return R2100_QPT_RC;
		case IB_QPT_UD:		
			return R2100_QPT_UD;
		case IB_QPT_XRC_INI:
		case IB_QPT_XRC_TGT:
			return R2100_QPT_XRC;
		case IB_QPT_RAW_ETHERTYPE:		
			return R2100_QPT_RAWETH;
		case IB_QPT_GSI:			
			return R2100_QPT_QP1;

		default:
			return 0xff;
	}
}

static enum r2100_wqe_size_limit to_hw_wqe_size_limit(u32 size)
{
	switch (size) {
		case 64:			
			return R2100_WQE_SIZE_LIMIT_64;
		case 128:		
			return R2100_WQE_SIZE_LIMIT_128;
		case 256:
			return R2100_WQE_SIZE_LIMIT_256;
		case 512:		
			return R2100_WQE_SIZE_LIMIT_512;

		default:
			return 0xff;
	}
}

u32 to_hw_mr_access(u32 flags)
{
	u32 mask = 0;

	if (flags & IB_ACCESS_REMOTE_READ)
		mask |=  R2100_ACCESS_REMOTE_READ;

	if (flags & IB_ACCESS_REMOTE_WRITE)
		mask |=  R2100_ACCESS_REMOTE_WRITE;

	if (flags & IB_ACCESS_REMOTE_ATOMIC)
		mask |=  R2100_ACCESS_REMOTE_ATOMIC;

	if (flags & IB_ACCESS_LOCAL_WRITE)
		mask |=  R2100_ACCESS_LOCAL_WRITE;

	if (flags & IB_ACCESS_MW_BIND)
		mask |=  R2100_ACCESS_MW_BIND;

	return mask;
}

static enum yib_mtu to_hw_mtu_size(enum ib_mtu mtu)
{
	switch (mtu) {
		case IB_MTU_256:
			return YIB_MTU_256;
		case IB_MTU_512:
			return YIB_MTU_512;
		case IB_MTU_1024:
			return YIB_MTU_1024;
		case IB_MTU_2048:
			return YIB_MTU_2048;
		case IB_MTU_4096:
			return YIB_MTU_4096;
		default:
			return 0xff;
	}
}

static enum r2100_mr_state to_hw_mr_state(enum yib_mr_state state)
{
	switch (state) {
		case YIB_MR_INVALID:
			return R2100_MR_INVALID;
		case YIB_MR_FREE:
			return R2100_MR_FREE;
		case YIB_MR_VALID:
			return R2100_MR_VALID;
		default:
			return 0xff;
	}
}

static enum r2100_network_type to_hw_network_type(enum yib_network_type type)
{
	switch (type) {
		case YIB_NETWORK_TYPE_IPV4:
			return R2100_NETWORK_TYPE_IPV4;
		case YIB_NETWORK_TYPE_IPV6:
			return R2100_NETWORK_TYPE_IPV6;
		default:
			return 0xff;
	}
}

static void r2100_nq_info_init(struct yib_sf *sf, struct yib_eq *eq, int index)
{
	r2100_eq_priv_t *eq_priv = (r2100_eq_priv_t *)eq->priv;
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_2100r_resource *hw_res = &r2100_sf->hw_res;
	struct yib_hw_nqc_entry *nqc_entry;
	int tbl_levels = 0;
	u64 nq_size = 0;
	int nq_pbl_size = 0;
	int nq_page_size = 0;
	u64 root_pa = 0;
	u64 pa;

	pa = r2100_get_hwres_pa(hw_res, index, R2100_TYPE_NQC);
	nqc_entry = (struct yib_hw_nqc_entry *)r2100_get_hwres_va(hw_res, index, R2100_TYPE_NQC);

	memset(nqc_entry, 0, sizeof(*nqc_entry));

	tbl_levels = eq_priv->queue->tbl.levels;
	nq_size = eq_priv->queue->depth;
	nq_page_size = r2100_size_to_n(eq_priv->queue->tbl.pg_size);
	nq_pbl_size = r2100_size_to_n(eq_priv->queue->tbl.pbl_pg_size);
	root_pa = eq_priv->queue->tbl.root_pa;

	yib_dbg_info(YUSUR_IB_M_EQ, YUSUR_IB_DBG_INIT, 
			"nq tbl_levels: 0x%x, nq_depth: 0x%x, pbl_size: 0x%x, page_size: 0x%x, root_pa: 0x%llx\n",
			tbl_levels, nq_size, nq_pbl_size, nq_page_size, root_pa);
	yib_dbg_info(YUSUR_IB_M_EQ, YUSUR_IB_DBG_INIT, "int_vector: 0x%x\n", eq->int_vector);

	root_pa = root_pa >> 12;

	yib_hwres_write(nqc_entry, YIB_NQC_NQ_INDIR_LVLS, tbl_levels);
	yib_hwres_write(nqc_entry, YIB_NQC_NQ_PG_SIZE, nq_page_size);
	yib_hwres_write(nqc_entry, YIB_NQC_NQ_PBL_PG_SIZE, nq_pbl_size);
	yib_hwres_write(nqc_entry, YIB_NQC_NQ_PBL_BA_LSB, u64_lsb(root_pa));
	yib_hwres_write(nqc_entry, YIB_NQC_NQ_PBL_BA_MSB, u64_msb(root_pa));
	yib_hwres_write(nqc_entry, YIB_NQC_NQ_SIZE, nq_size);
	yib_hwres_write(nqc_entry, YIB_NQC_NQ_ENABLE, R2100_NQ_ENABLE);
	yib_hwres_write(nqc_entry, YIB_NQC_NQ_INT_VEC, eq->int_vector);

	yib_dbg_info(YUSUR_IB_M_EQ, YUSUR_IB_DBG_INIT, "init nq: %d\n", index);
	r2100_debugfs_print_nqc(nqc_entry, false);
}

static void r2100_nq_init(struct yib_sf *sf)
{
	struct yib_eq *eq = NULL;
	r2100_eq_priv_t *eq_priv = NULL;
	int eq_intr_num = 0;
	int i = 0;
	int j = 0;

	eq_intr_num = sf->eq_ops->get_eq_intr_num(sf);
	for (i = 0; i < eq_intr_num; i++) {
		eq = sf->event_queue[i];
		eq_priv = (r2100_eq_priv_t *)eq->priv;
		if (eq_priv->baeq == false) {
			r2100_nq_info_init(sf, eq, j++);
		}
	}
}

int r2100_sf_pre_init(struct yib_sf *sf)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;

	memset(r2100_sf, 0, sizeof(*r2100_sf));

	//todo after hardware ready.
	sf->reg_base[0] = sf->hw->reg_base[0];
	sf->bar_size[0] = sf->hw->bar_size[0];

	os_mutex_init(&r2100_sf->fw_mutex);
	os_atomic_set(&r2100_sf->executing, 0);
	
	if (yib_fw_init(sf, &r2100_sf->fw)) {
		os_printe(sf->hw->dev, "fw init failed");
		goto err;
	}
	
	return 0;
err:
	yib_fw_exit(sf, &r2100_sf->fw);
	return -ENOMEM;
	
}

int r2100_sf_init(struct yib_sf *sf, bool b_del)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	int ret = 0;

	if (b_del == false) {
		ret = yib_fw_cmd_alloc_channel(sf, &r2100_sf->fw);
		if (ret) {
			os_printe(sf->hw->dev, "alloc channel failed");
			return ret;
		}
	} else {
		r2100_hw_res_exit(sf, &r2100_sf->hw_res);
	}
	
	return 0;
}

int r2100_start_sf(struct yib_sf *sf)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	int ret = 0;

	if (r2100_sf->started == true)
		return 0;

	ret = r2100_hw_res_init(sf, &r2100_sf->hw_res);
	if (ret) {
		os_printe(sf->hw->dev, "hw_res init failed");
		return ret;
	}

	r2100_nq_init(sf);
	
	ret = yib_fw_cmd_start_channel(sf, &r2100_sf->fw);
	if (ret) {
		os_printe(sf->hw->dev, "start channel failed");
		return ret;
	}
	
	r2100_sf->started = true;
	return 0;
}

void r2100_stop_sf(struct yib_sf *sf, bool is_shutdown)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	int ret = 0;

	if (r2100_sf->started == false)
		return;

	ret = yib_fw_cmd_destroy_channel(sf, &r2100_sf->fw);
	if (ret) {
		os_printe(sf->hw->dev, "destroy channel failed");
		return;
	}

	if (is_shutdown == false)
		r2100_hw_res_exit(sf, &r2100_sf->hw_res);

	r2100_sf->started = false;
}

void r2100_add_mac(struct yib_sf *sf, u8 *mac, int index, u8 port_num)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_2100r_resource *hw_res = &r2100_sf->hw_res;
	u8 *smac_va = r2100_get_hwres_va(hw_res, index, R2100_TYPE_SMAC_TBL);
	int i = 0;

	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, 
			"user mac[%d]: %02x %02x %02x %02x %02x %02x\n", 
			index, mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);

	for(i = 0; i < 6; i++) {
		smac_va[i] = mac[5-i];
	}

	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "smac[5-0][%d]: %02x:%02x:%02x:%02x:%02x:%02x\n", 
			index, smac_va[5], smac_va[4], smac_va[3], smac_va[2], smac_va[1], smac_va[0]);

	if (yib_fw_cmd_set_smac(sf, &r2100_sf->fw, index, mac)) {
		os_printe(sf->hw->dev, "set smac failed");
		return;
	}
}

void r2100_modify_mac(struct yib_sf *sf, u8 *mac, int index, u8 port_num, bool bdel)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_2100r_resource *hw_res = &r2100_sf->hw_res;
	u8 *smac_va = r2100_get_hwres_va(hw_res, index, R2100_TYPE_SMAC_TBL);
	int i = 0;

	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, 
			"user mac[%d]: %02x %02x %02x %02x %02x %02x\n", 
			index, mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);

	if (yib_fw_cmd_modify_smac(sf, &r2100_sf->fw, index, mac, bdel)) {
		os_printe(sf->hw->dev, "modify smac failed");
		return;
	}

	if (bdel) {
		for(i = 0; i < 6; i++) {
			smac_va[i] = 0;
		}
	} else {
		// for(i = 0; i < 6; i++) {
		// 	smac_va[i] = mac[5-i];
		// }
	}
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "smac[5-0][%d]: %02x:%02x:%02x:%02x:%02x:%02x\n", 
			index, smac_va[5], smac_va[4], smac_va[3], smac_va[2], smac_va[1], smac_va[0]);
}

void r2100_set_gid(struct yib_sf *sf, bool brocev2, bool bipv4, int index, u8 *raw, bool bdel)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_2100r_resource *hw_res = &r2100_sf->hw_res;
	u8 *sgid = r2100_get_hwres_va(hw_res, index, R2100_TYPE_SGID_TBL);
	int i = 0;

	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, 
			"raw[%d]:%02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x\n", 
			index, raw[0], raw[1], raw[2], raw[3], raw[4], raw[5], raw[6], raw[7], 
			raw[8], raw[9], raw[10], raw[11], raw[12], raw[13], raw[14], raw[15]);

	if (!brocev2)
		return;

	if (bdel) {
		if (yib_fw_cmd_del_sgid(sf, &r2100_sf->fw, index)) {
			os_printe(sf->hw->dev, "del sgid failed");
			return;
		}
		if (bipv4) {
			for(i = 0; i < 4; i++) {
				sgid[i] = 0;
			}
		} else {
			for(i = 0; i < 16; i++) {
				sgid[i] = 0;
			}
		}
	} else {
		if (bipv4) {
			for(i = 0; i < 4; i++) {
				sgid[i] = raw[15-i];
			}
			yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "ip[%d]: %d.%d.%d.%d\n", 
					index, sgid[3], sgid[2], sgid[1], sgid[0]);
		} else {
			for(i = 0; i < 16; i++) {
				sgid[i] = raw[15-i];
			}
			yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, 
					"ip[15-0][%d]: %02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x\n", 
					index, sgid[15], sgid[14], sgid[13], sgid[12], sgid[11], sgid[10], sgid[9], 
					sgid[8], sgid[7], sgid[6], sgid[5], sgid[4], sgid[3], sgid[2], sgid[1], sgid[0]);
		}
		if (yib_fw_cmd_add_sgid(sf, &r2100_sf->fw, index, raw, bipv4)) {
			os_printe(sf->hw->dev, "add sgid failed");
			return;
		}
	}
}

int r2100_mrw_alloc(struct yib_sf *sf, struct yib_mr *mr, u32 *lkey, u32 *rkey)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_2100r_resource *hw_res = &r2100_sf->hw_res;
	struct yib_hw_mpt_entry *mpt_entry;
	struct yib_page_tbl *mtt_tbl = NULL;
	u32 index = yib_get_mr_sw_idx(mr);

	mpt_entry = (struct yib_hw_mpt_entry *)r2100_get_hwres_va(hw_res, index, R2100_TYPE_MPT);
	memset(mpt_entry, 0, sizeof(*mpt_entry));
	
	if (!mr->type.is_dma && !mr->type.is_fast && !mr->type.is_mw) {
		mtt_tbl = kzalloc(sizeof(struct yib_page_tbl), GFP_KERNEL);
		if (mtt_tbl == NULL) {
			os_printe(sf->hw->dev, "alloc mr page_tbl failed");
			return -ENOMEM;
		}
		mr->priv.page_tbl = (void *)mtt_tbl;
	}

	yib_mr_helper_get_key(mr->entry.index, lkey, rkey);
	return 0;
}

void r2100_mrw_destroy(struct yib_sf *sf, struct yib_mr *mr)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_2100r_resource *hw_res = &r2100_sf->hw_res;
	struct yib_page_tbl *mtt_tbl = NULL;
	int ret = 0;
	u32 index = 0;
	u64 mrw_pa;

	index = yib_get_mr_sw_idx(mr);
	mrw_pa = r2100_get_hwres_pa(hw_res, index, R2100_TYPE_MPT);

	if (mr->state == YIB_MR_INVALID) {
		return;
	}

	ret = yib_fw_cmd_dereg_mr(sf, &r2100_sf->fw, index, mrw_pa);
	if (ret) {
		os_printe(sf->hw->dev, "dereg mr failed");
		return;
	}

	if (mr->type.is_dma || mr->type.is_fast || mr->type.is_mw) {
		return;
	} else {
		mtt_tbl = (struct yib_page_tbl *)mr->priv.page_tbl;
		if (mtt_tbl) {
			yib_destroy_page_table(sf, mtt_tbl);
			kfree(mtt_tbl);
		}
		mr->priv.page_tbl = NULL;
	}
}

int r2100_mr_mtt_init(struct yib_sf *sf, struct yib_mr *mr, struct scatterlist *sg,
				int npages, u32 page_size, u64 pa0)
{
	struct yib_page_tbl *mtt_tbl = (struct yib_page_tbl *)mr->priv.page_tbl;
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_2100r_resource *hw_res = &r2100_sf->hw_res;
	struct yib_hw_mpt_entry *mpt_entry;
	int ret = 0;
	u32 index = 0;

	index = yib_get_mr_sw_idx(mr);
	yib_dbg_info(YUSUR_IB_M_MR, YUSUR_IB_DBG_INIT, "index: %d, npages: %d, page_size: %d, pa0: 0x%llx\n", 
			index, npages, page_size, pa0);

	ret = yib_create_page_table_by_sg(sf, mtt_tbl, sg, npages, page_size, sf->hw->funcs.mr_l2_tbl);
	if (ret) {
		kfree(mtt_tbl);
		os_printe(sf->hw->dev, "create mr page_tbl failed");
		return -ENOMEM;
	}

	mpt_entry = (struct yib_hw_mpt_entry *)r2100_get_hwres_va(hw_res, index, R2100_TYPE_MPT);
	yib_hwres_write(mpt_entry, YIB_MPT_PA0_LSB, u64_lsb(pa0));
	yib_hwres_write(mpt_entry, YIB_MPT_PA0_MSB, u64_msb(pa0));
	
	return 0;
}

int r2100_mr_mpt_update(struct yib_sf *sf, struct yib_mr *ymr)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_2100r_resource *hw_res = &r2100_sf->hw_res;
	struct yib_page_tbl *tbl;
	struct yib_hw_mpt_entry *mpt_entry;
	enum r2100_hw_mr_type mr_type;
	int tbl_levels = 0;
	int mr_state = 0;
	int mr_pdn = 0;
	int mr_access = 0;
	u64 mr_size = 0;
	int mr_pbl_size = 0;
	int mr_page_size = 0;
	u64 pbl_pa = 0;
	int ret = 0;
	u32 index = 0;
	u64 mrw_pa;
	u64 va = 0;
	bool bupdate = false;
	u64 pa1 = 0;
	u64 handle;

	index = yib_get_mr_sw_idx(ymr);
	mpt_entry = (struct yib_hw_mpt_entry *)r2100_get_hwres_va(hw_res, index, R2100_TYPE_MPT);
	
	mr_state = to_hw_mr_state(ymr->state);
	mr_pdn = ymr->pd_num;
	mr_access = to_hw_mr_access(ymr->access);

	if (ymr->type.is_fast) {
		mr_type = R2100_HW_MR_NORMAL;
		mr_state = R2100_MR_FREE;
		tbl_levels = 1;
		bupdate = true;
		mr_access |= R2100_ACCESS_INVALID;
		pbl_pa = ymr->priv.fmr->desc_map;
		mr_pbl_size = r2100_size_to_n(4096);
		mr_page_size = r2100_size_to_n(4096);
	} else if (ymr->type.is_dma) {
		mr_type = R2100_HW_MR_GLOBAL_KEY;
		tbl_levels = 0;
		mr_size = 0xFFFFFFFFFFFFFFFF;
	} else if (ymr->type.is_mw) {
		mr_type = R2100_HW_MR_MW_TYPE1;
		mr_state = R2100_MR_FREE;
		yib_hwres_write(mpt_entry, YIB_MPT_PARENT_MR_IDX_CNT, (ymr->priv.pmw->pmr->ib_mr.lkey >> 8));
	} else {
		tbl = (struct yib_page_tbl *)ymr->priv.page_tbl;
		yib_dbg_info(YUSUR_IB_M_MR, YUSUR_IB_DBG_INIT, "real pbl_pg_size: %d real pg_size: %d\n", 
			tbl->pbl_pg_size, tbl->pg_size);
		mr_type = R2100_HW_MR_NORMAL;
		tbl_levels = tbl->levels;
		mr_size = yib_os_mr_length(ymr);
		mr_pbl_size = r2100_size_to_n(tbl->pbl_pg_size);
		mr_page_size = r2100_size_to_n(tbl->pg_size);
		pbl_pa = tbl->root_pa;
		va = yib_os_mr_iova(ymr);
		if (tbl_levels == 0)
			pa1 = 0;
		else
			pa1 = yib_mem_get_pa(tbl, 1);
	}

	if (ymr->type.is_user)
		handle = ymr->u_mr_handler;
	else
		handle = (u64)ymr;
	
	yib_dbg_info(YUSUR_IB_M_MR, YUSUR_IB_DBG_INIT, "tbl_levels: 0x%x, pbl_size: 0x%x, page_size: 0x%x, pbl_pa: 0x%llx\n", 
			tbl_levels, mr_pbl_size, mr_page_size, pbl_pa);
	yib_dbg_info(YUSUR_IB_M_MR, YUSUR_IB_DBG_INIT, "type: 0x%x, state: 0x%x, pdn: 0x%x, access: 0x%x, size: 0x%llx\n",
			mr_type, mr_state, mr_pdn, mr_access, mr_size);
	yib_dbg_info(YUSUR_IB_M_MR, YUSUR_IB_DBG_INIT, "va: 0x%llx, pa1: 0x%llx, mr_handle: 0x%llx\n", 
			va, pa1, handle);

	pbl_pa = pbl_pa >>12;
	pa1 = pa1 >> 12;
	yib_hwres_write(mpt_entry, YIB_MPT_TYPE, mr_type);
	yib_hwres_write(mpt_entry, YIB_MPT_NUM_TRANS_LAYERS, tbl_levels);
	yib_hwres_write(mpt_entry, YIB_MPT_SIZE_LSB, u64_lsb(mr_size));
	yib_hwres_write(mpt_entry, YIB_MPT_SIZE_MSB, u64_msb(mr_size));
	yib_hwres_write(mpt_entry, YIB_MPT_MRW_PBL_PG_SIZE, mr_pbl_size);
	yib_hwres_write(mpt_entry, YIB_MPT_MRW_PG_SIZE, mr_page_size);
	yib_hwres_write(mpt_entry, YIB_MPT_PBL_BA_LSB, u64_lsb(pbl_pa));
	yib_hwres_write(mpt_entry, YIB_MPT_PBL_BA_MSB, u64_msb(pbl_pa));
	yib_hwres_write(mpt_entry, YIB_MPT_VA_LSB, u64_lsb(va));
	yib_hwres_write(mpt_entry, YIB_MPT_VA_MSB, u64_msb(va));
	yib_hwres_write(mpt_entry, YIB_MPT_STATE, mr_state);
	yib_hwres_write(mpt_entry, YIB_MPT_PD, mr_pdn);
	yib_hwres_write(mpt_entry, YIB_MPT_KEY_LSB, ymr->ib_mr.lkey & 0xFF);
	yib_hwres_write(mpt_entry, YIB_MPT_ACCESS_RIGHT, mr_access);
	yib_hwres_write(mpt_entry, YIB_MPT_PA1_LSB, u64_lsb(pa1));
	yib_hwres_write(mpt_entry, YIB_MPT_PA1_MSB, u64_msb(pa1));
	yib_hwres_write(mpt_entry, YIB_MPT_HANDLE_LSB, u64_lsb(handle));
	yib_hwres_write(mpt_entry, YIB_MPT_HANDLE_MSB, u64_msb(handle));

	mrw_pa = r2100_get_hwres_pa(hw_res, index, R2100_TYPE_MPT);
	
	ret = yib_fw_cmd_reg_mr(sf, &r2100_sf->fw, index, mrw_pa, bupdate);
	if (ret) {
		os_printe(sf->hw->dev, "reg mr failed");
		return -EAGAIN;
	}
	yib_dbg_info(YUSUR_IB_M_MR, YUSUR_IB_DBG_INIT, "reg mr: %d\n", index);
	r2100_debugfs_print_mpt(mpt_entry, false);
	return 0;
}

static int r2100_mr_query(struct yib_sf *sf, struct yib_mr *mr)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_2100r_resource *hw_res = &r2100_sf->hw_res;
	u32 index = yib_get_mr_sw_idx(mr);
	u64 pa = r2100_get_hwres_pa(hw_res, index, R2100_TYPE_MPT);

	if (yib_fw_cmd_query_mr(sf, &r2100_sf->fw, index, pa)) {
		os_printe(sf->hw->dev, "query mr failed");
		return -EAGAIN;
	}
	return 0;
}

int r2100_mr_debugfs(struct yib_sf *sf, struct yib_mr *mr)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_2100r_resource *hw_res = &r2100_sf->hw_res;
	u32 index = yib_get_mr_sw_idx(mr);
	int ret = 0;
	struct yib_hw_mpt_entry *mpt_entry = (struct yib_hw_mpt_entry *)r2100_get_hwres_va(hw_res, 
					index, R2100_TYPE_MPT);

	ret = r2100_mr_query(sf, mr);
	if (ret)
		return ret;

	pr_info("mr index: %d\n", index);
	r2100_debugfs_print_mpt(mpt_entry, true);
	return 0;
}

int r2100_cq_info_init(struct yib_sf *sf, struct yib_cq *cq, bool enable)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_2100r_resource *hw_res = &r2100_sf->hw_res;
	struct yib_hw_cqc_entry *cqc_entry;
	int tbl_levels = 0;
	u64 cq_size = 0;
	int cq_pbl_size = 0;
	int cq_page_size = 0;
	u64 root_pa = 0;
	int ret = 0;
	u32 index = 0;
	u64 pa;
	u64 handle;

	index = cq->entry.index;
	pa = r2100_get_hwres_pa(hw_res, index, R2100_TYPE_CQC);
	cqc_entry = (struct yib_hw_cqc_entry *)r2100_get_hwres_va(hw_res, index, R2100_TYPE_CQC);
	
	if (enable == true) {
		memset(cqc_entry, 0, sizeof(*cqc_entry));

		tbl_levels = cq->queue->tbl.levels;
		cq_size = cq->queue->depth;
		cq_page_size = r2100_size_to_n(cq->queue->tbl.pg_size);
		cq_pbl_size = r2100_size_to_n(cq->queue->tbl.pbl_pg_size);
		root_pa = cq->queue->tbl.root_pa;

		yib_dbg_info(YUSUR_IB_M_CQ, YUSUR_IB_DBG_CREATE, "cq tbl_levels: 0x%x, cq_depth: 0x%x, pbl_size: 0x%x, page_size: 0x%x, root_pa: 0x%llx\n",
			tbl_levels, cq_size, cq_pbl_size, cq_page_size, root_pa);

		root_pa = root_pa >> 12;
		
		handle = (u64)cq;

		yib_dbg_info(YUSUR_IB_M_CQ, YUSUR_IB_DBG_CREATE, "is_user: %d, cq_handle: 0x%llx, cq_nq_id: %d\n", 
				cq->is_user, handle, cq->comp_vector);
		
		yib_hwres_write(cqc_entry, YIB_CQC_CQ_INDIR_LVLS, tbl_levels);
		yib_hwres_write(cqc_entry, YIB_CQC_CQ_PG_SIZE, cq_page_size);
		yib_hwres_write(cqc_entry, YIB_CQC_CQ_PBL_PG_SIZE, cq_pbl_size);
		yib_hwres_write(cqc_entry, YIB_CQC_CQ_PDE_BA_LSB, root_pa & 0xFFFFF);
		yib_hwres_write(cqc_entry, YIB_CQC_CQ_PDE_BA_MSB, root_pa >> 20);
		yib_hwres_write(cqc_entry, YIB_CQC_CQ_SIZE, cq_size);
		yib_hwres_write(cqc_entry, YIB_CQC_CQ_HANDLE_LSB, u64_lsb(handle));
		yib_hwres_write(cqc_entry, YIB_CQC_CQ_HANDLE_MSB, u64_msb(handle));
		yib_hwres_write(cqc_entry, YIB_CQC_CQ_NQ_ID, cq->comp_vector);

		ret = yib_fw_cmd_create_cq(sf, &r2100_sf->fw, index, pa);
		if (ret) {
			os_printe(sf->hw->dev, "create cq failed");
			return -EAGAIN;
		}
		yib_dbg_info(YUSUR_IB_M_CQ, YUSUR_IB_DBG_CREATE, "create cq: %d\n", index);
		r2100_debugfs_print_cqc(cqc_entry, false);
	} else {
		ret = yib_fw_cmd_destroy_cq(sf, &r2100_sf->fw, index, pa);
		if (ret) {
			os_printe(sf->hw->dev, "destroy cq failed");
			return -EAGAIN;
		}
		memset(cqc_entry, 0, sizeof(*cqc_entry));
		yib_dbg_info(YUSUR_IB_M_CQ, YUSUR_IB_DBG_DESTROY, "destroy cq: %d\n", index);
	}
	return 0;
}

void r2100_cq_notify_update(struct yib_sf *sf, struct yib_cq *cq, u32 solicited_only)
{
	struct yib_queue_info *info = cq->queue->info;
	u64 val = 0;
	u32 val_lsb;
	u64 val_msb;
	u32 cq_idx;
	u16 index, epoch, resize_toggle;
	u16 path, valid, debug_trace, type;
	
	index = os_atomic_read(&info->ci) & 0xFFFF;
	epoch = info->ci_toggle & 0x01;
	resize_toggle = 0;
	cq_idx = cq->entry.index;
	path = 0;
	valid =0;//unknown
	debug_trace = 0;
	if (solicited_only)
		type = YIB_DB_CQARMSE;
	else
		type = YIB_DB_CQARMALL;

	val_lsb = index | (epoch << 16) | (resize_toggle << 17);
	val_msb = cq_idx | (path << 23) | (valid << 25) | (debug_trace << 26) | (type << 27);
	val = val_lsb | (val_msb << 32);
	yib_dbg_info(YUSUR_IB_M_CQ, YUSUR_IB_DBG_NOTIFY, "cq_notify: index=%d epoch=%d type=%d cq_idx=%d\n", 
			index, epoch, type, cq_idx);
	r2100_write_reg64(sf->reg_base[0], R2100_DB64_REG, val);
}

static int r2100_cq_query(struct yib_sf *sf, struct yib_cq *cq)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_2100r_resource *hw_res = &r2100_sf->hw_res;
	u64 pa = r2100_get_hwres_pa(hw_res, cq->entry.index, R2100_TYPE_CQC);

	if (yib_fw_cmd_query_cq(sf, &r2100_sf->fw, cq->entry.index, pa)) {
		os_printe(sf->hw->dev, "query cq failed");
		return -EAGAIN;
	}
	return 0;
}

int r2100_cq_debugfs(struct yib_sf *sf, struct yib_cq *ycq)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_2100r_resource *hw_res = &r2100_sf->hw_res;
	u32 index = yib_get_cq_sw_idx(ycq);
	int ret = 0;
	struct yib_hw_cqc_entry *cqc_entry = (struct yib_hw_cqc_entry *)r2100_get_hwres_va(hw_res, 
					index, R2100_TYPE_CQC);

	ret = r2100_cq_query(sf, ycq);
	if (ret)
		return ret;

	pr_info("cq index: %d\n", index);
	r2100_debugfs_print_cqc(cqc_entry, true);
	return 0;
}

int r2100_rq_info_init(struct yib_sf *sf, struct yib_rq *yrq, bool enable, bool bsrq)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_2100r_resource *hw_res = &r2100_sf->hw_res;
	struct yib_hw_rqc_entry *rqc_entry;
	int tbl_levels = 0;
	u64 rq_size = 0;
	int rq_pbl_size = 0;
	int rq_page_size = 0;
	u64 root_pa = 0;
	u32 pde_ba_lsb = 0;
	u32 pde_ba_msb = 0;
	int ret = 0;
	u32 index = 0;
	u64 pa;
	u64 handle;

	index = yrq->entry.index;
	pa = r2100_get_hwres_pa(hw_res, index, R2100_TYPE_RQC);
	rqc_entry = (struct yib_hw_rqc_entry *)r2100_get_hwres_va(hw_res, index, R2100_TYPE_RQC);
	
	if (enable == true) {
		memset(rqc_entry, 0, sizeof(*rqc_entry));

		tbl_levels = yrq->queue->tbl.levels;
		rq_size = yrq->queue->depth;
		rq_page_size = r2100_size_to_n(yrq->queue->tbl.pg_size);
		rq_pbl_size = r2100_size_to_n(yrq->queue->tbl.pbl_pg_size);
		root_pa = yrq->queue->tbl.root_pa;

		yib_dbg_info(YUSUR_IB_M_RQ, YUSUR_IB_DBG_CREATE, 
				"rq tbl_levels: 0x%x, rq_depth: 0x%x, pbl_size: 0x%x, page_size: 0x%x, root_pa: 0x%llx\n",
				tbl_levels, rq_size, rq_pbl_size, rq_page_size, root_pa);

		if (yrq->is_user)
			handle = yrq->u_rq_handler;
		else
			handle = (u64)yrq;

		yib_dbg_info(YUSUR_IB_M_RQ, YUSUR_IB_DBG_CREATE, "is_user: %d, rq_handle: 0x%llx\n", yrq->is_user, handle);
		
		root_pa = root_pa >> 12;
		pde_ba_lsb = root_pa & 0xFFFFF;
		pde_ba_msb = root_pa >> 20;
		
		yib_hwres_write(rqc_entry, YIB_RQC_RQ_HANDLE_LSB, u64_lsb(handle));
		yib_hwres_write(rqc_entry, YIB_RQC_RQ_HANDLE_MSB, u64_msb(handle));
		yib_hwres_write(rqc_entry, YIB_RQC_RQ_INDIR_LVLS, tbl_levels);
		yib_hwres_write(rqc_entry, YIB_RQC_RQ_PG_SIZE, rq_page_size);
		yib_hwres_write(rqc_entry, YIB_RQC_RQ_PBL_PG_SIZE, rq_pbl_size);
		yib_hwres_write(rqc_entry, YIB_RQC_RQ_PDE_BA_LSB, pde_ba_lsb);
		yib_hwres_write(rqc_entry, YIB_RQC_RQ_PDE_BA_MSB, pde_ba_msb);
		yib_hwres_write(rqc_entry, YIB_RQC_RQ_SIZE, rq_size);
		yib_hwres_write(rqc_entry, YIB_RQC_RQ_TYPE, bsrq ? R2100_RQ_TYPE_SRQ : R2100_RQ_TYPE_RQ);
		
		ret = yib_fw_cmd_create_rq(sf, &r2100_sf->fw, index, pa, bsrq);
		if (ret) {
			os_printe(sf->hw->dev, "create rq failed");
			return -EAGAIN;
		}
		yib_dbg_info(YUSUR_IB_M_RQ, YUSUR_IB_DBG_CREATE, "create rq: %d\n", index);
		r2100_debugfs_print_rqc(rqc_entry, false);
	} else {
		ret = yib_fw_cmd_destroy_rq(sf, &r2100_sf->fw, index, pa);
		if (ret) {
			os_printe(sf->hw->dev, "destroy rq failed");
			return -EAGAIN;
		}

		memset(rqc_entry, 0, sizeof(*rqc_entry));
		
		yib_dbg_info(YUSUR_IB_M_RQ, YUSUR_IB_DBG_DESTROY, "destroy rq: %d\n", index);
	}
	return 0;
}

int r2100_rq_query(struct yib_sf *sf, struct yib_rq *rq)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_2100r_resource *hw_res = &r2100_sf->hw_res;
	u32 index = yib_get_rq_sw_idx(rq);
	u64 pa = r2100_get_hwres_pa(hw_res, index, R2100_TYPE_RQC);

	if (yib_fw_cmd_query_rq(sf, &r2100_sf->fw, index, pa)) {
		os_printe(sf->hw->dev, "query rq failed");
		return -EAGAIN;
	}
	return 0;
}

int r2100_srq_debugfs(struct yib_sf *sf, struct yib_srq *ysrq)
{
	struct yib_rq *yrq = ysrq->yrq;
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_2100r_resource *hw_res = &r2100_sf->hw_res;
	u32 index = yib_get_rq_sw_idx(yrq);
	int ret = 0;
	struct yib_hw_rqc_entry *rqc_entry = (struct yib_hw_rqc_entry *)r2100_get_hwres_va(hw_res,
			index, R2100_TYPE_RQC);
	
	ret = r2100_rq_query(sf, yrq);
	if (ret)
		return ret;

	pr_info("srq index: %d\n", index);
	r2100_debugfs_print_rqc(rqc_entry, true);
	return 0;
}

static void r2100_clear_qpc(struct yib_sf *sf, struct yib_qp *yqp)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_2100r_resource *hw_res = &r2100_sf->hw_res;
	struct yib_hw_cflow *cflow;
	struct yib_hw_sflow *sflow;
	struct yib_hw_qpc_entry *qpc_entry;
	struct yib_hw_sqc_entry *sqc_entry;
	u32 index = yqp->entry.index;

	cflow = (struct yib_hw_cflow *)r2100_get_hwres_va(hw_res, index, R2100_TYPE_CLIENT_FLOW);
	sflow = (struct yib_hw_sflow *)r2100_get_hwres_va(hw_res, index, R2100_TYPE_SERVER_FLOW);
	qpc_entry = (struct yib_hw_qpc_entry *)r2100_get_hwres_va(hw_res, index, R2100_TYPE_QPC_COMMON);
	sqc_entry = (struct yib_hw_sqc_entry *)r2100_get_hwres_va(hw_res, index, R2100_TYPE_SQC);

	memset(cflow, 0, sizeof(*cflow));
	memset(sflow, 0, sizeof(*sflow));
	memset(qpc_entry, 0, sizeof(*qpc_entry));
	memset(sqc_entry, 0, sizeof(*sqc_entry));
}

void r2100_fill_av(struct yib_hw_av *hw_av, struct yib_av *av)
{
	bool bipv6;
	bool vlan_enable;
	u16 vlan_id;
	u32 dmac_lsb, dmac_msb;
	u32 val;
	int network_type = to_hw_network_type(av->network_type);

	yib_dbg_info(YUSUR_IB_M_AH, YUSUR_IB_DBG_INIT, "network_type = %d smac_idx = %d sgid_index = %d\n", 
			network_type, av->smac_idx, av->grh.sgid_index);
	
	bipv6 = (network_type == R2100_NETWORK_TYPE_IPV6)? true: false;
	vlan_id = av->vlan_id;
	vlan_enable = (vlan_id == 0xFFFF)? false: true;
	dmac_lsb = av->dmac[5] | (av->dmac[4] << 8) | (av->dmac[3] << 16) | (av->dmac[2] << 24);
	dmac_msb = av->dmac[1] | (av->dmac[0] << 8);

	yib_hwres_write(hw_av, YIB_AV_DST_MAC_ADDR_LSB, dmac_lsb);
	yib_hwres_write(hw_av, YIB_AV_DST_MAC_ADDR_MSB, dmac_msb);
	yib_hwres_write(hw_av, YIB_AV_TC, av->grh.traffic_class);
	yib_hwres_write(hw_av, YIB_AV_SRC_MAC_IDX, av->smac_idx);
	yib_hwres_write(hw_av, YIB_AV_FLOW_LABEL, av->grh.flow_label);
	yib_hwres_write(hw_av, YIB_AV_NETWORK_TYPE, network_type);
	yib_hwres_write(hw_av, YIB_AV_SRC_GID_IDX, av->grh.sgid_index);
	yib_hwres_write(hw_av, YIB_AV_VLAN_VID, vlan_id & 0xFFF);
	yib_hwres_write(hw_av, YIB_AV_VLAN_PRI, av->vlan_pcp);
	yib_hwres_write(hw_av, YIB_AV_VLAN_CFI, 0);
	yib_hwres_write(hw_av, YIB_AV_VLAN_ENABLE, vlan_enable);
	yib_hwres_write(hw_av, YIB_AV_TTL, av->grh.hop_limit);
	if (!bipv6) {
		u8 *addrv4;
		addrv4 = (u8 *)(&av->dgid_addr._sockaddr_in.sin_addr.s_addr);
		val = net_addr2_le32(addrv4);
		yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "fill av: val =0x%x\n", val);
		yib_hwres_write(hw_av, YIB_AV_DST_GID_OR_IP_0, val);
	} else {
		u8 *dat;
		dat = (u8 *)(&av->dgid_addr._sockaddr_in6.sin6_addr.s6_addr);
		val = net_addr2_le32(dat + 12);
		yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "fill av: val =0x%x\n", val);
		yib_hwres_write(hw_av, YIB_AV_DST_GID_OR_IP_0, val);
		val = net_addr2_le32(dat + 8);
		yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "fill av: val =0x%x\n", val);
		yib_hwres_write(hw_av, YIB_AV_DST_GID_OR_IP_1, val);
		val = net_addr2_le32(dat + 4);
		yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "fill av: val =0x%x\n", val);
		yib_hwres_write(hw_av, YIB_AV_DST_GID_OR_IP_2, val);
		val = net_addr2_le32(dat);
		yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "fill av: val =0x%x\n", val);
		yib_hwres_write(hw_av, YIB_AV_DST_GID_OR_IP_3, val);
	}
}

static void r2100_reset_qpc(struct yib_sf *sf, struct yib_qp *yqp)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_2100r_resource *hw_res = &r2100_sf->hw_res;
	struct yib_hw_cflow *cflow;
	struct yib_hw_sflow *sflow;
	struct yib_hw_qpc_entry *qpc_entry;
	struct yib_hw_sqc_entry *sqc_entry;
	int tbl_levels = 0;
	u64 sq_size = 0;
	int sq_pbl_size = 0;
	int sq_page_size = 0;
	u64 root_pa = 0;
	u32 index = 0;
	u64 handle;
	u32 sq_cq_id;
	u32 sq_cq_id_lsb;
	u32 sq_cq_id_msb;
	u16 sport = 0;
	u32 item_size;
	u32 rqn;

	index = yqp->entry.index;
	cflow = (struct yib_hw_cflow *)r2100_get_hwres_va(hw_res, index, R2100_TYPE_CLIENT_FLOW);
	sflow = (struct yib_hw_sflow *)r2100_get_hwres_va(hw_res, index, R2100_TYPE_SERVER_FLOW);
	qpc_entry = (struct yib_hw_qpc_entry *)r2100_get_hwres_va(hw_res, index, R2100_TYPE_QPC_COMMON);
	sqc_entry = (struct yib_hw_sqc_entry *)r2100_get_hwres_va(hw_res, index, R2100_TYPE_SQC);
	
	memset(cflow, 0, sizeof(*cflow));
	memset(sflow, 0, sizeof(*sflow));
	memset(qpc_entry, 0, sizeof(*qpc_entry));
	memset(sqc_entry, 0, sizeof(*sqc_entry));

	tbl_levels = yqp->ysq.queue->tbl.levels;
	sq_size = yqp->ysq.queue->depth;
	sq_page_size = r2100_size_to_n(yqp->ysq.queue->tbl.pg_size);
	sq_pbl_size = r2100_size_to_n(yqp->ysq.queue->tbl.pbl_pg_size);
	root_pa = yqp->ysq.queue->tbl.root_pa;

	yib_dbg_info(YUSUR_IB_M_SQ, YUSUR_IB_DBG_CREATE, 
			"sq tbl_levels: 0x%x, sq_depth: 0x%x, pbl_size: 0x%x, page_size: 0x%x, root_pa: 0x%llx\n",
			tbl_levels, sq_size, sq_pbl_size, sq_page_size, root_pa);

	root_pa = root_pa >> 12;

	if (yqp->is_user)
		handle = yqp->u_qp_handler;
	else 
		handle = (u64)yqp;

	if (yqp->use_srq)
		rqn = yqp->type.ysrq->yrq->entry.index;
	else
		rqn = yqp->type.yrq->entry.index;

	yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_CREATE, 
		"is_user: %d, qp_handle: 0x%llx, use_srq: %d, rqn: %d\n", yqp->is_user, handle, yqp->use_srq, rqn);
	
	yib_hwres_write(sqc_entry, YIB_SQC_SQ_INDIR_LVLS, tbl_levels);
	yib_hwres_write(sqc_entry, YIB_SQC_SQ_PG_SIZE, sq_page_size);
	yib_hwres_write(sqc_entry, YIB_SQC_SQ_PBL_PG_SIZE, sq_pbl_size);
	yib_hwres_write(sqc_entry, YIB_SQC_SQ_SIZE, sq_size);
	yib_hwres_write(sqc_entry, YIB_SQC_SQ_PDE_PA_LSB, u64_lsb(root_pa));
	yib_hwres_write(sqc_entry, YIB_SQC_SQ_PDE_PA_MSB, u64_msb(root_pa));
	yib_hwres_write(sqc_entry, YIB_SQC_PORT_ID, 0);

	item_size = yqp->ysq.queue->item_size;
	yib_hwres_write(cflow, YIB_CFLOW_RE_TXMITS_COUNT_INIT_VALUE, 0);
	yib_hwres_write(cflow, YIB_CFLOW_RNR_RE_TXMITS_COUNT_INIT_VALUE, 0);
	yib_hwres_write(cflow, YIB_CFLOW_WQE_SIZE_LIMIT, to_hw_wqe_size_limit(item_size));
	yib_hwres_write(cflow, YIB_CFLOW_GET_WQES_LIMIT, 512 / item_size);
	yib_hwres_write(cflow, YIB_CFLOW_SQ_NEXT_PSN, 0);
	yib_hwres_write(cflow, YIB_CFLOW_OLDEST_UNACK_PSN, 0);

	yib_hwres_write(sflow, YIB_SFLOW_INCOME_MSG_KEY_OR_QKEY, 0);
	yib_hwres_write(sflow, YIB_SFLOW_RNR_TIME_TO_WAIT, 0);
	yib_hwres_write(sflow, YIB_SFLOW_RX_READ_ATOMIC_LIMIT, 0);

	sq_cq_id = yqp->ysq_cq->entry.index;
	sq_cq_id_lsb = sq_cq_id & 0xFF;
	sq_cq_id_msb = (sq_cq_id >>8) & 0xF;
	sport = yib_get_random_u32_inclusive(R2100_ROCE_UDP_ENCAP_VALID_PORT_MIN, 
					 R2100_ROCE_UDP_ENCAP_VALID_PORT_MAX);
		
	yib_hwres_write(qpc_entry, YIB_QPC_P_KEY, 0);
	yib_hwres_write(qpc_entry, YIB_QPC_SOURCE_PORT, sport);
	yib_hwres_write(qpc_entry, YIB_QPC_DST_QP, 0);
	yib_hwres_write(qpc_entry, YIB_QPC_RQN, rqn);
	yib_hwres_write(qpc_entry, YIB_QPC_SQ_CQ_ID_LSB, sq_cq_id_lsb);
	yib_hwres_write(qpc_entry, YIB_QPC_SQ_CQ_ID_MSB, sq_cq_id_msb);
	yib_hwres_write(qpc_entry, YIB_QPC_RQ_CQ_ID, yqp->yrq_cq->entry.index);
	yib_hwres_write(qpc_entry, YIB_QPC_SEND_PKT_LIMIT, R2100_SEND_PKT_LIMIT);
	yib_hwres_write(qpc_entry, YIB_QPC_READ_ATOMIC_LIMIT, 0);
	yib_hwres_write(qpc_entry, YIB_QPC_PD, yqp->ypd->entry.index);
	yib_hwres_write(qpc_entry, YIB_QPC_SERV_TYPE, to_hw_serv_type(yqp->qp_type));
	yib_hwres_write(qpc_entry, YIB_QPC_LOCAL_RQ_CREDITS_EN, R2100_LOCAL_RQ_CREDITS_EN);
	yib_hwres_write(qpc_entry, YIB_QPC_MTU_SIZE, to_hw_mtu_size(yqp->attr.path_mtu));
	yib_hwres_write(qpc_entry, YIB_QPC_REMOTE_RQ_CREDITS_EN, R2100_REMOTE_RQ_CREDITS_EN);
	yib_hwres_write(qpc_entry, YIB_QPC_ENABLE_ECN, R2100_ENABLE_ECN);
	yib_hwres_write(qpc_entry, YIB_QPC_ACCESS_RIGHT, to_hw_mr_access(yqp->attr.qp_access_flags));
	yib_hwres_write(qpc_entry, YIB_QPC_SQ_HANDLE_LSB, u64_lsb(handle));
	yib_hwres_write(qpc_entry, YIB_QPC_SQ_HANDLE_MSB, u64_msb(handle));
}

int r2100_qp_info_init(struct yib_sf *sf, struct yib_qp *yqp, bool enable)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_2100r_resource *hw_res = &r2100_sf->hw_res;
	struct r2100_hwres_pa hwres_pa;
	int ret = 0;
	u32 index = 0;
	u32 send_cqn = 0;
	u32 recv_cqn = 0;

	index = yqp->entry.index;
	hwres_pa.cflow_pa = r2100_get_hwres_pa(hw_res, index, R2100_TYPE_CLIENT_FLOW);
	hwres_pa.sflow_pa = r2100_get_hwres_pa(hw_res, index, R2100_TYPE_SERVER_FLOW);
	hwres_pa.qpc_pa = r2100_get_hwres_pa(hw_res, index, R2100_TYPE_QPC_COMMON);
	hwres_pa.sqc_pa = r2100_get_hwres_pa(hw_res, index, R2100_TYPE_SQC);
	
	if (enable == true) {
		r2100_reset_qpc(sf, yqp);
		send_cqn = yqp->ysq_cq->entry.index;
		recv_cqn = yqp->yrq_cq->entry.index;

		ret = yib_fw_cmd_create_qp(sf, &r2100_sf->fw, index, send_cqn, recv_cqn, &hwres_pa);
		if (ret) {
			os_printe(sf->hw->dev, "create qp failed");
			return -EAGAIN;
		}
		yqp->attr.qp_state = IB_QPS_RESET;
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_CREATE, "create qp: %d\n", index);
		r2100_debugfs_print_qpc(sf, yqp, false);
		return 0;
	} else {
		ret = yib_fw_cmd_destroy_qp(sf, &r2100_sf->fw, index, &hwres_pa);
		if (ret) {
			os_printe(sf->hw->dev, "destroy qp failed");
			return -EAGAIN;
		}

		r2100_clear_qpc(sf, yqp);
		
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_DESTROY, "destroy qp: %d\n", index);
		return 0;
	}
}

static bool r2100_can_modify_qpc(enum ib_qp_state cur_state, enum ib_qp_state to_state, 
				u32 mask, enum ib_qp_type qp_type)
{

	u32 modify_mask = 0;
	u32 warn_mask = 0;

	yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, 
			"cur_qp_state = %d qp_state = %d mask = 0x%x qp_type = %d\n", 
			cur_state, to_state, mask, qp_type);

	if (qp_type == IB_QPT_GSI)
		qp_type = IB_QPT_UD;

	if (qp_type != IB_QPT_RC && qp_type != IB_QPT_UD)
		return false;

	modify_mask = r2100_qpc_modify_mask[cur_state][to_state][qp_type];
	warn_mask = r2100_qpc_warn_mask[cur_state][to_state][qp_type];
	
	modify_mask &= mask;
	if (modify_mask)
		return true;
	
	warn_mask &= mask;
	if (warn_mask) {
		yib_pr_warn("mask invalid! warn_mask = 0x%x", warn_mask);
	}
	
	return false;
}

bool r2100_qp_info_update(struct yib_sf *sf, struct yib_qp *qp, u32 mask, bool state_chg)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_2100r_resource *hw_res = &r2100_sf->hw_res;
	struct yib_fw_modify_qp_ctx modify_qp_ctx;
	struct yib_fw_modify_qp_ctx *ctx = &modify_qp_ctx;
	struct yib_hw_cflow *cflow;
	struct yib_hw_sflow *sflow;
	struct yib_hw_qpc_entry *qpc_entry;
	struct yib_hw_sqc_entry *sqc_entry;
	u32 index = 0;
	int ret = 0;
	u32 cur_qp_state = qp->attr.cur_qp_state;
	u32 qp_state = qp->attr.qp_state;
	
	memset(ctx, 0, sizeof(*ctx));
	ctx->is_used_srq = qp->use_srq;
	ctx->is_state_chg = state_chg;
	ctx->send_cqn = qp->ysq_cq->entry.index;
	ctx->recv_cqn = qp->yrq_cq->entry.index;
	index = qp->entry.index;
	cflow = (struct yib_hw_cflow *)r2100_get_hwres_va(hw_res, index, R2100_TYPE_CLIENT_FLOW);
	sflow = (struct yib_hw_sflow *)r2100_get_hwres_va(hw_res, index, R2100_TYPE_SERVER_FLOW);
	qpc_entry = (struct yib_hw_qpc_entry *)r2100_get_hwres_va(hw_res, index, R2100_TYPE_QPC_COMMON);
	sqc_entry = (struct yib_hw_sqc_entry *)r2100_get_hwres_va(hw_res, index, R2100_TYPE_SQC);

	if (state_chg) {
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "qp:%d qp_state=0x%x\n", 
				index, qp->attr.qp_state);
		ctx->qp_attr.qp_state = qp->attr.qp_state;
		ctx->qp_attr_mask |= YIB_QP_STATE;
		if (qp->attr.qp_state == IB_QPS_RESET || qp->attr.qp_state == IB_QPS_ERR) 
			goto modify;			
	} else if (qp->attr.qp_state == IB_QPS_RESET || qp->attr.qp_state == IB_QPS_ERR) {
		return true;
	}

	if (mask & IB_QP_PATH_MTU) {
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "qp:%d path_mtu=0x%x\n", 
				index, qp->attr.path_mtu);
		ctx->qp_attr.path_mtu = to_hw_mtu_size(qp->attr.path_mtu);
		ctx->qp_attr_mask |= YIB_QP_PATH_MTU;
		if (r2100_can_modify_qpc(cur_qp_state, qp_state, mask, qp->qp_type)) {
			yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "write qpc: path_mtu\n");
			yib_hwres_write(qpc_entry, YIB_QPC_MTU_SIZE, to_hw_mtu_size(qp->attr.path_mtu));
		}
	}

	if (mask & IB_QP_QKEY) {
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "qp:%d qkey=0x%x\n", 
				index, qp->attr.qkey);
		ctx->qp_attr.qkey = qp->attr.qkey;
		ctx->qp_attr_mask |= YIB_QP_QKEY;
		if (r2100_can_modify_qpc(cur_qp_state, qp_state, mask, qp->qp_type)) {
			yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "write qpc: qkey\n");
			yib_hwres_write(sflow, YIB_SFLOW_INCOME_MSG_KEY_OR_QKEY, qp->attr.qkey);
		}
	}

	if (mask & IB_QP_RQ_PSN) {//unknown  server flow没psn
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "qp:%d rq_psn=0x%x\n", 
				index, qp->attr.rq_psn);
		ctx->qp_attr.rq_psn = qp->attr.rq_psn;
		ctx->qp_attr_mask |= YIB_QP_RQ_PSN;
		if (r2100_can_modify_qpc(cur_qp_state, qp_state, mask, qp->qp_type)) {
			yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "write qpc: rq_psn\n");
			yib_hwres_write(cflow, YIB_CFLOW_OLDEST_UNACK_PSN, qp->attr.rq_psn);
		}
	}

	if (mask & IB_QP_SQ_PSN) {
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "qp:%d sq_psn=0x%x\n", 
				index, qp->attr.sq_psn);
		ctx->qp_attr.sq_psn = qp->attr.sq_psn;
		ctx->qp_attr_mask |= YIB_QP_SQ_PSN;
		if (r2100_can_modify_qpc(cur_qp_state, qp_state, mask, qp->qp_type)) {
			yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "write qpc: sq_psn\n");
			yib_hwres_write(cflow, YIB_CFLOW_SQ_NEXT_PSN, qp->attr.sq_psn);
		}
	}

	if (mask & IB_QP_DEST_QPN) {
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "qp:%d dest_qp_num=0x%x\n", 
				index, qp->attr.dest_qp_num);
		ctx->qp_attr.dest_qp_num = qp->attr.dest_qp_num;
		ctx->qp_attr_mask |= YIB_QP_DEST_QPN;
		if (r2100_can_modify_qpc(cur_qp_state, qp_state, mask, qp->qp_type)) {
			yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "write qpc: dest_qp_num\n");
			yib_hwres_write(qpc_entry, YIB_QPC_DST_QP, qp->attr.dest_qp_num);
		}
	}

	if (mask & IB_QP_ACCESS_FLAGS) {
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "qp:%d qp_access_flags=0x%x\n", 
				index, qp->attr.qp_access_flags);
		ctx->qp_attr.qp_access_flags = to_hw_mr_access(qp->attr.qp_access_flags);
		ctx->qp_attr_mask |= YIB_QP_ACCESS_FLAGS;
		if (r2100_can_modify_qpc(cur_qp_state, qp_state, mask, qp->qp_type)) {
			yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "write qpc: qp_access_flags\n");
			yib_hwres_write(qpc_entry, YIB_QPC_ACCESS_RIGHT, to_hw_mr_access(qp->attr.qp_access_flags));
		}
	}

	if (mask & IB_QP_PKEY_INDEX) {
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "qp:%d pkey[%d]=0x%x\n", 
				index, qp->attr.pkey_index, g_yib_pkey_table[qp->attr.pkey_index]);
		ctx->qp_attr.pkey = g_yib_pkey_table[qp->attr.pkey_index];
		ctx->qp_attr_mask |= YIB_QP_PKEY_INDEX;
		if (r2100_can_modify_qpc(cur_qp_state, qp_state, mask, qp->qp_type)) {
			yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "write qpc: pkey\n");
			yib_hwres_write(qpc_entry, YIB_QPC_P_KEY, g_yib_pkey_table[qp->attr.pkey_index]);
		}
	}

	if (mask & IB_QP_MAX_QP_RD_ATOMIC) {
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "qp:%d max_rd_atomic=0x%x\n", 
				index, qp->attr.max_rd_atomic);
		ctx->qp_attr.max_rd_atomic = qp->attr.max_rd_atomic;
		ctx->qp_attr_mask |= YIB_QP_MAX_QP_RD_ATOMIC;
		if (r2100_can_modify_qpc(cur_qp_state, qp_state, mask, qp->qp_type)) {
			yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "write qpc: max_rd_atomic\n");
			yib_hwres_write(qpc_entry, YIB_QPC_READ_ATOMIC_LIMIT, qp->attr.max_rd_atomic);
		}
	}

	if (mask & IB_QP_MAX_DEST_RD_ATOMIC) {
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "qp:%d max_dest_rd_atomic=0x%x\n", 
				index, qp->attr.max_dest_rd_atomic);
		ctx->qp_attr.max_dest_rd_atomic = qp->attr.max_dest_rd_atomic;
		ctx->qp_attr_mask |= YIB_QP_MAX_DEST_RD_ATOMIC;
		if (r2100_can_modify_qpc(cur_qp_state, qp_state, mask, qp->qp_type)) {
			yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "write qpc: max_dest_rd_atomic\n");
			yib_hwres_write(sflow, YIB_SFLOW_RX_READ_ATOMIC_LIMIT, qp->attr.max_dest_rd_atomic);
		}
	}

	if (mask & IB_QP_MIN_RNR_TIMER) {
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "qp:%d min_rnr_timer=0x%x\n", 
				index, qp->attr.min_rnr_timer);
		ctx->qp_attr.min_rnr_timer = qp->attr.min_rnr_timer;
		ctx->qp_attr_mask |= YIB_QP_MIN_RNR_TIMER;
		if (r2100_can_modify_qpc(cur_qp_state, qp_state, mask, qp->qp_type)) {
			yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "write qpc: min_rnr_timer\n");
			yib_hwres_write(sflow, YIB_SFLOW_RNR_TIME_TO_WAIT, qp->attr.min_rnr_timer);
		}		
	}

	if (mask & IB_QP_PORT) {
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "qp:%d port_num=0x%x\n", 
				index, qp->attr.port_num);
		ctx->qp_attr.port_num = qp->attr.port_num;
		ctx->qp_attr_mask |= YIB_QP_PORT;
		if (r2100_can_modify_qpc(cur_qp_state, qp_state, mask, qp->qp_type)) {
			yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "write qpc: port_num\n");
			yib_hwres_write(sqc_entry, YIB_SQC_PORT_ID, qp->attr.port_num);
		}
	}

	if (mask & IB_QP_TIMEOUT) {//todo, 放在流控的class
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "qp:%d timeout=0x%x\n", 
				index, qp->attr.timeout);
		ctx->qp_attr.timeout = qp->attr.timeout;
		ctx->qp_attr_mask |= YIB_QP_TIMEOUT;
	}

	if (mask & IB_QP_RETRY_CNT) {
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "qp:%d retry_cnt=0x%x\n", 
				index, qp->attr.retry_cnt);
		ctx->qp_attr.retry_cnt = qp->attr.retry_cnt;
		ctx->qp_attr_mask |= YIB_QP_RETRY_CNT;
		if (r2100_can_modify_qpc(cur_qp_state, qp_state, mask, qp->qp_type)) {
			yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "write qpc: retry_cnt\n");
			yib_hwres_write(cflow, YIB_CFLOW_RE_TXMITS_COUNT_INIT_VALUE, qp->attr.retry_cnt);
		}
	}

	if (mask & IB_QP_RNR_RETRY) {
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "qp:%d rnr_retry=0x%x\n", 
				index, qp->attr.rnr_retry);
		ctx->qp_attr.rnr_retry = qp->attr.rnr_retry;
		ctx->qp_attr_mask |= YIB_QP_RNR_RETRY;
		if (r2100_can_modify_qpc(cur_qp_state, qp_state, mask, qp->qp_type)) {
			yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "write qpc: rnr_retry\n");
			yib_hwres_write(cflow, YIB_CFLOW_RNR_RE_TXMITS_COUNT_INIT_VALUE, qp->attr.rnr_retry);
		}
	}

	if (mask & IB_QP_AV) {
		struct yib_av *av = &qp->pri_av;
		struct yib_hw_av *hw_av;

		ctx->qp_attr_mask |= YIB_QP_AV;
		hw_av = &ctx->qp_attr.av;
		r2100_fill_av(hw_av, av);

		if (r2100_can_modify_qpc(cur_qp_state, qp_state, mask, qp->qp_type)) {
			yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "write qpc: av\n");
			hw_av = &qpc_entry->av;
			r2100_fill_av(hw_av, av);
		}
	}

modify:
	ret = yib_fw_cmd_modify_qp(sf, &r2100_sf->fw, index, ctx);
	if (ret) {
		os_printe(sf->hw->dev, "modify qp failed");
		return false;
	}

	if (state_chg) {
		if (qp->attr.qp_state == IB_QPS_RESET) {
			r2100_reset_qpc(sf, qp);
		} else if (qp->attr.qp_state == IB_QPS_SQD) {
			qp->attr.sq_draining = 1;
		}
	}
	return true;
}

int r2100_qp_query(struct yib_sf *sf, struct yib_qp *qp, os_qp_attr *attr, int mask, bool bdebug)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_fw_query_qp_ctx ctx;
	u32 index = qp->entry.index;

	if (yib_fw_cmd_query_qp(sf, &r2100_sf->fw, index, &ctx, bdebug)) {
		os_printe(sf->hw->dev, "query qp failed");
		return -EAGAIN;
	}

	if (bdebug == 0) {
		attr->qp_state = ctx.qp_state;
		attr->sq_psn = ctx.sq_psn;
		attr->rq_psn = ctx.rq_psn;
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_QUERY, "query qp: %d qp_state: %d sq_psn: %d rq_psn: %d\n", 
				index, attr->qp_state, attr->sq_psn, attr->rq_psn);
	} else {
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_QUERY, "query qp: %d\n", index);
		r2100_debugfs_print_qpc(sf, qp, false);
	}
	return 0;
}

int r2100_qp_debugfs(struct yib_sf *sf, struct yib_qp *qp)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	u32 index = yib_get_qp_sw_idx(qp);
	int ret = 0;

	ret = yib_fw_cmd_query_qp(sf, &r2100_sf->fw, index, NULL, true);
	if (ret) {
		os_printe(sf->hw->dev, "query qp failed");
		return ret;
	}

	pr_info("qp index: %d\n", index);
	r2100_debugfs_print_qpc(sf, qp, true);
	return 0;
}

void r2100_sf_debugfs(struct yib_sf *sf)
{
	r2100_debugfs_print_channel(sf);
}






