#ifndef _YUSUR_IB_R2100_DBG_H_
#define _YUSUR_IB_R2100_DBG_H_


void r2100_dbg_print_channel(struct yib_sf *sf);
void r2100_debugfs_print_cqc(void *buf, bool bdbg);
void r2100_debugfs_print_mpt(void *buf, bool bdbg);
void r2100_debugfs_print_qpc(struct yib_sf *sf, struct yib_qp *yqp, bool bdbg);
void r2100_debugfs_print_rqc(void *buf, bool bdebug);
void r2100_debugfs_print_nqc(void *buf, bool bdebug);
void r2100_debugfs_print_channel(struct yib_sf *sf);
void r2100_debugfs_print_smac(struct yib_hw_host *hw);
void r2100_debugfs_print_sgid(struct yib_hw_host *hw);
void r2100_debugfs_print_bar(void *buf, u32 size);
void r2100_debugfs_print_mem(u64 addr, u32 len);
void r2100_dbg_print_fw_cmd(struct yib_fw_req *req);

#endif


