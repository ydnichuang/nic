#include "r2100_cfg.h"
#include "../../include/basic.h"
#include "../../include/os_api.h"
#include "../../include/os_ds.h"
#include "../../include/mem.h"
#include "../../include/queue.h"
#include "../../include/host.h"
#include "../../include/verbs.h"
#include "../../include/yusur_ib.h"
#include "../../include/user.h"
#include "../hostpriv.h"
#include "../hwcomn.h"
#include "rdma-header/include/yib_inc_hw.h"
#include "rdma-header/include/yib_inc_fw.h"
#include "rdma-header/include/yib_inc_base.h"
#include "r2100_sf.h"
#include "r2100_fw.h"
#include "r2100_fw_cmd.h"
#include "r2100_dbg.h"
#include "r2100_host.h"

#if (COUNTER_STAT_DESC)
static const struct rdma_stat_desc r2100_counter_name[] = {
	[YIB_CNT_LINK_DOWN].name      	=  "link_downed",
};
#else
static const char * const r2100_counter_name[] = {
	[YIB_CNT_LINK_DOWN]      =  "link_downed",
};
#endif

#if (COUNTER_STAT_DESC)
static const struct rdma_stat_desc hadep_counter_name[] = {
	[YIB_CNT_LINK_DOWN].name      	=  "link_downed",
	[HADEP_CNT_SENT_PKTS].name      =  "send_pkts",
	[HADEP_CNT_RCVD_PKTS].name      =  "rcvd_pkts",
	[HADEP_CNT_DUP_REQ].name      =  "dup_req",
	[HADEP_CNT_OUT_OF_SEQ_REQ].name      =  "out_of_seq_req",
	[HADEP_CNT_RCV_RNR].name      =  "rcv_rnr",
	[HADEP_CNT_SND_RNR].name      =  "snd_rnr",
	[HADEP_CNT_RCV_SEQ_ERR].name      =  "rcv_seq_err",
	[HADEP_CNT_COMPLETER_SCHED].name      =  "completer_sched",
	[HADEP_CNT_RETRY_EXCEEDED].name      =  "retry_exceeded",
	[HADEP_CNT_RNR_RETRY_EXCEEDED].name      =  "rnr_retry_exceeded",
	[HADEP_CNT_COMP_RETRY].name      =  "comp_retry",
	[HADEP_CNT_SEND_ERR].name      =  "send_err",
	[HADEP_CNT_LINK_DOWNED].name      =  "hadep_link_downed",
	[HADEP_CNT_RDMA_SEND].name     =  "rdma_send",
	[HADEP_CNT_RDMA_RECV].name      =  "rdma_recv",
	[HADEP_CNT_SEND_CNP].name      =  "send_cnp",
	[HADEP_CNT_RECV_CNP].name      =  "recv_cnp",
	[HADEP_CNT_RECV_ECN].name      =  "recv_ecn",
};
#else
static const char * const hadep_counter_name[] = {
	[YIB_CNT_LINK_DOWN]      	=  "link_downed",
	[HADEP_CNT_SENT_PKTS]      =  "send_pkts",
	[HADEP_CNT_RCVD_PKTS]      =  "rcvd_pkts",
	[HADEP_CNT_DUP_REQ]      =  "dup_req",
	[HADEP_CNT_OUT_OF_SEQ_REQ]      =  "out_of_seq_req",
	[HADEP_CNT_RCV_RNR]      =  "rcv_rnr",
	[HADEP_CNT_SND_RNR]      =  "snd_rnr",
	[HADEP_CNT_RCV_SEQ_ERR]     =  "rcv_seq_err",
	[HADEP_CNT_COMPLETER_SCHED]     =  "completer_sched",
	[HADEP_CNT_RETRY_EXCEEDED]     =  "retry_exceeded",
	[HADEP_CNT_RNR_RETRY_EXCEEDED]      =  "rnr_retry_exceeded",
	[HADEP_CNT_COMP_RETRY]      =  "comp_retry",
	[HADEP_CNT_SEND_ERR]      =  "send_err",
	[HADEP_CNT_LINK_DOWNED]      =  "hadep_link_downed",
	[HADEP_CNT_RDMA_SEND]     =  "rdma_send",
	[HADEP_CNT_RDMA_RECV]      =  "rdma_recv",
	[HADEP_CNT_SEND_CNP]      =  "send_cnp",
	[HADEP_CNT_RECV_CNP]      =  "recv_cnp",
	[HADEP_CNT_RECV_ECN]      =  "recv_ecn",
};
#endif

int r2100_init_caps(struct yib_hw_host *hw, struct yib_sf *sf)
{
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	struct yib_fw_roce_caps fw_caps;
	struct yib_roce_caps *caps = &hw->caps;
	struct yib_dev_funcs *func = &hw->funcs;
	int ret = 0;
	
	memset(&fw_caps, 0, sizeof(fw_caps));
	ret = yib_fw_cmd_query_device(sf, &r2100_sf->fw, &fw_caps);
	if (ret) {
		os_printe(sf->hw->dev, "query device failed");
		return -EAGAIN;
	}

#if(!R2100_SW_DEBUG_ON)
	if (fw_caps.max_irq_for_channel < 2) {
		os_printe(sf->hw->dev, "max_irq_for_channel < 2");
		return -EINVAL;
	}
#endif

#if(!R2100_SW_DEBUG_ON)
	caps->fw_ver = fw_caps.fw_ver_lsb | ((u64)fw_caps.fw_ver_msb << 32);
	caps->hw_ver = fw_caps.hw_ver_lsb | ((u64)fw_caps.hw_ver_msb << 32);
	caps->num_ports = fw_caps.sf_max_port;
	caps->num_qps = fw_caps.sf_max_qp;
	caps->num_cqs = fw_caps.sf_max_cq;
	caps->max_mr = fw_caps.sf_max_mr;
	caps->max_srqs = fw_caps.sf_max_srq;
	caps->num_comp_vector = fw_caps.max_irq_for_channel - 1;
	caps->max_mcast_qps = fw_caps.max_mcast_qps;
	caps->max_mcast_grp = fw_caps.max_mcast_grp;
#else
	caps->fw_ver = 1;
	caps->hw_ver = 1;
	caps->num_ports = 8;
	caps->num_qps = 256;
	caps->num_cqs = 512;
	caps->max_mr = 1024;
	caps->max_srqs = 128;
	caps->num_comp_vector = 2;
	caps->max_mcast_qps = 0;
	caps->max_mcast_grp = 0;
#endif

	caps->max_rqs = caps->num_qps;
	caps->max_res_rd_atom = 16;	
	caps->num_pds = 16384; 
	caps->max_mr_sgs = 1024*1024;
	caps->max_eqs = 2048;
	caps->max_sq_inline = 208;
	caps->max_qp_wr = 32*1024;
	caps->max_cqes = 64*1024;
	caps->max_srqes = 32*1024;
	caps->max_rq_sg = 3;
	caps->max_sq_sg = 18;
	caps->page_size_cap = 0xFFFFF000;
	caps->max_mtu = IB_MTU_4096;
	caps->max_qp_init_rd_atom = 16;
	caps->max_qp_rd_atom = 16;
	caps->max_ah = 64*1024;
	caps->max_mr_size = caps->max_mr_sgs * (u64)(4*1024*1024*1024ull);//一个mr最多的内存数

#if(!R2100_SW_DEBUG_ON)
	func->ud_multicast = yib_hwres_read(&fw_caps, YIB_CAPS_UD_MCAST);
	func->srq_supp     = yib_hwres_read(&fw_caps, YIB_CAPS_SRQ);
	func->srq_limit    = yib_hwres_read(&fw_caps, YIB_CAPS_SRQ_LIMIT);
	func->xrc_supp     = yib_hwres_read(&fw_caps, YIB_CAPS_XRC);
	func->ud_supp      = yib_hwres_read(&fw_caps, YIB_CAPS_UD);
	func->uc_supp      = yib_hwres_read(&fw_caps, YIB_CAPS_UC);
	func->srq_modify   = yib_hwres_read(&fw_caps, YIB_CAPS_SRQ_MODIFY);
	func->mw_supp      = yib_hwres_read(&fw_caps, YIB_CAPS_MW);
	func->atomic_supp  = yib_hwres_read(&fw_caps, YIB_CAPS_ATOMIC);
	func->quick_excep  = yib_hwres_read(&fw_caps, YIB_CAPS_QUICK_EXECP);
	func->sw_err_flush  = yib_hwres_read(&fw_caps, YIB_CAPS_SW_ERR_FLUSH);
	func->srq_seq  = yib_hwres_read(&fw_caps, YIB_CAPS_SRQ_SEQ);
	func->queue_l2_tbl  = yib_hwres_read(&fw_caps, YIB_CAPS_QUEUE_L2_TBL);
	func->mr_l2_tbl  = yib_hwres_read(&fw_caps, YIB_CAPS_MR_L2_TBL);

	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "fw_ver: %llx\n", caps->fw_ver);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "hw_ver: %llx\n", caps->hw_ver);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "num_ports: %u\n", caps->num_ports);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "num_qps: %u\n", caps->num_qps);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "num_cqs: %u\n", caps->num_cqs);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "max_mr: %u\n", caps->max_mr);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "max_srqs: %u\n", caps->max_srqs);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "num_comp_vector: %u\n", caps->num_comp_vector);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "max_mcast_qps: %u\n", caps->max_mcast_qps);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "max_mcast_grp: %u\n", caps->max_mcast_grp);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "funcs: 0x%x\n", fw_caps.support);
#else
	func->ud_multicast = 0;
	func->srq_supp     = 0;
	func->srq_limit    = 0;
	func->xrc_supp     = 0;
	func->ud_supp      = 1;
	func->uc_supp      = 0;
	func->srq_modify   = 0;
	func->mw_supp      = 0;
	func->atomic_supp  = 0;
	func->quick_excep  = 0;
	func->sw_err_flush = 0;
	func->srq_seq  	   = 0;
	func->queue_l2_tbl = 0;
	func->mr_l2_tbl    = 1;
#endif
	return 0;
}

void r2100_global_reset(struct yib_hw_host *hw)
{
	hw->vf_id = 0;
	hw->pf_id = 0;
	hw->host_id = 0;
	//todo
}

int r2100_hadep_start_host(struct yib_hw_host *hw)
{
#if(!R2100_SW_DEBUG_ON)	
	unsigned long start_time = jiffies;
	unsigned long jiffies_timeout = msecs_to_jiffies(R2100_HOST_WAIT_TIME);

	if (hw->chip_subtype == YRDMA_SUB_R2100_HADEP_1) {
		r2100_write_reg32(hw->reg_base[0], R2100_HADEP_RDMA_REG_BASE + R2100_HADEP_DEV_SET_STATE, R2100_HADEP_DEV_START);
		while (time_before(jiffies, start_time + jiffies_timeout)) {
		    if (r2100_read_reg32(hw->reg_base[0], R2100_HADEP_RDMA_REG_BASE + R2100_HADEP_DEV_GET_STATE) == R2100_HADEP_DEV_START) {
		        break;
		    }
		    os_msleep(1);
	    }
	}
#endif
	//todo
	return 0;
}

void r2100_hadep_stop_host(struct yib_hw_host *hw)
{
#if(!R2100_SW_DEBUG_ON)
	unsigned long start_time = jiffies;
	unsigned long jiffies_timeout = msecs_to_jiffies(R2100_HOST_WAIT_TIME);

	if (hw->chip_subtype == YRDMA_SUB_R2100_HADEP_1) {
		r2100_write_reg32(hw->reg_base[0], R2100_HADEP_RDMA_REG_BASE + R2100_HADEP_DEV_SET_STATE, R2100_HADEP_DEV_END);
		while (time_before(jiffies, start_time + jiffies_timeout)) {
		    if (r2100_read_reg32(hw->reg_base[0], R2100_HADEP_RDMA_REG_BASE + R2100_HADEP_DEV_GET_STATE) == R2100_HADEP_DEV_END) {
		        break;
		    }
		    os_msleep(1);
	    }
	}
#endif
	//todo
}

int r2100_start_host(struct yib_hw_host *hw)
{
	r2100_hadep_start_host(hw);
	return 0;
}

void r2100_stop_host(struct yib_hw_host *hw)
{
	r2100_hadep_stop_host(hw);
}

void r2100_shutdown_host(struct yib_hw_host *hw)
{
	r2100_stop_sf(&hw->sf, true);
	r2100_hadep_stop_host(hw);
}

int r2100_set_qos(struct yib_hw_host *hw, struct yib_rdma_qos_info *qos_info)
{
	struct yib_sf *sf = &hw->sf;
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	int ret = 0;

	ret = yib_fw_cmd_set_qos(sf, &r2100_sf->fw, qos_info);
	if (ret) {
		os_printe(sf->hw->dev, "set_qos failed");
		return -EAGAIN;
	}
	
	return 0;
}

int r2100_set_rx_buf_size(struct yib_hw_host *hw)
{
	return -ENOENT;
}

#if (COUNTER_STAT_DESC)	
const struct rdma_stat_desc  *r2100_get_counter_info(struct yib_hw_host *hw, u32 *count)
#else
const char * const *r2100_get_counter_info(struct yib_hw_host *hw, u32 *count)
#endif
{
	if (hw->chip_subtype == YRDMA_SUB_R2100_HADEP_1) {
		*count = HADEP_NUM_OF_COUNTERS;
		return hadep_counter_name;
	} else {
		*count = R2100_NUM_OF_COUNTERS;
		return r2100_counter_name;
	}
}

void r2100_get_hw_counter(struct yib_hw_host *hw, u64 *value, u32 port_num)
{
	int i = 0;
	u32 length = 0;
	struct yib_sf *sf = &hw->sf;
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	unsigned long jiffies_timeout = msecs_to_jiffies(R2100_CNT_WAIT_TIME_MS);

	if (time_after(jiffies, (unsigned long)r2100_sf->get_couter_tick + jiffies_timeout)) {
		if (yib_fw_cmd_get_stats(sf, &r2100_sf->fw, (u8 *)r2100_sf->counter_val, &length)) {
			os_printe(sf->hw->dev, "get stats failed\n");
			return;
		}
		if (length != sizeof(r2100_sf->counter_val[0]) * (hw->hw_counter_cnt - 1)) {
			os_printe(sf->hw->dev, "get stats length %d error\n", length);
		}
		r2100_sf->get_couter_tick = jiffies;
	}

	for (i = 0; i < hw->hw_counter_cnt; i++) {
		switch (i) {
			case YIB_CNT_LINK_DOWN:
				value[i] = hw->ndev_info[port_num - 1].link_down;
				break;
			default:
				value[i] = r2100_sf->counter_val[i - 1];
				break;
		}
	}
}

int r2100_host_reg_mmap(struct yib_hw_host *hw, struct vm_area_struct *vma, ssize_t length, u64 offset)
{
#if(!R2100_SW_DEBUG_ON)
	u64 bar_addr = 0;
	bar_addr = yusur_hw_get_bar_pa_by_off(hw, 0, offset);
	if (bar_addr == 0) {
		os_printe(hw->dev, "bar_addr invalid");
		return -EINVAL;
	} else {
		if (io_remap_pfn_range(vma, vma->vm_start, bar_addr >> PAGE_SHIFT,
							length, vma->vm_page_prot)) {
			os_printe(hw->dev, "Failed to map device memory");
			return -EAGAIN;
		}
	}
#endif
	return 0;
}

int r2100_host_def_mmap(struct yib_hw_host *hw, struct vm_area_struct *vma, ssize_t length, u64 offset, int type)
{
	return 0;
}

int r2100_get_usable_channels(struct yib_hw_host *hw)
{
	struct yib_sf *sf = &hw->sf;
	struct r2100_yib_sf *r2100_sf = sf->sf_priv;
	int ret =0;
	
	ret = yib_fw_cmd_query_left_channels(sf, &r2100_sf->fw);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "left channles: %d\n", ret);
	
	return ret;
}

void r2100_get_queue_user_info(struct yib_hw_host *hw, enum yib_elem_type type, void *verbs, u32 hw_id, u8 *res, int *len)
{
	*len = 0;
	switch(type) {
	case YIB_TYPE_PD:
	{
		struct yib_ib_alloc_uctx_resp uctx;
		uctx.bar_offset = R2100_SF_START_OFFSET;//hw->sf->hw_base_off for other type
		uctx.bar_map_len = hw->sf.bar_size[0] - R2100_SF_START_OFFSET; //yusur_hw_get_bar_len(hw) for other type
		uctx.cq_isize = hw->hw_ops.queue_ops->cqe_isize;
		uctx.chip_type = hw->hw_ops.host_type;
		uctx.chip_subtype = hw->chip_subtype;
		uctx.quick_excep = (hw->funcs.quick_excep == 0)? 0 : 1;
		uctx.sw_err_flush = (hw->funcs.sw_err_flush == 0)? 0 : 1;
		*len = sizeof(struct yib_ib_alloc_uctx_resp);
		memcpy(res, &uctx, *len);
		break;
	}
	case YIB_TYPE_CQ:
	{
		struct yib_ib_create_cq_resp cq;
		struct yib_cq *ycq = (struct yib_cq*)verbs;
		cq.cqid = hw_id;
		cq.max_cqe = ycq->queue->depth;
		*len = sizeof(struct yib_ib_create_cq_resp);
		memcpy(res, &cq, *len);
		break;
	}
	case YIB_TYPE_QP:
	{
		struct yib_ib_create_qp_resp qp;
		struct yib_qp *yqp = (struct yib_qp*)verbs;
		qp.qpid = yib_get_qp_sw_idx(yqp);
		qp.capture_pa = 0;
		qp.nvme_rq_rqe_pa = 0;
		qp.max_send_wr = yqp->cap.max_send_wr;
		qp.max_recv_wr = yqp->cap.max_recv_wr;
		qp.max_send_sge = yqp->cap.max_send_sge;
		qp.max_recv_sge = yqp->cap.max_recv_sge;
		qp.max_inline_data = yqp->cap.max_inline_data;
		qp.send_isize = yqp->ysq.queue->item_size;
		if ((yqp->use_srq == false) && (yqp->type.yrq != NULL)) {
			qp.rqid = yib_get_rq_sw_idx(yqp->type.yrq);
			qp.recv_isize = yqp->type.yrq->queue->item_size;
		} else if (yqp->use_srq && yqp->qp_type != IB_QPT_XRC_TGT) {
			qp.rqid = yib_get_rq_sw_idx(yqp->type.ysrq->yrq);
			qp.recv_isize = yqp->type.ysrq->yrq->queue->item_size;
		} else {
			qp.rqid = 0;
			qp.recv_isize = 0;
		}
		*len = sizeof(struct yib_ib_create_qp_resp);
		memcpy(res, &qp, *len);
		break;
	}
	case YIB_TYPE_RQ:
	{
		struct yib_ib_create_srq_resp srq;
		struct yib_srq *ysrq = (struct yib_srq*)verbs;
		srq.srqid = hw_id;
		srq.max_sge = ysrq->attr.max_sge;
		srq.max_wr = ysrq->attr.max_wr;
		srq.isize = ysrq->yrq->queue->item_size;
		*len = sizeof(struct yib_ib_create_srq_resp);
		memcpy(res, &srq, *len);
		break;
	}
	default:
		*len = 0;
		break;
	}
}

void r2100_host_debugfs_reg(struct yib_hw_host *hw)
{
	r2100_debugfs_print_bar((void *)hw->reg_base[0], hw->bar_size[0]);
}

void r2100_host_debugfs_mem(struct yib_hw_host *hw, u32 len, u64 addr)
{
	r2100_debugfs_print_mem(addr, len);
}

void r2100_smac_debugfs(struct yib_hw_host *hw)
{
	r2100_debugfs_print_smac(hw);
}

void r2100_sgid_debugfs(struct yib_hw_host *hw)
{
	r2100_debugfs_print_sgid(hw);
}




