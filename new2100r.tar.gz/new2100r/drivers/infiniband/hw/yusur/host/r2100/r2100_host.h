#ifndef _YUSUR_IB_R2100_HOST_H_
#define _YUSUR_IB_R2100_HOST_H_

#define R2100_CNT_WAIT_TIME_MS	50

typedef enum {
	R2100_CNT_SENT_PKTS = 1,
	R2100_NUM_OF_COUNTERS,
} r2100_stat_type;

typedef enum {
	HADEP_CNT_SENT_PKTS = 1,
	HADEP_CNT_RCVD_PKTS,
	HADEP_CNT_DUP_REQ,
	HADEP_CNT_OUT_OF_SEQ_REQ,
	HADEP_CNT_RCV_RNR,
	HADEP_CNT_SND_RNR,
	HADEP_CNT_RCV_SEQ_ERR,
	HADEP_CNT_COMPLETER_SCHED,
	HADEP_CNT_RETRY_EXCEEDED,
	HADEP_CNT_RNR_RETRY_EXCEEDED,
	HADEP_CNT_COMP_RETRY,
	HADEP_CNT_SEND_ERR,
	HADEP_CNT_LINK_DOWNED,
	HADEP_CNT_RDMA_SEND,
	HADEP_CNT_RDMA_RECV,
	HADEP_CNT_SEND_CNP,
	HADEP_CNT_RECV_CNP,
	HADEP_CNT_RECV_ECN,
	HADEP_NUM_OF_COUNTERS,
} hadep_stat_type;

int r2100_init_caps(struct yib_hw_host *hw, struct yib_sf *sf);
void r2100_global_reset(struct yib_hw_host *hw);
int r2100_start_host(struct yib_hw_host *hw);
void r2100_stop_host(struct yib_hw_host *hw);
void r2100_shutdown_host(struct yib_hw_host *hw);
int r2100_set_qos(struct yib_hw_host *hw, struct yib_rdma_qos_info *qos_info);
int r2100_set_rx_buf_size(struct yib_hw_host *hw);
void r2100_get_hw_counter(struct yib_hw_host *hw, u64 *value, u32 port_num);
int r2100_host_reg_mmap(struct yib_hw_host *hw, struct vm_area_struct *vma, ssize_t length, u64 offset);
int r2100_host_def_mmap(struct yib_hw_host *hw, struct vm_area_struct *vma, ssize_t length, u64 offset, int type);
int r2100_get_usable_channels(struct yib_hw_host *hw);
void r2100_get_queue_user_info(struct yib_hw_host *hw, enum yib_elem_type type, void *verbs, u32 hw_id, u8 *res, int *len);
void r2100_host_debugfs_reg(struct yib_hw_host *hw);
void r2100_host_debugfs_mem(struct yib_hw_host *hw, u32 len, u64 addr);
void r2100_smac_debugfs(struct yib_hw_host *hw);
void r2100_sgid_debugfs(struct yib_hw_host *hw);
#if (COUNTER_STAT_DESC)	
const struct rdma_stat_desc  *r2100_get_counter_info(struct yib_hw_host *hw, u32 *count);
#else
const char * const *r2100_get_counter_info(struct yib_hw_host *hw, u32 *count);
#endif

#endif


