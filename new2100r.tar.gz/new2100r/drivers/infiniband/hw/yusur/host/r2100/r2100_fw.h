#ifndef _YUSUR_IB_R2100_FW_H_
#define _YUSUR_IB_R2100_FW_H_


struct yib_fw_cmd_ctl
{
	void *in_buf;
	void *out_buf;
	int in_buf_len;
	int out_buf_len;
};

int yib_fw_init(struct yib_sf *sf, struct r2100_fw *fw);
void yib_fw_exit(struct yib_sf *sf, struct r2100_fw *fw);
void yib_cplq_advance_ci(struct r2100_fw *fw, int diff);
void* yib_cplq_get_vaddr(struct r2100_fw *fw);
int yib_fw_send_cmd_and_wait(struct yib_sf *sf, struct r2100_fw *fw, struct yib_fw_req *req, 
				struct cplq_entry *entry, bool bcheck, int wait_time);
int yib_fw_send_cmd_and_wait_ext(struct yib_sf *sf, struct r2100_fw *fw, struct yib_fw_req *req, 
				struct cplq_entry *entry, bool bcheck, int wait_time, struct yib_fw_cmd_ctl *ctl);

#endif


