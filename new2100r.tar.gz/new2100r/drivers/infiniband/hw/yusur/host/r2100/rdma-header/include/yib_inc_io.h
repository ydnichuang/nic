#ifndef _YIB_INC_IO_H
#define _YIB_INC_IO_H


#include "yib_inc_base.h"
#include "yib_inc_hw_base.h"

enum yib_wqe_type {
    YIB_WQE_SEND = 0,
    YIB_WQE_SEND_WITH_IMM = 1,
    YIB_WQE_SEND_WITH_INV = 2,
    YIB_WQE_RDMA_WRITE = 4,
    YIB_WQE_RDMA_WRITE_WITH_IMM = 5,
    YIB_WQE_READ = 6,
    YIB_WQE_ATOMIC_CAS = 8,
    YIB_WQE_ATOMIC_FETCH_ADD = 9,
    YIB_WQE_LOCAL_INV = 12,
    YIB_WQE_FR_PMR = 13,
    YIB_WQE_MEM_BIND = 14,
    YIB_WQE_RECV = 128
};

struct yib_hw_sge {
    __le32 addr_l;
    __le32 addr_h;
    __le32 l_key;
    __le32 size;
};//16字节

#define YIB_SGE_FIELD_LOC(h, l) YIB_FIELD_LOC(struct yib_hw_sge, h, l)
#define YIB_SGE_VA_OR_PA_LSB    YIB_SGE_FIELD_LOC(31, 0)
#define YIB_SGE_VA_OR_PA_MSB    YIB_SGE_FIELD_LOC(63, 32)
#define YIB_SGE_L_KEY    YIB_SGE_FIELD_LOC(95, 64)
#define YIB_SGE_SIZE    YIB_SGE_FIELD_LOC(127, 96)

struct yib_hw_cqe {
    __le32 wqeidx_pipenum;      //[15:0]wqe_idx; [23:16]pipe_num; [31:24]status
    __le32 qp_handle_lsb;       //[31:0]qp_handle_lsb
    __le32 qp_handle_msb;       //[31:0]qp_handle_msb
    __le32 byte_len;    //[31:0]byte_len
    __le32 immdata_or_invkey;
    __le32 byte20_23;   //如果是RC, [31:0]mr_handle_lsb; 如果是UD, [31:0]src_mac_lsb
    __le32 byte24_27;   //如果是RC, [63:32]mr_handle_msb; 如果是UD, [15:0]src_mac_msb, [31:16]src_qpn
    __le32 opcode_toggle;   //[7:0]opcode; [10:8]cqe_type; [11:11]special_cqe; [12:12]network_type; [27:16]vlan_id; [31:31]toggle
};//32字节

#define YIB_CQE_FIELD_LOC(h, l) YIB_FIELD_LOC(struct yib_hw_cqe, h, l)
#define YIB_CQE_WQE_IDX    YIB_CQE_FIELD_LOC(15, 0)     //该CQE对应的WQEs_index
#define YIB_CQE_PIPE_NUM    YIB_CQE_FIELD_LOC(23, 16)    //全0时，表示硬件流水线无错误，有错误时，为硬件流水线编码
#define YIB_CQE_STATUS    YIB_CQE_FIELD_LOC(31, 24)    //全0时，任务正常结束，非0时有异常
#define YIB_CQE_QP_HANDLE_LSB    YIB_CQE_FIELD_LOC(63, 32)  //qp_handle[31:0]
#define YIB_CQE_QP_HANDLE_MSB    YIB_CQE_FIELD_LOC(95, 64)  //qp_handle[63:32] 
#define YIB_CQE_BYTE_LEN    YIB_CQE_FIELD_LOC(127, 96) //for sever send
#define YIB_CQE_IMMDATA_OR_INVKEY    YIB_CQE_FIELD_LOC(159, 128)  //immediate data或者invalidate key
#define YIB_CQE_MR_HANDLE_LSB    YIB_CQE_FIELD_LOC(191, 160)  //mr_handle[31:0]
#define YIB_CQE_SRC_MAC_LSB    YIB_CQE_FIELD_LOC(191, 160)  //src_mac[31:0]
#define YIB_CQE_MR_HANDLE_MSB    YIB_CQE_FIELD_LOC(223, 192)  //mr_handle[63:32]
#define YIB_CQE_SRC_MAC_MSB    YIB_CQE_FIELD_LOC(207, 192)  //src_mac[47:32]
#define YIB_CQE_SRC_QPN    YIB_CQE_FIELD_LOC(223, 208)  //源qpn
#define YIB_CQE_OPCODE    YIB_CQE_FIELD_LOC(231, 224)    //对应wqe的操作码
#define YIB_CQE_CQE_TYPE    YIB_CQE_FIELD_LOC(234, 232) //0:client cqe; 1:server for rq cqe; 2:server for srq cqe; 7:cq resize
#define YIB_CQE_SPECIAL_CQE    YIB_CQE_FIELD_LOC(235, 235)  //0表示普通CQE，1表示CQE具体格式由固件和驱动决定
#define YIB_CQE_NETWORK_TYPE    YIB_CQE_FIELD_LOC(236, 236)    //0:IPv4; 1:IPv6
#define YIB_CQE_VLAN_ID    YIB_CQE_FIELD_LOC(251, 240)  //12bit的vlan id
#define YIB_CQE_TOGGLE    YIB_CQE_FIELD_LOC(255, 255) //软件通过该bit判断硬件是否更新。软件初始化为0，第一轮硬件填写1，当队列满后，翻转该位

struct yib_hw_rc_wqe {
    __le32 wqetype_signalcomp;  //[7:0]wqe_type; [8:8]signal_comp; [9:9]rd_or_atomic_fence_flag; 
                                //[10:10]uc_fence_flag; [11:11]se_flag; [12:12]inline_flag; [23:16]wqe_size
    union { 
        __le32 length;
        __le32 swap_data_lsb;
        __le32 add_data_lsb;
    } length_data;
    union { 
        __le32 inv_key;
        __le32 imm_data;
        __le32 swap_data_msb;
        __le32 add_data_msb;
    } key_data;
    __le32 remote_va_lsb;   //[31:0]remote_va_lsb
    __le32 remote_va_msb;   //[31:0]remote_va_msb
    __le32 remote_key;  //[31:0]remote_key
    __le32 com_data_lsb;   //[31:0]com_data_lsb
    __le32 com_data_msb;   //[31:0]com_data_msb
};//32字节

#define YIB_RC_WQE_FIELD_LOC(h, l) YIB_FIELD_LOC(struct yib_hw_rc_wqe, h, l)
#define YIB_RC_WQE_TYPE    YIB_RC_WQE_FIELD_LOC(7, 0)   //本WQEs的操作类型
#define YIB_RC_WQE_SIGNAL_COMP    YIB_RC_WQE_FIELD_LOC(8, 8)    //0:本WQEs不需要返回CQEs; 1:本WQEs需要返回CQEs
#define YIB_RC_WQE_RD_OR_ATOMIC_FENCE_FLAG    YIB_RC_WQE_FIELD_LOC(9, 9)    //本WQEs前面的read和atomic全部返回CQEs，才能执行WQEs
#define YIB_RC_WQE_UC_FENCE_FLAG    YIB_RC_WQE_FIELD_LOC(10, 10)    //本WQEs前面的所有WQEs全部返回CQEs，本WQEs才能执行
#define YIB_RC_WQE_SE_FLAG    YIB_RC_WQE_FIELD_LOC(11, 11)  //solicit event flag，用于BTH header，只能在last或者only报文中使用
#define YIB_RC_WQE_INLINE_FLAG    YIB_RC_WQE_FIELD_LOC(12, 12)  //PLD是否由WQE自带，置1表示sge0和sge1为pld
#define YIB_RC_WQE_WQE_SIZE    YIB_RC_WQE_FIELD_LOC(23, 16)     //本WQE大小，粒度为16B，2^n *16B
#define YIB_RC_WQE_LENGTH_OR_SWAP_DATA_OR_ADD_DATA    YIB_RC_WQE_FIELD_LOC(63, 32)  //不同操作复用此字段, 非原子操作时为传输总长度; 
                                                        //原子操作时, compare swap的swap数的低32位, 或者为fetchadd的add数的低32位。
#define YIB_RC_WQE_INVKEY_OR_IMMDATA_OR_SWAP_DATA_OR_ADD_DATA    YIB_RC_WQE_FIELD_LOC(95, 64) //不同操作复用此字段, invalidate操作
                      //所无效的key; immdiate操作所携带的立即数; 原子操作compare swap的swap数的高32位, 原子操作fetchadd的add数的高32位。
#define YIB_RC_WQE_REMOTE_VA_LSB    YIB_RC_WQE_FIELD_LOC(127, 96)   //远端的虚拟地址[31:0]
#define YIB_RC_WQE_REMOTE_VA_MSB    YIB_RC_WQE_FIELD_LOC(159, 128)  //远端的虚拟地址[63:32]
#define YIB_RC_WQE_REMOTE_KEY    YIB_RC_WQE_FIELD_LOC(191, 160)     //远端使用的key
#define YIB_RC_WQE_COM_DATA_LSB    YIB_RC_WQE_FIELD_LOC(223, 192)   //原子操作compare swap的compare数[31:0]
#define YIB_RC_WQE_COM_DATA_MSB    YIB_RC_WQE_FIELD_LOC(255, 224)   //原子操作compare swap的compare数[63:32]

struct yib_hw_fmr_bind {
    __le32 wqetype_signalcomp;  //[7:0]wqe_type; [8:8]signal_comp; [9:9]rd_or_atomic_fence_flag; 
                                //[10:10]uc_fence_flag; [11:11]se_flag; [12:12]inline_flag; [23:16]wqe_size
    __le32 qpn_state;   //[21:0]qpn; [25:24]state; [31:27]access_right
    __le32 pa0_lsb;     //[31:0]pa0_lsb
    __le32 pa0_msb;     //[31:0]pa0_msb
    __le32 pa1_lsb;     //[31:0]pa1_lsb
    __le32 pa1_msb;     //[19:0]pa1_msb
    __le32 size_lsb;    //[31:0]size_lsb
    __le32 size_msb;    //[31:0]size_msb
    __le32 va_lsb;      //[31:0]va_lsb
    __le32 va_msb;      //[31:0]va_msb
    __le32 parent_mr_idx_or_child_mw_count; //[31:8]parent_mr_idx_or_child_mw_count
    __le32 pbl_ba_lsb;  //[31:0]pbl_ba_lsb
    __le32 pbl_ba_msb;  //[19:0]pbl_ba_msb
    __le32 key;
    __le32 byte56_59;
    __le32 byte60_63;
};//64字节

#define YIB_FMR_BIND_FIELD_LOC(h, l) YIB_FIELD_LOC(struct yib_hw_fmr_bind, h, l)
#define YIB_FMR_BIND_WQE_TYPE    YIB_FMR_BIND_FIELD_LOC(7, 0)   //本WQEs的操作类型
#define YIB_FMR_BIND_SIGNAL_COMP    YIB_FMR_BIND_FIELD_LOC(8, 8)    //0:本WQEs不需要返回CQEs; 1:本WQEs需要返回CQEs
#define YIB_FMR_BIND_RD_OR_ATOMIC_FENCE_FLAG    YIB_FMR_BIND_FIELD_LOC(9, 9)    //本WQEs前面的read和atomic全部返回CQEs，才能执行WQEs
#define YIB_FMR_BIND_UC_FENCE_FLAG    YIB_FMR_BIND_FIELD_LOC(10, 10)    //本WQEs前面的所有WQEs全部返回CQEs，本WQEs才能执行
#define YIB_FMR_BIND_SE_FLAG    YIB_FMR_BIND_FIELD_LOC(11, 11)  //solicit event flag，用于BTH header，只能在last或者only报文中使用
#define YIB_FMR_BIND_INLINE_FLAG    YIB_FMR_BIND_FIELD_LOC(12, 12)  //PLD是否位于本控制域尾部
#define YIB_FMR_BIND_WQE_SIZE    YIB_FMR_BIND_FIELD_LOC(23, 16)     //本WQE大小，粒度为16B
#define YIB_FMR_BIND_QPN    YIB_FMR_BIND_FIELD_LOC(53, 32)  //拥有此MW的QPC的QID(qp标识号)。对于2A类，此字段仅在绑定操作成功后有效。
#define YIB_FMR_BIND_STATE    YIB_FMR_BIND_FIELD_LOC(57, 56)    //0:invalid(init状态); 1: free(收到invalid命令); 2:valid(可工作)
#define YIB_FMR_BIND_ACCESS_RIGHT    YIB_FMR_BIND_FIELD_LOC(63, 58) //0:远程读; 1:远程写; 2:远程原子操作; 3:本端写; 4:Bind
#define YIB_FMR_BIND_PA0_LSB    YIB_FMR_BIND_FIELD_LOC(95, 64)      //pa0[31:0]
#define YIB_FMR_BIND_PA0_MSB    YIB_FMR_BIND_FIELD_LOC(127, 96)     //pa0[63:32]
#define YIB_FMR_BIND_PA1_LSB    YIB_FMR_BIND_FIELD_LOC(159, 128)    //pa1[31:0]
#define YIB_FMR_BIND_PA1_MSB    YIB_FMR_BIND_FIELD_LOC(179, 160)    //pa1[51:32]
#define YIB_FMR_BIND_SIZE_LSB    YIB_FMR_BIND_FIELD_LOC(223, 192)   //MR/MW的大小，以字节为单位[31:0]
#define YIB_FMR_BIND_SIZE_MSB    YIB_FMR_BIND_FIELD_LOC(255, 224)   //MR/MW的大小，以字节为单位[63:32]
#define YIB_FMR_BIND_VA_LSB    YIB_FMR_BIND_FIELD_LOC(287, 256)     //va[31:0]
#define YIB_FMR_BIND_VA_MSB    YIB_FMR_BIND_FIELD_LOC(319, 288)     //va[63:32]
#define YIB_FMR_BIND_PARENT_MR_IDX_OR_CHILD_MW_COUNT    YIB_FMR_BIND_FIELD_LOC(351, 328)
#define YIB_FMR_BIND_PBL_BA_LSB    YIB_FMR_BIND_FIELD_LOC(383, 352) //pbl基地址[31:0]
#define YIB_FMR_BIND_PBL_BA_MSB    YIB_FMR_BIND_FIELD_LOC(403, 384) //pbl基地址[51:32]
#define YIB_FMR_BIND_KEY    YIB_FMR_BIND_FIELD_LOC(447, 416)

struct yib_hw_ud_wqe {
    __le32 wqetype_signalcomp;  //[7:0]wqe_type; [8:8]signal_comp; [9:9]rd_or_atomic_fence_flag; 
                                //[10:10]uc_fence_flag; [11:11]se_flag; [12:12]inline_flag; [23:16]wqe_size
    __le32 qpn_length;      //[15:0]dest_qpn; [31:16]length
    __le32 imm_data;    //[31:0]imm_data
    __le32 q_key;       //[31:0]q_key
    struct yib_hw_av av;
};//48字节

#define YIB_UD_WQE_FIELD_LOC(h, l) YIB_FIELD_LOC(struct yib_hw_ud_wqe, h, l)
#define YIB_UD_WQE_TYPE    YIB_UD_WQE_FIELD_LOC(7, 0)   //本WQEs的操作类型
#define YIB_UD_WQE_SIGNAL_COMP    YIB_UD_WQE_FIELD_LOC(8, 8)    //0:本WQEs不需要返回CQEs; 1:本WQEs需要返回CQEs
#define YIB_UD_WQE_RD_OR_ATOMIC_FENCE_FLAG    YIB_UD_WQE_FIELD_LOC(9, 9)    //本WQEs前面的read和atomic全部返回CQEs，才能执行WQEs
#define YIB_UD_WQE_UC_FENCE_FLAG    YIB_UD_WQE_FIELD_LOC(10, 10)    //本WQEs前面的所有WQEs全部返回CQEs，本WQEs才能执行
#define YIB_UD_WQE_SE_FLAG    YIB_UD_WQE_FIELD_LOC(11, 11)  //solicit event flag，用于BTH header，只能在last或者only报文中使用
#define YIB_UD_WQE_INLINE_FLAG    YIB_UD_WQE_FIELD_LOC(12, 12)  //PLD是否位于本控制域尾部，1表示位于尾部
#define YIB_UD_WQE_SIZE    YIB_UD_WQE_FIELD_LOC(23, 16)     //本WQE大小，粒度为16B，2^n *16B
#define YIB_UD_WQE_DEST_QPN    YIB_UD_WQE_FIELD_LOC(47, 32)   //目的qpn
#define YIB_UD_WQE_LENGTH    YIB_UD_WQE_FIELD_LOC(63, 48)   //传输长度
#define YIB_UD_WQE_IMM_DATA    YIB_UD_WQE_FIELD_LOC(95, 64) //immdiate操作所携带的立即数
#define YIB_UD_WQE_Q_KEY    YIB_UD_WQE_FIELD_LOC(127, 96)   //q_key

struct yib_hw_rq_wqe {
    __le32 type_rqeindex;   //[7:0]type; [31:8]rqe_index
    __le32 length;    //[31:0]length
    __le32 wqe_size;    //[7:0]wqe_size
    __le32 byte12_15;
};//16字节

#define YIB_RQ_WQE_FIELD_LOC(h, l) YIB_FIELD_LOC(struct yib_hw_rq_wqe, h, l)
#define YIB_RQ_WQE_TYPE    YIB_RQ_WQE_FIELD_LOC(7, 0)   //本WQEs的操作类型
#define YIB_RQ_WQE_RQE_INDEX    YIB_RQ_WQE_FIELD_LOC(31, 8) //本rqe的index，cqe需要使用
#define YIB_RQ_WQE_LENGTH    YIB_RQ_WQE_FIELD_LOC(63, 32) //sge的size之和
#define YIB_RQ_WQE_SIZE    YIB_RQ_WQE_FIELD_LOC(71, 64) //本WQE大小，粒度为16B

struct yib_hw_nqe {
    __le32 cq_handle_lsb;   //[31:0]cq_handle_lsb
    __le32 cq_handle_msb;   //[31:0]cq_handle_msb
    __le32 byte8_11;
    __le32 toggle;   //[31:31]toggle
};//16字节

#define YIB_NQE_FIELD_LOC(h, l) YIB_FIELD_LOC(struct yib_hw_nqe, h, l)
#define YIB_NQE_CQ_HANDLE_LSB    YIB_NQE_FIELD_LOC(31, 0)
#define YIB_NQE_CQ_HANDLE_MSB    YIB_NQE_FIELD_LOC(63, 32)
#define YIB_NQE_TOGGLE    YIB_NQE_FIELD_LOC(127, 127)

#endif

