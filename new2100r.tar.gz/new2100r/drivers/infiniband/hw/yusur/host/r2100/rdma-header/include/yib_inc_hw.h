#ifndef _YIB_INC_HW_H
#define _YIB_INC_HW_H

#include "yib_inc_base.h"
#include "yib_inc_hw_base.h"
#include "yib_inc_io.h"

struct yib_hw_mpt_entry {
    __le32 type_pd;   //[2:0]type; [4:3]num_trans_layers; [7:6]state; [31:8]pd
    __le32 qpn;  //[29:8]qpn
    __le32 pa0_lsb;  //[31:0]pa0_lsb
    __le32 pa0_msb;  //[31:0]pa0_msb
    __le32 pa1_lsb;  //[31:0]pa1_lsb
    __le32 pa1msb_pgsize;   //[19:0]pa1_msb; [26:22]mrw_pbl_pg_size; [31:27]mrw_pg_size
    __le32 size_lsb;     //[31:0]size_lsb
    __le32 size_msb;     //[31:0]size_msb
    __le32 key_lsb;   //[7:0]key_lsb; [31:8]parent_mr_idx_or_child_mw_count
    __le32 va_lsb;   //[31:0]va_lsb
    __le32 va_msb;   //[31:0]va_msb
    __le32 pbl_ba_lsb;    //[31:0]pbl_ba_lsb
    __le32 pblbamsb_access;     //[19:0]pbl_ba_msb; [31:26]access_right
    __le32 mr_handle_lsb;	//[31:0]mr_handle_lsb
    __le32 mr_handle_msb;   //[31:0]mr_handle_msb
    __le32 byte60_63;
};//64字节

#define YIB_MPT_FIELD_LOC(h, l) YIB_FIELD_LOC(struct yib_hw_mpt_entry, h, l)
#define YIB_MPT_TYPE    YIB_MPT_FIELD_LOC(2, 0)     //0:MR; 1:PMR; 2:MW Type 1; 3:MW Type 2A; 4:FMR; 5:Globle Key
#define YIB_MPT_NUM_TRANS_LAYERS    YIB_MPT_FIELD_LOC(4, 3)     //0:0级寻址  1:1级寻址  2:2级寻址
#define YIB_MPT_STATE    YIB_MPT_FIELD_LOC(7, 6)    //0:invalid(init状态); 1: free(收到invalid命令); 2:valid(可工作)
#define YIB_MPT_PD    YIB_MPT_FIELD_LOC(31, 8)  //pd
#define YIB_MPT_QPN    YIB_MPT_FIELD_LOC(61, 40)    //拥有此 MW 的 QPC 的 QID(qp标识号)。对于 2A 类，此字段仅在绑定操作成功后有效。
#define YIB_MPT_PA0_LSB    YIB_MPT_FIELD_LOC(95, 64)    //pa0[31:0]
#define YIB_MPT_PA0_MSB    YIB_MPT_FIELD_LOC(127, 96)   //pa0[63:32]  
#define YIB_MPT_PA1_LSB    YIB_MPT_FIELD_LOC(159, 128)  //pa1[31:0]
#define YIB_MPT_PA1_MSB    YIB_MPT_FIELD_LOC(179, 160)  //pa1[51:32] 
#define YIB_MPT_MRW_PBL_PG_SIZE    YIB_MPT_FIELD_LOC(186, 182)  //PDE或者PBL的页表大小,4K*2^n
#define YIB_MPT_MRW_PG_SIZE    YIB_MPT_FIELD_LOC(191, 187)  //数据buf的page大小,4K*2^n
#define YIB_MPT_SIZE_LSB    YIB_MPT_FIELD_LOC(223, 192)     //MR/W的大小，以字节为单位[31:0]
#define YIB_MPT_SIZE_MSB    YIB_MPT_FIELD_LOC(255, 224)     //MR/W的大小，以字节为单位[63:32]
#define YIB_MPT_KEY_LSB    YIB_MPT_FIELD_LOC(263, 256)      //L_Key/R_Key的低8bit
#define YIB_MPT_PARENT_MR_IDX_CNT    YIB_MPT_FIELD_LOC(287, 264) 
#define YIB_MPT_VA_LSB    YIB_MPT_FIELD_LOC(319, 288)       //va[31:0]
#define YIB_MPT_VA_MSB    YIB_MPT_FIELD_LOC(351, 320)       //va[63:32]
#define YIB_MPT_PBL_BA_LSB    YIB_MPT_FIELD_LOC(383, 352)   //pbl_ba[31:0]
#define YIB_MPT_PBL_BA_MSB    YIB_MPT_FIELD_LOC(403, 384)   //pbl_ba[51:32]
#define YIB_MPT_ACCESS_RIGHT    YIB_MPT_FIELD_LOC(415, 410)
#define YIB_MPT_HANDLE_LSB    YIB_MPT_FIELD_LOC(447, 416)      //mr handle low
#define YIB_MPT_HANDLE_MSB    YIB_MPT_FIELD_LOC(479, 448)      //mr handle high

struct yib_hw_channel_entry {
    __le32 qpc_ba_lsb;          //[31:0]qpc_ba_lsb
    __le32 qpcbamsb_mptnum;     //[19:0]qpc_ba_msb; [31:20]mpt_num_lsb
    __le32 mptnum_cflownum;     //[11:0]mpt_num_msb; [31:12]client_flow_num
    __le32 sflownum_qpcinfo;    //[19:0]server_flow_num; [24:20]qpc_pg_size; [29:25]qpc_pbl_pg_size; [31:30]qpc_indir_lvls
    __le32 rqc_ba_lsb;          //[31:0]rqc_ba_lsb
    __le32 rqcinfo;             //[19:0]rqc_ba_msb; [24:20]rqc_pg_size; [29:25]rqc_pbl_pg_size; [31:30]rqc_indir_lvls
    __le32 cqc_ba_lsb;          //[31:0]cqc_ba_lsb
    __le32 cqcinfo;             //[19:0]cqc_ba_msb; [24:20]cqc_pg_size; [29:25]cqc_pbl_pg_size; [31:30]cqc_indir_lvls
    __le32 nqc_ba_lsb;          //[31:0]nqc_ba_lsb
    __le32 nqcinfo;             //[19:0]nqc_ba_msb; [24:20]nqc_pg_size; [29:25]nqc_pbl_pg_size; [31:30]nqc_indir_lvls
    __le32 commonnum_mptinfo;   //[19:0]common_num; [24:20]mpt_pg_size; [29:25]mpt_pbl_pg_size; [31:30]mpt_indir_lvls
    __le32 sqcnum_smacinfo;     //[19:0]sqc_num; [24:20]smac_pg_size; [29:25]smac_pbl_pg_size; [31:30]smac_indir_lvls
    __le32 rqcnum_smacnum;      //[19:0]rqc_num; [29:20]smac_num; [31:30]port_id
    __le32 cqcnum_sgidinfo;     //[19:0]cqc_num; [24:20]sgid_pg_size; [29:25]sgid_pbl_pg_size; [31:30]sgid_indir_lvls
    __le32 nqcnum_sgidnum;      //[19:0]nqc_num; [29:20]sgid_num; [30:30]halt; [31:31]done
    __le32 mpt_ba_lsb;          //[31:0]mpt_ba_lsb
    __le32 mptbamsb_hostid;     //[19:0]mpt_ba_msb; [26:24]host_id; [27:27]valid
    __le32 smac_ba_lsb;         //[31:0]smac_ba_lsb
    __le32 smac_ba_msb;         //[19:0]smac_ba_msb
    __le32 sgid_ba_lsb;         //[31:0]sgid_ba_lsb
    __le32 sgid_ba_msb;         //[19:0]sgid_ba_msb
    __le32 bdf_msixentryidx;    //[15:0]bdf; [31:16]msix_entry_idx
};

#define YIB_CHANNEL_FIELD_LOC(h, l) YIB_FIELD_LOC(struct yib_hw_channel_entry, h, l)
#define YIB_CHANNEL_QPC_BA_LSB    YIB_CHANNEL_FIELD_LOC(31, 0)      //QPC基地址[31:0]
#define YIB_CHANNEL_QPC_BA_MSB    YIB_CHANNEL_FIELD_LOC(51, 32)     //QPC基地址[51:32]   
#define YIB_CHANNEL_MPT_NUM_LSB    YIB_CHANNEL_FIELD_LOC(63, 52)    //mpt个数[11:0]，从0开始编码, 0表示1个mpt
#define YIB_CHANNEL_MPT_NUM_MSB    YIB_CHANNEL_FIELD_LOC(75, 64)    //mpt个数[23:12]，从0开始编码, 0表示1个mpt
#define YIB_CHANNEL_CLIENT_FLOW_NUM    YIB_CHANNEL_FIELD_LOC(95, 76)    //client flow个数，从0开始编码，0表示1个QP
#define YIB_CHANNEL_SERVER_FLOW_NUM    YIB_CHANNEL_FIELD_LOC(115, 96)   //server flow个数
#define YIB_CHANNEL_QPC_PG_SIZE    YIB_CHANNEL_FIELD_LOC(120, 116)      //qpc的数据buf的page大小,4K*2^n 
#define YIB_CHANNEL_QPC_PBL_PG_SIZE    YIB_CHANNEL_FIELD_LOC(125, 121)  //qpc的PDE或者PBL的页表大小,4K*2^n
#define YIB_CHANNEL_QPC_INDIR_LVLS    YIB_CHANNEL_FIELD_LOC(127, 126)   //qpc的寻址级别，0表示0级寻址, 1表示1级寻址, 2表示2级寻址
#define YIB_CHANNEL_RQC_BA_LSB    YIB_CHANNEL_FIELD_LOC(159, 128)      //rqc基地址[31:0]
#define YIB_CHANNEL_RQC_BA_MSB    YIB_CHANNEL_FIELD_LOC(179, 160)     //rqc基地址[51:32]  
#define YIB_CHANNEL_RQC_PG_SIZE    YIB_CHANNEL_FIELD_LOC(184, 180)      //rqc的数据buf的page大小,4K*2^n 
#define YIB_CHANNEL_RQC_PBL_PG_SIZE    YIB_CHANNEL_FIELD_LOC(189, 185)  //rqc的PDE或者PBL的页表大小,4K*2^n
#define YIB_CHANNEL_RQC_INDIR_LVLS    YIB_CHANNEL_FIELD_LOC(191, 190)   //rqc的寻址级别，0表示0级寻址, 1表示1级寻址, 2表示2级寻址
#define YIB_CHANNEL_CQC_BA_LSB    YIB_CHANNEL_FIELD_LOC(223, 192)      //cqc基地址[31:0]
#define YIB_CHANNEL_CQC_BA_MSB    YIB_CHANNEL_FIELD_LOC(243, 224)     //cqc基地址[51:32]  
#define YIB_CHANNEL_CQC_PG_SIZE    YIB_CHANNEL_FIELD_LOC(248, 244)      //cqc的数据buf的page大小,4K*2^n 
#define YIB_CHANNEL_CQC_PBL_PG_SIZE    YIB_CHANNEL_FIELD_LOC(253, 249)  //cqc的PDE或者PBL的页表大小,4K*2^n
#define YIB_CHANNEL_CQC_INDIR_LVLS    YIB_CHANNEL_FIELD_LOC(255, 254)   //cqc的寻址级别，0表示0级寻址, 1表示1级寻址, 2表示2级寻址
#define YIB_CHANNEL_NQC_BA_LSB    YIB_CHANNEL_FIELD_LOC(287, 256)      //nqc基地址[31:0]
#define YIB_CHANNEL_NQC_BA_MSB    YIB_CHANNEL_FIELD_LOC(307, 288)     //nqc基地址[51:32]  
#define YIB_CHANNEL_NQC_PG_SIZE    YIB_CHANNEL_FIELD_LOC(312, 308)      //nqc的数据buf的page大小,4K*2^n 
#define YIB_CHANNEL_NQC_PBL_PG_SIZE    YIB_CHANNEL_FIELD_LOC(317, 313)  //nqc的PDE或者PBL的页表大小,4K*2^n
#define YIB_CHANNEL_NQC_INDIR_LVLS    YIB_CHANNEL_FIELD_LOC(319, 318)   //nqc的寻址级别，0表示0级寻址, 1表示1级寻址, 2表示2级寻址
#define YIB_CHANNEL_COMMON_NUM    YIB_CHANNEL_FIELD_LOC(339, 320)       //common表个数
#define YIB_CHANNEL_MPT_PG_SIZE    YIB_CHANNEL_FIELD_LOC(344, 340)      //mpt的数据buf的page大小,4K*2^n
#define YIB_CHANNEL_MPT_PBL_PG_SIZE    YIB_CHANNEL_FIELD_LOC(349, 345)  //mpt的PDE或者PBL的页表大小,4K*2^n
#define YIB_CHANNEL_MPT_INDIR_LVLS    YIB_CHANNEL_FIELD_LOC(351, 350)   //mpt的寻址级别, 0表示0级寻址, 1表示1级寻址, 2表示2级寻址
#define YIB_CHANNEL_SQC_NUM    YIB_CHANNEL_FIELD_LOC(371, 352)          //sqc个数
#define YIB_CHANNEL_SMAC_PG_SIZE    YIB_CHANNEL_FIELD_LOC(376, 372)     //smac的数据buf的page大小,4K*2^n
#define YIB_CHANNEL_SMAC_PBL_PG_SIZE    YIB_CHANNEL_FIELD_LOC(381, 377) //smac的PDE或者PBL的页表大小,4K*2^n
#define YIB_CHANNEL_SMAC_INDIR_LVLS    YIB_CHANNEL_FIELD_LOC(383, 382)  //smac的寻址级别, 0表示0级寻址, 1表示1级寻址, 2表示2级寻址
#define YIB_CHANNEL_RQC_NUM    YIB_CHANNEL_FIELD_LOC(403, 384)      //rqc个数
#define YIB_CHANNEL_SMAC_NUM    YIB_CHANNEL_FIELD_LOC(413, 404)     //smac个数
#define YIB_CHANNEL_PORT_ID    YIB_CHANNEL_FIELD_LOC(415, 414)      //逻辑mac port id  
#define YIB_CHANNEL_CQC_NUM    YIB_CHANNEL_FIELD_LOC(435, 416)      //cqc个数
#define YIB_CHANNEL_SGID_PG_SIZE    YIB_CHANNEL_FIELD_LOC(440, 436) //sgid的数据buf的page大小,4K*2^n
#define YIB_CHANNEL_SGID_PBL_PG_SIZE    YIB_CHANNEL_FIELD_LOC(445, 441)     //sgid的PDE或者PBL的页表大小,4K*2^n 
#define YIB_CHANNEL_SGID_INDIR_LVLS    YIB_CHANNEL_FIELD_LOC(447, 446)      //sgid的寻址级别, 0表示0级寻址, 1表示1级寻址, 2表示2级寻址
#define YIB_CHANNEL_NQC_NUM    YIB_CHANNEL_FIELD_LOC(467, 448)     //nqc个数
#define YIB_CHANNEL_SGID_NUM    YIB_CHANNEL_FIELD_LOC(477, 468)    //sgid个数
#define YIB_CHANNEL_HALT    YIB_CHANNEL_FIELD_LOC(478, 478)     //暂停标记     
#define YIB_CHANNEL_DONE    YIB_CHANNEL_FIELD_LOC(479, 479)     //硬件停止标记     
#define YIB_CHANNEL_MPT_BA_LSB    YIB_CHANNEL_FIELD_LOC(511, 480)     //mpt基地址[31:0]
#define YIB_CHANNEL_MPT_BA_MSB    YIB_CHANNEL_FIELD_LOC(531, 512)     //mpt基地址[51:32]  
#define YIB_CHANNEL_HOST_ID    YIB_CHANNEL_FIELD_LOC(538, 536)  //0xx表示host, 1xx表示本地小核
#define YIB_CHANNEL_VALID    YIB_CHANNEL_FIELD_LOC(539, 539)    //有效标记
#define YIB_CHANNEL_SMAC_BA_LSB    YIB_CHANNEL_FIELD_LOC(575, 544)     //源mac基地址[31:0]
#define YIB_CHANNEL_SMAC_BA_MSB    YIB_CHANNEL_FIELD_LOC(595, 576)     //源mac基地址[52:32]
#define YIB_CHANNEL_SGID_BA_LSB    YIB_CHANNEL_FIELD_LOC(639, 608)  //sgid基地址[31:0]
#define YIB_CHANNEL_SGID_BA_MSB    YIB_CHANNEL_FIELD_LOC(659, 640)  //sgid基地址[52:32] 
#define YIB_CHANNEL_BDF    YIB_CHANNEL_FIELD_LOC(687, 672)  //该设备的BDF号
#define YIB_CHANNEL_MSIX_ENTRY_IDX    YIB_CHANNEL_FIELD_LOC(703, 688)     //0:AEQ中断; 1~N-1:NQ中断

struct yib_hw_cqc_entry {
    __le32 cqinfo;   //[1:0]cq_indir_lvls; [6:2]cq_pg_size; [11:7]cq_pbl_pg_size; [31:12]cq_pde_ba_lsb
    __le32 cq_pde_ba_msb;          //[31:0]cq_pde_ba_msb
    __le32 cqsize_nqid;            //[15:0]cq_size; [19:16]cq_nq_id
    __le32 cq_handle_lsb;          //[31:0]cq_handle_lsb
    __le32 cq_handle_msb;          //[31:0]cq_handle_msb
    __le32 pi_ci;                  //[3:0]cq_pi; [3:0]cq_ci
    __le32 byte24_27;
    __le32 byte28_31;
    __le32 byte32_35;
    __le32 byte36_39;
    __le32 byte40_43;
    __le32 byte44_47;
    __le32 byte48_51;
    __le32 byte52_55;
    __le32 byte56_59;
    __le32 byte60_63;
};//64字节

#define YIB_CQC_FIELD_LOC(h, l) YIB_FIELD_LOC(struct yib_hw_cqc_entry, h, l)
#define YIB_CQC_CQ_INDIR_LVLS    YIB_CQC_FIELD_LOC(1, 0)    //0表示0级寻址, 1表示1级寻址, 2表示2级寻址
#define YIB_CQC_CQ_PG_SIZE    YIB_CQC_FIELD_LOC(6, 2)       //buffer页表的大小，4K*2^n        
#define YIB_CQC_CQ_PBL_PG_SIZE    YIB_CQC_FIELD_LOC(11, 7)  //PDE & PBL页表的大小，4K*2^n
#define YIB_CQC_CQ_PDE_BA_LSB    YIB_CQC_FIELD_LOC(31, 12)  //PDE表/PBL表/CQ队列的基地址[19:0]
#define YIB_CQC_CQ_PDE_BA_MSB    YIB_CQC_FIELD_LOC(63, 32)  //PDE表/PBL表/CQ队列的基地址[51:20]
#define YIB_CQC_CQ_SIZE    YIB_CQC_FIELD_LOC(79, 64)    //cq的深度，放多少个wqes
#define YIB_CQC_CQ_NQ_ID    YIB_CQC_FIELD_LOC(83, 80)      //相对于channel的nq id, 即nqn
#define YIB_CQC_CQ_HANDLE_LSB    YIB_CQC_FIELD_LOC(127, 96)  //cq_handle[31:0]
#define YIB_CQC_CQ_HANDLE_MSB    YIB_CQC_FIELD_LOC(159, 128) //cq_handle[63:32]
#define YIB_CQC_CQ_PI    YIB_CQC_FIELD_LOC(175, 160)
#define YIB_CQC_CQ_CI    YIB_CQC_FIELD_LOC(191, 176)

struct yib_hw_nqc_entry {
    __le32 nqindirlvls_nqpgsize;   //[1:0]nq_indir_lvls; [5:2]nq_pg_size; [9:6]nq_pbl_pg_size; 
                                   //[10:10]nq_enable; [31:24]nq_int_vec
    __le32 nq_pbl_ba_lsb;          //[31:0]nq_pbl_ba_lsb
    __le32 nq_pbl_ba_msb;          //[19:0]nq_pbl_ba_msb
    __le32 byte12_15;
    __le32 byte16_19;
    __le32 byte20_23;
    __le32 nq_size;            //[15:0]nq_ci; [31:16]nq_size
    __le32 nq_pi;              //[31:16]nq_pi
};//32字节

#define YIB_NQC_FIELD_LOC(h, l) YIB_FIELD_LOC(struct yib_hw_nqc_entry, h, l)
#define YIB_NQC_NQ_INDIR_LVLS    YIB_NQC_FIELD_LOC(1, 0)    //0表示0级寻址, 1表示1级寻址, 2表示2级寻址
#define YIB_NQC_NQ_PG_SIZE    YIB_NQC_FIELD_LOC(5, 2)       //buffer页表的大小，4K*2^n
#define YIB_NQC_NQ_PBL_PG_SIZE    YIB_NQC_FIELD_LOC(9, 6)   //PDE & PBL页表的大小，4K*2^n
#define YIB_NQC_NQ_ENABLE    YIB_NQC_FIELD_LOC(10, 10)
#define YIB_NQC_NQ_INT_VEC    YIB_NQC_FIELD_LOC(31, 24)
#define YIB_NQC_NQ_PBL_BA_LSB    YIB_NQC_FIELD_LOC(63, 32)  //PDE表/PBL表/NQ队列的基地址[31:0]
#define YIB_NQC_NQ_PBL_BA_MSB    YIB_NQC_FIELD_LOC(83, 64)  //PDE表/PBL表/NQ队列的基地址[51:32]
#define YIB_NQC_NQ_CI    YIB_NQC_FIELD_LOC(207, 192)
#define YIB_NQC_NQ_SIZE    YIB_NQC_FIELD_LOC(223, 208)
#define YIB_NQC_NQ_PI    YIB_NQC_FIELD_LOC(255, 240)

struct yib_hw_sqc_entry {
    __le32 sqindirlvls_sqpgsize;    //[1:0]sq_indir_lvls; [6:2]sq_pg_size; [11:7]sq_pbl_pg_size; [13:12]port_id; [31:16]sq_size
    __le32 sq_pde_pa_lsb;   //[31:0]sq_pde_pa_lsb
    __le32 sq_pde_pa_msb;   //[19:0]sq_pde_pa_msb
    __le32 byte12_15;
    __le32 sq_ci;           //[31:16]sq_ci
    __le32 sq_pi;           //[31:16]sq_pi
    __le32 byte24_27;
    __le32 byte28_31;
    __le32 byte32_35;    
    __le32 byte36_39; 
    __le32 byte40_43;    
    __le32 byte44_47;  
    __le32 byte48_51;
    __le32 byte52_55;
    __le32 byte56_59;
    __le32 byte60_63;
};//64字节

#define YIB_SQC_FIELD_LOC(h, l) YIB_FIELD_LOC(struct yib_hw_sqc_entry, h, l)
#define YIB_SQC_SQ_INDIR_LVLS    YIB_SQC_FIELD_LOC(1, 0)   //0表示0级寻址, 1表示1级寻址, 2表示2级寻址
#define YIB_SQC_SQ_PG_SIZE    YIB_SQC_FIELD_LOC(6, 2)      //buffer页表的大小，4K*2^n        
#define YIB_SQC_SQ_PBL_PG_SIZE    YIB_SQC_FIELD_LOC(11, 7)  //PDE & PBL页表的大小，4K*2^n
#define YIB_SQC_PORT_ID    YIB_SQC_FIELD_LOC(13, 12)
#define YIB_SQC_SQ_SIZE    YIB_SQC_FIELD_LOC(31, 16)         //sq的深度，放多少个wqes 
#define YIB_SQC_SQ_PDE_PA_LSB    YIB_SQC_FIELD_LOC(63, 32)  //PDE表/PBL表/SQ队列的基地址[31:0]
#define YIB_SQC_SQ_PDE_PA_MSB    YIB_SQC_FIELD_LOC(83, 64) //PDE表/PBL表/SQ队列的基地址[51:32]
#define YIB_SQC_SQ_CI    YIB_SQC_FIELD_LOC(159, 144)
#define YIB_SQC_SQ_PI    YIB_SQC_FIELD_LOC(191, 176)

struct yib_hw_rqc_entry {
    __le32 rq_handle_lsb;   //[31:0]rq_handle_lsb
    __le32 rq_handle_msb;   //[31:0]rq_handle_msb
    __le32 rqindirlvls_rqpgsize;    //[1:0]rq_indir_lvls; [6:2]rq_pg_size; [11:7]rq_pbl_pg_size; [31:12]rq_pbl_ba_lsb
    __le32 rq_pbl_ba_msb;   //[31:0]rq_pbl_ba_msb
    __le32 rq_size;         //[15:0]rq_size; [31:16]rq_ci
    __le32 rq_pi;           //[31:16]rq_pi
    __le32 byte24_27;
    __le32 byte28_31;
    __le32 byte32_35;
    __le32 byte36_39; 
    __le32 byte40_43;    
    __le32 rq_type;         //[23:22]rq_type
    __le32 byte48_51;
    __le32 byte52_55;
    __le32 byte56_59;
    __le32 byte60_63;
    __le32 byte64_67;
    __le32 byte68_71;
    __le32 byte72_75;
    __le32 byte76_79;
    __le32 byte80_83;
    __le32 byte84_87;
    __le32 byte88_91;
    __le32 byte92_95;
    __le32 byte96_99;
    __le32 byte100_103;
    __le32 byte104_107;
    __le32 byte108_111;
    __le32 byte112_115;
    __le32 byte116_119;
    __le32 byte120_123;
    __le32 byte124_127;
    __le32 byte128_131;
    __le32 byte132_135;
    __le32 byte136_139;
    __le32 byte140_143;
    __le32 byte144_147;
    __le32 byte148_151;
    __le32 byte152_155;
    __le32 byte156_159;
    __le32 byte160_163;
    __le32 byte164_167;
    __le32 byte168_171;
    __le32 byte172_175;
    __le32 byte176_179;
    __le32 byte180_183;
    __le32 byte184_187;
    __le32 byte188_191;
    __le32 byte192_195;
    __le32 byte196_199;
    __le32 byte200_203;
    __le32 byte204_207;
    __le32 byte208_211;
    __le32 byte212_215;
    __le32 byte216_219;
    __le32 byte220_223;
    __le32 byte224_227;
    __le32 byte228_231;
    __le32 byte232_235;
    __le32 byte236_239;
    __le32 byte240_243;
    __le32 byte244_247;
    __le32 byte248_251;
    __le32 byte252_255;
};//256字节

#define YIB_RQC_FIELD_LOC(h, l) YIB_FIELD_LOC(struct yib_hw_rqc_entry, h, l)
#define YIB_RQC_RQ_HANDLE_LSB    YIB_RQC_FIELD_LOC(31, 0)   //rq_handle[31:0]
#define YIB_RQC_RQ_HANDLE_MSB    YIB_RQC_FIELD_LOC(63, 32)  //rq_handle[63:32]
#define YIB_RQC_RQ_INDIR_LVLS    YIB_RQC_FIELD_LOC(65, 64)  //0表示0级寻址, 1表示1级寻址, 2表示2级寻址
#define YIB_RQC_RQ_PG_SIZE    YIB_RQC_FIELD_LOC(70, 66)     //buffer页表的大小，4K*2^n
#define YIB_RQC_RQ_PBL_PG_SIZE    YIB_RQC_FIELD_LOC(75, 71) //PDE & PBL页表的大小，4K*2^n
#define YIB_RQC_RQ_PDE_BA_LSB    YIB_RQC_FIELD_LOC(95, 76)  //PDE表/PBL表/RQ队列的基地址[31:0]
#define YIB_RQC_RQ_PDE_BA_MSB    YIB_RQC_FIELD_LOC(127, 96) //PDE表/PBL表/RQ队列的基地址[31:0]
#define YIB_RQC_RQ_SIZE    YIB_RQC_FIELD_LOC(143, 128)
#define YIB_RQC_RQ_CI    YIB_RQC_FIELD_LOC(159, 144)
#define YIB_RQC_RQ_PI    YIB_RQC_FIELD_LOC(191, 176)
#define YIB_RQC_RQ_TYPE    YIB_RQC_FIELD_LOC(375, 374)

struct yib_hw_smac_entry {
    u8 mac[8];
} __attribute__((packed));//8字节

struct yib_hw_sgid_entry {
    u8 ip[16];
};//16字节

struct yib_hw_cflow {
    __le32 byte0_3;
    __le32 re_txmits_count_init_value;  //[2:0]re_txmits_count_init_value; [5:3]rnr_re_txmits_count_init_value
                                        //[7:6]wqe_size_limit; [11:8]get_wqes_limit
    __le32 sq_next_psn;                 //[23:0]sq_next_psn
    __le32 byte12_15;
    __le32 byte16_19;
    __le32 byte20_23;
    __le32 byte24_27;
    __le32 byte28_31;     
    __le32 byte32_35;       
    __le32 byte36_39;
    __le32 byte40_43;
    __le32 byte44_47;
    __le32 byte48_51;
    __le32 oldest_unack_psn;    //[23:0]oldest_unack_psn
    __le32 byte56_59;
    __le32 byte60_63;
};//64字节

#define YIB_CFLOW_FIELD_LOC(h, l) YIB_FIELD_LOC(struct yib_hw_cflow, h, l)
#define YIB_CFLOW_RE_TXMITS_COUNT_INIT_VALUE    YIB_CFLOW_FIELD_LOC(34, 32) 
#define YIB_CFLOW_RNR_RE_TXMITS_COUNT_INIT_VALUE    YIB_CFLOW_FIELD_LOC(37, 35)
#define YIB_CFLOW_WQE_SIZE_LIMIT    YIB_CFLOW_FIELD_LOC(39, 38)
#define YIB_CFLOW_GET_WQES_LIMIT    YIB_CFLOW_FIELD_LOC(43, 40)
#define YIB_CFLOW_SQ_NEXT_PSN    YIB_CFLOW_FIELD_LOC(87, 64)  
#define YIB_CFLOW_OLDEST_UNACK_PSN    YIB_CFLOW_FIELD_LOC(439, 416)

struct yib_hw_sflow {
    __le32 msg_key_or_Qkey_msb;        //[31:0]msg_key_or_Qkey_lsb
    __le32 byte4_7;
    __le32 byte8_11;
    __le32 byte12_15;
    __le32 byte16_19;
    __le32 byte20_23;
    __le32 byte24_27;
    __le32 byte28_31;
    __le32 byte32_35;
    __le32 byte36_39;
    __le32 byte40_43;
    __le32 byte44_47;
    __le32 byte48_51;
    __le32 byte52_55;
    __le32 byte56_59;
    __le32 rx_read_atomic_limit;    //[23:19]rnr_time_to_wait; [31:24]rx_read_atomic_limit
};//64字节

#define YIB_SFLOW_FIELD_LOC(h, l) YIB_FIELD_LOC(struct yib_hw_sflow, h, l)
#define YIB_SFLOW_INCOME_MSG_KEY_OR_QKEY    YIB_SFLOW_FIELD_LOC(31, 0)
#define YIB_SFLOW_RNR_TIME_TO_WAIT    YIB_SFLOW_FIELD_LOC(503, 499)
#define YIB_SFLOW_RX_READ_ATOMIC_LIMIT    YIB_SFLOW_FIELD_LOC(511, 504)

struct yib_hw_qpc_entry {
    __le32 pkey_sourceport;    //[15:0]p_key; [31:16]source_port
    __le32 dstqp_rqn;          //[11:0]dst_qp; [23:12]rqn; [31:24]sq_cq_id_lsb
    __le32 sqcqid_rqcqid;      //[3:0]sq_cq_id_msb; [15:4]rq_cq_id; [23:16]send_pkt_limit; [31:24]read_atomic_limit
    __le32 serv_type;          //[19:0]pd; [22:20]serv_type; [23:23]local_rq_credits_en
                               //[26:24]mtu_size; [27:27]remote_rq_credits_en; [28:28]enable_ecn
    __le32 sq_handle_lsb;      //[31:0]sq_handle_lsb
    __le32 sq_handle_msb;      //[31:0]sq_handle_msb
    __le32 access_right;       //[5:0]access_right
    __le32 byte28_31;
    struct yib_hw_av av;
};//64字节

#define YIB_QPC_FIELD_LOC(h, l) YIB_FIELD_LOC(struct yib_hw_qpc_entry, h, l)
#define YIB_QPC_P_KEY    YIB_QPC_FIELD_LOC(15, 0)  
#define YIB_QPC_SOURCE_PORT    YIB_QPC_FIELD_LOC(31, 16)  
#define YIB_QPC_DST_QP    YIB_QPC_FIELD_LOC(43, 32)
#define YIB_QPC_RQN    YIB_QPC_FIELD_LOC(55, 44)  
#define YIB_QPC_SQ_CQ_ID_LSB    YIB_QPC_FIELD_LOC(63, 56)    
#define YIB_QPC_SQ_CQ_ID_MSB    YIB_QPC_FIELD_LOC(67, 64)  
#define YIB_QPC_RQ_CQ_ID    YIB_QPC_FIELD_LOC(79, 68) 
#define YIB_QPC_SEND_PKT_LIMIT    YIB_QPC_FIELD_LOC(87, 80)  
#define YIB_QPC_READ_ATOMIC_LIMIT    YIB_QPC_FIELD_LOC(95, 88) 
#define YIB_QPC_PD    YIB_QPC_FIELD_LOC(115, 96)
#define YIB_QPC_SERV_TYPE    YIB_QPC_FIELD_LOC(118, 116) 
#define YIB_QPC_LOCAL_RQ_CREDITS_EN    YIB_QPC_FIELD_LOC(119, 119)
#define YIB_QPC_MTU_SIZE    YIB_QPC_FIELD_LOC(122, 120) 
#define YIB_QPC_REMOTE_RQ_CREDITS_EN    YIB_QPC_FIELD_LOC(123, 123)
#define YIB_QPC_ENABLE_ECN    YIB_QPC_FIELD_LOC(124, 124)
#define YIB_QPC_SQ_HANDLE_LSB    YIB_QPC_FIELD_LOC(159, 128)
#define YIB_QPC_SQ_HANDLE_MSB    YIB_QPC_FIELD_LOC(191, 160)
#define YIB_QPC_ACCESS_RIGHT    YIB_QPC_FIELD_LOC(197, 192)

#endif

