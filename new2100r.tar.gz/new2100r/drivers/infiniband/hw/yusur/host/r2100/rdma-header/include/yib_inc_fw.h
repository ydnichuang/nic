#ifndef _YIB_INC_FW_H
#define _YIB_INC_FW_H

#include "yib_inc_base.h"
#include "yib_inc_hw_base.h"

enum r2100_network_type {
	R2100_NETWORK_TYPE_IPV4 = 2,
	R2100_NETWORK_TYPE_IPV6 = 3,
};

enum yib_qos_type {
    YIB_QOS_COS,
    YIB_QOS_VM,
    YIB_QOS_HOST,
    YIB_QOS_PORT,
};

/* 命令类别 */
enum yib_fw_type {
    YIB_FW_CMD,
    YIB_FW_DEVICE_ERROR,
    YIB_FW_ASYNC_EVENT,
};

/* cmd opcode */
enum yib_fw_cmd_opcode {
    YIB_FW_CMD_ALLOC_CHANNEL = 1,
    YIB_FW_CMD_QUERY_LEFT_CHANNELS,
    YIB_FW_CMD_START_CHANNEL,
    YIB_FW_CMD_DESTROY_CHANNEL,
    YIB_FW_CMD_QUERY_DEVICE,
    YIB_FW_CMD_CREATE_CQ,
    YIB_FW_CMD_QUERY_CQ,
    YIB_FW_CMD_DESTROY_CQ,
    YIB_FW_CMD_CREATE_SRQ,
    YIB_FW_CMD_QUERY_SRQ,
    YIB_FW_CMD_DESTROY_SRQ,
    YIB_FW_CMD_QUERY_NQ,
    YIB_FW_CMD_CREATE_QP,
    YIB_FW_CMD_MODIFY_QP,
    YIB_FW_CMD_QUERY_QP,
    YIB_FW_CMD_DESTROY_QP,
    YIB_FW_CMD_REG_MR,
    YIB_FW_CMD_DEREG_MR,
    YIB_FW_CMD_ADD_SGID,
    YIB_FW_CMD_DEL_SGID,
    YIB_FW_CMD_SET_SMAC,
    YIB_FW_CMD_CHG_ACTIVE_PORT,
    YIB_FW_CMD_SET_QOS,
    YIB_FW_CMD_MODIFY_SMAC,
    YIB_FW_CMD_QUERY_MR,
    YIB_FW_CMD_UPDATE_CI,
    YIB_FW_CMD_GET_STAT,
    YIB_FW_CMD_MAX,
};

/* 设备级别错误 */
enum yib_device_error_type {
    YIB_FW_EQ_OVERFLOW = 1,
    YIB_FW_BUS_RESET,
    YIB_FW_DEVICE_NOT_WORKING,
    YIB_FW_OTHER_ERROR,
};

/* async event */
enum yib_event_type {
    YIB_EVENT_CQ_ERR,   //CQ满
    YIB_EVENT_COMM_EST,     //当rtr时收到第一个包
    YIB_EVENT_QP_REQ_ERR,   //rc命令非法(非法opcode, 或opcode顺序错误, 如send_last前，没send_first引起的qp err state)
    YIB_EVENT_QP_ACCESS_ERR,    //qp访问权限引起的qp err state
    YIB_EVENT_QP_FATAL,     //其它进入qp err state的
    YIB_EVENT_SQ_DRAINED,   //qp进入drained完成
    YIB_EVENT_SRQ_ERR,      //当srq上发生不允许消耗rqe的错误, 会生成此事件，该错误会阻止rdma设备从srq中出列rqe并报告接收完成。
    YIB_EVENT_SRQ_LIMIT_REACHED,    //srq告警
    YIB_EVENT_QP_LAST_WQE_REACHED,  //当与srq相关联的qp进入IBV_QPS_ERR状态时(软件触发或硬件触发), 如果满足如下条件之一：
                                    //最后一个rqe完成; 进入err state时, 没rqe了。
};

enum yib_event_subopcode {
    YIB_EVENT_SUBOPCODE_CQ,
    YIB_EVENT_SUBOPCODE_QP,
    YIB_EVENT_SUBOPCODE_RQ,
};

enum yib_db_type {
    YIB_DB_SQ,
    YIB_DB_RQ,
    YIB_DB_SRQ,
    YIB_DB_SRQ_ARM,
    YIB_DB_CQ,
    YIB_DB_CQARMSE,
    YIB_DB_CQARMALL,
    YIB_DB_CQARMENA,
    YIB_DB_SRQ_ARMENA,
    YIB_DB_RX_ECN_DETECT,
    YIB_DB_NQ,
    YIB_DB_NQ_ARM,
    YIB_DB_SQ_MSN_CREDITS,
    YIB_DB_CQ_PI,
    YIB_DB_NQ_MASK,
    YIB_DB_NQ_PI,
    YIB_DB_RQ_CI,
    YIB_DB_RETRANS,
    YIB_DB_RESP,
};

struct cplq_entry {
    __le32 header;      //[3:0]命令类别(cmd/aeq); [15:8]opcode； [31:16]sub_opcode
    __le32 ret_val;
    __le32 byte8;
    __le32 byte12;
    __le32 byte16;
    __le32 byte20;
    __le32 byte24;
    __le32 ready;       //[0:0]READY bit
};

#define YIB_CPLQ_FIELD_LOC(h, l) YIB_FIELD_LOC(struct cplq_entry, h, l)
#define YIB_CPLQ_TYPE   YIB_CPLQ_FIELD_LOC(3, 0)      //0:CMD, 1:设备级别的AEQ, 2:资源级别的AEQ
#define YIB_CPLQ_OPCODE    YIB_CPLQ_FIELD_LOC(15, 8)     //opcode
#define YIB_CPLQ_SUB_OPCODE    YIB_CPLQ_FIELD_LOC(31, 16)     //sub_opcode
#define YIB_CPLQ_RET_VAL    YIB_CPLQ_FIELD_LOC(63, 32)     //ret_val
#define YIB_CPLQ_CHANNEL_ID    YIB_CPLQ_FIELD_LOC(95, 64)     //channel_id
#define YIB_CPLQ_INDEX    YIB_CPLQ_FIELD_LOC(127, 96)     //index(cqn,qpn, rqn)
#define YIB_CPLQ_PIPE_ERR    YIB_CPLQ_FIELD_LOC(175, 160)     //pipe_err
#define YIB_CPLQ_PIPE_NUM    YIB_CPLQ_FIELD_LOC(191, 176)     //pipe_num
#define YIB_CPLQ_START_INDEX    YIB_CPLQ_FIELD_LOC(223, 192)     //start_index(第一个未完成的位置)
#define YIB_CPLQ_READY  YIB_CPLQ_FIELD_LOC(224, 224)    //READY bit

/*
 * support字段的定义：
 * [0:0]ud_mcast_supp
 * [1:1]srq_supp
 * [2:2]srq_limit_supp
 * [3:3]xrc_supp
 * [4:4]ud_supp
 * [5:5]uc_supp
 * [6:6]srq_modify
 * [7:7]mw_supp
 * [8:8]atomic_supp
 * [9:9]quick_excep
 * [10:10]sw_err_flush
 * [11:11]srq_seq
 * [12:12]queue_l2_tbl
 * [13:13]mr_l2_tbl
 */
struct yib_fw_roce_caps {
    __le32 support;
    __le32 fw_ver_lsb;
    __le32 fw_ver_msb;
    __le32 hw_ver_lsb;
    __le32 hw_ver_msb;
    __le32 max_port;   //支持的最大port数
    __le32 max_qp;     //支持的最大qp
    __le32 max_cq;     //支持的最大cq数
    __le32 max_mr;      //支持的最大mr数
    __le32 max_srq;    //支持的最大srq数
    __le32 sf_max_port;
    __le32 sf_max_qp;
    __le32 sf_max_cq;
    __le32 sf_max_mr;
    __le32 sf_max_srq;
    __le32 max_irq_for_channel;     //一个channel支持的中断数量(最小不能小于2, 如果为n, 则0对应fw_intr,[1,n-1]对应eq)
    __le32 max_mcast_qps;   //支持的最大广播qp数
    __le32 max_mcast_grp;   //支持的最大广播组数
};

#define YIB_CAPS_FIELD_LOC(h, l) YIB_FIELD_LOC(struct yib_fw_roce_caps, h, l)
#define YIB_CAPS_UD_MCAST    YIB_CAPS_FIELD_LOC(0, 0) 
#define YIB_CAPS_SRQ    YIB_CAPS_FIELD_LOC(1, 1) 
#define YIB_CAPS_SRQ_LIMIT    YIB_CAPS_FIELD_LOC(2, 2) 
#define YIB_CAPS_XRC    YIB_CAPS_FIELD_LOC(3, 3) 
#define YIB_CAPS_UD    YIB_CAPS_FIELD_LOC(4, 4) 
#define YIB_CAPS_UC    YIB_CAPS_FIELD_LOC(5, 5) 
#define YIB_CAPS_SRQ_MODIFY    YIB_CAPS_FIELD_LOC(6, 6) 
#define YIB_CAPS_MW    YIB_CAPS_FIELD_LOC(7, 7) 
#define YIB_CAPS_ATOMIC    YIB_CAPS_FIELD_LOC(8, 8)
#define YIB_CAPS_QUICK_EXECP    YIB_CAPS_FIELD_LOC(9, 9)    //驱动做快速异常处理，默认关闭
#define YIB_CAPS_SW_ERR_FLUSH    YIB_CAPS_FIELD_LOC(10, 10)  
#define YIB_CAPS_SRQ_SEQ    YIB_CAPS_FIELD_LOC(11, 11)    //设置为1表明框架层实现srq保序
#define YIB_CAPS_QUEUE_L2_TBL    YIB_CAPS_FIELD_LOC(12, 12)    //队列是否支持二级页表
#define YIB_CAPS_MR_L2_TBL    YIB_CAPS_FIELD_LOC(13, 13)    //mr是否支持二级页表

/* qp_attr_mask */
enum yib_qp_attr_mask {
    YIB_QP_STATE                = (1<<0),
    YIB_QP_ACCESS_FLAGS         = (1<<3),
    YIB_QP_PKEY_INDEX           = (1<<4),
    YIB_QP_PORT                 = (1<<5),
    YIB_QP_QKEY                 = (1<<6),
    YIB_QP_AV                   = (1<<7),
    YIB_QP_PATH_MTU             = (1<<8),
    YIB_QP_TIMEOUT              = (1<<9),
    YIB_QP_RETRY_CNT            = (1<<10),
    YIB_QP_RNR_RETRY            = (1<<11),
    YIB_QP_RQ_PSN               = (1<<12),
    YIB_QP_MAX_QP_RD_ATOMIC     = (1<<13),
    YIB_QP_MIN_RNR_TIMER        = (1<<15),
    YIB_QP_SQ_PSN               = (1<<16),
    YIB_QP_MAX_DEST_RD_ATOMIC   = (1<<17),
    YIB_QP_DEST_QPN             = (1<<20),
    YIB_QP_RATE_LIMIT		    = (1<<25),
};

/* qp_state */
enum yib_qp_state {
	YIB_QPS_RESET,
	YIB_QPS_INIT,
	YIB_QPS_RTR,
	YIB_QPS_RTS,
	YIB_QPS_SQD,
	YIB_QPS_SQE,
	YIB_QPS_ERR
};

/* path_mtu */
enum yib_mtu {
	YIB_MTU_256  = 0,
	YIB_MTU_512,
	YIB_MTU_1024,
	YIB_MTU_2048,
	YIB_MTU_4096,
    YIB_MTU_8192,   //暂不支持
};

struct yib_fw_qp_attr {
    __le32 qp_state;
    __le32 path_mtu;      //RC:进入RTR状态时配置; UD没有path_mtu, 但要在RTR之前赋值, 取当前系统的mtu
    __le32 qkey;        //UD:进入INIT状态时配置
    __le32 rq_psn;      //RC:进入RTR状态时配置
    __le32 sq_psn;      //进入RTS状态时配置
    __le32 dest_qp_num;     //RC:进入RTR状态时配置
    __le32 qp_access_flags;     //进入INIT状态时配置
    struct yib_hw_av av;     //RC:进入RTR状态时配置
    __le32 pkey;      //进入INIT状态时配置
    __le32 max_rd_atomic;       //RC:进入RTS状态时配置
    __le32 max_dest_rd_atomic;      //RC到RTR
    __le32 min_rnr_timer;       //RC:进入RTR状态时配置
    __le32 port_num;        //进入INIT状态时配置
    __le32 timeout;     //RC:进入RTS状态时配置
    __le32 retry_cnt;       //RC:进入RTS状态时配置
    __le32 rnr_retry;       //RC:进入RTS状态时配置
    __le32 rate_limit;
    __le32 max_burst_sz;
    __le32 typical_pkt_sz;
};

struct yib_fw_modify_qp_ctx {
    struct yib_fw_qp_attr qp_attr;
    __le32 qp_attr_mask;
    __le32 is_used_srq;     //是否使用srq
    __le32 is_state_chg;    //是否改变qp_state
    __le32 send_cqn;
    __le32 recv_cqn;
};

struct yib_fw_query_qp_ctx {
    __le32 qp_state;
    __le32 sq_psn;
    __le32 rq_psn;
};

#endif
