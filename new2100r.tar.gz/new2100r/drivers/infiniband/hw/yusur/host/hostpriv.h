#ifndef _YUSUR_HW_HOST_H_
#define _YUSUR_HW_HOST_H_

const struct yib_hw_ops *swtest_get_host_ops(void);
const struct yib_hw_ops *r2100_get_host_ops(void);
const struct yib_hw_ops *np_get_host_ops(void);

#endif /* end _YUSUR_HW_PRIV_H_ */
