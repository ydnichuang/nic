#ifndef _YUSUR_HW_COMN_H_
#define _YRDMA_HW_COMN_H_

#define YIB_BAR_BITMAP_BASE 0x300
#define YIB_DDR_BITMAP_BASE 0x300000

void hwcomn_config_mac(struct yib_hw_host *hw, u64 offset, u8 *mac);
void hwcomn_config_ip(struct yib_hw_host *hw, u64 base, bool ipv6, bool src, struct yib_av * yav);
u64 yib_get_tbl_base_addr(struct yib_hw_host *hw, u64 reg, u32 scale);
u32 net_addr2_le32(u8 * dat);

u64 hwcomn_get_base_phy_addr(struct yib_hw_host *hw);
u64 hwcomn_get_ddr_phy_addr(struct yib_hw_host *hw);
//virtual switch ,this only enabled in special hw version
void hwvf_config_mac(struct yib_hw_host *hw, u64 base, u8 *mac);
void yib_aquire_hw_lock(struct yib_sf *sf, yib_gbl_lock_t type);
void yib_release_hw_lock(struct yib_sf *sf, yib_gbl_lock_t type);
u8* hwcomn_get_bar_bitmap_base(struct yib_sf *sf);
u64 hwcomn_get_ddr_bitmap_base(struct yib_hw_host *hw);

#if USE_INDIRECT_DDR_ACCESS == 0
#define yib_read_ddrl(xl, offset) yib_read32(xl->reg_baseddr, offset)
#define yib_write_ddrl(xl, offset, val) yib_write32(xl->reg_baseddr, offset, val)
#define yib_ddr_orl(xl, offset, val) yib_write32(xl->reg_baseddr, offset, ((val)  | yib_read_ddrl(xl, offset)))
#define yib_ddr_andl(xl, offset, val) yib_write32(xl->reg_baseddr, offset, ((val) & yib_read_ddrl(xl, offset)))
#else
u32 hwcomn_ddr_readl(struct yib_sf *sf, u64 base);
void hwcomn_ddr_writel(struct yib_sf *sf, u64 base ,u32 value);
#define yib_read_ddrl(xl, offset) hwcomn_ddr_readl(xl, offset)
#define yib_write_ddrl(xl, offset, val) hwcomn_ddr_writel(xl, offset, val)
#define yib_ddr_orl(xl, offset, val) hwcomn_ddr_writel(xl, offset, ((val)  | yib_read_ddrl(xl, offset)))
#define yib_ddr_andl(xl, offset, val) hwcomn_ddr_writel(xl, offset, ((val) & yib_read_ddrl(xl, offset)))
#endif

#define yib_write_ddrq(xl, offset, val) do { \
						yib_write_ddrl(xl, offset,   u64_lsb(val)); \
						yib_write_ddrl(xl, (offset+4),  u64_msb(val)); \
					} while(0)


#endif /* end _YUSUR_HW_COMN_H_ */
