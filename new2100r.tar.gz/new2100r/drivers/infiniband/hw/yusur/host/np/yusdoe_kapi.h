/**
 * @Author: Xing Wang (wangx_ddpt@yusur.tech)
 * @date: 2024-03-11 10:44:47
 * @last_author: Xing Wang (wangx_ddpt@yusur.tech)
 * @last_edit_time: 2024-03-26 09:46:41
 */

#ifndef YUSDOE_KAPI_H
#define YUSDOE_KAPI_H

#include <linux/types.h>

/**
 * @brief 硬件相关参数
 * @details l1缓存被分为16个通道，每个通道包含32个tag
 *		l2缓存没有划分通道，每次最大配置128
 */
struct hw_advance_cfg {
	bool shared_tbl;			///< 是否共享表
	__u8 l1_cache_ways[16];                   ///< 16个l1缓存通道上分别占用多少way
	__u8 l2_cache_ways;			///< 占用l2缓存多少个way
};

/**
 * @brief 判断表是否存在
 *
 * @param [in] table_id		表号
 * @return 存在返回1，不存在返回0，设备不存在返回-ENXIO
 */
extern int hados_doe_tbl_existed(__u8 table_id);

/**
 * @brief 创建数组表
 *
 * @param [in] table_id		表号
 * @param [in] depth		表最大容量
 * @param [in] data_len		表数据长度
 * @param [in] cfg              硬件配置
 * @return 
 */
extern int hados_doe_create_arraytbl(__u8 table_id, __u32 depth,
				     __u8 data_len,
				     const struct hw_advance_cfg *cfg);

/**
 * @brief 创建哈希表
 *
 * @param [in] table_id		表号
 * @param [in] depth		表最大容量
 * @param [in] key_len		索引值最大长度
 * @param [in] value_len	索引数据最大长度
 * @param [in] cfg              硬件配置
 * @return 
 */
extern int hados_doe_create_hashtbl(__u8 table_id, __u32 depth,
				    __u8 key_len, __u8 value_len,
				    const struct hw_advance_cfg *cfg);

/**
 * @brief 删除数组表
 *
 * @param [in] table_id		表号
 * @return 
 */
extern int hados_doe_delete_arraytbl(__u8 table_id);

/**
 * @brief 删除哈希表
 *
 * @param [in] table_id		表号
 * @return 
 */
extern int hados_doe_delete_hashtbl(__u8 table_id);

/**
 * @brief 数组表存储
 *
 * @param [in] table_id		表号
 * @param [in] index		数组表索引
 * @param [in] data		数据指针
 * @param [in] size		数据长度
 * @return 
 */
extern int hados_doe_array_store(__u8 table_id, __u32 index,
				 const void *data, __u8 size);

/**
 * @brief 数组表读取
 *
 * @param [in] table_id		表号
 * @param [in] index		数组表索引
 * @param [out] data		数据指针，必须指向有效的内存空间
 * @param [in] size		数据长度
 * @return 
 */
extern int hados_doe_array_load(__u8 table_id, __u32 index,
			        void *data, __u8 size);

/**
 * @brief 数组表读取清除数据
 *
 * @param [in] table_id		表号
 * @param [in] index		数组表索引
 * @param [out] data		数据指针，必须指向有效的内存空间
 * @param [in] size		数据长度
 * @return 
 */
extern int hados_doe_array_read_clear(__u8 table_id, __u32 index,
				      void *data, __u8 size);

/**
 * @brief 哈希表插入
 *
 * @param [in] table_id		表号
 * @param [in] key		key值
 * @param [in] key_len		key长度
 * @param [in] value		value值
 * @param [in] value_len	value长度
 * @return 
 */
extern int hados_doe_hash_insert(__u8 table_id, const void *key,
			         __u8 key_len, const void *value,
				 __u8 value_len);

/**
 * @brief 哈希表查询
 *
 * @param [in] table_id		表号
 * @param [in] key		key值
 * @param [in] key_len		key长度
 * @param [out] value		value值
 * @param [in] value_len	value长度
 * @return 
 */
extern int hados_doe_hash_query(__u8 table_id, const void *key,
			        __u8 key_len, void *value, __u8 value_len);

/**
 * @brief 哈希表删除
 *
 * @param [in] table_id		表号
 * @param [in] key		key值
 * @param [in] key_len		key长度
 * @return 
 */
extern int hados_doe_hash_delete(__u8 table_id, const void *key,
				 __u8 key_len);

/**
 * @brief 数组表批量存储
 *
 * @param [in] table_id		表号
 * @param [in] cnt		数据个数
 * @param [in] pair_list	{index : data}数据组
 * @return 批量操作成功次数
 */
extern __u32 hados_doe_array_store_batch(__u8 table_id, __u32 cnt,
					 const void *pair_list);

/**
 * @brief 数组表批量读取
 *
 * @param [in] table_id		表号
 * @param [in] cnt		数据个数
 * @param [in] index_list	索引列表
 * @param [out] pair_list	{index:data}数据组
 * @return 批量操作成功次数
 */
extern __u32 hados_doe_array_load_batch(__u8 table_id, __u32 cnt,
				 	const void *index_list,
					void *pair_list);

/**
 * @brief 数组表批量读取清除
 *
 * @param [in] table_id		表号
 * @param [in] cnt		数据个数
 * @param [in] index_list	索引列表
 * @param [out] pair_list	{index:data}数据组
 * @return 批量操作成功次数
 */
extern __u32 hados_doe_array_readclear_batch(__u8 table_id, __u32 cnt,
					     const void *index_list,
					     void *pair_list);

/**
 * @brief 哈希表批量插入
 *
 * @param [in] table_id		表号
 * @param [in] cnt		数据个数
 * @param [in] pair_list	{key:value} 数据组
 * @return 批量操作成功次数
 */
extern __u32 hados_doe_hash_insert_batch(__u8 table_id, __u32 cnt,
					 const void *pair_list);

/**
 * @brief 哈希表批量查询
 *
 * @param [in] table_id		表号
 * @param [in] cnt		数据个数
 * @param [in] key_list		key值列表
 * @param [out] pair_list	{key:value}数据组
 * @return 批量操作成功次数
 */
extern __u32 hados_doe_hash_query_batch(__u8 table_id, __u32 cnt,
					const void *key_list,
					void *pair_list);

/**
 * @brief 哈希表批量删除
 *
 * @param [in] table_id		表号
 * @param [in] cnt		数据个数
 * @param [in] key_list		key值列表
 * @return 批量操作成功次数
 */
extern __u32 hados_doe_hash_delete_batch(__u8 table_id, __u32 cnt,
					 const void *key_list);

#endif