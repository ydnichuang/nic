/*
 * @Descripttion: Copyright(c) All rights reserved.
 * @version: 
 * @Author: wangyingfu
 * @Date: 2024-05-22 15:37:14
 * @LastEditors: wangyingfu
 * @LastEditTime: 2024-05-22 19:43:50
 */
#include "../../include/basic.h"
#include "../../include/os_api.h"
#include "../../include/os_ds.h"
#include "../../include/mem.h"
#include "../../include/queue.h"
#include "../../include/host.h"
#include "../../include/verbs.h"
#include "../../include/yusur_ib.h"
#include "../../include/user.h"
#include "np_inc_base.h"
#include "np_inc_hw.h"
#include "../hostpriv.h"
#include "../hwcomn.h"
#include "np_sf.h"
#include "yusdoe_kapi.h"
#include "np_api.h"
#include "np_dbg.h"
#include "np_res.h"

u32 np_qpc_modify_mask[NP_MAX_STATES][NP_MAX_STATES][NP_MAX_QP_TYPES] = {
    [IB_QPS_RESET] = {
        [IB_QPS_INIT] = {
		[IB_QPT_RC] = NP_QP_STATE | NP_QP_ACCESS_FLAGS | NP_QP_PKEY_INDEX | NP_QP_PORT | NP_QP_AV |
                                                   NP_QP_PATH_MTU | NP_QP_TIMEOUT | NP_QP_RETRY_CNT | NP_QP_RNR_RETRY |
                                                   NP_QP_RQ_PSN | NP_QP_MAX_QP_RD_ATOMIC | NP_QP_MIN_RNR_TIMER | NP_QP_SQ_PSN |
                                                   NP_QP_MAX_DEST_RD_ATOMIC | NP_QP_DEST_QPN,
		[IB_QPT_UD] = NP_QP_PKEY_INDEX | NP_QP_PORT | NP_QP_ACCESS_FLAGS | NP_QP_QKEY
	},
    },
    [IB_QPS_INIT] = {
        [IB_QPS_INIT] = {
		[IB_QPT_RC] = NP_QP_STATE | NP_QP_ACCESS_FLAGS | NP_QP_PKEY_INDEX | NP_QP_PORT | NP_QP_AV |
                                                   NP_QP_PATH_MTU | NP_QP_TIMEOUT | NP_QP_RETRY_CNT | NP_QP_RNR_RETRY |
                                                   NP_QP_RQ_PSN | NP_QP_MAX_QP_RD_ATOMIC | NP_QP_MIN_RNR_TIMER | NP_QP_SQ_PSN |
                                                   NP_QP_MAX_DEST_RD_ATOMIC | NP_QP_DEST_QPN,
		[IB_QPT_UD] = NP_QP_PKEY_INDEX | NP_QP_PORT | NP_QP_ACCESS_FLAGS | NP_QP_QKEY
	},
        [IB_QPS_RTR] = {
		[IB_QPT_RC] = NP_QP_PKEY_INDEX | NP_QP_PORT | NP_QP_ACCESS_FLAGS | NP_QP_PATH_MTU | NP_QP_RQ_PSN | NP_QP_DEST_QPN | NP_QP_AV | NP_QP_MAX_DEST_RD_ATOMIC | NP_QP_MIN_RNR_TIMER,
                [IB_QPT_UD] = NP_QP_PKEY_INDEX | NP_QP_PORT | NP_QP_ACCESS_FLAGS | NP_QP_PATH_MTU | NP_QP_QKEY
	},
    },
    [IB_QPS_RTR] = {
        [IB_QPS_RTR] = {
		[IB_QPT_RC] = NP_QP_TIMEOUT | NP_QP_RETRY_CNT | NP_QP_RNR_RETRY | NP_QP_SQ_PSN |
                                                                          NP_QP_MAX_QP_RD_ATOMIC | NP_QP_DEST_QPN,
                [IB_QPT_UD] = NP_QP_STATE | NP_QP_SQ_PSN
	},
        [IB_QPS_RTS] = {
		[IB_QPT_RC] = NP_QP_STATE | NP_QP_TIMEOUT | NP_QP_RETRY_CNT | NP_QP_RNR_RETRY | NP_QP_SQ_PSN | NP_QP_MAX_QP_RD_ATOMIC | NP_QP_DEST_QPN,
                [IB_QPT_UD] = NP_QP_STATE | NP_QP_SQ_PSN
	},
    },
    [IB_QPS_RTS] = {
        [IB_QPS_RTS] = {
		[IB_QPT_RC] = 0, 
		[IB_QPT_UD] = 0
	},
        [IB_QPS_SQD] = {
		[IB_QPT_RC] = 0, 
		[IB_QPT_UD] = 0
	},
        [IB_QPS_SQE] = {
		[IB_QPT_RC] = 0, 
		[IB_QPT_UD] = 0
	},
    },
    [IB_QPS_SQD] = {
        [IB_QPS_RTS] = {
		[IB_QPT_RC] = 0, 
		[IB_QPT_UD] = 0
	},
        [IB_QPS_SQD] = {
		[IB_QPT_RC] = 0, 
		[IB_QPT_UD] = 0
	},
        [IB_QPS_SQE] = {
		[IB_QPT_RC] = 0, 
		[IB_QPT_UD] = 0
	},
    },
    [IB_QPS_SQE] = {
        [IB_QPS_RTS] = {
		[IB_QPT_RC] = NP_QP_STATE, 
		[IB_QPT_UD] = 0
	},
        [IB_QPS_SQD] = {
		[IB_QPT_RC] = 0, 
		[IB_QPT_UD] = 0
	},
        [IB_QPS_SQE] = {
		[IB_QPT_RC] = 0, 
		[IB_QPT_UD] = 0
	},
    },
};

u32 np_qpc_warn_mask[NP_MAX_STATES][NP_MAX_STATES][NP_MAX_QP_TYPES] = {
    [IB_QPS_RESET] = {
        [IB_QPS_INIT] = {
		[IB_QPT_RC] = NP_QP_QKEY | NP_QP_PATH_MTU | NP_QP_RQ_PSN | NP_QP_DEST_QPN | NP_QP_AV |
                                                   NP_QP_MAX_DEST_RD_ATOMIC | NP_QP_MIN_RNR_TIMER,
                [IB_QPT_UD] = NP_QP_TIMEOUT | NP_QP_RETRY_CNT | NP_QP_RNR_RETRY | NP_QP_MAX_QP_RD_ATOMIC |
                                                   NP_QP_DEST_QPN | NP_QP_RQ_PSN | NP_QP_AV | NP_QP_MAX_DEST_RD_ATOMIC | NP_QP_PATH_MTU
	},
    },
    [IB_QPS_INIT] = {
        [IB_QPS_INIT] = {
		[IB_QPT_RC] = NP_QP_QKEY | NP_QP_PATH_MTU | NP_QP_RQ_PSN | NP_QP_DEST_QPN | NP_QP_AV |
                                                   NP_QP_MAX_DEST_RD_ATOMIC | NP_QP_MIN_RNR_TIMER,
                [IB_QPT_UD] = NP_QP_TIMEOUT | NP_QP_RETRY_CNT | NP_QP_RNR_RETRY | NP_QP_MAX_QP_RD_ATOMIC |
                                                   NP_QP_DEST_QPN | NP_QP_RQ_PSN | NP_QP_AV | NP_QP_MAX_DEST_RD_ATOMIC | NP_QP_PATH_MTU
	},
        [IB_QPS_RTR] = {
		[IB_QPT_RC] = NP_QP_QKEY,
                [IB_QPT_UD] = NP_QP_TIMEOUT | NP_QP_RETRY_CNT | NP_QP_RNR_RETRY | NP_QP_MAX_QP_RD_ATOMIC |
                                                  NP_QP_DEST_QPN | NP_QP_RQ_PSN | NP_QP_AV | NP_QP_MAX_DEST_RD_ATOMIC
	},
    },
    [IB_QPS_RTR] = {
        [IB_QPS_RTR] = {
		[IB_QPT_RC] = NP_QP_QKEY,
                [IB_QPT_UD] = NP_QP_TIMEOUT | NP_QP_RETRY_CNT | NP_QP_RNR_RETRY | NP_QP_MAX_QP_RD_ATOMIC |
                                                  NP_QP_DEST_QPN | NP_QP_RQ_PSN | NP_QP_AV | NP_QP_MAX_DEST_RD_ATOMIC
	},
        [IB_QPS_RTS] = {
		[IB_QPT_RC] = NP_QP_QKEY,
                [IB_QPT_UD] = NP_QP_TIMEOUT | NP_QP_RETRY_CNT | NP_QP_RNR_RETRY | NP_QP_MAX_QP_RD_ATOMIC |
                                                  NP_QP_DEST_QPN | NP_QP_RQ_PSN | NP_QP_AV | NP_QP_MAX_DEST_RD_ATOMIC
	},
    },
    [IB_QPS_RTS] = {
        [IB_QPS_RTS] = {
		[IB_QPT_RC] = 0, 
		[IB_QPT_UD] = 0
	},
        [IB_QPS_SQD] = {
		[IB_QPT_RC] = 0, 
		[IB_QPT_UD] = 0
	},
        [IB_QPS_SQE] = {
		[IB_QPT_RC] = 0, 
		[IB_QPT_UD] = 0
	},
    },
    [IB_QPS_SQD] = {
        [IB_QPS_RTS] = {
		[IB_QPT_RC] = 0, 
		[IB_QPT_UD] = 0
	},
        [IB_QPS_SQD] = {
		[IB_QPT_RC] = 0, 
		[IB_QPT_UD] = 0
	},
        [IB_QPS_SQE] = {
		[IB_QPT_RC] = 0, 
		[IB_QPT_UD] = 0
	},
    },
    [IB_QPS_SQE] = {
        [IB_QPS_RTS] = {
		[IB_QPT_RC] = 0, 
		[IB_QPT_UD] = 0
	},
        [IB_QPS_SQD] = {
		[IB_QPT_RC] = 0, 
		[IB_QPT_UD] = 0
	},
        [IB_QPS_SQE] = {
		[IB_QPT_RC] = 0, 
		[IB_QPT_UD] = 0
	},
    },
};

u32 np_qp_map[NP_MAX_QP_NUMS] = {0, 39, 0, 8, 16, 24, 32};

struct np_qpn_map_item{
   u32 qpn:16;
   u32 cluster_id:15;
   u32 valid:1;
   u32 av_index;
} ;

static u32 to_hw_mr_access(u32 flags)
{
	u32 mask = 0;

	if (flags & IB_ACCESS_REMOTE_READ)
		mask |=  NP_ACCESS_REMOTE_READ;

	if (flags & IB_ACCESS_REMOTE_WRITE)
		mask |=  NP_ACCESS_REMOTE_WRITE;

	if (flags & IB_ACCESS_REMOTE_ATOMIC)
		mask |=  NP_ACCESS_REMOTE_ATOMIC;

	if (flags & IB_ACCESS_LOCAL_WRITE)
		mask |=  NP_ACCESS_LOCAL_WRITE;

	if (flags & IB_ACCESS_MW_BIND)
		mask |=  NP_ACCESS_MW_BIND;

	return mask;
}

static enum np_mtu to_hw_mtu_size(enum ib_mtu mtu)
{
	switch (mtu) {
		case IB_MTU_256:
			return NP_MTU_256;
		case IB_MTU_512:
			return NP_MTU_512;
		case IB_MTU_1024:
			return NP_MTU_1024;
		case IB_MTU_2048:
			return NP_MTU_2048;
		case IB_MTU_4096:
			return NP_MTU_4096;
		default:
			return 0xff;
	}
}

static enum np_qp_state to_hw_qp_state(enum ib_qp_state state)
{
	switch (state) {
		case IB_QPS_RESET:
			return NP_QPS_RESET;
		case IB_QPS_INIT:
			return NP_QPS_INIT;
		case IB_QPS_RTR:
			return NP_QPS_RTR;
		case IB_QPS_RTS:
			return NP_QPS_RTS;
		case IB_QPS_SQD:
			return NP_QPS_SQD;
		case IB_QPS_SQE:
			return NP_QPS_SQE;
		case IB_QPS_ERR:
			return NP_QPS_ERR;
		default:
			return 0xff;
	}
}

static enum np_mr_state to_hw_mr_state(enum yib_mr_state state)
{
	switch (state) {
		case YIB_MR_INVALID:
			return NP_MR_INVALID;
		case YIB_MR_FREE:
			return NP_MR_FREE;
		case YIB_MR_VALID:
			return NP_MR_VALID;
		default:
			return 0xff;
	}
}

static void np_set_qp_map_item(struct np_yib_sf *np_sf, struct np_qpn_map_item * item, int index)
{
	void *buf = NULL;

	buf = yib_frag_get_vaddr(np_sf->qid_cid_base, sizeof(struct np_qpn_map_item), index);
	memcpy(buf, item, sizeof(struct np_qpn_map_item));
}

static struct np_qpn_map_item * np_get_qp_map_item(struct np_yib_sf *np_sf,  int index)
{
	struct yib_frag_buf *buf = np_sf->qid_cid_base;
	
	if((index * sizeof(struct np_qpn_map_item)) > buf->real_size)
		return NULL;

	return yib_frag_get_vaddr(buf, sizeof(struct np_qpn_map_item), index);
}
#if 0
static int np_alloc_qp_cluster(struct np_yib_sf *np_sf, int pd, u32 qpn, void *priv, bool enable)
{
	struct np_qpn_map_item *temp_item = NULL;
	struct np_qpn_map_item item;
	struct np_qp_priv *qp_priv = (struct np_qp_priv *)priv;
	int index, start, start_cid = pd % YIB_NP_CLU_NUM;
    	int  i = 0;
	int  j = 0;
	
	memset(&item, 0, sizeof(struct np_qpn_map_item));
	os_mutex_lock(&np_sf->np_mutex);
	if (enable)
	{
#ifdef NP_MAP_DEBUG
		if(qpn < NP_MAX_QP_NUMS)
		{
			index = np_qp_map[qpn];
	
#else
                while (i < YIB_NP_CLU_NUM) {
                for (j = 0; j < YIB_MAX_QID_PER_CLU; j++) {
                        start = (start_cid + i) % YIB_NP_CLU_NUM;
                        index = (start * YIB_MAX_QID_PER_CLU) + j;
#endif
			temp_item = np_get_qp_map_item(np_sf, index);
     			if (temp_item)
                        {
                                if(temp_item->valid == 0) {
                                        item.qpn = qpn & 0xFFFF;
                                        item.cluster_id = (index / YIB_MAX_QID_PER_CLU) & 0x7FFF;
                                        item.valid = 1;
                                        if(qp_priv->ah)
                                                item.av_index = qp_priv->ah->entry.index;
                                        np_set_qp_map_item(np_sf, &item, index);
                                        qp_priv->index = (u32)index;
                                        os_mutex_unlock(&np_sf->np_mutex);
                                        return 0;
                                }
                        }
#ifdef NP_MAP_DEBUG
#else
                }
                i++;
#endif
                }
        }else{
                start = qp_priv->index;
                temp_item = np_get_qp_map_item(np_sf, start);
                if (temp_item)
                {
                        item.qpn = 0;
                        item.valid = 0;
                        np_set_qp_map_item(np_sf, &item, start);
                        os_mutex_unlock(&np_sf->np_mutex);
                        return 0;
                }
        }

        os_mutex_unlock(&np_sf->np_mutex);
        return -EAGAIN;
}
#endif
static int np_alloc_qp_cluster(struct np_yib_sf *np_sf, int pd, u32 qpn, void *priv, bool enable)
{
        struct np_qpn_map_item *temp_item = NULL;
        struct np_qpn_map_item item;
        struct np_qp_priv *qp_priv = (struct np_qp_priv *)priv;
        int start, start_cid = pd % YIB_NP_CLU_NUM;
        int  i = 0;
        int  j = 0;

        memset(&item, 0, sizeof(struct np_qpn_map_item));
        os_mutex_lock(&np_sf->np_mutex);
        if (enable)
        {
                while (i < YIB_NP_CLU_NUM) {
                for (j = 0; j < YIB_MAX_QID_PER_CLU; j++) {
                        start = (start_cid + i) % YIB_NP_CLU_NUM;
                        temp_item = np_get_qp_map_item(np_sf, (start * YIB_MAX_QID_PER_CLU) + j);
                        printk("np qid_cid map index:%d %u\n", (start * YIB_MAX_QID_PER_CLU) + j, (start * YIB_MAX_QID_PER_CLU) + j);
			if (temp_item)
                        {
                                if(temp_item->valid == 0) {
                                        item.qpn = qpn & 0xFFFF;
                                        item.cluster_id = start & 0x7FFF;
                                        item.valid = 1;
                                        if(qp_priv->ah)
                                                item.av_index = qp_priv->ah->entry.index;
                                        np_set_qp_map_item(np_sf, &item, (start * YIB_MAX_QID_PER_CLU) + j);
                                        qp_priv->index = (start * YIB_MAX_QID_PER_CLU) + j;
                                        os_mutex_unlock(&np_sf->np_mutex);
                                        return 0;
                                }
                        }
                }
                i++;
                }
        }else{
                start = qp_priv->index;
                temp_item = np_get_qp_map_item(np_sf, start);
                if (temp_item)
                {
                        item.qpn = 0;
                        item.valid = 0;
                        np_set_qp_map_item(np_sf, &item, start);
                        os_mutex_unlock(&np_sf->np_mutex);
                        return 0;
                }
        }

        os_mutex_unlock(&np_sf->np_mutex);
        return -EAGAIN;
}


int np_sf_pre_init(struct yib_sf *sf)
{
	struct np_yib_sf *np_sf = sf->sf_priv;
	
	sf->reg_base[0] = sf->hw->reg_base[0];
	sf->bar_size[0] = YIB_NP_BAR_SIZE;

	os_mutex_init(&np_sf->np_mutex);
	
	return 0;
}

int np_sf_init(struct yib_sf *sf, bool b_del)
{
	struct np_yib_sf *np_sf = sf->sf_priv;
	u64 size = sizeof(struct np_qpn_map_item)* YIB_NP_CLU_NUM * YIB_MAX_QID_PER_CLU;
	//int i = 0;
	//void *buf = NULL;	
	if(b_del){
    		if (np_sf->qid_cid_base) {
			yib_frag_free_node(sf, np_sf->qid_cid_base);
			np_sf->qid_cid_base = NULL;
		}
	}else{
		size = os_align_up(size, 4096UL);
		np_sf->qid_cid_base = yib_frag_buf_alloc_node(sf, size, true);
		if (np_sf->qid_cid_base == NULL) {
			os_printe(sf->hw->dev, "np qid_cid buf mem not enough");
			return -ENOMEM;
		}
#if 0	
		for(i = 0; i < size; i++){
			//*(((char *)np_sf->qid_cid_base->frags->vaddr) + i) = 0x56;
			buf = yib_frag_get_vaddr(np_sf->qid_cid_base, sizeof(char), i);
			*((char *)buf) = 0x56;
		}
#endif
	}
	return 0;
}

int np_start_sf(struct yib_sf *sf)
{
	struct np_yib_sf *np_sf = sf->sf_priv;
	int ret = 0;

	if (np_sf->started == true)
		return 0;
	
    	ret = np_hw_res_init(sf, &np_sf->hw_res);
	if (ret) {
		os_printe(sf->hw->dev, "hw_res init failed");
		return ret;
	}

	np_sf->started = true;
	return 0;
}

void np_stop_sf(struct yib_sf *sf, bool is_shutdown)
{
	struct np_yib_sf *np_sf = sf->sf_priv;

	if (np_sf->started == false)
		return;
	
	np_hw_res_exit(sf, &np_sf->hw_res);

	np_sf->started = false;
}

void np_add_mac(struct yib_sf *sf, u8 *mac, int index, u8 port_num)
{
	struct np_yib_sf *np_sf = sf->sf_priv;
	struct yib_np_resource *hw_res = &np_sf->hw_res;
	struct np_hw_smac_port_entry mac_port;
        int i = 0;

        yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT,
                        "user mac[%d]: %02x %02x %02x %02x %02x %02x\n",
                        index, mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);

        for(i = 0; i < 6; i++) {
                mac_port.mac[i] = mac[5-i];
        }

        yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "smac[5-0][%d]: %02x:%02x:%02x:%02x:%02x:%02x\n",
                        index, mac_port.mac[5], mac_port.mac[4], mac_port.mac[3], mac_port.mac[2], mac_port.mac[1], mac_port.mac[0]);

	np_hwres_write(&mac_port, NP_MAC_PORT_PORTID, NP_CFG_PORT_ID);	
        if (np_store_array(hw_res->mac_port_id, index, &mac_port, sizeof(struct np_hw_smac_port_entry))) {
                os_printe(sf->hw->dev, "set smac failed");
                return;
        }
}

void np_init_av(struct yib_sf *sf, struct yib_av *av, int index, bool b_del)
{
        struct np_yib_sf *np_sf = sf->sf_priv;
        struct yib_np_resource *hw_res = &np_sf->hw_res;	
	u8 size = 0;
	char databuf[128];
	u8 *buf = NULL;
	
	buf = databuf + (0x4 - ((u64)databuf & 0x3));
	size = (yib_packet_hdr_fill(sf->hw->yib, av, buf, 0)) & 0xFF;
	
        if (np_store_array(hw_res->avt_id, index, buf, size)) {
                os_printe(sf->hw->dev, "init ah av table failed");
                return;
        }

}

int np_mrw_alloc(struct yib_sf *sf, struct yib_mr *mr, u32 *lkey, u32 *rkey)
{
	struct yib_page_tbl *mtt_tbl = NULL;
	
	if (!mr->type.is_dma && !mr->type.is_fast && !mr->type.is_mw) {
		mtt_tbl = kzalloc(sizeof(*mtt_tbl), GFP_KERNEL);
		if (mtt_tbl == NULL) {
			os_printe(sf->hw->dev, "alloc mr page_tbl failed");
			return -ENOMEM;
		}
		mr->priv.page_tbl = (void *)mtt_tbl;
	}

	yib_mr_helper_get_key(mr->entry.index, lkey, rkey);
	return 0;
}

void np_mrw_destroy(struct yib_sf *sf, struct yib_mr *mr)
{
	struct np_yib_sf *np_sf = sf->sf_priv;
	struct yib_np_resource *hw_res = &np_sf->hw_res;
	struct yib_page_tbl *mtt_tbl = NULL;
	struct np_hw_mpt_entry mpt_entry;
	int ret = 0;
	u32 index = 0;

	if(mr->state != YIB_MR_INVALID){
		index = yib_get_mr_sw_idx(mr);
		memset(&mpt_entry, 0, sizeof(mpt_entry));

		//ret = np_store_array(hw_res->mpt_id, index, &mpt_entry, sizeof(mpt_entry));
		if (ret) {
			os_printe(sf->hw->dev, "dereg mr failed");
			return;
		}
	}

	if (mr->type.is_dma || mr->type.is_fast || mr->type.is_mw) {
		return;
	} else {
		mtt_tbl = (struct yib_page_tbl *)mr->priv.page_tbl;
		if (mtt_tbl) {
			kfree(mtt_tbl);
		}
		mr->priv.page_tbl = NULL;
	}
}

int np_mr_mtt_init(struct yib_sf *sf, struct yib_mr *mr, struct scatterlist *sg,
				int npages, u32 page_size, u64 pa0)
{
	struct yib_page_tbl *mtt_tbl = (struct yib_page_tbl *)mr->priv.page_tbl;
	mtt_tbl->root_pa = pa0;
	
	return 0;
}

int np_mr_mpt_update(struct yib_sf *sf, struct yib_mr *ymr)
{
	struct np_yib_sf *np_sf = sf->sf_priv;
	struct yib_np_resource *hw_res = &np_sf->hw_res;
	struct np_hw_mpt_entry mpt_entry;
	enum np_hw_mr_type mr_type;
	struct yib_page_tbl *mtt_tbl = (struct yib_page_tbl *)ymr->priv.page_tbl;
	u32 mr_state, mr_access, index = 0, tbl_levels = 0;
	u64 va = 0, pa1 = 0, pbl_pa = 0, mr_size = 0;
	int ret = 0;
	bool bupdate = false;

	memset(&mpt_entry, 0, sizeof(mpt_entry));
	index = yib_get_mr_sw_idx(ymr);
	
	mr_state = to_hw_mr_state(ymr->state);
	mr_access = to_hw_mr_access(ymr->access);

	if (ymr->type.is_fast) {
		mr_type = NP_HW_MR_NORMAL;
		mr_state = NP_MR_FREE;
		tbl_levels = 1;
		bupdate = true;
		mr_access |= NP_ACCESS_INVALID;
	} else if (ymr->type.is_dma) {
		mr_type = NP_HW_MR_PMR;
		tbl_levels = 0;
		mr_size = 0xFFFFFFFFFFFFFFFF;
	} else if (ymr->type.is_mw) {
		mr_type = NP_HW_MR_MW_TYPE1;
		mr_state = NP_MR_FREE;
	} else {
		mr_type = NP_HW_MR_NORMAL;
		tbl_levels = 0;
		pbl_pa = mtt_tbl->root_pa;
		mr_size = yib_os_mr_length(ymr);
		va = yib_os_mr_iova(ymr);
		if (tbl_levels == 0)
			pa1 = 0;
	}

	yib_dbg_info(YUSUR_IB_M_MR, YUSUR_IB_DBG_INIT, "mr type: 0x%x, tbl_levels: 0x%x, state: 0x%x, pdn: 0x%x, access: 0x%x, size: 0x%llx\n",
			mr_type, tbl_levels, mr_state, ymr->pd_num, mr_access, mr_size);

	yib_dbg_info(YUSUR_IB_M_MR, YUSUR_IB_DBG_INIT, "mr pbl_pa: 0x%llx, va: 0x%llx\n", pbl_pa, va);

	pa1 = pa1 >> 12;
	//todo fill mpt
	np_hwres_write(&mpt_entry, NP_MPT_SIZE_LSB, u64_lsb(mr_size));	
	np_hwres_write(&mpt_entry, NP_MPT_SIZE_MSB, (u64_msb(mr_size) & 0xFFFF));	
	np_hwres_write(&mpt_entry, NP_MPT_ACCESS_RIGHT, mr_access);	
	np_hwres_write(&mpt_entry, NP_MPT_PD, ymr->pd_num);	
	np_hwres_write(&mpt_entry, NP_MPT_PA0_LSB, u64_lsb(pbl_pa));	
	np_hwres_write(&mpt_entry, NP_MPT_PA0_MSB, u64_msb(pbl_pa));	
	np_hwres_write(&mpt_entry, NP_MPT_PA1_LSB, u64_lsb(pa1));	
	np_hwres_write(&mpt_entry, NP_MPT_PA1_MSB, u64_msb(pa1));	
	np_hwres_write(&mpt_entry, NP_MPT_MRW_PG_SIZE, 0);	
	np_hwres_write(&mpt_entry, NP_MPT_NUM_TRANS_LAYERS, tbl_levels);	
	np_hwres_write(&mpt_entry, NP_MPT_TYPE, mr_type);	
	np_hwres_write(&mpt_entry, NP_MPT_VA_LSB, u64_lsb(va));	
	np_hwres_write(&mpt_entry, NP_MPT_VA_MSB, u64_msb(va));	
	np_hwres_write(&mpt_entry, NP_MPT_STATE, mr_state);	
	if (ymr->type.is_user) {
		//todo fill mpt
	} else {
		//todo fill mpt
	}

	ret = np_store_array(hw_res->mpt_id, index, &mpt_entry, sizeof(mpt_entry));
	if (ret) {
		os_printe(sf->hw->dev, "reg mr failed");
		return ret;
	}
	yib_dbg_info(YUSUR_IB_M_MR, YUSUR_IB_DBG_INIT, "reg mr: %d\n", index);
	np_dbg_print_mpt(&mpt_entry, false);
	return 0;
}

int np_mr_debugfs(struct yib_sf *sf, struct yib_mr *mr)
{
	struct np_yib_sf *np_sf = sf->sf_priv;
	struct yib_np_resource *hw_res = &np_sf->hw_res;
	struct np_hw_mpt_entry mpt_entry;
	u32 index = 0;
	
	index = yib_get_mr_sw_idx(mr);
	
	if (np_load_array(hw_res->mpt_id, index, &mpt_entry, sizeof(mpt_entry)))
		goto err;

	if (pr_info("mr_idx:%u\n", index))
		goto err;

	if (pr_info("type:%d\n", np_hwres_read(&mpt_entry, NP_MPT_TYPE)))
		goto err;

	if (pr_info("state:%d\n", np_hwres_read(&mpt_entry, NP_MPT_STATE)))
		goto err;

	if (np_dbg_print_mpt(&mpt_entry, true))
		goto err;

	return 0;
err:
	return -EMSGSIZE;
}

int np_cq_info_init(struct yib_sf *sf, struct yib_cq *cq, bool enable)
{
	struct np_yib_sf *np_sf = sf->sf_priv;
	struct yib_np_resource *hw_res = &np_sf->hw_res;
	struct np_hw_cqc_entry cqc_entry;
	int tbl_levels = 0;
	u64 cq_size = 0;
	int cq_pbl_size = 0;
	int cq_page_size = 0;
	int ret = 0;
	u32 index = 0;
	u64 handle;
	u64 pa_arr[8] = {0};

	index = yib_get_cq_sw_idx(cq);
	
	if (enable == true) {
		memset(&cqc_entry, 0, sizeof(cqc_entry));

		tbl_levels = cq->queue->tbl.levels;
		cq_size = cq->queue->depth;
		cq_page_size = NP_SIZE_TO_N(cq->queue->tbl.pg_size);
		cq_pbl_size = NP_SIZE_TO_N(cq->queue->tbl.pbl_pg_size);

		ret = yib_get_4kpages_from_pagetbl(&cq->queue->tbl, 8, pa_arr);
		if (ret < 0) {
			os_printe(sf->hw->dev, "get cq 4kpages failed");
			return -EAGAIN;
		}

		yib_dbg_info(YUSUR_IB_M_CQ, YUSUR_IB_DBG_CREATE, "cq tbl_levels: 0x%x, cq_depth: 0x%x, pbl_size: 0x%x, page_size: 0x%x, pa0: 0x%llx, pa1: 0x%llx\n",
			tbl_levels, cq_size, cq_pbl_size, cq_page_size, pa_arr[0], pa_arr[1]);
		
		if (cq->is_user)
			handle = cq->u_cq_handler;
		else
			handle = (u64)cq;
		
		//todo fill cqc
		np_hwres_write(&cqc_entry, NP_CQC_CQ_SIZE, (cq_size & 0xFFFF));	
		np_hwres_write(&cqc_entry, NP_CQC_CQ_PA0_LSB, u64_lsb(pa_arr[0]));	
		np_hwres_write(&cqc_entry, NP_CQC_CQ_PA0_MSB, u64_msb(pa_arr[0]));	
		np_hwres_write(&cqc_entry, NP_CQC_CQ_PA1_LSB, u64_lsb(pa_arr[1]));	
		np_hwres_write(&cqc_entry, NP_CQC_CQ_PA1_MSB, u64_msb(pa_arr[1]));	
			
		ret = np_store_array(hw_res->cqc_id, index, &cqc_entry, sizeof(cqc_entry));
		if (ret) {
			os_printe(sf->hw->dev, "create cq failed");
			return -EAGAIN;
		}
		yib_dbg_info(YUSUR_IB_M_CQ, YUSUR_IB_DBG_CREATE, "create cq: %d\n", index);
		np_dbg_print_cqc(&cqc_entry, false);
	} else {
		memset(&cqc_entry, 0, sizeof(cqc_entry));
		//ret = np_store_array(hw_res->cqc_id, index, &cqc_entry, sizeof(cqc_entry));
		if (ret) {
			os_printe(sf->hw->dev, "destroy cq failed");
			return -EAGAIN;
		}
		yib_dbg_info(YUSUR_IB_M_CQ, YUSUR_IB_DBG_DESTROY, "destroy cq: %d\n", index);
	}
	return 0;
}

void np_cq_notify_update(struct yib_sf *sf, struct yib_cq *cq, u32 flag)
{
}

int np_cq_debugfs(struct yib_sf *sf, struct yib_cq *ycq)
{
	struct np_yib_sf *np_sf = sf->sf_priv;
	struct yib_np_resource *hw_res = &np_sf->hw_res;
	struct np_hw_cqc_entry cqc_entry;
	u32 index = yib_get_cq_sw_idx(ycq);

	if (np_load_array(hw_res->cqc_id, index, &cqc_entry, sizeof(cqc_entry)))
		goto err;

	if (pr_info("cqid:%u\n", index))
		goto err;

	if (pr_info("cq_root_pa:%llx\n", ycq->queue->tbl.root_pa))
		goto err;

	if (pr_info("pi:%d\n", np_hwres_read(&cqc_entry, NP_CQC_CQ_PI)))
		goto err;

	if (pr_info("ci:%d\n", np_hwres_read(&cqc_entry, NP_CQC_CQ_CI)))
		goto err;

	if (np_dbg_print_cqc(&cqc_entry, true))
		goto err;

	return 0;
err:
	return -EMSGSIZE;
}
#if 1
static u32 index_to_cluster(u32 index)
{
	return index/YIB_MAX_QID_PER_CLU;
}

static u32 index_to_qid(u32 index)
{
	return index%YIB_MAX_QID_PER_CLU;
}
#endif

static int np_reset_qpc(struct yib_sf *sf, struct yib_qp *yqp, struct np_hw_sqc_entry *sqc_entry, struct np_hw_sqs_entry *sqs_entry)
{
	int tbl_levels = 0;
	u32 send_cqn, recv_cqn, index = 0;
	u64 pa_arr[8] = {0};
	int ret = 0;

	index = yib_get_qp_sw_idx(yqp);
	send_cqn = yib_get_cq_sw_idx(yqp->ysq_cq);
	recv_cqn = yib_get_cq_sw_idx(yqp->yrq_cq);

	tbl_levels = yqp->ysq.queue->tbl.levels;
	ret = yib_get_4kpages_from_pagetbl(&yqp->ysq.queue->tbl, 8, pa_arr);
	if (ret < 0)
		return -EINVAL;

	yib_dbg_info(YUSUR_IB_M_SQ, YUSUR_IB_DBG_CREATE, 
			"sq tbl_levels: 0x%x, sq_depth: 0x%x\n",
			tbl_levels, yqp->ysq.queue->depth);
	
	yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_CREATE, 
		"is_user: %d, use_srq: %d\n", yqp->is_user,yqp->use_srq);

	memset(sqc_entry, 0, sizeof(struct np_hw_sqc_entry));
	memset(sqs_entry, 0, sizeof(struct np_hw_sqs_entry));
	//todo store array
	if(yqp->qp_type == IB_QPT_UD || yqp->qp_type == IB_QPT_GSI){
		np_hwres_write(sqs_entry, NP_SQS_SERVICE_TYPE, NP_QPT_UD);	
	}
	np_hwres_write(sqs_entry, NP_SQS_SQ_CQ_ID, send_cqn);	
	np_hwres_write(sqs_entry, NP_SQS_QPN, index);	
	np_hwres_write(sqs_entry, NP_SQS_ACCESS_RIGHT, to_hw_mr_access(yqp->attr.qp_access_flags));	
	np_hwres_write(sqs_entry, NP_SQS_PDN, yqp->ypd->entry.index);	
	np_hwres_write(sqs_entry, NP_SQS_MTU_SIZE, to_hw_mtu_size(yqp->attr.path_mtu));	
	np_hwres_write(sqc_entry, NP_SQC_SQ_SIZE, yqp->ysq.queue->depth);	
	np_hwres_write(sqc_entry, NP_SQC_SQ_L1_SIZE, YIB_NP_SQE_L1_TAG);	
	np_hwres_write(sqc_entry, NP_SQC_SQ_PA0_LSB, u64_lsb(pa_arr[0]));
	np_hwres_write(sqc_entry, NP_SQC_SQ_PA0_MSB, u64_msb(pa_arr[0]));
	np_hwres_write(sqc_entry, NP_SQC_SQ_PA1_LSB, u64_lsb(pa_arr[1]));
	np_hwres_write(sqc_entry, NP_SQC_SQ_PA1_MSB, u64_msb(pa_arr[1]));
	np_hwres_write(sqc_entry, NP_SQC_SQ_PA2_LSB, u64_lsb(pa_arr[2]));
	np_hwres_write(sqc_entry, NP_SQC_SQ_PA2_MSB, u64_msb(pa_arr[2]));
	np_hwres_write(sqc_entry, NP_SQC_SQ_PA3_LSB, u64_lsb(pa_arr[3]));
	np_hwres_write(sqc_entry, NP_SQC_SQ_PA3_MSB, u64_msb(pa_arr[3]));
	np_hwres_write(sqc_entry, NP_SQC_SQ_PA4_LSB, u64_lsb(pa_arr[4]));
	np_hwres_write(sqc_entry, NP_SQC_SQ_PA4_MSB, u64_msb(pa_arr[4]));
	np_hwres_write(sqc_entry, NP_SQC_SQ_PA5_LSB, u64_lsb(pa_arr[5]));
	np_hwres_write(sqc_entry, NP_SQC_SQ_PA5_MSB, u64_msb(pa_arr[5]));
	np_hwres_write(sqc_entry, NP_SQC_SQ_PA6_LSB, u64_lsb(pa_arr[6]));
	np_hwres_write(sqc_entry, NP_SQC_SQ_PA6_MSB, u64_msb(pa_arr[6]));
	np_hwres_write(sqc_entry, NP_SQC_SQ_PA7_LSB, u64_lsb(pa_arr[7]));
	np_hwres_write(sqc_entry, NP_SQC_SQ_PA7_MSB, u64_msb(pa_arr[7]));
	
	return 0;
}

static int np_reset_rqc(struct yib_sf *sf, struct yib_qp *yqp, struct np_hw_rqc_entry *rqc_entry, struct np_hw_rqs_entry *rqs_entry)
{
	struct yib_rq *yrq = yqp->type.yrq;
	int tbl_levels = 0;
	u32 send_cqn, recv_cqn, index = 0;
	u64 pa_arr[8] = {0};
	int ret = 0;

	index = yib_get_qp_sw_idx(yqp);
	send_cqn = yib_get_cq_sw_idx(yqp->ysq_cq);
	recv_cqn = yib_get_cq_sw_idx(yqp->yrq_cq);

	tbl_levels = yrq->queue->tbl.levels;
	ret = yib_get_4kpages_from_pagetbl(&yrq->queue->tbl, 8, pa_arr);
	if (ret < 0)
		return -EINVAL;

	yib_dbg_info(YUSUR_IB_M_SQ, YUSUR_IB_DBG_CREATE, 
			"rq tbl_levels: 0x%x, rq_depth: 0x%x\n",
			tbl_levels, yrq->queue->depth);
	
	yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_CREATE, 
		"is_user: %d, use_srq: %d\n", yqp->is_user,yqp->use_srq);

	memset(rqc_entry, 0, sizeof(struct np_hw_rqc_entry));
	memset(rqs_entry, 0, sizeof(struct np_hw_rqs_entry));
	//todo store array
	if(yqp->qp_type == IB_QPT_UD || yqp->qp_type == IB_QPT_GSI){
		np_hwres_write(rqs_entry, NP_RQS_SERVICE_TYPE, NP_QPT_UD);	
	}
	np_hwres_write(rqs_entry, NP_RQS_RQ_CQ_ID, recv_cqn);	
	np_hwres_write(rqs_entry, NP_RQS_QPN, index);	
	np_hwres_write(rqs_entry, NP_RQS_MTU_SIZE, to_hw_mtu_size(yqp->attr.path_mtu));	
	np_hwres_write(rqs_entry, NP_RQS_ACCESS_RIGHT, to_hw_mr_access(yqp->attr.qp_access_flags));	
	np_hwres_write(rqs_entry, NP_RQS_PDN, yqp->ypd->entry.index);	
	np_hwres_write(rqc_entry, NP_RQC_RQ_SIZE, yrq->queue->depth);	
	np_hwres_write(rqc_entry, NP_RQC_RQ_L1_SIZE, YIB_NP_RQE_L1_TAG);	
	np_hwres_write(rqc_entry, NP_RQC_RQ_PA0_LSB, u64_lsb(pa_arr[0]));
	np_hwres_write(rqc_entry, NP_RQC_RQ_PA0_MSB, u64_msb(pa_arr[0]));
	np_hwres_write(rqc_entry, NP_RQC_RQ_PA1_LSB, u64_lsb(pa_arr[1]));
	np_hwres_write(rqc_entry, NP_RQC_RQ_PA1_MSB, u64_msb(pa_arr[1]));
	np_hwres_write(rqc_entry, NP_RQC_RQ_PA2_LSB, u64_lsb(pa_arr[2]));
	np_hwres_write(rqc_entry, NP_RQC_RQ_PA2_MSB, u64_msb(pa_arr[2]));
	np_hwres_write(rqc_entry, NP_RQC_RQ_PA3_LSB, u64_lsb(pa_arr[3]));
	np_hwres_write(rqc_entry, NP_RQC_RQ_PA3_MSB, u64_msb(pa_arr[3]));
	np_hwres_write(rqc_entry, NP_RQC_RQ_PA4_LSB, u64_lsb(pa_arr[4]));
	np_hwres_write(rqc_entry, NP_RQC_RQ_PA4_MSB, u64_msb(pa_arr[4]));
	np_hwres_write(rqc_entry, NP_RQC_RQ_PA5_LSB, u64_lsb(pa_arr[5]));
	np_hwres_write(rqc_entry, NP_RQC_RQ_PA5_MSB, u64_msb(pa_arr[5]));
	np_hwres_write(rqc_entry, NP_RQC_RQ_PA6_LSB, u64_lsb(pa_arr[6]));
	np_hwres_write(rqc_entry, NP_RQC_RQ_PA6_MSB, u64_msb(pa_arr[6]));
	np_hwres_write(rqc_entry, NP_RQC_RQ_PA7_LSB, u64_lsb(pa_arr[7]));
	np_hwres_write(rqc_entry, NP_RQC_RQ_PA7_MSB, u64_msb(pa_arr[7]));
	
	return 0;
}

int np_qp_info_init(struct yib_sf *sf, struct yib_qp *yqp, bool enable)
{
	struct np_yib_sf *np_sf = sf->sf_priv;
	struct yib_np_resource *hw_res = &np_sf->hw_res;
	struct np_qp_priv *priv = NULL;
	struct np_hw_sqc_entry sqc_entry;
	struct np_hw_sqs_entry sqs_entry;
	struct np_hw_rqc_entry rqc_entry;
	struct np_hw_rqs_entry rqs_entry;
	struct np_hw_qp_remap_entry qp_remap;
	struct np_hw_qp_state_entry qp_state;
	int ret = 0;
	u32 cid, qid, index = 0;

	index = yib_get_qp_sw_idx(yqp);
	
	if (enable == true) {
		ret = np_reset_qpc(sf, yqp, &sqc_entry, &sqs_entry);
		if(ret)
			return ret;		
		ret = np_reset_rqc(sf, yqp, &rqc_entry, &rqs_entry);
		if(ret)
			return ret;		
		
		priv = os_zalloc(sizeof(struct np_qp_priv));
		if (priv == NULL)
		{
			os_printe(sf->hw->dev, "alloc qp privdata failed");
			return -ENOMEM;
		}
		if(yqp->qp_type == IB_QPT_RC){
			priv->ah = yib_inner_create_ah(sf);
			if(priv->ah == NULL)
			{	
				os_printe(sf->hw->dev, "alloc ah from pool failed");
				ret = -ENOMEM;
				goto err1;
			}
		}
		ret = np_alloc_qp_cluster(np_sf, yqp->ypd->entry.index, index, priv, true);
		if (ret)
		{
			os_printe(sf->hw->dev, "alloc qp cluster map failed");
			goto err2;
		}	
		yqp->privdata = priv;		
		cid = index_to_cluster(priv->index);
		qid = index_to_qid(priv->index);

		os_printe(sf->hw->dev, "alloc qp pd_num:%d index:%d", yqp->ypd->entry.index, priv->index);
		memset(&qp_remap, 0, sizeof(struct np_hw_qp_remap_entry));
		memset(&qp_state, 0, sizeof(struct np_hw_qp_state_entry));
		
		np_hwres_write(&qp_remap, NP_QP_REMAP_QPID, (qid & 0xF));	
		np_hwres_write(&qp_remap, NP_QP_REMAP_CID, ((cid + 4) & 0xF));	
		
		np_hwres_write(&qp_state, NP_QPN_STATE, NP_QPS_RESET);	

		ret = np_store_array(hw_res->np_qp_tbl[cid].sqc_id, qid, &sqc_entry, sizeof(struct np_hw_sqc_entry));
		if(ret){
			os_printe(sf->hw->dev, "create qp store sqc failed");
			goto err3;	
		}
		ret = np_store_array(hw_res->np_qp_tbl[cid].sqs_id, qid, &sqs_entry, sizeof(struct np_hw_sqs_entry));
		if(ret){
			os_printe(sf->hw->dev, "create qp store sqs failed");
			goto sqc_err;	
		}
		ret = np_store_array(hw_res->np_qp_tbl[cid].rqc_id, qid, &rqc_entry, sizeof(struct np_hw_rqc_entry));
		if(ret){
			os_printe(sf->hw->dev, "create qp store rqc failed");
			goto sqs_err;	
		}
		ret = np_store_array(hw_res->np_qp_tbl[cid].rqs_id, qid, &rqs_entry, sizeof(struct np_hw_rqs_entry));
		if(ret){
			os_printe(sf->hw->dev, "create qp store rqs failed");
			goto rqc_err;	
		}
		ret = np_store_array(hw_res->qp_remap_id, index, &qp_remap, sizeof(struct np_hw_qp_remap_entry));
		if(ret){
			os_printe(sf->hw->dev, "create qp store qp remap failed");
			goto rqs_err;	
		}
		ret = np_store_array(hw_res->qp_state_id, priv->index, &qp_state, sizeof(struct np_hw_qp_state_entry));
		if(ret){
			os_printe(sf->hw->dev, "create qp store qp state failed");
			goto qp_remap_err;	
		}
		yqp->attr.qp_state = IB_QPS_RESET;
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_CREATE, "create qp: %d\n", index);
		np_dbg_print_qpc(sf, yqp, false);
		return 0;
	} else {
		priv = yqp->privdata;
		if(priv != NULL){
			cid = index_to_cluster(priv->index);
			qid = index_to_qid(priv->index);
#if 0
			//todo clear array
			np_read_clear_array(hw_res->np_qp_tbl[cid].sqc_id, qid, &sqc_entry, sizeof(struct np_hw_sqc_entry));
			np_read_clear_array(hw_res->np_qp_tbl[cid].sqs_id, qid, &sqs_entry, sizeof(struct np_hw_sqs_entry));
			np_read_clear_array(hw_res->np_qp_tbl[cid].rqc_id, qid, &rqc_entry, sizeof(struct np_hw_rqc_entry));
			np_read_clear_array(hw_res->np_qp_tbl[cid].rqs_id, qid, &rqs_entry, sizeof(struct np_hw_rqs_entry));
			np_read_clear_array(hw_res->qp_remap_id, index, &qp_remap, sizeof(struct np_hw_qp_remap_entry));
			np_read_clear_array(hw_res->qp_state_id, priv->index, &qp_state, sizeof(struct np_hw_qp_state_entry));
#endif
			ret = np_alloc_qp_cluster(np_sf, yqp->ypd->entry.index, index, priv, false);
			if (ret)
			{
				os_printe(sf->hw->dev, "destroy qp cluster map failed");
			}
			if(yqp->qp_type == IB_QPT_RC)
				yib_inner_destroy_ah(priv->ah);

			os_free(yqp->privdata);
			yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_DESTROY, "destroy qp: %d qid:%d cid:%d sqc:%d index:%d\n", index, qid, cid, hw_res->np_qp_tbl[cid].sqc_id, priv->index);
			os_msleep(500);
		}
		return 0;
	}

qp_remap_err:
rqs_err:
rqc_err:
sqs_err:
sqc_err:
err3:
       	np_alloc_qp_cluster(np_sf, yqp->ypd->entry.index, index, priv, false);
err2:
        if(yqp->qp_type == IB_QPT_RC)
        	yib_inner_destroy_ah(priv->ah);
err1:
        os_free(priv);
       	priv = NULL;
        
	return ret;

}

static bool np_can_modify_qpc(enum ib_qp_state cur_state, enum ib_qp_state to_state, u32 mask, enum ib_qp_type qp_type)
{

        return true;
}

static void np_fill_av(struct yib_sf *sf, struct yib_ah *ah)
{
        struct np_yib_sf *np_sf = sf->sf_priv;
        struct yib_np_resource *hw_res = &np_sf->hw_res;	
	u8 size = 0;
	char databuf[128];
	u8 *buf = NULL;
	
	buf = databuf + (0x4 - ((u64)databuf & 0x3));
	size = (yib_packet_hdr_fill(sf->hw->yib, &ah->av, buf, 0)) & 0xFF;
	
        if (np_store_array(hw_res->avt_id, ah->entry.index, buf, size)) {
                os_printe(sf->hw->dev, "init av table failed");
                return;
        }
}

bool np_qp_info_update(struct yib_sf *sf, struct yib_qp *qp, u32 mask, bool state_chg)
{
        struct np_yib_sf *np_sf = sf->sf_priv;
        struct yib_np_resource *hw_res = &np_sf->hw_res;
	struct np_qp_priv *priv = (struct np_qp_priv *)qp->privdata;
	struct np_hw_sqc_entry sqc_entry;
	struct np_hw_sqs_entry sqs_entry;
	struct np_hw_rqs_entry rqs_entry;
	struct np_hw_rqc_entry rqc_entry;
	struct np_hw_qp_state_entry qp_state_entry;
        u32 cid, qid, index = 0;
        int ret = 0;
        u32 cur_qp_state = qp->attr.cur_qp_state;
        u32 qp_state = qp->attr.qp_state;

        index = yib_get_qp_sw_idx(qp);

	cid = index_to_cluster(priv->index);
	qid = index_to_qid(priv->index);
	
	ret |= np_load_array(hw_res->np_qp_tbl[cid].sqc_id, qid, &sqc_entry, sizeof(struct np_hw_sqc_entry));
	ret |= np_load_array(hw_res->np_qp_tbl[cid].sqs_id, qid, &sqs_entry, sizeof(struct np_hw_sqs_entry));
	ret |= np_load_array(hw_res->np_qp_tbl[cid].rqs_id, qid, &rqs_entry, sizeof(struct np_hw_rqs_entry));
	ret |= np_load_array(hw_res->np_qp_tbl[cid].rqc_id, qid, &rqc_entry, sizeof(struct np_hw_rqc_entry));
	if(ret){
		os_printe(sf->hw->dev, "modify qp load qp arraytbl failed");
		return false;	
	}
        
	if (state_chg) {
                yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "qp:%d qp_state=0x%x\n",
                                index, qp->attr.qp_state);
                if (qp->attr.qp_state == IB_QPS_RESET || qp->attr.qp_state == IB_QPS_ERR)
                        goto modify;
        } else if (qp->attr.qp_state == IB_QPS_RESET || qp->attr.qp_state == IB_QPS_ERR) {
                return true;
        }

        if (mask & IB_QP_PATH_MTU) {
                yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "qp:%d path_mtu=0x%x\n",
                                index, qp->attr.path_mtu);
                if (np_can_modify_qpc(cur_qp_state, qp_state, mask, qp->qp_type)) {
                        yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "write qpc: path_mtu\n");
			np_hwres_write(&rqs_entry, NP_RQS_MTU_SIZE, to_hw_mtu_size(qp->attr.path_mtu));	
			np_hwres_write(&sqs_entry, NP_SQS_MTU_SIZE, to_hw_mtu_size(qp->attr.path_mtu));	
                }
        }

        if (mask & IB_QP_QKEY) {
                yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "qp:%d qkey=0x%x\n",
                                index, qp->attr.qkey);
                if (np_can_modify_qpc(cur_qp_state, qp_state, mask, qp->qp_type)) {
                        yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "write qpc: qkey\n");
			np_hwres_write(&rqs_entry, NP_RQS_INCOME_MSG_KEY_OR_QKEY, qp->attr.qkey);	
                }
        }

        if (mask & IB_QP_RQ_PSN) {//unknown  server flow没psn
                yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "qp:%d rq_psn=0x%x\n",
                                index, qp->attr.rq_psn);
                if (np_can_modify_qpc(cur_qp_state, qp_state, mask, qp->qp_type)) {
                        yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "write qpc: rq_psn\n");
			np_hwres_write(&rqs_entry, NP_RQS_EPSN, qp->attr.rq_psn);	
			np_hwres_write(&rqs_entry, NP_RQS_ACK_NEXT_PSN, qp->attr.rq_psn);	
                }
        }

        if (mask & IB_QP_SQ_PSN) {
                yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "qp:%d sq_psn=0x%x\n",
                                index, qp->attr.sq_psn);
                if (np_can_modify_qpc(cur_qp_state, qp_state, mask, qp->qp_type)) {
                        yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "write qpc: sq_psn\n");
			np_hwres_write(&sqs_entry, NP_SQS_SQ_NEXT_PSN, (qp->attr.sq_psn & 0xFFFFFF));	
			np_hwres_write(&sqs_entry, NP_SQS_SQ_ACK_EPSN, (qp->attr.sq_psn & 0xFFFFFF));	
                }
        }

        if (mask & IB_QP_DEST_QPN) {
                yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "qp:%d dest_qp_num=0x%x\n",
                                index, qp->attr.dest_qp_num);
                if (np_can_modify_qpc(cur_qp_state, qp_state, mask, qp->qp_type)) {
                        yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "write qpc: dest_qp_num\n");
			np_hwres_write(&sqs_entry, NP_SQS_DST_QPN, (qp->attr.dest_qp_num & 0xFFF));	
			np_hwres_write(&rqs_entry, NP_RQS_DST_QPN, (qp->attr.dest_qp_num & 0xFFFF));	
                }
        }

        if (mask & IB_QP_ACCESS_FLAGS) {
                yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "qp:%d qp_access_flags=0x%x\n",
                                index, qp->attr.qp_access_flags);
                if (np_can_modify_qpc(cur_qp_state, qp_state, mask, qp->qp_type)) {
                        yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "write qpc: qp_access_flags\n");
			np_hwres_write(&sqs_entry, NP_SQS_ACCESS_RIGHT, to_hw_mr_access(qp->attr.qp_access_flags));	
			np_hwres_write(&rqs_entry, NP_RQS_ACCESS_RIGHT, to_hw_mr_access(qp->attr.qp_access_flags));	
                }
        }

        if (mask & IB_QP_PKEY_INDEX) {
                yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "qp:%d pkey[%d]=0x%x\n",
                                index, qp->attr.pkey_index, g_yib_pkey_table[qp->attr.pkey_index]);
                if (np_can_modify_qpc(cur_qp_state, qp_state, mask, qp->qp_type)) {
                        yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "write qpc: pkey\n");
			np_hwres_write(&sqs_entry, NP_SQS_SQ_PKEY, (g_yib_pkey_table[qp->attr.pkey_index] & 0x0000FFFF));	
			np_hwres_write(&rqs_entry, NP_RQS_RQ_PKEY, (g_yib_pkey_table[qp->attr.pkey_index] & 0x0000FFFF));	
                }
        }

        if (mask & IB_QP_MAX_QP_RD_ATOMIC) {
                yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "qp:%d max_rd_atomic=0x%x\n",
                                index, qp->attr.max_rd_atomic);
                if (np_can_modify_qpc(cur_qp_state, qp_state, mask, qp->qp_type)) {
                        yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "write qpc: max_rd_atomic\n");
			np_hwres_write(&sqc_entry, NP_SQC_SQ_READ_LIMIT, qp->attr.max_rd_atomic);	
                }
        }

        if (mask & IB_QP_MAX_DEST_RD_ATOMIC) {
                yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "qp:%d max_dest_rd_atomic=0x%x\n",
                                index, qp->attr.max_dest_rd_atomic);
                if (np_can_modify_qpc(cur_qp_state, qp_state, mask, qp->qp_type)) {
                        yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "write qpc: max_dest_rd_atomic\n");
			np_hwres_write(&rqs_entry, NP_RQS_READ_ATOMIC_LIMIT, qp->attr.max_dest_rd_atomic);	
                }
        }

        if (mask & IB_QP_MIN_RNR_TIMER) {
                yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "qp:%d min_rnr_timer=0x%x\n",
                                index, qp->attr.min_rnr_timer);
                if (np_can_modify_qpc(cur_qp_state, qp_state, mask, qp->qp_type)) {
                        yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "write qpc: min_rnr_timer\n");
                        //todo qp->attr.min_rnr_timer
                }
        }

        if (mask & IB_QP_PORT) {
                yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "qp:%d port_num=0x%x\n",
                                index, qp->attr.port_num);
                if (np_can_modify_qpc(cur_qp_state, qp_state, mask, qp->qp_type)) {
                        yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "write qpc: port_num\n");
                        //todo qp->attr.port_num
                }
        }

        if (mask & IB_QP_TIMEOUT) {//todo, 放在流控的class
                yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "qp:%d timeout=0x%x\n",
                                index, qp->attr.timeout);
                if (np_can_modify_qpc(cur_qp_state, qp_state, mask, qp->qp_type)) {
                        yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "write qpc: timeout\n");
			np_hwres_write(&sqs_entry, NP_SQS_TMOUT_VALUE, (qp->attr.timeout & 0x1F));	
                }
        }

        if (mask & IB_QP_RETRY_CNT) {
                yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "qp:%d retry_cnt=0x%x\n",
                                index, qp->attr.retry_cnt);
                if (np_can_modify_qpc(cur_qp_state, qp_state, mask, qp->qp_type)) {
                        yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "write qpc: retry_cnt\n");
			np_hwres_write(&sqs_entry, NP_SQS_RE_TXMITS_COUNT_INIT_VALUE, (qp->attr.retry_cnt & 0x7));	
                }
        }

        if (mask & IB_QP_RNR_RETRY) {
                yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "qp:%d rnr_retry=0x%x\n",
                                index, qp->attr.rnr_retry);
                if (np_can_modify_qpc(cur_qp_state, qp_state, mask, qp->qp_type)) {
                        yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "write qpc: rnr_retry\n");
			np_hwres_write(&sqs_entry, NP_SQS_RNR_RE_TXMITS_COUNT_INIT_VALUE, (qp->attr.rnr_retry & 0x7));	
                }
        }

        if (mask & IB_QP_AV) {
		struct np_qp_priv *priv = (struct np_qp_priv *)qp->privdata;
                struct yib_av *av = &qp->pri_av;
		if(qp->qp_type == IB_QPT_RC){
			memcpy(&priv->ah->av, av, sizeof(struct yib_av));
                	if (np_can_modify_qpc(cur_qp_state, qp_state, mask, qp->qp_type)) {
                        	yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "write qpc: av\n");
                        	np_fill_av(sf, priv->ah);
                	}
		}	
        }

modify:
	if (state_chg) {
                if (qp->attr.qp_state == IB_QPS_RESET) {
			struct np_qp_priv *priv = (struct np_qp_priv *)qp->privdata;
	
			memset(&qp_state_entry, 0, sizeof(struct np_hw_qp_state_entry));
			np_hwres_write(&qp_state_entry, NP_QPN_STATE, to_hw_qp_state(qp->attr.qp_state));	
			ret = np_store_array(hw_res->qp_state_id, priv->index, &qp_state_entry, sizeof(struct np_hw_qp_state_entry));
			if(ret){
				os_printe(sf->hw->dev, "modify qp store reset arraytbl failed");
				return false;	
			}
			ret = np_reset_qpc(sf, qp, &sqc_entry, &sqs_entry);
			if(ret)
				return false;		
			ret = np_reset_rqc(sf, qp, &rqc_entry, &rqs_entry);
			if(ret)
				return false;		
                } else if (qp->attr.qp_state == IB_QPS_SQD) {
                        qp->attr.sq_draining = 1;
                }
        }
	
	ret |= np_store_array(hw_res->np_qp_tbl[cid].sqc_id, qid, &sqc_entry, sizeof(struct np_hw_sqc_entry));
	ret |= np_store_array(hw_res->np_qp_tbl[cid].sqs_id, qid, &sqs_entry, sizeof(struct np_hw_sqs_entry));
	ret |= np_store_array(hw_res->np_qp_tbl[cid].rqs_id, qid, &rqs_entry, sizeof(struct np_hw_rqs_entry));
	ret |= np_store_array(hw_res->np_qp_tbl[cid].rqc_id, qid, &rqc_entry, sizeof(struct np_hw_rqc_entry));
        if (ret) {
                os_printe(sf->hw->dev, "modify qp store arraytbl failed");
                return false;
        }

        if (state_chg) {
                if (qp->attr.qp_state != IB_QPS_RESET) {
			struct np_qp_priv *priv = (struct np_qp_priv *)qp->privdata;
	
			memset(&qp_state_entry, 0, sizeof(struct np_hw_qp_state_entry));
			np_hwres_write(&qp_state_entry, NP_QPN_STATE, to_hw_qp_state(qp->attr.qp_state));	
			ret = np_store_array(hw_res->qp_state_id, priv->index, &qp_state_entry, sizeof(struct np_hw_qp_state_entry));
			if(ret){
				os_printe(sf->hw->dev, "modify qp store state arraytbl failed");
				return false;	
			}
			if(qp->attr.qp_state == IB_QPS_ERR)
				os_msleep(500);
		}
	}
        
        return true;
}

int np_qp_query(struct yib_sf *sf, struct yib_qp *qp, os_qp_attr *attr, int mask, bool bdebug)
{
        struct np_yib_sf *np_sf = sf->sf_priv;
        struct yib_np_resource *hw_res = &np_sf->hw_res;
	struct np_qp_priv *priv = (struct np_qp_priv *)qp->privdata;
        struct np_hw_sqs_entry sqs_entry;
	struct np_hw_rqs_entry rqs_entry;
	struct np_hw_qp_state_entry qp_state;
	u32 qid = 0, cid = 0;	
	int ret = 0;
	
	cid = index_to_cluster(priv->index);
	qid = index_to_qid(priv->index);
	
	ret = np_load_array(hw_res->np_qp_tbl[cid].sqs_id, qid, &sqs_entry, sizeof(struct np_hw_sqs_entry));
	if(ret){
		os_printe(sf->hw->dev, "query qp load sqs failed");
		return -EAGAIN;
	}
	ret = np_load_array(hw_res->np_qp_tbl[cid].rqs_id, qid, &rqs_entry, sizeof(struct np_hw_rqs_entry));
	if(ret){
		os_printe(sf->hw->dev, "query qp load rqs failed");
		return -EAGAIN;
	}
	ret = np_load_array(hw_res->qp_state_id, priv->index, &qp_state, sizeof(struct np_hw_qp_state_entry));
	if(ret){
		os_printe(sf->hw->dev, "query qp load state failed");
		return -EAGAIN;
	}
	
	if(bdebug == 0){	
		attr->sq_psn = np_hwres_read(&sqs_entry, NP_SQS_SQ_NEXT_PSN);
		attr->rq_psn = np_hwres_read(&rqs_entry, NP_RQS_EPSN);
		attr->qp_state = np_hwres_read(&qp_state, NP_QPN_STATE);
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_QUERY, "query qp: %d qp_state: %d sq_psn: %d rq_psn: %d\n", 
				qp->entry.index, attr->qp_state, attr->sq_psn, attr->rq_psn);
	}else{
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_QUERY, "query qp: %d\n", qp->entry.index);
		np_dbg_print_qpc(sf, qp, false);
	}

	return 0;
}

