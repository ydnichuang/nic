/*
 * @Descripttion: Copyright(c) All rights reserved.
 * @version: 
 * @Author: wangyingfu
 * @Date: 2024-05-22 15:37:14
 * @LastEditors: wangyingfu
 * @LastEditTime: 2024-05-22 19:43:50
 */

#include "yusdoe_kapi.h"

int np_create_arraytbl(u8 table_id, u32 depth, u8 len, const void *cfg)
{
	return hados_doe_create_arraytbl(table_id, depth, len, cfg);
	//return 0;
}

int np_delete_arraytbl(u8 table_id)
{
	return hados_doe_delete_arraytbl(table_id);
	//return 0;
}

int np_store_array(u8 table_id, u32 index, const void *data, u8 size)
{
	return hados_doe_array_store(table_id, index, data, size);
	//return 0;
}

int np_load_array(u8 table_id, u32 index, void *data, u8 size)
{
	return hados_doe_array_load(table_id, index, data, size);
	//return 0;
}

int np_read_clear_array(u8 table_id, u32 index, void *data, u8 size)
{
#if 1
	u8 buf[128];

	if(data == NULL){
		return hados_doe_array_read_clear(table_id, index, buf, size);
	}else{
		return hados_doe_array_read_clear(table_id, index, data, size);
	}
#endif
	//return 0;
}

