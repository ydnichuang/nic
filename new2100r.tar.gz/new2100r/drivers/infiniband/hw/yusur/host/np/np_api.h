/*
 * @Descripttion: Copyright(c) All rights reserved.
 * @version: 
 * @Author: wangyingfu
 * @Date: 2024-05-22 15:37:26
 * @LastEditors: wangyingfu
 * @LastEditTime: 2024-05-22 19:04:33
 */
#ifndef _YUSUR_IB_NP_API_H_
#define _YUSUR_IB_NP_API_H_

int np_create_arraytbl(u8 table_id, u32 depth, u8 len, const void *cfg);
int np_delete_arraytbl(u8 table_id);

int np_store_array(u8 table_id, u32 index, const void *data, u8 size);
int np_load_array(u8 table_id, u32 index, void *data, u8 size);
int np_read_clear_array(u8 table_id, u32 index, void *data, u8 size);

#endif


