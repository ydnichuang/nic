#ifndef _NP_INC_HW_H
#define _NP_INC_HW_H

#include "np_inc_base.h"

struct np_hw_qp_remap_entry {
    __le32 resv0;   //[3:0]qpid; [7:4]cid
};//4字节

#define NP_QP_REMAP_FIELD_LOC(h, l) 	NP_FIELD_LOC(struct np_hw_qp_remap_entry, h, l)
#define NP_QP_REMAP_QPID   	NP_QP_REMAP_FIELD_LOC(3, 0)      //cluster内部qpid号
#define NP_QP_REMAP_CID   	NP_QP_REMAP_FIELD_LOC(7, 4)      //cluster id号

struct np_hw_qp_state_entry {
    __le32 resv0;   //[7:0]qp_state
};//4字节

#define NP_QP_STATE_FIELD_LOC(h, l) 	NP_FIELD_LOC(struct np_hw_qp_state_entry, h, l)
#define NP_QPN_STATE   		NP_QP_STATE_FIELD_LOC(7, 0)      //state

struct np_hw_mpt_entry {
    __le32 resv0;   //[31:0]length
    __le32 resv1;   //[31:24]pd_num[22:21]state[20:16]access_right[15:0]length
    __le32 resv2;   //[31:0]pa0_lsb
    __le32 resv3;   //[31:0]pa0_msb
    __le32 resv4;   //[31:0]pa1_lsb
    __le32 resv5;   //[19:0]pa1_msb; [27:20]pg_size;[28]lvs [31:29]type
    __le32 resv6;   //[31:0]va_lsb
    __le32 resv7;   //[31:0]va_msb
};//32字节

#define NP_MPT_FIELD_LOC(h, l) 	NP_FIELD_LOC(struct np_hw_mpt_entry, h, l)
#define NP_MPT_SIZE_LSB    	NP_MPT_FIELD_LOC(31, 0)      //MR/W的大小，以字节为单位[31:0]
#define NP_MPT_SIZE_MSB    	NP_MPT_FIELD_LOC(47, 32)     //MR/W的大小，以字节为单位[47:32]
#define NP_MPT_ACCESS_RIGHT    	NP_MPT_FIELD_LOC(52, 48)     //MR的access
#define NP_MPT_STATE    	NP_MPT_FIELD_LOC(54, 53)     //0:invalid(init状态); 1: free(收到invalid命令); 2:valid(可工作)
#define NP_MPT_PD    		NP_MPT_FIELD_LOC(63, 56)     //pd_num
#define NP_MPT_PA0_LSB    	NP_MPT_FIELD_LOC(95, 64)     //pa0[31:0]
#define NP_MPT_PA0_MSB    	NP_MPT_FIELD_LOC(127, 96)    //pa0[63:32]  
#define NP_MPT_PA1_LSB    	NP_MPT_FIELD_LOC(159, 128)   //pa1[31:0]
#define NP_MPT_PA1_MSB    	NP_MPT_FIELD_LOC(179, 160)   //pa1[51:32] 
#define NP_MPT_MRW_PG_SIZE    	NP_MPT_FIELD_LOC(187, 180)   //数据buf的page大小,4K*2^n
#define NP_MPT_NUM_TRANS_LAYERS NP_MPT_FIELD_LOC(188, 188)   //0:0级寻址  1:1级寻址
#define NP_MPT_TYPE    		NP_MPT_FIELD_LOC(191, 189)   //0:MR; 1:PMR; 2:MW Type 1; 3:MW Type 2A;
#define NP_MPT_VA_LSB    	NP_MPT_FIELD_LOC(223, 192)   //va[31:0]
#define NP_MPT_VA_MSB    	NP_MPT_FIELD_LOC(255, 224)   //va[63:32]

struct np_hw_cqc_entry {
    __le32 resv0;   //[7:0]cq_status; [31:16]cq_size
    __le32 resv1;   //[15:0]cq_ci; [31:16]cq_pi
    __le32 resv2;   //[15:0]cq_wi;
    __le32 resv3;   //
    __le32 resv4;   //[31:0]cq_addr_page0_lsb
    __le32 resv5;   //[63:32]cq_addr_page0_msb
    __le32 resv6;   //[31:0]cq_addr_page1_lsb
    __le32 resv7;   //[63:32]cq_addr_page1_msb
};//32字节

#define NP_CQC_FIELD_LOC(h, l) NP_FIELD_LOC(struct np_hw_cqc_entry, h, l)
#define NP_CQC_CQ_SIZE    	NP_CQC_FIELD_LOC(31, 16)    //cq的深度，放多少个cqes
#define NP_CQC_CQ_CI    	NP_CQC_FIELD_LOC(47, 32)
#define NP_CQC_CQ_PI    	NP_CQC_FIELD_LOC(63, 48)
#define NP_CQC_CQ_PA0_LSB    	NP_CQC_FIELD_LOC(159, 128)  //CQ队列的第一个基地址[31:0]
#define NP_CQC_CQ_PA0_MSB    	NP_CQC_FIELD_LOC(191, 160)  //CQ队列的第一个基地址[63:32]
#define NP_CQC_CQ_PA1_LSB    	NP_CQC_FIELD_LOC(223, 192)  //CQ队列的第二个基地址[31:0]
#define NP_CQC_CQ_PA1_MSB    	NP_CQC_FIELD_LOC(255, 224)  //CQ队列的第二个基地址[63:32]

struct np_hw_nqc_entry {
    __le32 resv0;   //[0:0]nq_enable; [15:8]nq_int_vec
    __le32 resv1;   //[15:0]nq_size; [31:16]nq_pi
    __le32 resv2;   //[15:0]nq_wi; [31:16]nq_ci 
    __le32 resv3;   //
    __le32 resv4;   //[31:0]nq_page0_lsb
    __le32 resv5;   //[63:32]nq_page0_msb
    __le32 resv6;   //
    __le32 resv7;   //
};//32字节

#define NP_NQC_FIELD_LOC(h, l) NP_FIELD_LOC(struct np_hw_nqc_entry, h, l)
#define NP_NQC_NQ_ENABLE    	NP_NQC_FIELD_LOC(0, 0)
#define NP_NQC_NQ_INT_VEC    	NP_NQC_FIELD_LOC(15, 8)
#define NP_NQC_NQ_SIZE    	NP_NQC_FIELD_LOC(47, 32)
#define NP_NQC_NQ_PI    	NP_NQC_FIELD_LOC(63, 48)
#define NP_NQC_NQ_CI    	NP_NQC_FIELD_LOC(95, 80)
#define NP_NQC_NQ_PA0_LSB    	NP_NQC_FIELD_LOC(159, 128)  //NQ队列的基地址[31:0]
#define NP_NQC_NQ_PA0_MSB    	NP_NQC_FIELD_LOC(191, 160)  //NQ队列的基地址[63:32]

struct np_hw_sqc_entry {
    __le32 resv0;    //[3:0]sq_wi_status; [8:8]sq_pi_toggle; [9:9]sq_ci_toggle; [31:16]sq_size
    __le32 resv1;    //[15:0]sq_pi; [31:16]sq_ci
    __le32 resv2;    //[15:0]sq_ei; [23:16]sq_l1_size; [31:24]sq_l1_pi
    __le32 resv3;    //[7:0]sq_l1_ci; [15:8]sq_l1_wi; [16:16]sq_l1_toggle; [17:17]sq_l1_empty_flag; [18:18]sq_l1_full_flag
    __le32 resv4;    //[15:0]sq_l1_index_base0; [31:16]sq_l1_index_base1
    __le32 resv5;    //[7:0]ost_read_cnt; [15:8]ost_total_cnt; [23:16]read_limit
    __le32 resv6;    //[31:0]pa0_lsb
    __le32 resv7;    //[31:0]pa0_msb
    __le32 resv8;    //[31:0]pa1_lsb
    __le32 resv9;    //[31:0]pa1_msb
    __le32 resv10;   //[31:0]pa2_lsb
    __le32 resv11;   //[31:0]pa2_msb
    __le32 resv12;   //[31:0]pa3_lsb
    __le32 resv13;   //[31:0]pa3_msb
    __le32 resv14;   //[31:0]pa4_lsb
    __le32 resv15;   //[31:0]pa4_msb
    __le32 resv16;   //[31:0]pa5_lsb
    __le32 resv17;   //[31:0]pa5_msb
    __le32 resv18;   //[31:0]pa6_lsb
    __le32 resv19;   //[31:0]pa6_msb
    __le32 resv20;   //[31:0]pa7_lsb
    __le32 resv21;   //[31:0]pa7_msb
    __le32 resv22;
    __le32 resv23;
    __le32 resv24;    
    __le32 resv25; 
    __le32 resv26;    
    __le32 resv27;  
    __le32 resv28;
    __le32 resv29;
    __le32 resv30;
    __le32 resv31;
};//128字节

#define NP_SQC_FIELD_LOC(h, l) NP_FIELD_LOC(struct np_hw_sqc_entry, h, l)
#define NP_SQC_SQ_SIZE    	NP_SQC_FIELD_LOC(31, 16)        //sq的深度，放多少个wqes 
#define NP_SQC_SQ_PI    	NP_SQC_FIELD_LOC(47, 32)
#define NP_SQC_SQ_CI    	NP_SQC_FIELD_LOC(63, 48)
#define NP_SQC_SQ_L1_SIZE    	NP_SQC_FIELD_LOC(87, 80)      	//sqe在L1的个数 
#define NP_SQC_SQ_READ_LIMIT    NP_SQC_FIELD_LOC(183, 176) 	//未完成的read请求的个数 
#define NP_SQC_SQ_PA0_LSB    	NP_SQC_FIELD_LOC(223, 192)  	//SQ队列的第一个基地址[31:0]
#define NP_SQC_SQ_PA0_MSB    	NP_SQC_FIELD_LOC(255, 224) 	//SQ队列的第一个基地址[63:32]
#define NP_SQC_SQ_PA1_LSB    	NP_SQC_FIELD_LOC(287, 256)  	//SQ队列的第二个基地址[31:0]
#define NP_SQC_SQ_PA1_MSB    	NP_SQC_FIELD_LOC(319, 288) 	//SQ队列的第二个基地址[63:32]
#define NP_SQC_SQ_PA2_LSB    	NP_SQC_FIELD_LOC(351, 320)  	//SQ队列的第三个基地址[31:0]
#define NP_SQC_SQ_PA2_MSB    	NP_SQC_FIELD_LOC(383, 352) 	//SQ队列的第三个基地址[63:32]
#define NP_SQC_SQ_PA3_LSB    	NP_SQC_FIELD_LOC(415, 384)  	//SQ队列的第四个基地址[31:0]
#define NP_SQC_SQ_PA3_MSB    	NP_SQC_FIELD_LOC(447, 416) 	//SQ队列的第四个基地址[63:32]
#define NP_SQC_SQ_PA4_LSB    	NP_SQC_FIELD_LOC(479, 448)  	//SQ队列的第五个基地址[31:0]
#define NP_SQC_SQ_PA4_MSB    	NP_SQC_FIELD_LOC(511, 480) 	//SQ队列的第五个基地址[63:32]
#define NP_SQC_SQ_PA5_LSB    	NP_SQC_FIELD_LOC(543, 512)  	//SQ队列的第六个基地址[31:0]
#define NP_SQC_SQ_PA5_MSB    	NP_SQC_FIELD_LOC(575, 544) 	//SQ队列的第六个基地址[63:32]
#define NP_SQC_SQ_PA6_LSB    	NP_SQC_FIELD_LOC(607, 576)  	//SQ队列的第七个基地址[31:0]
#define NP_SQC_SQ_PA6_MSB    	NP_SQC_FIELD_LOC(639, 608) 	//SQ队列的第七个基地址[63:32]
#define NP_SQC_SQ_PA7_LSB    	NP_SQC_FIELD_LOC(671, 640)  	//SQ队列的第八个基地址[31:0]
#define NP_SQC_SQ_PA7_MSB    	NP_SQC_FIELD_LOC(703, 672) 	//SQ队列的第八个基地址[63:32]

struct np_hw_rqc_entry {
    __le32 resv0;   	//[15:0]rq_size; [31:16]rq_pi
    __le32 resv1;   	//[15:0]rq_ci; [31:16]rq_ei
    __le32 resv2;    	//[15:0]rq_l1_size; [23:16]rq_l1_pi
    __le32 resv3;   	//[7:0]rq_l1_wi; [23:16]rq_l1_ci
    __le32 resv4;       //[0:0]rq_l1_toggle; [8:8]rq_l1_empty_flag; [16:16]rq_l1_full_flag
    __le32 resv5;       //[15:0]rq_l1_index_base0; [31:16]rq_l1_index_base1
    __le32 resv6;	//pa0_lsb
    __le32 resv7;       //pa0_msb
    __le32 resv8;       //pa1_lsb
    __le32 resv9;       //pa1_msb
    __le32 resv10;      //pa2_lsb
    __le32 resv11;      //pa2_msb
    __le32 resv12;      //pa3_lsb
    __le32 resv13;      //pa3_msb
    __le32 resv14;      //pa4_lsb
    __le32 resv15;      //pa4_msb
    __le32 resv16;      //pa5_lsb
    __le32 resv17;      //pa5_msb
    __le32 resv18;      //pa6_lsb
    __le32 resv19;      //pa6_msb
    __le32 resv20;      //pa7_lsb
    __le32 resv21;      //pa7_msb
    __le32 resv22;
    __le32 resv23;
    __le32 resv24;    
    __le32 resv25; 
    __le32 resv26;    
    __le32 resv27;  
    __le32 resv28;
    __le32 resv29;
    __le32 resv30;
    __le32 resv31;
};//128字节

#define NP_RQC_FIELD_LOC(h, l) NP_FIELD_LOC(struct np_hw_rqc_entry, h, l)
#define NP_RQC_RQ_SIZE    	NP_RQC_FIELD_LOC(15, 0)
#define NP_RQC_RQ_PI    	NP_RQC_FIELD_LOC(31, 16)
#define NP_RQC_RQ_CI    	NP_RQC_FIELD_LOC(47, 32)
#define NP_RQC_RQ_L1_SIZE    	NP_RQC_FIELD_LOC(79, 64)	//rqe在L1的个数
#define NP_RQC_RQ_PA0_LSB    	NP_RQC_FIELD_LOC(223, 192)  	//RQ队列的第一个基地址[31:0]
#define NP_RQC_RQ_PA0_MSB    	NP_RQC_FIELD_LOC(255, 224) 	//RQ队列的第一个基地址[63:32]
#define NP_RQC_RQ_PA1_LSB    	NP_RQC_FIELD_LOC(287, 256)  	//RQ队列的第二个基地址[31:0]
#define NP_RQC_RQ_PA1_MSB    	NP_RQC_FIELD_LOC(319, 288) 	//RQ队列的第二个基地址[63:32]
#define NP_RQC_RQ_PA2_LSB    	NP_RQC_FIELD_LOC(351, 320)  	//RQ队列的第三个基地址[31:0]
#define NP_RQC_RQ_PA2_MSB    	NP_RQC_FIELD_LOC(383, 352) 	//RQ队列的第三个基地址[63:32]
#define NP_RQC_RQ_PA3_LSB    	NP_RQC_FIELD_LOC(415, 384)  	//RQ队列的第四个基地址[31:0]
#define NP_RQC_RQ_PA3_MSB    	NP_RQC_FIELD_LOC(447, 416) 	//RQ队列的第四个基地址[63:32]
#define NP_RQC_RQ_PA4_LSB    	NP_RQC_FIELD_LOC(479, 448)  	//RQ队列的第五个基地址[31:0]
#define NP_RQC_RQ_PA4_MSB    	NP_RQC_FIELD_LOC(511, 480) 	//RQ队列的第五个基地址[63:32]
#define NP_RQC_RQ_PA5_LSB    	NP_RQC_FIELD_LOC(543, 512)  	//RQ队列的第六个基地址[31:0]
#define NP_RQC_RQ_PA5_MSB    	NP_RQC_FIELD_LOC(575, 544) 	//RQ队列的第六个基地址[63:32]
#define NP_RQC_RQ_PA6_LSB    	NP_RQC_FIELD_LOC(607, 576)  	//RQ队列的第七个基地址[31:0]
#define NP_RQC_RQ_PA6_MSB    	NP_RQC_FIELD_LOC(639, 608) 	//RQ队列的第七个基地址[63:32]
#define NP_RQC_RQ_PA7_LSB    	NP_RQC_FIELD_LOC(671, 640)  	//RQ队列的第八个基地址[31:0]
#define NP_RQC_RQ_PA7_MSB    	NP_RQC_FIELD_LOC(703, 672) 	//RQ队列的第八个基地址[63:32]

struct np_hw_smac_port_entry {
    u8 mac[6];
    u8 portid[2];
} __attribute__((packed));//6字节

#define NP_MAC_PORT_FIELD_LOC(h, l) NP_FIELD_LOC(struct np_hw_smac_port_entry, h, l)
#define NP_MAC_PORT_PORTID    	NP_MAC_PORT_FIELD_LOC(63, 48)

struct np_hw_sgid_entry {
    u8 ip[16];
};//16字节

struct np_hw_sqs_entry {
    __le32 resv0;   	//[0:0]service_type; [15:4]sq_cq_id; [27:16]dst_qpn
    __le32 resv1;  	//[15:0]qpn; [20:16]access_right; [28:24]timeout_Value
    __le32 resv2;  	//[7:0]pdn; [18:16]re_txmits_count_init_value; [22:20]re_txmits_count; [26:24]rnr_re_txmits_count_init_value; [30:28]rnr_re_txmits_count
    __le32 resv3;  	//[23:0]next_psn
    __le32 resv4;  	//[23:0]ack_epsn
    __le32 resv5;   	//[23:0]pkey; [27:24]mtu_size
    __le32 resv6;     	//
    __le32 resv7;     	//
    __le32 resv8;   	//
    __le32 resv9;   	//
    __le32 resv10;   	//
    __le32 resv11;    	//
    __le32 resv12;     	//
    __le32 resv13;	//
    __le32 resv14;   	//
    __le32 resv15;
};//64字节

#define NP_SQS_FIELD_LOC(h, l) NP_FIELD_LOC(struct np_hw_sqs_entry, h, l)
#define NP_SQS_SERVICE_TYPE    			NP_SQS_FIELD_LOC(0, 0)
#define NP_SQS_SQ_CQ_ID    			NP_SQS_FIELD_LOC(15, 4)
#define NP_SQS_DST_QPN    			NP_SQS_FIELD_LOC(27, 16)
#define NP_SQS_QPN    				NP_SQS_FIELD_LOC(47, 32)
#define NP_SQS_ACCESS_RIGHT    			NP_SQS_FIELD_LOC(52, 48)
#define NP_SQS_TMOUT_VALUE    			NP_SQS_FIELD_LOC(60, 56)
#define NP_SQS_PDN    				NP_SQS_FIELD_LOC(71, 64)
#define NP_SQS_RE_TXMITS_COUNT_INIT_VALUE    	NP_SQS_FIELD_LOC(82, 80) 
#define NP_SQS_RNR_RE_TXMITS_COUNT_INIT_VALUE   NP_SQS_FIELD_LOC(90, 88)
#define NP_SQS_SQ_NEXT_PSN    			NP_SQS_FIELD_LOC(119, 96)  
#define NP_SQS_SQ_ACK_EPSN    			NP_SQS_FIELD_LOC(151, 128)  
#define NP_SQS_SQ_PKEY    			NP_SQS_FIELD_LOC(183, 160)  
#define NP_SQS_MTU_SIZE    			NP_SQS_FIELD_LOC(187, 184)

struct np_hw_rqs_entry {
    __le32 resv0;   //[0:0]service_type; [15:8]read_atomic_limit; [27:16]rq_cq_id
    __le32 resv1;  //[15:0]pkey; [31:16]dst_qpn
    __le32 resv2;  //[15:0]qpn; [31:16]av_index
    __le32 resv3;  //[2:0]mtu_size; [12:8]access_right; [23:16]pdn
    __le32 resv4;  //[31:0]q_key
    __le32 resv5;   //[7:0]rq_l1_imsg_pi; [15:8]rq_l1_imsg_ci; [16:16]rq_l1_imsg_empty_flag; [24:24]rq_l1_imsg_full_flag
    __le32 resv6;     //[31:0]epsn
    __le32 resv7;     //[31:0]ack_next_psn
    __le32 resv8;   //
    __le32 resv9;   //
    __le32 resv10;   //
    __le32 resv11;    //
    __le32 resv12;     //
    __le32 resv13;	//
    __le32 resv14;   //
    __le32 resv15;
};//64字节

#define NP_RQS_FIELD_LOC(h, l) NP_FIELD_LOC(struct np_hw_rqs_entry, h, l)
#define NP_RQS_SERVICE_TYPE    		NP_RQS_FIELD_LOC(0, 0)
#define NP_RQS_READ_ATOMIC_LIMIT    	NP_RQS_FIELD_LOC(15, 8)
#define NP_RQS_RQ_CQ_ID    		NP_RQS_FIELD_LOC(27, 16)
#define NP_RQS_RQ_PKEY    		NP_RQS_FIELD_LOC(47, 32)  
#define NP_RQS_DST_QPN    		NP_RQS_FIELD_LOC(63, 48)
#define NP_RQS_QPN    			NP_RQS_FIELD_LOC(79, 64)
#define NP_RQS_AV_INDEX    		NP_RQS_FIELD_LOC(95, 80)
#define NP_RQS_MTU_SIZE    		NP_RQS_FIELD_LOC(98, 96)
#define NP_RQS_ACCESS_RIGHT    		NP_RQS_FIELD_LOC(108, 104)
#define NP_RQS_PDN    			NP_RQS_FIELD_LOC(119, 112)
#define NP_RQS_INCOME_MSG_KEY_OR_QKEY   NP_RQS_FIELD_LOC(159, 128)
#define NP_RQS_EPSN    			NP_RQS_FIELD_LOC(223, 192)
#define NP_RQS_ACK_NEXT_PSN    		NP_RQS_FIELD_LOC(255, 224)






struct np_hw_av {
    __le32 resv0;       //[31:0]dst_gid_or_ip
    __le32 resv1;       //[31:0]dst_gid_or_ip
    __le32 resv2;       //[31:0]dst_gid_or_ip
    __le32 resv3;       //[31:0]dst_gid_or_ip
    __le32 resv4;       //[31:0]dst_mac_addr_lsb
    __le32 resv5;       //[15:0]dst_mac_addr_msb; [23:16]tc; [31:24]src_mac_idx
    __le32 resv6;       //[19:0]flow_label; [21:20]network_type; [31:22]src_gid_idx
    __le32 resv7;       //[11:0]vlan_vid; [14:12]vlan_pri; [15:15]vlan_cfi; [16:16]vlan_enable; [31:24]ttl
};//32字节

#define NP_AV_FIELD_LOC(h, l) 	 NP_FIELD_LOC(struct np_hw_av, h, l)
#define NP_AV_DST_GID_OR_IP_0    NP_AV_FIELD_LOC(31, 0)   //ROCEv1的目的GID或ROCEv2的IP地址[31:0]
#define NP_AV_DST_GID_OR_IP_1    NP_AV_FIELD_LOC(63, 32)  //ROCEv1的目的GID或ROCEv2的IP地址[63:32]
#define NP_AV_DST_GID_OR_IP_2    NP_AV_FIELD_LOC(95, 64)  //ROCEv1的目的GID或ROCEv2的IP地址[95:64]
#define NP_AV_DST_GID_OR_IP_3    NP_AV_FIELD_LOC(127, 96) //ROCEv1的目的GID或ROCEv2的IP地址[127:96]
#define NP_AV_DST_MAC_ADDR_LSB   NP_AV_FIELD_LOC(159, 128)   //L2报头的目的MAC地址[31:0]
#define NP_AV_DST_MAC_ADDR_MSB   NP_AV_FIELD_LOC(175, 160)   //L2报头的目的MAC地址[47:32]
#define NP_AV_TC    		 NP_AV_FIELD_LOC(183, 176)     //traffic class
#define NP_AV_SRC_MAC_IDX    	 NP_AV_FIELD_LOC(191, 184)    //索引smac的偏移
#define NP_AV_FLOW_LABEL    	 NP_AV_FIELD_LOC(211, 192)     //流标签，标记IP数据包的一个流
#define NP_AV_NETWORK_TYPE    	 NP_AV_FIELD_LOC(213, 212)     //0:rocev1; 2:rocev2 ipv4; 3:rocev2 ipv6
#define NP_AV_SRC_GID_IDX    	 NP_AV_FIELD_LOC(223, 214)    //索引sgid的偏移
#define NP_AV_VLAN_VID    	 NP_AV_FIELD_LOC(235, 224)   //LAN ID，长度为12比特，表示该帧所属的VLAN
#define NP_AV_VLAN_PRI    	 NP_AV_FIELD_LOC(238, 236)     //表示帧的优先级, 取值范围为0~7, 值越大优先级越高。
#define NP_AV_VLAN_CFI    	 NP_AV_FIELD_LOC(239, 239)   //表示MC地址是否是经典格式
#define NP_AV_VLAN_ENABLE    	 NP_AV_FIELD_LOC(240, 240)    //vlan使能
#define NP_AV_TTL    		 NP_AV_FIELD_LOC(255, 248)      //Time To Live

#endif

