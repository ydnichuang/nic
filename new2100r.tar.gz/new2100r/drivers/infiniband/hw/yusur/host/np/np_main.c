#include "../../include/basic.h"
#include "../../include/os_api.h"
#include "../../include/os_ds.h"
#include "../../include/mem.h"
#include "../../include/queue.h"
#include "../../include/host.h"
#include "../../include/verbs.h"
#include "../../include/yusur_ib.h"
#include "../../include/user.h"
#include "../hostpriv.h"
#include "../hwcomn.h"
#include "np_sf.h"

#define YIB_EQ_ISIZE	64
#define YIB_AEQ_ISIZE	128

#if (COUNTER_STAT_DESC)
static const struct rdma_stat_desc np_counter_name[] = {
	[YIB_CNT_LINK_DOWN].name      	=  "link_downed",
};
#else
static const char * const np_counter_name[] = {
	[YIB_CNT_LINK_DOWN]      =  "link_downed",
};
#endif


typedef struct
{
	struct yib_queue_mem *queue;
}np_eq_priv_t;

#define NP_SMAC_ISIZE 8


static void np_modify_mac(struct yib_sf *sf, u8 *mac, int index, u8 port_num, bool bdel)
{

}

static void np_set_gid(struct yib_sf *sf, bool brocev2, bool bipv4, int index, u8 *raw, bool bdel)
{
	yib_pr_info(YUSUR_IB_DBG_INIT, "%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x",
		raw[0], raw[1], raw[2], raw[3], raw[4], raw[5], raw[6], raw[7], raw[8],
		raw[9], raw[10], raw[11], raw[12], raw[13], raw[14], raw[15]);
}

static int np_qp_debugfs(struct yib_sf *sf, struct yib_qp *qp)
{
	return 0;
}

static int np_rq_info_init(struct yib_sf *sf, struct yib_rq *yrq, bool enable, bool bsrq)
{
	if (enable) {
		yib_pr_info(YUSUR_IB_DBG_INIT, "enable rq:%d \n", yrq->entry.index);
	} else
		yib_pr_info(YUSUR_IB_DBG_INIT, "disable rq:%d n", yrq->entry.index);
	return 0;
}
static int np_srq_debugfs(struct yib_sf *sf, struct yib_srq *ysrq)
{
	return 0;
}

static int np_eq_debugfs(struct yib_sf *sf, struct yib_eq *yeq)
{
	return 0;
}

static void np_sf_debugfs(struct yib_sf *sf)
{
	return;
}

static int np_uio_post_send(struct yib_hw_host *hw, struct yib_qp *qp, const void* os_wr, bool db_only)
{
	return 0;
}

static int np_uio_post_recv(struct yib_hw_host *hw, struct yib_rq *rq, const void* os_wr, bool db_only)
{
	return 0;
}

static int np_uio_poll_cq(struct yib_hw_host *hw, struct yib_cq *cq, int num, void *wc, bool db_only)
{
	return 0;
}

static int np_fill_rqe(struct yib_hw_host *hw, struct yib_rq *rq, const void *os_wq, u8 *buf, u32 length)
{
	return 0;
}

static int np_fill_srqe(struct yib_hw_host *hw, struct yib_rq *rq, const void *os_wq, u8 *buf, u32 length, int pos)
{
	return 0;
}

static int np_fill_wqe(struct yib_hw_host *hw, struct yib_qp *qp, const void *os_wq, u8 *buf, u32 length, u32 mask)
{
	return 0;
}

static void np_fill_cqe(struct yib_hw_host *hw, struct yib_cq *cq, struct yib_qp **qp_cache, void *os_cq, u8 *buf)
{
}

static int np_sw_fill_cqe(struct yib_hw_host *hw, struct yib_cq *cq, void *os_cq)
{
	//yib_sq_swcmd_done
	return -1;
}

static bool np_check_sq_full(struct yib_hw_host *hw, struct yib_sq *ysq)
{
	return false;
}

static bool np_check_rq_full(struct yib_hw_host *hw, struct yib_rq *yrq)
{
	return false;
}

static bool np_check_srq_full(struct yib_hw_host *hw, struct yib_srq *ysrq, int *pos)
{
	return false;
}

static bool np_check_cq_empty(struct yib_hw_host *hw, struct yib_cq *ycq, u8 *cqe)
{
	return true;
}

static int np_get_sq_item_size(int *inline_len, int *max_sg, bool is_ud)
{
	//inline: 16 80 208
	//sg: 1 5 13
	//ud inline: 48 176
	*inline_len = 32;
	*max_sg = 1;
	return 64;
}

static int np_get_rq_item_size(int *max_sg)
{
	*max_sg = 1;
	return 32;
}

static void np_sq_pi_db_update(struct yib_hw_host *hw, struct yib_qp *qp, int io_cnt)
{
}

static void np_rq_pi_db_update(struct yib_hw_host *hw, struct yib_rq *rq, int io_cnt)
{
}

static void np_srq_pi_db_update(struct yib_hw_host *hw, struct yib_srq *srq, int pos)
{
}

static void np_cq_ci_db_update(struct yib_hw_host *hw, struct yib_cq *cq, int poll_cnt)
{
}

int np_get_eq_intr_num(struct yib_sf *sf)
{
#if 0
	int num_comp_vector = sf->hw->caps.num_comp_vector;
	if (num_comp_vector + 1 > YIB_MAX_EQ_NUM)
		return -EINVAL;

	//num_comp_vector为CQ中断向量数目，eq数量为aeq+nq (1+num_comp_vector)
#endif
	return 0;
}

#if 0
static int np_get_eq_isize(struct yib_sf *sf, struct yib_eq *yeq)
{
	int eq_isize;
	if (yeq->entry.index == 0)
		eq_isize = YIB_AEQ_ISIZE;
	else
		eq_isize = YIB_EQ_ISIZE;

	return eq_isize;
}
#endif
static int np_eq_info_init(struct yib_sf *sf, struct yib_eq *eq, int depth, bool b_del)
{
	return 0;
}

static bool np_check_eq_empty(struct yib_sf *sf, struct yib_eq *eq)
{
	return true;
}

static void np_eq_sw_handler(struct yib_sf *sf, struct yib_eq *eq, u8 *buf)
{
	return;
}

static void np_eq_handler(struct yib_sf *sf, struct yib_eq *eq, struct yib_evts_occurs *evts_occurs)
{
}

static void np_eq_ci_db_update(struct yib_sf *sf, struct yib_eq *eq, int io_cnt)
{
}

static int np_init_caps(struct yib_hw_host *hw, struct yib_sf *sf)
{
	struct yib_roce_caps	*caps = &hw->caps;
	struct yib_dev_funcs	*func = &hw->funcs;

	sf->udp_port = 3721;

	caps->fw_ver    = 1;
	caps->hw_ver    = 1;
	caps->num_ports = 1;
	caps->num_qps   = 40;
	caps->num_cqs   = caps->num_qps * 2;
	caps->max_mr    = 1024;
	caps->max_srqs  = 0;
	caps->max_mcast_qps = 0;
	caps->max_mcast_grp = 0;

	caps->max_rqs = caps->num_qps;
	caps->max_res_rd_atom = 16;	
	caps->num_pds = 256; 
	caps->max_mr_sgs = 512;
	caps->max_eqs = 1;
	caps->max_sq_inline = 32;
	caps->max_qp_wr = 512;
	caps->max_cqes = 1024;
	caps->max_srqes = 1;
	caps->max_rq_sg = 1;
	caps->max_sq_sg = 1;
	caps->num_comp_vector = 1;
	caps->page_size_cap =   0xFFFFF000;
	caps->max_mtu = IB_MTU_4096;
	caps->max_qp_init_rd_atom = 16; //todo
	caps->max_qp_rd_atom = 16;
	caps->max_ah = 4096;
	caps->max_mr_size = caps->max_mr_sgs * (u64)(4*1024*1024*1024ull);//一个mr最多的内存�?

	func->ud_multicast = 0;
	func->srq_supp     = 0;
	func->srq_modify   = 0;
	func->mw_supp      = 0;
	func->atomic_supp  = 0;
	func->ud_supp      = 0;
	func->uc_supp      = 0;
	func->xrc_supp     = 0;
	func->quick_excep  = 1;
	func->sw_err_flush = 1;
	func->srq_seq      = 0;
	func->queue_l2_tbl = 0;
	func->mr_l2_tbl    = 0;
	return 0;
}

static void np_global_reset(struct yib_hw_host *hw)
{
	hw->vf_id = 0;
	hw->pf_id = 0;
	hw->host_id = 0;
}

static int np_start_host(struct yib_hw_host *hw)
{

	return 0;//-ENOMEM; // current return fail to let upper layer fail
}

static void np_stop_host(struct yib_hw_host *hw)
{
}

static void np_shutdown_host(struct yib_hw_host *hw)
{
}

static int np_set_qos(struct yib_hw_host *hw, struct yib_rdma_qos_info *qos_info)
{
	return -ENOENT;
}

static int np_set_rx_buf_size(struct yib_hw_host *hw)
{
	return -ENOENT;
}

static void np_get_hw_counter(struct yib_hw_host *hw, u64 *stats, u32 port_num)
{
	int i = 0;
	for (i = 0; i < hw->hw_counter_cnt; i++) {
		switch (i) {
			case YIB_CNT_LINK_DOWN:
				stats[i] = hw->ndev_info[port_num - 1].link_down;
				break;
			default:
				stats[i] = 0; //keep value
				break;
		}
	}
}

static int np_host_reg_mmap(struct yib_hw_host *hw, struct vm_area_struct *vma, ssize_t length, u64 offset)
{
	u64 bar_addr = 0;
	bar_addr = yusur_hw_get_bar_pa_by_off(hw, 0, offset);
	if(bar_addr == 0){
		os_printe(hw->dev, "bar addr get failed");
		return -EINVAL;
	}else{
		if (remap_pfn_range(vma, vma->vm_start, bar_addr >> PAGE_SHIFT,
					length, vma->vm_page_prot)) {
			os_printe(hw->dev, "Failed to map np mem memory");
			return -EAGAIN;
		}
	}
	return 0;
}

static int np_host_def_mmap(struct yib_hw_host *hw, struct vm_area_struct *vma, ssize_t length, u64 offset, int type)
{
	struct yib_frag_buf *frag_buf = NULL;
	struct np_yib_sf *np_sf = hw->sf.sf_priv;
	unsigned long remap_size;
	uint32_t frag_sz;
	int nfrags_need;
	int i;
	
	switch (type)
	{
		case YIB_MMAP_TYPE_HW1:
			frag_buf = np_sf->qid_cid_base;
			break;
		case YIB_MMAP_TYPE_HW2:
		case YIB_MMAP_TYPE_HW3:
		case YIB_MMAP_TYPE_HW4:
		case YIB_MMAP_TYPE_HW5:
		case YIB_MMAP_TYPE_HW6:
		case YIB_MMAP_TYPE_HW7:
		case YIB_MMAP_TYPE_HW8:
			break;
		default:
			break;
	}

	if (frag_buf == NULL)
		return -ENOMEM;

	frag_sz = yib_frag_get_pagesz(frag_buf);
	nfrags_need = DIV_ROUND_UP(length, frag_sz);
	for (i = 0; i < nfrags_need; i++) {
		if (frag_sz * (i+1) > length)
			remap_size = length - frag_sz * i;
		else
			remap_size = frag_sz;

		if (remap_pfn_range(vma, vma->vm_start + i*frag_sz, frag_buf->frags[i].dma_addr >> PAGE_SHIFT,
							remap_size, vma->vm_page_prot)) {
			os_printe(hw->dev, "Failed to map def type:%d memory", type);
			return -EAGAIN;
		}
	}

	yib_pr_info(YUSUR_IB_DBG_INIT, "%s : def phy_addr: %llx length: %d \n",
		__func__, frag_buf->frags->dma_addr, (int)length);

	return 0;
}

static int np_get_usable_channels(struct yib_hw_host *hw)
{
	return 0;
}

static void np_get_queue_user_info(struct yib_hw_host *hw, enum yib_elem_type type, void *verbs, u32 hw_id, u8 *res, int *len)
{
	*len = 0;
	switch(type) {
	case YIB_TYPE_PD:
	{
		struct yib_ib_alloc_uctx_resp uctx;
		uctx.bar_offset = 0;//hw->sf->hw_base_off for other type
		uctx.bar_map_len = YIB_NP_BAR_SIZE; //yusur_hw_get_bar_len(hw) for other type
		uctx.cq_isize = hw->hw_ops.queue_ops->cqe_isize;
		uctx.chip_type = hw->hw_ops.host_type;
		uctx.chip_subtype = hw->chip_subtype;
		uctx.quick_excep = hw->funcs.quick_excep;
		uctx.sw_err_flush = hw->funcs.sw_err_flush;
		*len = sizeof(struct yib_ib_alloc_uctx_resp);
		memcpy(res, &uctx, *len);
		break;
	}
	case YIB_TYPE_CQ:
	{
		struct yib_ib_create_cq_resp cq;
		struct yib_cq *ycq = (struct yib_cq*)verbs;
		cq.cqid = hw_id;
		cq.max_cqe = ycq->queue->depth;
		*len = sizeof(struct yib_ib_create_cq_resp);
		memcpy(res, &cq, *len);
		break;
	}
	case YIB_TYPE_QP:
	{
		struct yib_ib_create_qp_resp qp;
		struct yib_qp *yqp = (struct yib_qp*)verbs;
		qp.qpid = yib_get_qp_sw_idx(yqp);
		qp.capture_pa = 0;
		qp.nvme_rq_rqe_pa = 0;
		qp.max_send_wr = yqp->cap.max_send_wr;
		qp.max_recv_wr = yqp->cap.max_recv_wr;
		qp.max_send_sge = yqp->cap.max_send_sge;
		qp.max_recv_sge = yqp->cap.max_recv_sge;
		qp.max_inline_data = yqp->cap.max_inline_data;
		qp.send_isize = yqp->ysq.queue->item_size;
		if ((yqp->use_srq == false) && (yqp->type.yrq != NULL)) {
			qp.rqid = yib_get_rq_sw_idx(yqp->type.yrq);
			qp.recv_isize = yqp->type.yrq->queue->item_size;
		} else if (yqp->use_srq && yqp->qp_type != IB_QPT_XRC_TGT) {
			qp.rqid = yib_get_rq_sw_idx(yqp->type.ysrq->yrq);
			qp.recv_isize = yqp->type.ysrq->yrq->queue->item_size;
		} else {
			qp.rqid = 0;
			qp.recv_isize = 0;
		}
		*len = sizeof(struct yib_ib_create_qp_resp);
		memcpy(res, &qp, *len);
		break;
	}
	case YIB_TYPE_RQ:
	{
		struct yib_ib_create_srq_resp srq;
		struct yib_srq *ysrq = (struct yib_srq*)verbs;
		srq.srqid = hw_id;
		srq.max_sge = ysrq->attr.max_sge;
		srq.max_wr = ysrq->attr.max_wr;
		srq.isize = ysrq->yrq->queue->item_size;
		*len = sizeof(struct yib_ib_create_srq_resp);
		memcpy(res, &srq, *len);
		break;
	}
	default:
		*len = 0;
		break;
	}
}

static void np_host_debugfs_reg(struct yib_hw_host *hw)
{
}
static void np_host_debugfs_mem(struct yib_hw_host *hw, u32 len, u64 addr)
{
}
static int np_user_def_hw_debugfs(struct yib_hw_host *hw, u8 *buf)
{
	return 0;
}
static void np_smac_debugfs(struct yib_hw_host *hw)
{
}
static void np_sgid_debugfs(struct yib_hw_host *hw)
{
}

#if (COUNTER_STAT_DESC)	
const struct rdma_stat_desc  *np_get_counter_info(struct yib_hw_host *hw, u32 *count)
#else
const char * const *np_get_counter_info(struct yib_hw_host *hw, u32 *count)
#endif
{
	*count = ARRAY_SIZE(np_counter_name);
	return np_counter_name;
}

struct yib_uio_ops np_uio_ops = {
	.uio_post_send = np_uio_post_send,
	.uio_post_recv = np_uio_post_recv,
	.uio_poll_cq = np_uio_poll_cq,
};

struct yib_queue_ops np_queue_ops = {
	.cqe_isize = 32,
	.fill_rqe = np_fill_rqe,
	.fill_srqe = np_fill_srqe,
	.fill_wqe = np_fill_wqe,
	.fill_cqe = np_fill_cqe,
	.sw_fill_cqe = np_sw_fill_cqe,

	.check_sq_full = np_check_sq_full,
	.check_rq_full = np_check_rq_full,
	.check_srq_full = np_check_srq_full,
	.check_cq_empty = np_check_cq_empty,

	.get_sq_item_size = np_get_sq_item_size,
	.get_rq_item_size = np_get_rq_item_size,

	.sq_pi_db_update = np_sq_pi_db_update,
	.rq_pi_db_update = np_rq_pi_db_update,
	.srq_pi_db_update = np_srq_pi_db_update,
	.cq_ci_db_update = np_cq_ci_db_update,
};

struct yib_eq_ops np_eq_ops = {
	.intr_enable = false,
	.priv_size = sizeof(np_eq_priv_t),
	.get_eq_intr_num = np_get_eq_intr_num,
	.eq_info_init = np_eq_info_init,
	.eq_debugfs = np_eq_debugfs,
	.check_eq_empty = np_check_eq_empty,
	.eq_sw_handler = np_eq_sw_handler,
	.eq_handler = np_eq_handler,
	.eq_ci_db_update = np_eq_ci_db_update,
};

struct yib_sf_ops np_sf_ops = {
	.host_type = YRDMA_TYPE_NP,
	.priv_size = sizeof(struct np_yib_sf),

	.sf_pre_init = np_sf_pre_init,
	.sf_init = np_sf_init,

	.start_sf = np_start_sf,
	.stop_sf = np_stop_sf,

	//mac
	.add_mac = np_add_mac,
	.modify_mac = np_modify_mac,

	.set_gid = np_set_gid,

	//av
	.init_av = np_init_av,

	//mr
	.mrw_alloc = np_mrw_alloc,
	.mrw_destroy = np_mrw_destroy,
	.mr_mtt_init = np_mr_mtt_init,
	.mr_mpt_update = np_mr_mpt_update,
	.mr_debugfs= np_mr_debugfs,

	//cq
	.cq_info_init = np_cq_info_init,
	.cq_notify_update = np_cq_notify_update,
	.cq_debugfs = np_cq_debugfs,

	//qp
	.qp_info_init = np_qp_info_init,
	.qp_info_update = np_qp_info_update,
	.qp_query = np_qp_query,
	.qp_debugfs = np_qp_debugfs,

	//np no ops
	.rq_info_init = np_rq_info_init,
	.srq_debugfs = np_srq_debugfs,

	.sf_debugfs = np_sf_debugfs,
};

static const struct yib_hw_ops np_hwops = {
	.host_type = YRDMA_TYPE_NP,
	.host_name = "NP",
	.priv_size = sizeof(np_priv_t),

	.init_caps =  np_init_caps,
	.global_reset = np_global_reset,

	.start_host = np_start_host,
	.stop_host = np_stop_host,
	.shutdown_host = np_shutdown_host,

	.set_qos = np_set_qos,
	.set_rx_buf_size = np_set_rx_buf_size,
	.get_hw_counter = np_get_hw_counter,
	.get_counter_info = np_get_counter_info,
	.host_reg_mmap = np_host_reg_mmap,
	.host_def_mmap = np_host_def_mmap,

	.get_usable_channels = np_get_usable_channels,
	.get_queue_user_info = np_get_queue_user_info,
	.host_debugfs_reg = np_host_debugfs_reg,
	.host_debugfs_mem = np_host_debugfs_mem,
	.user_def_hw_debugfs = np_user_def_hw_debugfs,
	.smac_debugfs = np_smac_debugfs,
	.sgid_debugfs = np_sgid_debugfs,

	.sf_ops = &np_sf_ops,
	.eq_ops = &np_eq_ops,
	.queue_ops = &np_queue_ops,
	.uio_ops = &np_uio_ops,
};

const struct yib_hw_ops *np_get_host_ops(void)
{
	return &np_hwops;
}
