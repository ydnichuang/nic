#include "../../include/basic.h"
#include "../../include/os_api.h"
#include "../../include/os_ds.h"
#include "../../include/mem.h"
#include "../../include/queue.h"
#include "../../include/host.h"
#include "../../include/verbs.h"
#include "../../include/yusur_ib.h"
#include "../../include/user.h"
#include "../hostpriv.h"
#include "../hwcomn.h"
#include "yusdoe_kapi.h"
#include "np_api.h"
#include "np_sf.h"
#include "np_res.h"

struct np_res_create_param np_res_createtbl_info[NP_TYPE_RES_MAX] = {
        [NP_TYPE_MAC_PORT]                              = {
                .table_id   = YIB_NP_MAC_PORT_ID,
                .entry_len  = YIB_NP_MAC_PORT_BYTES,
                .depth      = YIB_NP_MAC_PORT_DEPTH,
                .cfg        = {
                        .shared_tbl = true,
                        .l2_cache_ways = YIB_NP_MAC_PORT_L2_TAG,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU0]     = YIB_NP_MAC_PORT_L1_TAG,
                            [NP_TYPE_CLU1]     = YIB_NP_MAC_PORT_L1_TAG,
                            [NP_TYPE_CLU2]     = YIB_NP_MAC_PORT_L1_TAG,
                            [NP_TYPE_CLU3]     = YIB_NP_MAC_PORT_L1_TAG,
                        }
                },
        },
        [NP_TYPE_QP_REMAP]                              = {
                .table_id   = YIB_NP_QP_REMAP_ID,
                .entry_len  = YIB_NP_QP_REMAP_BYTES,
                .depth      = YIB_NP_QP_REMAP_DEPTH,
                .cfg        = {
                        .shared_tbl = true,
                        .l2_cache_ways = YIB_NP_QP_REMAP_L2_TAG,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU0]     = YIB_NP_QP_REMAP_L1_TAG,
                            [NP_TYPE_CLU1]     = YIB_NP_QP_REMAP_L1_TAG,
                            [NP_TYPE_CLU2]     = YIB_NP_QP_REMAP_L1_TAG,
                            [NP_TYPE_CLU3]     = YIB_NP_QP_REMAP_L1_TAG,
                        }
                },
        },
        [NP_TYPE_QP_STATE]                              = {
                .table_id   = YIB_NP_QP_STATE_ID,
                .entry_len  = YIB_NP_QP_STATE_BYTES,
                .depth      = YIB_NP_QP_STATE_DEPTH,
                .cfg        = {
                        .shared_tbl = true,
                        .l2_cache_ways = YIB_NP_QP_STATE_L2_TAG,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU4]     = YIB_NP_QP_STATE_L1_TAG,
                            [NP_TYPE_CLU5]     = YIB_NP_QP_STATE_L1_TAG,
                            [NP_TYPE_CLU6]     = YIB_NP_QP_STATE_L1_TAG,
                            [NP_TYPE_CLU7]     = YIB_NP_QP_STATE_L1_TAG,
                            [NP_TYPE_CLU8]     = YIB_NP_QP_STATE_L1_TAG,
                            [NP_TYPE_CLU9]     = YIB_NP_QP_STATE_L1_TAG,
                            [NP_TYPE_CLU10]     = YIB_NP_QP_STATE_L1_TAG,
                            [NP_TYPE_CLU11]     = YIB_NP_QP_STATE_L1_TAG,
                            [NP_TYPE_CLU12]     = YIB_NP_QP_STATE_L1_TAG,
                            [NP_TYPE_CLU13]     = YIB_NP_QP_STATE_L1_TAG,
                        }
                },
        },
        [NP_TYPE_SQC_CLU4]                              = {
                .table_id   = YIB_NP_SQC_CLU4_ID,
                .entry_len  = YIB_NP_SQC_BYTES_ENTRY,
                .depth      = YIB_NP_SQC_TABLE_DEPTH,
                .cfg        = {
                        .shared_tbl = false,
                        .l2_cache_ways = 0,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU4]     = YIB_NP_SQC_L1_TAG,
                        }
                },
        },
        [NP_TYPE_SQC_CLU5]                              = {
                .table_id   = YIB_NP_SQC_CLU5_ID,
                .entry_len  = YIB_NP_SQC_BYTES_ENTRY,
                .depth      = YIB_NP_SQC_TABLE_DEPTH,
                .cfg        = {
                        .shared_tbl = false,
                        .l2_cache_ways = 0,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU5]     = YIB_NP_SQC_L1_TAG,
                        }
                },
        },
        [NP_TYPE_SQC_CLU6]                              = {
                .table_id   = YIB_NP_SQC_CLU6_ID,
                .entry_len  = YIB_NP_SQC_BYTES_ENTRY,
                .depth      = YIB_NP_SQC_TABLE_DEPTH,
                .cfg        = {
                        .shared_tbl = false,
                        .l2_cache_ways = 0,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU6]     = YIB_NP_SQC_L1_TAG,
                        }
                },
        },
        [NP_TYPE_SQC_CLU7]                              = {
                .table_id   = YIB_NP_SQC_CLU7_ID,
                .entry_len  = YIB_NP_SQC_BYTES_ENTRY,
                .depth      = YIB_NP_SQC_TABLE_DEPTH,
                .cfg        = {
                        .shared_tbl = false,
                        .l2_cache_ways = 0,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU7]     = YIB_NP_SQC_L1_TAG,
                        }
                },
        },
        [NP_TYPE_SQC_CLU8]                              = {
                .table_id   = YIB_NP_SQC_CLU8_ID,
                .entry_len  = YIB_NP_SQC_BYTES_ENTRY,
                .depth      = YIB_NP_SQC_TABLE_DEPTH,
                .cfg        = {
                        .shared_tbl = false,
                        .l2_cache_ways = 0,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU8]     = YIB_NP_SQC_L1_TAG,
                        }
                },
        },        
        [NP_TYPE_RQC_CLU9]                              = {
                .table_id   = YIB_NP_RQC_CLU9_ID,
                .entry_len  = YIB_NP_RQC_BYTES_ENTRY,
                .depth      = YIB_NP_RQC_TABLE_DEPTH,
                .cfg        = {
                        .shared_tbl = false,
                        .l2_cache_ways = 0,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU9]     = YIB_NP_RQC_L1_TAG,
                        }
                },
        },        
        [NP_TYPE_RQC_CLU10]                              = {
                .table_id   = YIB_NP_RQC_CLU10_ID,
                .entry_len  = YIB_NP_RQC_BYTES_ENTRY,
                .depth      = YIB_NP_RQC_TABLE_DEPTH,
                .cfg        = {
                        .shared_tbl = false,
                        .l2_cache_ways = 0,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU10]     = YIB_NP_RQC_L1_TAG,
                        }
                },
        },        
        [NP_TYPE_RQC_CLU11]                              = {
                .table_id   = YIB_NP_RQC_CLU11_ID,
                .entry_len  = YIB_NP_RQC_BYTES_ENTRY,
                .depth      = YIB_NP_RQC_TABLE_DEPTH,
                .cfg        = {
                        .shared_tbl = false,
                        .l2_cache_ways = 0,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU11]     = YIB_NP_RQC_L1_TAG,
                        }
                },
        },        
        [NP_TYPE_RQC_CLU12]                              = {
                .table_id   = YIB_NP_RQC_CLU12_ID,
                .entry_len  = YIB_NP_RQC_BYTES_ENTRY,
                .depth      = YIB_NP_RQC_TABLE_DEPTH,
                .cfg        = {
                        .shared_tbl = false,
                        .l2_cache_ways = 0,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU12]     = YIB_NP_RQC_L1_TAG,
                        }
                },
        },        
        [NP_TYPE_RQC_CLU13]                              = {
                .table_id   = YIB_NP_RQC_CLU13_ID,
                .entry_len  = YIB_NP_RQC_BYTES_ENTRY,
                .depth      = YIB_NP_RQC_TABLE_DEPTH,
                .cfg        = {
                        .shared_tbl = false,
                        .l2_cache_ways = 0,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU13]     = YIB_NP_RQC_L1_TAG,
                        }
                },
        },        
        [NP_TYPE_SQS_CLU4]                              = {
                .table_id   = YIB_NP_SQS_CLU4_ID,
                .entry_len  = YIB_NP_SQ_STATUS_BYTES,
                .depth      = YIB_NP_SQ_STATUS_DEPTH,
                .cfg        = {
                        .shared_tbl = false,
                        .l2_cache_ways = 0,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU4]     = YIB_NP_SQS_L1_TAG,
                        }
                },
        },        
        [NP_TYPE_SQS_CLU5]                              = {
                .table_id   = YIB_NP_SQS_CLU5_ID,
                .entry_len  = YIB_NP_SQ_STATUS_BYTES,
                .depth      = YIB_NP_SQ_STATUS_DEPTH,
                .cfg        = {
                        .shared_tbl = false,
                        .l2_cache_ways = 0,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU5]     = YIB_NP_SQS_L1_TAG,
                        }
                },
        },
        [NP_TYPE_SQS_CLU6]                              = {
                .table_id   = YIB_NP_SQS_CLU6_ID,
                .entry_len  = YIB_NP_SQ_STATUS_BYTES,
                .depth      = YIB_NP_SQ_STATUS_DEPTH,
                .cfg        = {
                        .shared_tbl = false,
                        .l2_cache_ways = 0,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU6]     = YIB_NP_SQS_L1_TAG,
                        }
                },
        },
        [NP_TYPE_SQS_CLU7]                              = {
                .table_id   = YIB_NP_SQS_CLU7_ID,
                .entry_len  = YIB_NP_SQ_STATUS_BYTES,
                .depth      = YIB_NP_SQ_STATUS_DEPTH,
                .cfg        = {
                        .shared_tbl = false,
                        .l2_cache_ways = 0,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU7]     = YIB_NP_SQS_L1_TAG,
                        }
                },
        },
        [NP_TYPE_SQS_CLU8]                              = {
                .table_id   = YIB_NP_SQS_CLU8_ID,
                .entry_len  = YIB_NP_SQ_STATUS_BYTES,
                .depth      = YIB_NP_SQ_STATUS_DEPTH,
                .cfg        = {
                        .shared_tbl = false,
                        .l2_cache_ways = 0,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU8]     = YIB_NP_SQS_L1_TAG,
                        }
                },
        },        
        [NP_TYPE_RQS_CLU9]                              = {
                .table_id   = YIB_NP_RQS_CLU9_ID,
                .entry_len  = YIB_NP_RQ_STATUS_BYTES,
                .depth      = YIB_NP_RQ_STATUS_DEPTH,
                .cfg        = {
                        .shared_tbl = false,
                        .l2_cache_ways = 0,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU9]     = YIB_NP_RQS_L1_TAG,
                        }
                },
        },        
        [NP_TYPE_RQS_CLU10]                              = {
                .table_id   = YIB_NP_RQS_CLU10_ID,
                .entry_len  = YIB_NP_RQ_STATUS_BYTES,
                .depth      = YIB_NP_RQ_STATUS_DEPTH,
                .cfg        = {
                        .shared_tbl = false,
                        .l2_cache_ways = 0,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU10]     = YIB_NP_RQS_L1_TAG,
                        }
                },
        },        
        [NP_TYPE_RQS_CLU11]                              = {
                .table_id   = YIB_NP_RQS_CLU11_ID,
                .entry_len  = YIB_NP_RQ_STATUS_BYTES,
                .depth      = YIB_NP_RQ_STATUS_DEPTH,
                .cfg        = {
                        .shared_tbl = false,
                        .l2_cache_ways = 0,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU11]     = YIB_NP_RQS_L1_TAG,
                        }
                },
        },        
        [NP_TYPE_RQS_CLU12]                              = {
                .table_id   = YIB_NP_RQS_CLU12_ID,
                .entry_len  = YIB_NP_RQ_STATUS_BYTES,
                .depth      = YIB_NP_RQ_STATUS_DEPTH,
                .cfg        = {
                        .shared_tbl = false,
                        .l2_cache_ways = 0,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU12]     = YIB_NP_RQS_L1_TAG,
                        }
                },
        },        
        [NP_TYPE_RQS_CLU13]                              = {
                .table_id   = YIB_NP_RQS_CLU13_ID,
                .entry_len  = YIB_NP_RQ_STATUS_BYTES,
                .depth      = YIB_NP_RQ_STATUS_DEPTH,
                .cfg        = {
                        .shared_tbl = false,
                        .l2_cache_ways = 0,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU13]     = YIB_NP_RQS_L1_TAG,
                        }
                },
        },        
        [NP_TYPE_SQE_CLU4]                              = {
                .table_id   = YIB_NP_SQE_CLU4_ID,
                .entry_len  = YIB_NP_SQE_RTIME_BYTES,
                .depth      = YIB_NP_SQE_RTIME_DEPTH,
                .cfg        = {
                        .shared_tbl = false,
                        .l2_cache_ways = 0,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU4]     = YIB_NP_SQE_L1_TAG,
                        }
                },
        },        
        [NP_TYPE_SQE_CLU5]                              = {
                .table_id   = YIB_NP_SQE_CLU5_ID,
                .entry_len  = YIB_NP_SQE_RTIME_BYTES,
                .depth      = YIB_NP_SQE_RTIME_DEPTH,
                .cfg        = {
                        .shared_tbl = false,
                        .l2_cache_ways = 0,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU5]     = YIB_NP_SQE_L1_TAG,
                        }
                },
        },
        [NP_TYPE_SQE_CLU6]                              = {
                .table_id   = YIB_NP_SQE_CLU6_ID,
                .entry_len  = YIB_NP_SQE_RTIME_BYTES,
                .depth      = YIB_NP_SQE_RTIME_DEPTH,
                .cfg        = {
                        .shared_tbl = false,
                        .l2_cache_ways = 0,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU6]     = YIB_NP_SQE_L1_TAG,
                        }
                },
        },
        [NP_TYPE_SQE_CLU7]                              = {
                .table_id   = YIB_NP_SQE_CLU7_ID,
                .entry_len  = YIB_NP_SQE_RTIME_BYTES,
                .depth      = YIB_NP_SQE_RTIME_DEPTH,
                .cfg        = {
                        .shared_tbl = false,
                        .l2_cache_ways = 0,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU7]     = YIB_NP_SQE_L1_TAG,
                        }
                },
        },
        [NP_TYPE_SQE_CLU8]                              = {
                .table_id   = YIB_NP_SQE_CLU8_ID,
                .entry_len  = YIB_NP_SQE_RTIME_BYTES,
                .depth      = YIB_NP_SQE_RTIME_DEPTH,
                .cfg        = {
                        .shared_tbl = false,
                        .l2_cache_ways = 0,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU8]     = YIB_NP_SQE_L1_TAG,
                        }
                },
        },        
        [NP_TYPE_RQE_CLU9]                              = {
                .table_id   = YIB_NP_RQE_CLU9_ID,
                .entry_len  = YIB_NP_RQE_RTIME_BYTES,
                .depth      = YIB_NP_RQE_RTIME_DEPTH,
                .cfg        = {
                        .shared_tbl = false,
                        .l2_cache_ways = 0,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU9]     = YIB_NP_RQE_L1_TAG,
                        }
                },
        },        
        [NP_TYPE_RQE_CLU10]                              = {
                .table_id   = YIB_NP_RQE_CLU10_ID,
                .entry_len  = YIB_NP_RQE_RTIME_BYTES,
                .depth      = YIB_NP_RQE_RTIME_DEPTH,
                .cfg        = {
                        .shared_tbl = false,
                        .l2_cache_ways = 0,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU10]     = YIB_NP_RQE_L1_TAG,
                        }
                },
        },        
        [NP_TYPE_RQE_CLU11]                              = {
                .table_id   = YIB_NP_RQE_CLU11_ID,
                .entry_len  = YIB_NP_RQE_RTIME_BYTES,
                .depth      = YIB_NP_RQE_RTIME_DEPTH,
                .cfg        = {
                        .shared_tbl = false,
                        .l2_cache_ways = 0,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU11]     = YIB_NP_RQE_L1_TAG,
                        }
                },
        },        
        [NP_TYPE_RQE_CLU12]                              = {
                .table_id   = YIB_NP_RQE_CLU12_ID,
                .entry_len  = YIB_NP_RQE_RTIME_BYTES,
                .depth      = YIB_NP_RQE_RTIME_DEPTH,
                .cfg        = {
                        .shared_tbl = false,
                        .l2_cache_ways = 0,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU12]     = YIB_NP_RQE_L1_TAG,
                        }
                },
        },        
        [NP_TYPE_RQE_CLU13]                              = {
                .table_id   = YIB_NP_RQE_CLU13_ID,
                .entry_len  = YIB_NP_RQE_RTIME_BYTES,
                .depth      = YIB_NP_RQE_RTIME_DEPTH,
                .cfg        = {
                        .shared_tbl = false,
                        .l2_cache_ways = 0,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU13]     = YIB_NP_RQE_L1_TAG,
                        }
                },
        },        
        [NP_TYPE_RMSG_CLU9]                              = {
                .table_id   = YIB_NP_RMSG_CLU9_ID,
                .entry_len  = YIB_NP_RMSG_RTIME_BYTES,
                .depth      = YIB_NP_RMSG_RTIME_DEPTH,
                .cfg        = {
                        .shared_tbl = false,
                        .l2_cache_ways = 0,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU9]     = YIB_NP_RMSG_L1_TAG,
                        }
                },
        },        
        [NP_TYPE_RMSG_CLU10]                              = {
                .table_id   = YIB_NP_RMSG_CLU10_ID,
                .entry_len  = YIB_NP_RMSG_RTIME_BYTES,
                .depth      = YIB_NP_RMSG_RTIME_DEPTH,
                .cfg        = {
                        .shared_tbl = false,
                        .l2_cache_ways = 0,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU10]     = YIB_NP_RMSG_L1_TAG,
                        }
                },
        },        
        [NP_TYPE_RMSG_CLU11]                              = {
                .table_id   = YIB_NP_RMSG_CLU11_ID,
                .entry_len  = YIB_NP_RMSG_RTIME_BYTES,
                .depth      = YIB_NP_RMSG_RTIME_DEPTH,
                .cfg        = {
                        .shared_tbl = false,
                        .l2_cache_ways = 0,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU11]     = YIB_NP_RMSG_L1_TAG,
                        }
                },
        },        
        [NP_TYPE_RMSG_CLU12]                              = {
                .table_id   = YIB_NP_RMSG_CLU12_ID,
                .entry_len  = YIB_NP_RMSG_RTIME_BYTES,
                .depth      = YIB_NP_RMSG_RTIME_DEPTH,
                .cfg        = {
                        .shared_tbl = false,
                        .l2_cache_ways = 0,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU12]     = YIB_NP_RMSG_L1_TAG,
                        }
                },
        },        
        [NP_TYPE_RMSG_CLU13]                              = {
                .table_id   = YIB_NP_RMSG_CLU13_ID,
                .entry_len  = YIB_NP_RMSG_RTIME_BYTES,
                .depth      = YIB_NP_RMSG_RTIME_DEPTH,
                .cfg        = {
                        .shared_tbl = false,
                        .l2_cache_ways = 0,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU13]     = YIB_NP_RMSG_L1_TAG,
                        }
                },
        },        
        [NP_TYPE_MPT]                              = {
                .table_id   = YIB_NP_MPT_ID,
                .entry_len  = YIB_NP_MPT_BYTES_ENTRY,
                .depth      = YIB_NP_MPT_DEPTH,
                .cfg        = {
                        .shared_tbl = true,
                        .l2_cache_ways = YIB_NP_MPT_L2_TAG,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU4]     = YIB_NP_MPT_L1_TAG,
                            [NP_TYPE_CLU5]     = YIB_NP_MPT_L1_TAG,
                            [NP_TYPE_CLU6]     = YIB_NP_MPT_L1_TAG,
                            [NP_TYPE_CLU7]     = YIB_NP_MPT_L1_TAG,
                            [NP_TYPE_CLU8]     = YIB_NP_MPT_L1_TAG,
                            [NP_TYPE_CLU9]     = YIB_NP_MPT_L1_TAG,
                            [NP_TYPE_CLU10]     = YIB_NP_MPT_L1_TAG,
                            [NP_TYPE_CLU11]     = YIB_NP_MPT_L1_TAG,
                            [NP_TYPE_CLU12]     = YIB_NP_MPT_L1_TAG,
                            [NP_TYPE_CLU13]     = YIB_NP_MPT_L1_TAG,
                            [NP_TYPE_CLU14]     = YIB_NP_MPT_L1_TAG,
                            [NP_TYPE_CLU15]     = YIB_NP_MPT_L1_TAG,
                        }
                },
        },
        [NP_TYPE_MTT]                              = {
                .table_id   = YIB_NP_MTT_ID,
                .entry_len  = YIB_NP_MTT_BYTES_ENTRY,
                .depth      = YIB_NP_MTT_DEPTH,
                .cfg        = {
                        .shared_tbl = true,
                        .l2_cache_ways = YIB_NP_MTT_L2_TAG,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU4]     = YIB_NP_MTT_L1_TAG,
                            [NP_TYPE_CLU5]     = YIB_NP_MTT_L1_TAG,
                            [NP_TYPE_CLU6]     = YIB_NP_MTT_L1_TAG,
                            [NP_TYPE_CLU7]     = YIB_NP_MTT_L1_TAG,
                            [NP_TYPE_CLU8]     = YIB_NP_MTT_L1_TAG,
                            [NP_TYPE_CLU9]     = YIB_NP_MTT_L1_TAG,
                            [NP_TYPE_CLU10]     = YIB_NP_MTT_L1_TAG,
                            [NP_TYPE_CLU11]     = YIB_NP_MTT_L1_TAG,
                            [NP_TYPE_CLU12]     = YIB_NP_MTT_L1_TAG,
                            [NP_TYPE_CLU13]     = YIB_NP_MTT_L1_TAG,
                            [NP_TYPE_CLU14]     = YIB_NP_MTT_L1_TAG,
                            [NP_TYPE_CLU15]     = YIB_NP_MTT_L1_TAG,
                        }
                },
        },
        [NP_TYPE_AVT]                              = {
                .table_id   = YIB_NP_AVT_ID,
                .entry_len  = YIB_NP_AVT_BYTES_ENTRY,
                .depth      = YIB_NP_AVT_DEPTH,
                .cfg        = {
                        .shared_tbl = true,
                        .l2_cache_ways = YIB_NP_AVT_L2_TAG,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU4]     = YIB_NP_AVT_L1_TAG,
                            [NP_TYPE_CLU5]     = YIB_NP_AVT_L1_TAG,
                            [NP_TYPE_CLU6]     = YIB_NP_AVT_L1_TAG,
                            [NP_TYPE_CLU7]     = YIB_NP_AVT_L1_TAG,
                            [NP_TYPE_CLU8]     = YIB_NP_AVT_L1_TAG,
                            [NP_TYPE_CLU9]     = YIB_NP_AVT_L1_TAG,
                            [NP_TYPE_CLU10]     = YIB_NP_AVT_L1_TAG,
                            [NP_TYPE_CLU11]     = YIB_NP_AVT_L1_TAG,
                            [NP_TYPE_CLU12]     = YIB_NP_AVT_L1_TAG,
                            [NP_TYPE_CLU13]     = YIB_NP_AVT_L1_TAG,
                            [NP_TYPE_CLU14]     = YIB_NP_AVT_L1_TAG,
                            [NP_TYPE_CLU15]     = YIB_NP_AVT_L1_TAG,
                        }
                },
        },
        [NP_TYPE_CQC]                              = {
                .table_id   = YIB_NP_CQC_ID,
                .entry_len  = YIB_NP_CQC_BYTES_ENTRY,
                .depth      = YIB_NP_CQC_DEPTH,
                .cfg        = {
                        .shared_tbl = false,
                        .l2_cache_ways = 0,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU14]     = YIB_NP_CQC_L1_TAG,
                        }
                },
        },        
        [NP_TYPE_NQC]                              = {
                .table_id   = YIB_NP_NQC_ID,
                .entry_len  = YIB_NP_NQC_BYTES_ENTRY,
                .depth      = YIB_NP_NQC_DEPTH,
                .cfg        = {
                        .shared_tbl = false,
                        .l2_cache_ways = 0,
                        .l1_cache_ways = {
                            [NP_TYPE_CLU14]     = YIB_NP_NQC_L1_TAG,
                        }
                },
        },        
};

static int np_hw_res_tbl_init(struct yib_sf *sf, struct yib_np_resource *hw_res)
{
	//struct np_yib_sf *np_sf = sf->sf_priv;
	int i, j, ret = 0;
	
	for(i = 0; i < NP_TYPE_RES_MAX; i++)
	{
    		np_delete_arraytbl(np_res_createtbl_info[i].table_id);
	}

	for(i = 0; i < NP_TYPE_RES_MAX; i++)
	{
		ret = np_create_arraytbl(np_res_createtbl_info[i].table_id, np_res_createtbl_info[i].depth, np_res_createtbl_info[i].entry_len, &np_res_createtbl_info[i].cfg);
		if (ret != 0) {
			os_printe(sf->hw->dev, "call np_create_arraytbl failed. errcode:%d\n", ret);
			return ret;
		}
		for(j = 0; j < np_res_createtbl_info[i].depth; j++)
		{
			ret = np_read_clear_array(np_res_createtbl_info[i].table_id, j, NULL, np_res_createtbl_info[i].entry_len);
			if (ret != 0) {
				os_printe(sf->hw->dev, "call np_read_clear_array failed. errcode:%d\n", ret);
				return ret;
			}
		}
	}

	return 0;
}

int np_hw_res_init(struct yib_sf *sf, struct yib_np_resource *hw_res)
{
//	struct yib_roce_caps *caps = &sf->hw->caps;
	int i, ret = 0;

	memset(hw_res, 0, sizeof(*hw_res));
        for ( i = 0; i < YIB_NP_CLU_NUM; i++)
        {
                hw_res->np_qp_tbl[i].sqc_id = np_res_createtbl_info[NP_TYPE_SQC_CLU4 + i].table_id;
                hw_res->np_qp_tbl[i].rqc_id = np_res_createtbl_info[NP_TYPE_RQC_CLU9 + i].table_id;
                hw_res->np_qp_tbl[i].sqs_id = np_res_createtbl_info[NP_TYPE_SQS_CLU4 + i].table_id;
                hw_res->np_qp_tbl[i].rqs_id = np_res_createtbl_info[NP_TYPE_RQS_CLU9 + i].table_id;
        }
	hw_res->mac_port_id = np_res_createtbl_info[NP_TYPE_MAC_PORT].table_id;
	hw_res->qp_remap_id = np_res_createtbl_info[NP_TYPE_QP_REMAP].table_id;
	hw_res->qp_state_id = np_res_createtbl_info[NP_TYPE_QP_STATE].table_id;
	hw_res->mpt_id = np_res_createtbl_info[NP_TYPE_MPT].table_id;
	hw_res->mtt_id = np_res_createtbl_info[NP_TYPE_MTT].table_id;
	hw_res->avt_id = np_res_createtbl_info[NP_TYPE_AVT].table_id;
	hw_res->cqc_id = np_res_createtbl_info[NP_TYPE_CQC].table_id;
	hw_res->nqc_id = np_res_createtbl_info[NP_TYPE_NQC].table_id;

	ret = np_hw_res_tbl_init(sf, hw_res);
	if (ret) {
		os_printe(sf->hw->dev, "res tbl init failed");
		return ret;
	}

	return 0;
}

void np_hw_res_exit(struct yib_sf *sf, struct yib_np_resource *hw_res)
{
	int i = 0;

	for(i = 0; i < NP_TYPE_RES_MAX; i++)
	{
    		np_delete_arraytbl(np_res_createtbl_info[i].table_id);
	}
}



