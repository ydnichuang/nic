/*
 * @Descripttion: Copyright(c) All rights reserved.
 * @version: 
 * @Author: wangyingfu
 * @Date: 2024-05-22 15:37:26
 * @LastEditors: wangyingfu
 * @LastEditTime: 2024-05-22 19:04:33
 */
#ifndef _YUSUR_IB_NP_SF_H_
#define _YUSUR_IB_NP_SF_H_



#define np_to_u64(a, b)	((u64)((a) | ((u64)(b) << 32)))
#define NP_SIZE_TO_N(size)		((u32)(ilog2((size)/4096)))
#define NP_MAX_STATES                7
#define NP_MAX_QP_TYPES              5
#define YIB_NP_BAR_SIZE 	(128 * 1024 * 1024)
#define YIB_NP_CLU_NUM		5
#define YIB_MAX_QID_PER_CLU	8
#define NP_QP_MAX_PAGE_NUM	8
#define NP_CFG_PORT_ID		3072
#define NP_MAX_QP_NUMS          32

/* qp_attr_mask */
enum np_qp_attr_mask {
    NP_QP_STATE                = (1<<0),
    NP_QP_ACCESS_FLAGS         = (1<<3),
    NP_QP_PKEY_INDEX           = (1<<4),
    NP_QP_PORT                 = (1<<5),
    NP_QP_QKEY                 = (1<<6),
    NP_QP_AV                   = (1<<7),
    NP_QP_PATH_MTU             = (1<<8),
    NP_QP_TIMEOUT              = (1<<9),
    NP_QP_RETRY_CNT            = (1<<10),
    NP_QP_RNR_RETRY            = (1<<11),
    NP_QP_RQ_PSN               = (1<<12),
    NP_QP_MAX_QP_RD_ATOMIC     = (1<<13),
    NP_QP_MIN_RNR_TIMER        = (1<<15),
    NP_QP_SQ_PSN               = (1<<16),
    NP_QP_MAX_DEST_RD_ATOMIC   = (1<<17),
    NP_QP_DEST_QPN             = (1<<20),
    NP_QP_RATE_LIMIT               = (1<<25),
};

/* qp_type */
enum np_qp_type {
        NP_QPT_RC,
	NP_QPT_UD,	
};

/* qp_state */
enum np_qp_state {
        NP_QPS_RESET,
        NP_QPS_INIT,
        NP_QPS_RTR,
        NP_QPS_RTS,
        NP_QPS_SQD,
        NP_QPS_SQE,
        NP_QPS_ERR
};

/* path_mtu */
enum np_mtu {
        NP_MTU_256  = 0,
        NP_MTU_512,
        NP_MTU_1024,
        NP_MTU_2048,
        NP_MTU_4096,
    	NP_MTU_8192,   //暂不支持
};

enum np_hw_mr_type {
	NP_HW_MR_NORMAL,
	NP_HW_MR_PMR,
	NP_HW_MR_MW_TYPE1,
	NP_HW_MR_MW_TYPE2A,
};

enum np_mr_access {
	NP_ACCESS_REMOTE_READ = 1,
	NP_ACCESS_REMOTE_WRITE = 1 << 1,
	NP_ACCESS_REMOTE_ATOMIC = 1 << 2,
	NP_ACCESS_LOCAL_WRITE = 1 << 3,
	NP_ACCESS_MW_BIND = 1 << 4,
	NP_ACCESS_INVALID = 1 << 5,
};

enum np_mr_state {
	NP_MR_INVALID,
	NP_MR_FREE,
	NP_MR_VALID = 3,
};

typedef struct
{
	os_cdma_t bar;
}np_priv_t;

struct np_qp_priv{
	struct yib_ah *ah;
	u32	index;
};

struct np_qp_table_info {
	u8 sqc_id;
	u8 rqc_id;
	u8 sqs_id;
	u8 rqs_id;
};

struct yib_np_resource {
	struct np_qp_table_info np_qp_tbl[YIB_NP_CLU_NUM];
	u8 mac_port_id;
	u8 qp_remap_id;
	u8 qp_state_id;
	u8 mpt_id;
	u8 mtt_id;
	u8 avt_id;
	u8 cqc_id;
	u8 nqc_id;	
};

struct np_yib_sf
{
	struct yib_frag_buf *qid_cid_base;
	struct yib_np_resource hw_res;
    	void *cache_cfg;
    	bool started;
	os_mutex_t np_mutex;
    	void *priv;
};



int np_sf_pre_init(struct yib_sf *sf);
int np_sf_init(struct yib_sf *sf, bool b_del);
int np_start_sf(struct yib_sf *sf);
void np_stop_sf(struct yib_sf *sf, bool is_shutdown);

void np_add_mac(struct yib_sf *sf, u8 *mac, int index, u8 port_num);
void np_init_av(struct yib_sf *sf, struct yib_av *av, int index, bool b_del);

int np_mrw_alloc(struct yib_sf *sf, struct yib_mr *mr, u32 *lkey, u32 *rkey);
void np_mrw_destroy(struct yib_sf *sf, struct yib_mr *mr);
int np_mr_mtt_init(struct yib_sf *sf, struct yib_mr *mr, struct scatterlist *sg,
				int npages, u32 page_size, u64 pa0);
int np_mr_mpt_update(struct yib_sf *sf, struct yib_mr *ymr);
int np_mr_debugfs(struct yib_sf *sf, struct yib_mr *mr);
int np_cq_info_init(struct yib_sf *sf, struct yib_cq *cq, bool enable);
void np_cq_notify_update(struct yib_sf *sf, struct yib_cq *cq, u32 flag);
int np_cq_debugfs(struct yib_sf *sf, struct yib_cq *ycq);

int np_qp_info_init(struct yib_sf *sf, struct yib_qp *yqp, bool enable);
bool np_qp_info_update(struct yib_sf *sf, struct yib_qp *qp, u32 mask, bool state_chg);
int np_qp_query(struct yib_sf *sf, struct yib_qp *qp, os_qp_attr *attr, int mask, bool bdebug);

#endif


