#include "../../include/basic.h"
#include "../../include/os_api.h"
#include "../../include/os_ds.h"
#include "../../include/mem.h"
#include "../../include/queue.h"
#include "../../include/host.h"
#include "../../include/verbs.h"
#include "../../include/yusur_ib.h"
#include "../../include/user.h"
#include "np_inc_hw.h"
#include "np_inc_base.h"
#include "../hostpriv.h"
#include "../hwcomn.h"
#include "np_api.h"
#include "np_sf.h"

int np_dbg_print_cqc(void *buf, bool bdbg)
{
	int i = 0;
	char buffer[128];
	int buf_pos = 0;
	int offset = 0;
	u8 *cqc_entry = (u8 *)buf;
	int n = sizeof (struct np_hw_cqc_entry) / 4;

	if (bdbg) {
		pr_info("######### CQC dbg_print BEGIN #######\n");
		for (i = 0; i < n; i++) {
			if (i % 4 == 0) {
				buf_pos = 0;
				memset(buffer, 0, sizeof(buffer));
				buf_pos = snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%04x:  ", offset);
				offset += 16;
			}
			buf_pos += snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%08x  ", np_hwres_read32(cqc_entry));
			cqc_entry += 4;
			if ((i + 1) % 4 == 0) {
				buf_pos += snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "\n");
				pr_info("%s\n", buffer);
			}
		}
		pr_info("######### CQC dbg_print END #######\n");
	} else {
		yib_dbg_info(YUSUR_IB_M_CQ, YUSUR_IB_DBG_QUERY, "######### CQC dbg_print BEGIN #######\n");
		for (i = 0; i < n; i++) {
			if (i % 4 == 0) {
				buf_pos = 0;
				memset(buffer, 0, sizeof(buffer));
				buf_pos = snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%04x:  ", offset);
				offset += 16;
			}
			buf_pos += snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%08x  ", np_hwres_read32(cqc_entry));
			cqc_entry += 4;
			if ((i + 1) % 4 == 0) {
				yib_dbg_info(YUSUR_IB_M_CQ, YUSUR_IB_DBG_QUERY, "%s\n", buffer);
			}
		}
		yib_dbg_info(YUSUR_IB_M_CQ, YUSUR_IB_DBG_QUERY, "######### CQC dbg_print END #######\n");
	}

	return 0;
}

int np_dbg_print_mpt(void *buf, bool bdbg)
{
	int i = 0;
	char buffer[128];
	int buf_pos = 0;
	int offset = 0;
	u8 *mpt_entry = (u8 *)buf;
	int n = sizeof (struct np_hw_mpt_entry) / 4;

	if (bdbg) {
		pr_info("######### MPT dbg_print BEGIN #######\n");
		for (i = 0; i < n; i++) {
			if (i % 4 == 0) {
				buf_pos = 0;
				memset(buffer, 0, sizeof(buffer));
				buf_pos = snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%04x:  ", offset);
				offset += 16;
			}
			buf_pos += snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%08x  ", np_hwres_read32(mpt_entry));
			mpt_entry += 4;
			if ((i + 1) % 4 == 0) {
				buf_pos += snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "\n");
				pr_info("%s\n", buffer);
			}
		}
		pr_info("######### MPT dbg_print END #######\n");
	} else {
		yib_dbg_info(YUSUR_IB_M_MR, YUSUR_IB_DBG_QUERY, "######### MPT dbg_print BEGIN #######\n");
		for (i = 0; i < n; i++) {
			if (i % 4 == 0) {
				buf_pos = 0;
				memset(buffer, 0, sizeof(buffer));
				buf_pos = snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%04x:  ", offset);
				offset += 16;
			}
			buf_pos += snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%08x  ", np_hwres_read32(mpt_entry));
			mpt_entry += 4;
			if ((i + 1) % 4 == 0) {
				yib_dbg_info(YUSUR_IB_M_MR, YUSUR_IB_DBG_QUERY, "%s\n", buffer);
			}
		}
		yib_dbg_info(YUSUR_IB_M_MR, YUSUR_IB_DBG_QUERY, "######### MPT dbg_print END #######\n");
	}

	return 0;
}

void np_debugfs_print_smac(struct yib_hw_host *hw)
{
	struct np_yib_sf *np_sf = hw->sf.sf_priv;
	struct yib_np_resource *hw_res = &np_sf->hw_res;
	struct np_hw_smac_port_entry mac_port;
	int i = 0;
	
	pr_info("######### debugfs smac print BEGIN #######\n");
	for (i = 0; i < 1; i++) {
		np_load_array(hw_res->mac_port_id, i, (void *)&mac_port, sizeof(struct np_hw_smac_port_entry));
		pr_info("smac[%d]: %02x:%02x:%02x:%02x:%02x:%02x\n", i, mac_port.mac[5], 
				mac_port.mac[4], mac_port.mac[3], mac_port.mac[2], mac_port.mac[1], mac_port.mac[0]);	
	}
	pr_info("######### debugfs smac print END #######\n");
}

static int np_dbg_print_sqc(void *buf, bool bdbg)
{
	int i = 0;
	char buffer[128];
	int buf_pos = 0;
	int offset = 0;
	u8 *sqc_entry = (u8 *)buf;
	int n = sizeof (struct np_hw_sqc_entry) / 4;

	if (bdbg) {
		pr_info("######### SQC dbg_print BEGIN #######\n");
		for (i = 0; i < n; i++) {
			if (i % 4 == 0) {
				buf_pos = 0;
				memset(buffer, 0, sizeof(buffer));
				buf_pos = snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%04x:  ", offset);
				offset += 16;
			}
			buf_pos += snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%08x  ", np_hwres_read32(sqc_entry));
			sqc_entry += 4;
			if ((i + 1) % 4 == 0) {
				buf_pos += snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "\n");
				pr_info("%s\n", buffer);
			}
		}
		pr_info("######### SQC dbg_print END #######\n");
	} else {
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_QUERY, "######### SQC dbg_print BEGIN #######\n");
		for (i = 0; i < n; i++) {
			if (i % 4 == 0) {
				buf_pos = 0;
				memset(buffer, 0, sizeof(buffer));
				buf_pos = snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%04x:  ", offset);
				offset += 16;
			}
			buf_pos += snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%08x  ", np_hwres_read32(sqc_entry));
			sqc_entry += 4;
			if ((i + 1) % 4 == 0) {
				yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_QUERY, "%s\n", buffer);
			}
		}
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_QUERY, "######### SQC dbg_print END #######\n");
	}

	return 0;
}

static int np_dbg_print_sqs(void *buf, bool bdbg)
{
	int i = 0;
	char buffer[128];
	int buf_pos = 0;
	int offset = 0;
	u8 *sqs_entry = (u8 *)buf;
	int n = sizeof (struct np_hw_sqs_entry) / 4;

	if (bdbg) {
		pr_info("######### SQS dbg_print BEGIN #######\n");
		for (i = 0; i < n; i++) {
			if (i % 4 == 0) {
				buf_pos = 0;
				memset(buffer, 0, sizeof(buffer));
				buf_pos = snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%04x:  ", offset);
				offset += 16;
			}
			buf_pos += snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%08x  ", np_hwres_read32(sqs_entry));
			sqs_entry += 4;
			if ((i + 1) % 4 == 0) {
				buf_pos += snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "\n");
				pr_info("%s\n", buffer);
			}
		}
		pr_info("######### SQS dbg_print END #######\n");
	} else {
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_QUERY, "######### SQS dbg_print BEGIN #######\n");
		for (i = 0; i < n; i++) {
			if (i % 4 == 0) {
				buf_pos = 0;
				memset(buffer, 0, sizeof(buffer));
				buf_pos = snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%04x:  ", offset);
				offset += 16;
			}
			buf_pos += snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%08x  ", np_hwres_read32(sqs_entry));
			sqs_entry += 4;
			if ((i + 1) % 4 == 0) {
				yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_QUERY, "%s\n", buffer);
			}
		}
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_QUERY, "######### SQS dbg_print END #######\n");
	}

	return 0;
}

static int np_dbg_print_rqc(void *buf, bool bdbg)
{
	int i = 0;
	char buffer[128];
	int buf_pos = 0;
	int offset = 0;
	u8 *rqc_entry = (u8 *)buf;
	int n = sizeof (struct np_hw_rqc_entry) / 4;

	if (bdbg) {
		pr_info("######### RQC dbg_print BEGIN #######\n");
		for (i = 0; i < n; i++) {
			if (i % 4 == 0) {
				buf_pos = 0;
				memset(buffer, 0, sizeof(buffer));
				buf_pos = snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%04x:  ", offset);
				offset += 16;
			}
			buf_pos += snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%08x  ", np_hwres_read32(rqc_entry));
			rqc_entry += 4;
			if ((i + 1) % 4 == 0) {
				buf_pos += snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "\n");
				pr_info("%s\n", buffer);
			}
		}
		pr_info("######### RQC dbg_print END #######\n");
	} else {
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_QUERY, "######### RQC dbg_print BEGIN #######\n");
		for (i = 0; i < n; i++) {
			if (i % 4 == 0) {
				buf_pos = 0;
				memset(buffer, 0, sizeof(buffer));
				buf_pos = snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%04x:  ", offset);
				offset += 16;
			}
			buf_pos += snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%08x  ", np_hwres_read32(rqc_entry));
			rqc_entry += 4;
			if ((i + 1) % 4 == 0) {
				yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_QUERY, "%s\n", buffer);
			}
		}
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_QUERY, "######### RQC dbg_print END #######\n");
	}

	return 0;
}

static int np_dbg_print_rqs(void *buf, bool bdbg)
{
	int i = 0;
	char buffer[128];
	int buf_pos = 0;
	int offset = 0;
	u8 *rqs_entry = (u8 *)buf;
	int n = sizeof (struct np_hw_rqs_entry) / 4;

	if (bdbg) {
		pr_info("######### RQS dbg_print BEGIN #######\n");
		for (i = 0; i < n; i++) {
			if (i % 4 == 0) {
				buf_pos = 0;
				memset(buffer, 0, sizeof(buffer));
				buf_pos = snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%04x:  ", offset);
				offset += 16;
			}
			buf_pos += snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%08x  ", np_hwres_read32(rqs_entry));
			rqs_entry += 4;
			if ((i + 1) % 4 == 0) {
				buf_pos += snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "\n");
				pr_info("%s\n", buffer);
			}
		}
		pr_info("######### RQS dbg_print END #######\n");
	} else {
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_QUERY, "######### RQS dbg_print BEGIN #######\n");
		for (i = 0; i < n; i++) {
			if (i % 4 == 0) {
				buf_pos = 0;
				memset(buffer, 0, sizeof(buffer));
				buf_pos = snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%04x:  ", offset);
				offset += 16;
			}
			buf_pos += snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%08x  ", np_hwres_read32(rqs_entry));
			rqs_entry += 4;
			if ((i + 1) % 4 == 0) {
				yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_QUERY, "%s\n", buffer);
			}
		}
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_QUERY, "######### RQS dbg_print END #######\n");
	}

	return 0;
}

static int np_dbg_print_qp_state(void *buf, bool bdbg)
{
	int i = 0;
	char buffer[128];
	int buf_pos = 0;
	int offset = 0;
	u8 *qp_state_entry = (u8 *)buf;
	int n = sizeof (struct np_hw_qp_state_entry) / 4;

	if (bdbg) {
		pr_info("######### QP STATE dbg_print BEGIN #######\n");
		for (i = 0; i < n; i++) {
			if (i % 4 == 0) {
				buf_pos = 0;
				memset(buffer, 0, sizeof(buffer));
				buf_pos = snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%04x:  ", offset);
				offset += 16;
			}
			buf_pos += snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%08x  ", np_hwres_read32(qp_state_entry));
			qp_state_entry += 4;
			if ((i + 1) % 4 == 0) {
				buf_pos += snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "\n");
				pr_info("%s\n", buffer);
			}
		}
		pr_info("######### QP STATE dbg_print END #######\n");
	} else {
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_QUERY, "######### QP STATE dbg_print BEGIN #######\n");
		for (i = 0; i < n; i++) {
			if (i % 4 == 0) {
				buf_pos = 0;
				memset(buffer, 0, sizeof(buffer));
				buf_pos = snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%04x:  ", offset);
				offset += 16;
			}
			buf_pos += snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%08x  ", np_hwres_read32(qp_state_entry));
			qp_state_entry += 4;
			if ((i + 1) % 4 == 0) {
				yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_QUERY, "%s\n", buffer);
			}
		}
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_QUERY, "######### QP STATE dbg_print END #######\n");
	}

	return 0;
}

static u32 index_to_cluster(u32 index)
{
	return index/YIB_MAX_QID_PER_CLU;
}

static u32 index_to_qid(u32 index)
{
	return index%YIB_MAX_QID_PER_CLU;
}

int np_dbg_print_qpc(struct yib_sf *sf, struct yib_qp *yqp, bool bdbg)
{
	struct np_yib_sf *np_sf = sf->sf_priv;
	struct yib_np_resource *hw_res = &np_sf->hw_res;
	struct np_qp_priv *priv = (struct np_qp_priv *)yqp->privdata;
	struct np_hw_sqc_entry sqc_entry;
	struct np_hw_sqs_entry sqs_entry;
	struct np_hw_rqs_entry rqs_entry;
	struct np_hw_rqc_entry rqc_entry;
	struct np_hw_qp_state_entry qp_state;
        u32 cid, qid;
	int ret = 0;
	
	cid = index_to_cluster(priv->index);
	qid = index_to_qid(priv->index);

	ret |= np_load_array(hw_res->np_qp_tbl[cid].sqc_id, qid, &sqc_entry, sizeof(struct np_hw_sqc_entry));
	ret |= np_load_array(hw_res->np_qp_tbl[cid].sqs_id, qid, &sqs_entry, sizeof(struct np_hw_sqs_entry));
	ret |= np_load_array(hw_res->np_qp_tbl[cid].rqs_id, qid, &rqs_entry, sizeof(struct np_hw_rqs_entry));
	ret |= np_load_array(hw_res->np_qp_tbl[cid].rqc_id, qid, &rqc_entry, sizeof(struct np_hw_rqc_entry));
	ret |= np_load_array(hw_res->qp_state_id, priv->index, &qp_state, sizeof(struct np_hw_qp_state_entry));
	if(ret){
		os_printe(sf->hw->dev, "print qpc load arraytbl failed");
		return ret;	
	}
	
	if (np_dbg_print_sqc(&sqc_entry, bdbg))
		goto err;
	if (np_dbg_print_sqs(&sqs_entry,  bdbg))
		goto err;
	if (np_dbg_print_rqc(&rqc_entry, bdbg))
		goto err;
	if (np_dbg_print_rqs(&rqs_entry, bdbg))
		goto err;
	if (np_dbg_print_qp_state(&qp_state, bdbg))
		goto err;

	return 0;
err:
	return -EMSGSIZE;
}


