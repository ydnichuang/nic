#ifndef _YUSUR_IB_NP_DBG_H_
#define _YUSUR_IB_NP_DBG_H_


int np_dbg_print_cqc(void *buf, bool bdbg);
int np_dbg_print_mpt(void *buf, bool bdbg);
void np_debugfs_print_smac(struct yib_hw_host *hw);
int np_dbg_print_qpc(struct yib_sf *sf, struct yib_qp *yqp, bool bdbg);

#endif


