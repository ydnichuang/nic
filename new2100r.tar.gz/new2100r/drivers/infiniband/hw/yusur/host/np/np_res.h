/*
 * @Descripttion: Copyright(c) All rights reserved.
 * @version: 
 * @Author: wangyingfu
 * @Date: 2024-05-22 15:28:45
 * @LastEditors: wangyingfu
 * @LastEditTime: 2024-05-22 17:42:27
 */
#ifndef _YUSUR_IB_NP_RES_H_
#define _YUSUR_IB_NP_RES_H_

#define MIN_REQUESTER_ID            4
#define MAX_REQUESTER_ID            8
#define MIN_RESPONSER_ID            9
#define MAX_RESPONSER_ID            13

#define YIB_NP_MAC_PORT_BYTES		8
#define YIB_NP_MAC_PORT_DEPTH		32
#define YIB_NP_MAC_PORT_ID		0
#define YIB_NP_MAC_PORT_L1_TAG          1
#define YIB_NP_MAC_PORT_L2_TAG          1

#define YIB_NP_QP_REMAP_BYTES		4
#define YIB_NP_QP_REMAP_DEPTH		64
#define YIB_NP_QP_REMAP_ID		1
#define YIB_NP_QP_REMAP_L1_TAG          1
#define YIB_NP_QP_REMAP_L2_TAG          8

#define YIB_NP_QP_STATE_BYTES		4
#define YIB_NP_QP_STATE_DEPTH		64
#define YIB_NP_QP_STATE_ID		3
#define YIB_NP_QP_STATE_L1_TAG          1
#define YIB_NP_QP_STATE_L2_TAG          16

#define YIB_NP_SQC_BYTES_ENTRY		128
#define YIB_NP_SQC_TABLE_DEPTH		8
#define YIB_NP_SQC_CLU4_ID		    4
#define YIB_NP_SQC_CLU5_ID		    5
#define YIB_NP_SQC_CLU6_ID		    6
#define YIB_NP_SQC_CLU7_ID		    7
#define YIB_NP_SQC_CLU8_ID		    8
#define YIB_NP_SQC_L1_TAG           1

#define YIB_NP_RQC_BYTES_ENTRY		128
#define YIB_NP_RQC_TABLE_DEPTH		8
#define YIB_NP_RQC_CLU9_ID		    9
#define YIB_NP_RQC_CLU10_ID		    10
#define YIB_NP_RQC_CLU11_ID		    11
#define YIB_NP_RQC_CLU12_ID		    12
#define YIB_NP_RQC_CLU13_ID		    13
#define YIB_NP_RQC_L1_TAG           1

#define YIB_NP_SQ_STATUS_BYTES		64
#define YIB_NP_SQ_STATUS_DEPTH		8
#define YIB_NP_SQS_CLU4_ID		14
#define YIB_NP_SQS_CLU5_ID		15
#define YIB_NP_SQS_CLU6_ID		16
#define YIB_NP_SQS_CLU7_ID		17
#define YIB_NP_SQS_CLU8_ID		18
#define YIB_NP_SQS_L1_TAG           	1

#define YIB_NP_RQ_STATUS_BYTES		64
#define YIB_NP_RQ_STATUS_DEPTH		8
#define YIB_NP_RQS_CLU9_ID		19
#define YIB_NP_RQS_CLU10_ID		20
#define YIB_NP_RQS_CLU11_ID		21
#define YIB_NP_RQS_CLU12_ID		22
#define YIB_NP_RQS_CLU13_ID		23
#define YIB_NP_RQS_L1_TAG           	1

#define YIB_NP_SQE_RTIME_BYTES		64
#define YIB_NP_SQE_RTIME_DEPTH		256
#define YIB_NP_SQE_CLU4_ID		24
#define YIB_NP_SQE_CLU5_ID		25
#define YIB_NP_SQE_CLU6_ID		26
#define YIB_NP_SQE_CLU7_ID		27
#define YIB_NP_SQE_CLU8_ID		28
#define YIB_NP_SQE_L1_TAG           	16

#define YIB_NP_RQE_RTIME_BYTES		32
#define YIB_NP_RQE_RTIME_DEPTH		256
#define YIB_NP_RQE_CLU9_ID		29
#define YIB_NP_RQE_CLU10_ID		30
#define YIB_NP_RQE_CLU11_ID		31
#define YIB_NP_RQE_CLU12_ID		32
#define YIB_NP_RQE_CLU13_ID		33
#define YIB_NP_RQE_L1_TAG           	8

#define YIB_NP_RMSG_RTIME_BYTES		64
#define YIB_NP_RMSG_RTIME_DEPTH		256
#define YIB_NP_RMSG_CLU9_ID		39
#define YIB_NP_RMSG_CLU10_ID		40
#define YIB_NP_RMSG_CLU11_ID		41
#define YIB_NP_RMSG_CLU12_ID		42
#define YIB_NP_RMSG_CLU13_ID		43
#define YIB_NP_RMSG_L1_TAG          	16

#define YIB_NP_MPT_BYTES_ENTRY		32
#define YIB_NP_MPT_DEPTH		1024
#define YIB_NP_MPT_ID               50
#define YIB_NP_MPT_L1_TAG           2
#define YIB_NP_MPT_L2_TAG           64

#define YIB_NP_MTT_BYTES_ENTRY		64
#define YIB_NP_MTT_DEPTH		    65536
#define YIB_NP_MTT_ID               51
#define YIB_NP_MTT_L1_TAG           1
#define YIB_NP_MTT_L2_TAG           128

#define YIB_NP_AVT_BYTES_ENTRY		64
#define YIB_NP_AVT_DEPTH		1024
#define YIB_NP_AVT_ID               52
#define YIB_NP_AVT_L1_TAG           1
#define YIB_NP_AVT_L2_TAG           128

#define YIB_NP_CQC_BYTES_ENTRY		32
#define YIB_NP_CQC_DEPTH		128
#define YIB_NP_CQC_ID               60
#define YIB_NP_CQC_L1_TAG           16

#define YIB_NP_NQC_BYTES_ENTRY		32
#define YIB_NP_NQC_DEPTH		1
#define YIB_NP_NQC_ID               61
#define YIB_NP_NQC_L1_TAG           1

enum np_clu_type
{
	NP_TYPE_CLU0,
	NP_TYPE_CLU1,
    	NP_TYPE_CLU2,
	NP_TYPE_CLU3,
	NP_TYPE_CLU4,
	NP_TYPE_CLU5,
    	NP_TYPE_CLU6,
	NP_TYPE_CLU7,
	NP_TYPE_CLU8,
	NP_TYPE_CLU9,
    	NP_TYPE_CLU10,
	NP_TYPE_CLU11,
	NP_TYPE_CLU12,
	NP_TYPE_CLU13,
    	NP_TYPE_CLU14,
	NP_TYPE_CLU15,
};

enum np_hwres_type
{
	NP_TYPE_MAC_PORT,
	NP_TYPE_QP_REMAP,
	NP_TYPE_QP_STATE,
	NP_TYPE_SQC_CLU4,
	NP_TYPE_SQC_CLU5,
    	NP_TYPE_SQC_CLU6,
    	NP_TYPE_SQC_CLU7,
    	NP_TYPE_SQC_CLU8,
	NP_TYPE_RQC_CLU9,
    	NP_TYPE_RQC_CLU10,
    	NP_TYPE_RQC_CLU11,
    	NP_TYPE_RQC_CLU12,
    	NP_TYPE_RQC_CLU13,
    	NP_TYPE_SQS_CLU4,
	NP_TYPE_SQS_CLU5,
    	NP_TYPE_SQS_CLU6,
   	NP_TYPE_SQS_CLU7,
    	NP_TYPE_SQS_CLU8,
	NP_TYPE_RQS_CLU9,
    	NP_TYPE_RQS_CLU10,
    	NP_TYPE_RQS_CLU11,
    	NP_TYPE_RQS_CLU12,
    	NP_TYPE_RQS_CLU13,
    	NP_TYPE_SQE_CLU4,
	NP_TYPE_SQE_CLU5,
    	NP_TYPE_SQE_CLU6,
    	NP_TYPE_SQE_CLU7,
    	NP_TYPE_SQE_CLU8,
	NP_TYPE_RQE_CLU9,
    	NP_TYPE_RQE_CLU10,
    	NP_TYPE_RQE_CLU11,
    	NP_TYPE_RQE_CLU12,
    	NP_TYPE_RQE_CLU13,
	NP_TYPE_RMSG_CLU9,
    	NP_TYPE_RMSG_CLU10,
    	NP_TYPE_RMSG_CLU11,
    	NP_TYPE_RMSG_CLU12,
    	NP_TYPE_RMSG_CLU13,
    	NP_TYPE_MPT,
    	NP_TYPE_MTT,
    	NP_TYPE_AVT,
	NP_TYPE_CQC,
	NP_TYPE_NQC,
    	NP_TYPE_RES_MAX,
};

struct np_res_create_param
{
    u8      table_id;
    u8      entry_len;
    u32     depth;
    struct hw_advance_cfg cfg;
};


int np_hw_res_init(struct yib_sf *sf, struct yib_np_resource *hw_res);
void np_hw_res_exit(struct yib_sf *sf, struct yib_np_resource *hw_res);


#endif
