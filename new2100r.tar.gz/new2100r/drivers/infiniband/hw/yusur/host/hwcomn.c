#include "../include/basic.h"
#include "../include/os_api.h"
#include "../include/os_ds.h"
#include "../include/mem.h"
#include "../include/queue.h"
#include "../include/host.h"
#include "../include/verbs.h"
#include "hostpriv.h"
#include "hwcomn.h"


inline u32 net_addr2_le32(u8 * dat)
{
	return (dat[0] << 24 | dat[1] << 16 | dat[2] << 8 | dat[3]);
}

void hwcomn_config_ip(struct yib_hw_host *hw, u64 base, bool ipv6, bool src, struct yib_av * yav)
{
	u32 val = 0;
	struct yib_sf *sf = &hw->sf;

	if (!ipv6) {
		u8 *addrv4 = src? (u8*)&yav->sgid_addr._sockaddr_in.sin_addr.s_addr:
				  (u8*)&yav->dgid_addr._sockaddr_in.sin_addr.s_addr;
		yib_write_regl(sf, base, net_addr2_le32(addrv4)); //我们寄存器填小端
	} else {
		u32 i;
		u8 * dat = src? (u8*)&yav->sgid_addr._sockaddr_in6.sin6_addr.s6_addr:
				(u8*)&yav->dgid_addr._sockaddr_in6.sin6_addr.s6_addr;

		for (i = 0; i < 4; i++) {
			val = net_addr2_le32(dat + 4 * (3 - i));
			yib_write_regl(sf, base + i * 4, val);
		}
	}
}

//mac为网络字节序
void hwcomn_config_mac(struct yib_hw_host *hw, u64 base, u8 *mac)
{
	u32 val;
	struct yib_sf *sf = &hw->sf;

	val = mac[5] | (mac[4] << 8) |
		(mac[3] << 16) | (mac[2] << 24);

	yib_write_regl(sf, base, val);

  	os_wmb();
  	val =  mac[1] | (mac[0] << 8);
	yib_write_regl(sf, base + 4, val);
}

u64 hwcomn_get_base_phy_addr(struct yib_hw_host *hw)
{
#if 0 //new_new todo
	return os_get_pci_bar_start(hw->sf->pdev, hw->sf->hw_reg_idx)  + hw->sf->hw_base_off;
#else
	return 0;
#endif
}

u64 hwcomn_get_ddr_phy_addr(struct yib_hw_host *hw)
{
#if 0 //new_new todo
	return os_get_pci_bar_start(hw->sf->pdev, hw->sf->hw_ddr_idx)  + hw->sf->hw_ddr_off;
#else
	return 0;
#endif
}

#define DDR_ACCESS_ADDR_REG	0x2c0
#define DDR_ACCESS_WDATA_REG	0x2c4
#define DDR_ACCESS_CTRL_REG	0x2c8
#define DDR_ACCESS_STAT_REG	0x2cc
#define DDR_ACCESS_RDATA_REG	0x2d0

//use this function must acquire sf->ddr_lock
u32 hwcomn_ddr_readl(struct yib_sf *sf, u64 base) //This function can't used in interrupt
{
	u32 val = 0;

	yib_write_regl(sf, DDR_ACCESS_ADDR_REG, (base >> 2));
	yib_write_regl(sf, DDR_ACCESS_CTRL_REG, 2);
	while ((yib_read_regl(sf, DDR_ACCESS_STAT_REG) & BIT(0)) == 0);
	val = yib_read_regl(sf, DDR_ACCESS_RDATA_REG);
	return val;
}

//use this function must acquire sf->ddr_lock
void hwcomn_ddr_writel(struct yib_sf *sf, u64 base ,u32 value)
{

	yib_write_regl(sf, DDR_ACCESS_ADDR_REG, (base >> 2));
	yib_write_regl(sf, DDR_ACCESS_WDATA_REG, value);
	yib_write_regl(sf, DDR_ACCESS_CTRL_REG, 1);
	while ((yib_read_regl(sf, DDR_ACCESS_STAT_REG) & BIT(0)) == 0);
}

void hwvf_config_mac(struct yib_hw_host *hw, u64 base, u8 *mac)
{
	u32 val;
	struct yib_sf *sf = &hw->sf;

	val = mac[0] | (mac[1] << 8) | 
		(mac[2] << 16) | (mac[3] << 24);
	yib_write_regl(sf, base, val);

	os_wmb();
	val = mac[4] | (mac[5] << 8) | (hw->vf_id << 16);
	yib_write_regl(sf, base + 0x10, val);
	os_wmb();
}

void yib_aquire_hw_lock(struct yib_sf *sf, yib_gbl_lock_t type)
{
#if 0 //new_new todo
	host_verbs_t *verbs = (host_verbs_t *)sf->ds;
	if (verbs->sf_ops->host_type == YRDMA_TYPE_SWTEST)
		return;
	//newtodo
#endif
}

void yib_release_hw_lock(struct yib_sf *sf, yib_gbl_lock_t type)
{
#if 0 //new_new todo
	host_verbs_t *verbs = (host_verbs_t *)sf->ds;
	if (verbs->sf_ops->host_type == YRDMA_TYPE_SWTEST)
		return;
	//newtodo
#endif
}

u8* hwcomn_get_bar_bitmap_base(struct yib_sf *sf)
{
#if 0 //new_new todo
	return sf->reg_base + YIB_BAR_BITMAP_BASE;
#else
	return 0;
#endif
}

u64 hwcomn_get_ddr_bitmap_base(struct yib_hw_host *hw)
{
	u32 each = YIB_MAX_DDR_RESOURCES / 8;
	u32 index = hw->host_id * YIB_MAX_HOST_CNT * YIB_MAX_HOST_PF * YIB_MAX_PF_VF
				+ hw->pf_id * YIB_MAX_HOST_PF * YIB_MAX_PF_VF
				+ hw->vf_id * YIB_MAX_PF_VF;
	return index * each + YIB_DDR_BITMAP_BASE;
}