#include "../include/basic.h"
#include "../include/os_api.h"
#include "../include/os_ds.h"
#include "../include/mem.h"
#include "../include/queue.h"
#include "../include/host.h"
#include "../include/verbs.h"
#include "../include/yusur_ib.h"
#include "../include/user.h"
#include "hostpriv.h"
#include "hwcomn.h"

#define YIB_SWTEST_BAR_SIZE (1024*1024)
#define YIB_EQ_ISIZE	64
#define YIB_AEQ_ISIZE	128

#if (COUNTER_STAT_DESC)
static const struct rdma_stat_desc swtest_counter_name[] = {
	[YIB_CNT_LINK_DOWN].name      	=  "link_downed",
};
#else
static const char * const swtest_counter_name[] = {
	[YIB_CNT_LINK_DOWN]      =  "link_downed",
};
#endif

enum swtest_hw_mr_type {
	SWTEST_HW_MR_NORMAL,
	SWTEST_HW_MR_PMR,
	SWTEST_HW_MR_MW_TYPE1,
	SWTEST_HW_MR_MW_TYPE2A,
	SWTEST_HW_MR_FMR,
	SWTEST_HW_MR_GLOBAL_KEY,
};

typedef struct
{
	os_cdma_t bar;
}swtest_priv_t;

typedef struct
{
	void *priv;
}swtest_sf_priv_t;

typedef struct
{
	struct yib_queue_mem *queue;
}swtest_eq_priv_t;

#define SWTEST_SMAC_ISIZE 8

static int swtest_sf_pre_init(struct yib_sf *sf)
{
	sf->reg_base[0] = sf->hw->reg_base[0];
	sf->bar_size[0] = YIB_SWTEST_BAR_SIZE;
	return 0;
}

static int swtest_sf_init(struct yib_sf *sf, bool b_del)
{
	return 0;
}

static int swtest_start_sf(struct yib_sf *sf)
{
	return 0;
}

static void swtest_stop_sf(struct yib_sf *sf, bool is_shutdown)
{
	return;
}

static void swtest_add_mac(struct yib_sf *sf, u8 *mac, int index, u8 port_num)
{

}

static void swtest_modify_mac(struct yib_sf *sf, u8 *mac, int index, u8 port_num, bool bdel)
{

}

static void swtest_set_gid(struct yib_sf *sf, bool brocev2, bool bipv4, int index, u8 *raw, bool bdel)
{
	yib_pr_info(YUSUR_IB_DBG_INIT, "%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x",
		raw[0], raw[1], raw[2], raw[3], raw[4], raw[5], raw[6], raw[7], raw[8],
		raw[9], raw[10], raw[11], raw[12], raw[13], raw[14], raw[15]);
}

static void swtest_init_av(struct yib_sf *sf, struct yib_av *av, int index, bool b_del)
{
}

static int swtest_mrw_alloc(struct yib_sf *sf, struct yib_mr *mr, u32 *lkey, u32 *rkey)
{
	struct yib_page_tbl *mtt_tbl = NULL;

	if (!mr->type.is_dma && !mr->type.is_fast && !mr->type.is_mw) {
		mtt_tbl = kzalloc(sizeof(struct yib_page_tbl), GFP_KERNEL);
		if (mtt_tbl == NULL) {
			os_printe(sf->hw->dev, "alloc mr page_tbl failed");
			return -ENOMEM;
		}
		mr->priv.page_tbl = (void *)mtt_tbl;
	}

	yib_mr_helper_get_key(mr->entry.index, lkey, rkey);
	return 0;
}

static void swtest_mrw_destroy(struct yib_sf *sf, struct yib_mr *mr)
{
	struct yib_page_tbl *mtt_tbl = NULL;

	if (mr->type.is_dma) {
		return;
	} else if (mr->type.is_fast) {
		return;
	} else if (mr->type.is_mw) {
		return;
	} else {
		mtt_tbl = (struct yib_page_tbl *)mr->priv.page_tbl;
		if (mtt_tbl) {
			yib_destroy_page_table(sf, mtt_tbl);
			kfree(mtt_tbl);
		}
		mr->priv.page_tbl = NULL;
	}
}

static int swtest_mr_mtt_init(struct yib_sf *sf, struct yib_mr *mr, struct scatterlist *sg,
				int npages, u32 page_size, u64 pa0)
{
	struct yib_page_tbl *mtt_tbl = (struct yib_page_tbl *)mr->priv.page_tbl;
	u32 pa0_lsb;
	u32 pa0_msb;
	u32 pa1_lsb;
	u32 pa1_msb;
	u64 pa1;
	int ret = 0;
	bool l2_tbl_supp = (sf->hw->funcs.mr_l2_tbl == 0)? false : true;

	ret = yib_create_page_table_by_sg(sf, mtt_tbl, sg, npages, page_size, l2_tbl_supp);
	if (ret) {
		kfree(mtt_tbl);
		os_printe(sf->hw->dev, "create mr page_tbl failed");
		return -ENOMEM;
	}

	pa0_lsb = u64_lsb(pa0);
	pa0_msb = u64_msb(pa0);
	if (mtt_tbl->levels == 0)
		pa1 = 0;
	else
		pa1 = yib_mem_get_pa(mtt_tbl, 1);

	pa1_lsb = u64_lsb(pa1);
	pa1_msb = u64_msb(pa1);

	yib_pr_info(YUSUR_IB_DBG_CREATE, "mr tbl levels: %d, page_size: %d, root_pa: 0x%08X, pbl_page_size: %d\n",
				mtt_tbl->levels, mtt_tbl->pg_size, mtt_tbl->root_pa, mtt_tbl->pbl_pg_size);

	yib_pr_info(YUSUR_IB_DBG_CREATE, "pa0_lsb: 0x%08X, pa0_msb: 0x%08X, pa1_lsb: 0x%08X, pa1_msb: 0x%08X\n",
				pa0_lsb, pa0_msb, pa1_lsb, pa1_msb);

	return 0;
}

static int swtest_mr_mpt_update(struct yib_sf *sf, struct yib_mr *ymr)
{
	enum swtest_hw_mr_type mr_type;
	int tbl_levels = 0;
	int mr_state = 0;
	int mr_pdn = 0;
	int mr_access = 0;
	u64 mr_size = 0;
	int mr_pbl_size = 0;
	int mr_page_size = 0;
	u32 pbl_pa_lsb = 0;
	u32 pbl_pa_msb = 0;
	u32 va_lsb = 0;
	u32 va_msb = 0;
	struct yib_page_tbl *tbl;

	mr_state = ymr->state;
	mr_pdn = ymr->pd_num;
	mr_access = ymr->access;

	if (ymr->type.is_fast) {
		mr_type = SWTEST_HW_MR_FMR;
		tbl_levels = 1;
		mr_size = yib_os_mr_length(ymr);
		mr_pbl_size = ymr->priv.fmr->desc_size * ymr->priv.fmr->max_descs;
		mr_page_size = PAGE_SIZE;
		pbl_pa_lsb = u64_lsb(ymr->priv.fmr->desc_map);
		pbl_pa_msb = u64_msb(ymr->priv.fmr->desc_map);
	} else if (ymr->type.is_dma) {
		mr_type = SWTEST_HW_MR_PMR;
		tbl_levels = 0;
		mr_size = yib_os_mr_length(ymr);
	} else if (ymr->type.is_mw) {
		mr_type = SWTEST_HW_MR_MW_TYPE1;
	} else {
		tbl = (struct yib_page_tbl *)ymr->priv.page_tbl;
		mr_type = SWTEST_HW_MR_NORMAL;
		tbl_levels = tbl->levels;
		mr_size = yib_os_mr_length(ymr);
		mr_pbl_size = tbl->pbl_pg_size;
		mr_page_size = tbl->pg_size;
		pbl_pa_lsb = u64_lsb(tbl->root_pa);
		pbl_pa_msb = u64_msb(tbl->root_pa);
		va_lsb = u64_lsb(yib_os_mr_iova(ymr));
		va_msb = u64_msb(yib_os_mr_iova(ymr));
	}

	yib_pr_info(YUSUR_IB_DBG_INIT, "mr type: %d, tbl_levels: %d, state: %d, pdn: %d, access: %d, size: %lld\n",
			mr_type, tbl_levels, mr_state, mr_pdn, mr_access, mr_size);

	yib_pr_info(YUSUR_IB_DBG_INIT, "mr pbl_size: %d, page_size: %d, pb1_pa_lsb: 0x%08X, pbl_pa_msb: 0x%08X, va_lsb: %d, va_msb: %d\n",
			mr_pbl_size, mr_page_size, pbl_pa_lsb, pbl_pa_msb, va_lsb, va_msb);
	return 0;
}

static int swtest_mr_debugfs(struct yib_sf *sf, struct yib_mr *mr)
{
	return 0;
}

static int swtest_cq_info_init(struct yib_sf *sf, struct yib_cq *cq, bool enable)
{
	int tbl_levels = 0;
	u64 cq_size = 0;
	int cq_pbl_size = 0;
	int cq_page_size = 0;
	u32 pbl_pa_lsb = 0;
	u32 pbl_pa_msb = 0;

	tbl_levels = cq->queue->tbl.levels;
	cq_size = cq->queue->depth;
	cq_page_size = cq->queue->tbl.pg_size;
	cq_pbl_size = cq->queue->tbl.pbl_pg_size;
	pbl_pa_lsb = u64_lsb(cq->queue->tbl.root_pa);
	pbl_pa_msb = u64_msb(cq->queue->tbl.root_pa);

	if (enable == false) {
		yib_pr_info(YUSUR_IB_DBG_INIT, "disable cq:%d\n", cq->entry.index);
	} else {
		yib_pr_info(YUSUR_IB_DBG_INIT, "enable cq:%d\n", cq->entry.index);
	}

	yib_pr_info(YUSUR_IB_DBG_INIT, "cq tbl_levels: %d, cq_depth: %d, pbl_size: %d, page_size: %d, pb1_pa_lsb: 0x%08X, pbl_pa_msb: 0x%08X\n",
			tbl_levels, cq_size, cq_pbl_size, cq_page_size, pbl_pa_lsb, pbl_pa_msb);

	return 0;
}

static void swtest_cq_notify_update(struct yib_sf *sf, struct yib_cq *cq, u32 solicited_only)
{
	yib_pr_info(YUSUR_IB_DBG_CHANGE, "notify cq:%d flag=%08x\n", cq->entry.index, solicited_only);
}

static int swtest_cq_debugfs(struct yib_sf *sf, struct yib_cq *ycq)
{
	return 0;
}
static int swtest_qp_info_init(struct yib_sf *sf, struct yib_qp *yqp, bool enable)
{
	if (enable) {
		yib_pr_info(YUSUR_IB_DBG_INIT, "qp:%d enable\n", yqp->entry.index);
		if (yqp->use_srq) {
			if (yqp->type.ysrq) {
				yib_pr_info(YUSUR_IB_DBG_INIT, "normal srq enable case");
			}
		}
		if (yqp->qp_type == IB_QPT_XRC_TGT)
			yib_pr_info(YUSUR_IB_DBG_INIT, "qp xrcdval=%d\n", yqp->type.xrcd_val);
	} else {
		yib_pr_info(YUSUR_IB_DBG_UINIT, "qp:%d disable\n", yqp->entry.index);
		if (yqp->use_srq) {
			if (yqp->type.ysrq) {
				yib_pr_info(YUSUR_IB_DBG_UINIT, "normal srq disable case");
			}
		}
	}
	return 0;
}

static bool swtest_qp_info_update(struct yib_sf *sf, struct yib_qp *qp, u32 mask, bool state_chg)
{
	if (mask & IB_QP_PKEY_INDEX) {
		yib_pr_info(YUSUR_IB_DBG_CHANGE, "qp:%d pkey[%d]=%04X\n", qp->entry.index, qp->attr.pkey_index, g_yib_pkey_table[qp->attr.pkey_index]);
	}

	if (mask & IB_QP_PATH_MTU) {
		yib_pr_info(YUSUR_IB_DBG_CHANGE, "qp:%d path_mtu=%d\n", qp->entry.index, qp->attr.path_mtu);
	}

	if (mask & IB_QP_TIMEOUT) {
		yib_pr_info(YUSUR_IB_DBG_CHANGE, "qp:%d timeout=%d\n", qp->entry.index, qp->attr.timeout);
	}

	if (mask & IB_QP_RETRY_CNT) {
		yib_pr_info(YUSUR_IB_DBG_CHANGE, "qp:%d retrycnt=%d\n", qp->entry.index, qp->attr.retry_cnt);
	}

	if (mask & IB_QP_RNR_RETRY) {
		yib_pr_info(YUSUR_IB_DBG_CHANGE, "qp:%d rnr_retry:%d\n", qp->entry.index, qp->attr.rnr_retry);
	}

	if (mask & IB_QP_RQ_PSN) {
		yib_pr_info(YUSUR_IB_DBG_CHANGE, "qp:%d rq_psn=%d\n", qp->entry.index, qp->attr.rq_psn);
	}

	if (mask & IB_QP_MIN_RNR_TIMER) {
		yib_pr_info(YUSUR_IB_DBG_CHANGE, "qp:%d min_rnr_timer=%d\n", qp->entry.index, qp->attr.min_rnr_timer);
	}

	if (mask & IB_QP_SQ_PSN) {
		yib_pr_info(YUSUR_IB_DBG_CHANGE, "qp:%d sq_psn=%d\n", qp->entry.index, qp->attr.sq_psn);
	}

	if (mask & IB_QP_DEST_QPN) {
		yib_pr_info(YUSUR_IB_DBG_CHANGE, "qp:%d dest_qpn=%d\n", qp->entry.index, qp->attr.dest_qp_num);
	}

	if (mask & IB_QP_AV) {
		u8 smac[6];
		struct yib_av *av = &qp->pri_av;

		yib_pr_info(YUSUR_IB_DBG_CHANGE, "qp:%d set av\n", qp->entry.index);
		yib_ah_print(av);
		os_get_netdev_mac(sf->hw->ndev_info[av->port_num - 1].netdev, smac);
		yib_ah_print_mac("smac:", smac);
	}

	if (state_chg) {
		yib_pr_info(YUSUR_IB_DBG_CHANGE, "qp:%d state change to %d\n", qp->entry.index, qp->attr.qp_state);
	}
	return true;
}

static int swtest_qp_query(struct yib_sf *sf, struct yib_qp *qp, os_qp_attr *attr, int mask, bool bdebug)
{
	attr->rq_psn = 0;
	attr->rq_psn = 0;
	return 0;
}

static int swtest_qp_debugfs(struct yib_sf *sf, struct yib_qp *qp)
{
	return 0;
}

static int swtest_rq_info_init(struct yib_sf *sf, struct yib_rq *yrq, bool enable, bool bsrq)
{
	if (enable) {
		yib_pr_info(YUSUR_IB_DBG_INIT, "enable rq:%d \n", yrq->entry.index);
	} else
		yib_pr_info(YUSUR_IB_DBG_INIT, "disable rq:%d n", yrq->entry.index);
	return 0;
}
static int swtest_srq_debugfs(struct yib_sf *sf, struct yib_srq *ysrq)
{
	return 0;
}

static int swtest_eq_debugfs(struct yib_sf *sf, struct yib_eq *yeq)
{
	return 0;
}

static void swtest_sf_debugfs(struct yib_sf *sf)
{
	return;
}

static int swtest_uio_post_send(struct yib_hw_host *hw, struct yib_qp *qp, const void* os_wr, bool db_only)
{
	int err = 0;
	u32 mask = 0;
	u32 length = 0;
	int io_cnt = 0;
	const os_ib_send_wr *wr = os_wr;

	while (wr) {
		length = 0;
		err = yib_send_wr_check(hw, qp, wr, &mask, &length);
		if (err) {
			qp->ysq.queue->info->direct_cnt++;
			goto exit;
		}

		//fill wqe

		qp->ysq.queue->info->io_count++;
		io_cnt++;
		wr = wr->next;
	}

	if (err) {
		qp->ysq.queue->info->err_count++;
	}
exit:
	return err;
}

static int swtest_uio_post_recv(struct yib_hw_host *hw, struct yib_rq *rq, const void* os_wr, bool db_only)
{
	const os_ib_recv_wr *wr = os_wr;
	int err = 0;
	int io_cnt = 0;

	while (wr) {
		err = yib_recv_wr_check(hw, rq, wr);
		if (err) {
			rq->queue->info->direct_cnt++;
			goto exit;
		}

		//fill wqe

		rq->queue->info->io_count++;
		io_cnt++;
		wr = wr->next;
	}

	if (err) {
		rq->queue->info->err_count++;
	}
exit:
	return err;
}

static int swtest_uio_poll_cq(struct yib_hw_host *hw, struct yib_cq *cq, int num, void *wc, bool db_only)
{
	return 0;
}

static int swtest_fill_rqe(struct yib_hw_host *hw, struct yib_rq *rq, const void *os_wq, u8 *buf, u32 length)
{
	return 0;
}

static int swtest_fill_srqe(struct yib_hw_host *hw, struct yib_rq *rq, const void *os_wq, u8 *buf, u32 length, int pos)
{
	return 0;
}

static int swtest_fill_wqe(struct yib_hw_host *hw, struct yib_qp *qp, const void *os_wq, u8 *buf, u32 length, u32 mask)
{
	return 0;
}

static void swtest_fill_cqe(struct yib_hw_host *hw, struct yib_cq *cq, struct yib_qp **qp_cache, void *os_cq, u8 *buf)
{
}

static int swtest_sw_fill_cqe(struct yib_hw_host *hw, struct yib_cq *cq, void *os_cq)
{
	//yib_sq_swcmd_done
	return -1;
}

static bool swtest_check_sq_full(struct yib_hw_host *hw, struct yib_sq *ysq)
{
	return true;
}

static bool swtest_check_rq_full(struct yib_hw_host *hw, struct yib_rq *yrq)
{
	return false;
}

static bool swtest_check_srq_full(struct yib_hw_host *hw, struct yib_srq *ysrq, int *pos)
{
	int ret = 0;
	ret = yib_srq_find_useable_pos(ysrq);
	if (ret == -ENOMEM)
		return true;

	*pos = ret;
	return false;
}

static bool swtest_check_cq_empty(struct yib_hw_host *hw, struct yib_cq *ycq, u8 *cqe)
{
	//read ycq ci, read ycq pi
	//ci == pi?
	return true;
}

static int swtest_get_sq_item_size(int *inline_len, int *max_sg, bool is_ud)
{
	//inline: 16 80 208
	//sg: 1 5 13
	//ud inline: 48 176
	int isize = 0;
	int input = max(*inline_len, *max_sg * 16);
	int len = 0, sg_num = 0;
	if (is_ud) {
		if (input <= 48) {
			isize = 128;
			len = 48;
		} else {
			isize = 256;
			len = 176;
		}
		sg_num = len / 16;
	} else {
		if (input <= 16) {
			isize = 64;
			len = 16;
		} else if (input > 16 && input <= 80) {
			isize = 128;
			len = 80;
		} else if (input > 80) {
			isize = 256;
			len = 208;
		}
		sg_num = len / 16;
	}

	*inline_len = len;
	*max_sg = sg_num;
	return isize;
}

static int swtest_get_rq_item_size(int *max_sg)
{
	//sg: 2 6 14
	int isize = 0;
	int sg_num = 0;
	if (*max_sg <= 2) {
		isize = 64;
		sg_num = 2;
	} else if (*max_sg > 2 && *max_sg <= 6) {
		isize = 128;
		sg_num = 6;
	} else if  (*max_sg > 6) {
		isize = 256;
		sg_num = 14;
	}
	*max_sg = sg_num;
	return isize;
}

static void swtest_sq_pi_db_update(struct yib_hw_host *hw, struct yib_qp *qp, int io_cnt)
{
}

static void swtest_rq_pi_db_update(struct yib_hw_host *hw, struct yib_rq *rq, int io_cnt)
{
}

static void swtest_srq_pi_db_update(struct yib_hw_host *hw, struct yib_srq *srq, int pos)
{
	bool bdb = false;

	bdb = yib_srq_db_helper(srq, pos);

	yib_pr_info(YUSUR_IB_DBG_RECV, "srq :%d need to db=%d dbpos=%d\n", srq->yrq->entry.index, (int)bdb, pos);
}

static void swtest_cq_ci_db_update(struct yib_hw_host *hw, struct yib_cq *cq, int poll_cnt)
{
}

int swtest_get_eq_intr_num(struct yib_sf *sf)
{
	int num_comp_vector = sf->hw->caps.num_comp_vector;
	if (num_comp_vector + 1 > YIB_MAX_EQ_NUM)
		return -EINVAL;

	//num_comp_vector为CQ中断向量数目，eq数量为aeq+nq (1+num_comp_vector)
	return num_comp_vector + 1;
}

static int swtest_get_eq_isize(struct yib_sf *sf, struct yib_eq *yeq)
{
	int eq_isize;
	if (yeq->entry.index == 0)
		eq_isize = YIB_AEQ_ISIZE;
	else
		eq_isize = YIB_EQ_ISIZE;

	return eq_isize;
}

static int swtest_eq_info_init(struct yib_sf *sf, struct yib_eq *eq, int depth, bool b_del)
{
	swtest_eq_priv_t *eq_priv = (swtest_eq_priv_t *)eq->priv;
	int eq_item_size = 0;

	if (b_del == false) {
		eq_item_size = swtest_get_eq_isize(sf, eq);
		yib_queue_calc_depth(eq_item_size, &depth);
		eq_priv->queue = yib_create_queue(sf, depth, eq_item_size, NULL);
		if (eq_priv->queue == NULL) {
			os_printw(&sf->pdev->dev, "alloc eq queue failed\n");
			return -ENOMEM;
		}

		eq_priv->queue->info = kzalloc(sizeof(struct yib_queue_info), GFP_KERNEL);
		if (eq_priv->queue->info == NULL) {
			os_printe(&sf->pdev->dev, "host eq queue info mem not enough");
			yib_destroy_queue(sf, eq_priv->queue);
			eq_priv->queue = NULL;
			return -ENOMEM;
		}
		yib_queue_info_init(eq_priv->queue->info);
	} else {
		if (eq_priv->queue) {
			if (eq_priv->queue->info)
				kfree(eq_priv->queue->info);
			yib_destroy_queue(sf, eq_priv->queue);
			eq_priv->queue = NULL;
		}
	}

	return 0;
}

static bool swtest_check_eq_empty(struct yib_sf *sf, struct yib_eq *eq)
{
	return true;
}

static void swtest_eq_sw_handler(struct yib_sf *sf, struct yib_eq *eq, u8 *buf)
{
	return;
}

static void swtest_eq_handler(struct yib_sf *sf, struct yib_eq *eq, struct yib_evts_occurs *evts_occurs)
{
	u8 *buf = NULL;
	swtest_eq_priv_t *eq_priv = (swtest_eq_priv_t *)eq->priv;
	buf = yib_queue_get_ci_vaddr(eq_priv->queue);
	//do eq event
	//维护各种xxx_occur计数
	yib_queue_advance_ci(eq_priv->queue, 1);
}

static void swtest_eq_ci_db_update(struct yib_sf *sf, struct yib_eq *eq, int io_cnt)
{
}

static int swtest_init_caps(struct yib_hw_host *hw, struct yib_sf *sf)
{
	struct yib_roce_caps	*caps = &hw->caps;
	struct yib_dev_funcs	*func = &hw->funcs;

	sf->udp_port = 3721;

	caps->fw_ver    = 1;
	caps->hw_ver    = 1;
	caps->num_ports = 1;
	caps->num_qps   = 4096;
	caps->num_cqs   = caps->num_qps * 2;
	caps->max_mr    = caps->num_qps * 2;
	caps->max_srqs  = caps->num_qps;
	caps->max_mcast_qps = 64;
	caps->max_mcast_grp = YIB_MAX_MCAST;

	caps->max_rqs = caps->num_qps;
	caps->max_res_rd_atom = 16;	
	caps->num_pds = 16384; 
	caps->max_mr_sgs = 1024*1024;
	caps->max_eqs = 2048;
	caps->max_sq_inline = 208;
	caps->max_qp_wr = 32*1024;
	caps->max_cqes = 256 * 1024;
	caps->max_srqes = 256 * 1024;
	caps->max_rq_sg = 14;
	caps->max_sq_sg = 13;
	caps->num_comp_vector = 1;
	caps->page_size_cap =   0xFFFFF000;
	caps->max_mtu = IB_MTU_4096;
	caps->max_qp_init_rd_atom = 16; //todo
	caps->max_qp_rd_atom = 16;
	caps->max_ah = 4096;
	caps->max_mr_size = caps->max_mr_sgs * (u64)(4*1024*1024*1024ull);//一个mr最多的内存�?

	func->ud_multicast = 0;
	func->srq_supp     = 1;
	func->srq_modify   = 1;
	func->mw_supp      = 1;
	func->atomic_supp  = 0;
	func->ud_supp      = 1;
	func->uc_supp      = 0;
	func->xrc_supp     = 0;
	func->quick_excep  = 0;
	func->sw_err_flush = 0;
	func->srq_seq      = 1;
	func->queue_l2_tbl = 1;
	func->mr_l2_tbl    = 1;
	return 0;
}

static void swtest_global_reset(struct yib_hw_host *hw)
{
	hw->vf_id = 0;
	hw->pf_id = 0;
	hw->host_id = 0;
}

static int swtest_start_host(struct yib_hw_host *hw)
{
	swtest_priv_t *swtest_priv = hw->hw_priv;

	swtest_priv->bar = os_alloc_coherent_dma(hw->sf.pdev, YIB_SWTEST_BAR_SIZE, hw->sf.num_node, hw->sf.host_mutex);
	if (swtest_priv->bar.dma_addr == 0) {
		os_printe(hw->dev, "swtest_priv->bar alloc failed");
		return -ENOMEM;
	}

	return 0;//-ENOMEM; // current return fail to let upper layer fail
}

static void swtest_stop_host(struct yib_hw_host *hw)
{
	swtest_priv_t *swtest_priv = hw->hw_priv;

	if (swtest_priv->bar.dma_addr != 0) {
		os_free_coherent_dma(hw->sf.pdev, &swtest_priv->bar);
	}
}

static void swtest_shutdown_host(struct yib_hw_host *hw)
{
	return;
}

static int swtest_set_qos(struct yib_hw_host *hw, struct yib_rdma_qos_info *qos_info)
{
	return -ENOENT;
}

static int swtest_set_rx_buf_size(struct yib_hw_host *hw)
{
	return -ENOENT;
}

static void swtest_get_hw_counter(struct yib_hw_host *hw, u64 *value, u32 port_num)
{
	int i = 0;
	u64 val;
	for (i = 0; i < hw->hw_counter_cnt; i++) {
		val = 0;
		switch (i) {
			case YIB_CNT_LINK_DOWN:
				value[i] = hw->ndev_info[port_num - 1].link_down;
				break;
			default:
				value[i] = 0; //keep value
				break;
		}
	}
}

static int swtest_host_reg_mmap(struct yib_hw_host *hw, struct vm_area_struct *vma, ssize_t length, u64 offset)
{
	swtest_priv_t *swtest_priv = hw->hw_priv;
	u64 bar_addr = swtest_priv->bar.dma_addr;

	if (remap_pfn_range(vma, vma->vm_start, bar_addr >> PAGE_SHIFT,
					length, vma->vm_page_prot)) {
		os_printe(hw->dev, "Failed to map swtest mem memory");
		return -EAGAIN;
	}

	return 0;
}

static int swtest_host_def_mmap(struct yib_hw_host *hw, struct vm_area_struct *vma, ssize_t length, u64 offset, int type)
{
	return 0;
}

static int swtest_get_usable_channels(struct yib_hw_host *hw)
{
	return 0;
}

static void swtest_get_queue_user_info(struct yib_hw_host *hw, enum yib_elem_type type, void *verbs, u32 hw_id, u8 *res, int *len)
{
	*len = 0;
	switch(type) {
	case YIB_TYPE_PD:
	{
		struct yib_ib_alloc_uctx_resp uctx;
		uctx.bar_offset = 0;//hw->sf->hw_base_off for other type
		uctx.bar_map_len = YIB_SWTEST_BAR_SIZE; //yusur_hw_get_bar_len(hw) for other type
		uctx.cq_isize = hw->hw_ops.queue_ops->cqe_isize;
		uctx.chip_type = hw->hw_ops.host_type;
		uctx.chip_subtype = hw->chip_subtype;
		uctx.quick_excep = (hw->funcs.quick_excep == 0)? 0 : 1;
		uctx.sw_err_flush = (hw->funcs.sw_err_flush == 0)? 0 : 1;
		*len = sizeof(struct yib_ib_alloc_uctx_resp);
		memcpy(res, &uctx, *len);
		break;
	}
	case YIB_TYPE_CQ:
	{
		struct yib_ib_create_cq_resp cq;
		struct yib_cq *ycq = (struct yib_cq*)verbs;
		cq.cqid = hw_id;
		cq.max_cqe = ycq->queue->depth;
		*len = sizeof(struct yib_ib_create_cq_resp);
		memcpy(res, &cq, *len);
		break;
	}
	case YIB_TYPE_QP:
	{
		struct yib_ib_create_qp_resp qp;
		struct yib_qp *yqp = (struct yib_qp*)verbs;
		qp.qpid = yib_get_qp_sw_idx(yqp);
		qp.capture_pa = 0;
		qp.nvme_rq_rqe_pa = 0;
		qp.max_send_wr = yqp->cap.max_send_wr;
		qp.max_recv_wr = yqp->cap.max_recv_wr;
		qp.max_send_sge = yqp->cap.max_send_sge;
		qp.max_recv_sge = yqp->cap.max_recv_sge;
		qp.max_inline_data = yqp->cap.max_inline_data;
		qp.send_isize = yqp->ysq.queue->item_size;
		if ((yqp->use_srq == false) && (yqp->type.yrq != NULL)) {
			qp.rqid = yib_get_rq_sw_idx(yqp->type.yrq);
			qp.recv_isize = yqp->type.yrq->queue->item_size;
		} else if (yqp->use_srq && yqp->qp_type != IB_QPT_XRC_TGT) {
			qp.rqid = yib_get_rq_sw_idx(yqp->type.ysrq->yrq);
			qp.recv_isize = yqp->type.ysrq->yrq->queue->item_size;
		} else {
			qp.rqid = 0;
			qp.recv_isize = 0;
		}
		*len = sizeof(struct yib_ib_create_qp_resp);
		memcpy(res, &qp, *len);
		break;
	}
	case YIB_TYPE_RQ:
	{
		struct yib_ib_create_srq_resp srq;
		struct yib_srq *ysrq = (struct yib_srq*)verbs;
		srq.srqid = hw_id;
		srq.max_sge = ysrq->attr.max_sge;
		srq.max_wr = ysrq->attr.max_wr;
		srq.isize = ysrq->yrq->queue->item_size;
		*len = sizeof(struct yib_ib_create_srq_resp);
		memcpy(res, &srq, *len);
		break;
	}
	default:
		*len = 0;
		break;
	}
}

static void swtest_host_debugfs_reg(struct yib_hw_host *hw)
{
}
static void swtest_host_debugfs_mem(struct yib_hw_host *hw, u32 len, u64 addr)
{
}
static int swtest_user_def_hw_debugfs(struct yib_hw_host *hw, u8 *buf)
{
	return 0;
}
static void swtest_smac_debugfs(struct yib_hw_host *hw)
{
}
static void swtest_sgid_debugfs(struct yib_hw_host *hw)
{
}

#if (COUNTER_STAT_DESC)	
const struct rdma_stat_desc  *swtest_get_counter_info(struct yib_hw_host *hw, u32 *count)
#else
const char * const *swtest_get_counter_info(struct yib_hw_host *hw, u32 *count)
#endif
{
	*count = ARRAY_SIZE(swtest_counter_name);
	return swtest_counter_name;
}

struct yib_uio_ops swtest_uio_ops = {
	.uio_post_send = swtest_uio_post_send,
	.uio_post_recv = swtest_uio_post_recv,
	.uio_poll_cq = swtest_uio_poll_cq,
};

struct yib_queue_ops swtest_queue_ops = {
	.cqe_isize = 32,
	.fill_rqe = swtest_fill_rqe,
	.fill_srqe = swtest_fill_srqe,
	.fill_wqe = swtest_fill_wqe,
	.fill_cqe = swtest_fill_cqe,
	.sw_fill_cqe = swtest_sw_fill_cqe,

	.check_sq_full = swtest_check_sq_full,
	.check_rq_full = swtest_check_rq_full,
	.check_srq_full = swtest_check_srq_full,
	.check_cq_empty = swtest_check_cq_empty,

	.get_sq_item_size = swtest_get_sq_item_size,
	.get_rq_item_size = swtest_get_rq_item_size,

	.sq_pi_db_update = swtest_sq_pi_db_update,
	.rq_pi_db_update = swtest_rq_pi_db_update,
	.srq_pi_db_update = swtest_srq_pi_db_update,
	.cq_ci_db_update = swtest_cq_ci_db_update,
};

struct yib_eq_ops swtest_eq_ops = {
	.intr_enable = false,
	.priv_size = sizeof(swtest_eq_priv_t),
	.get_eq_intr_num = swtest_get_eq_intr_num,
	.eq_info_init = swtest_eq_info_init,
	.eq_debugfs = swtest_eq_debugfs,
	.check_eq_empty = swtest_check_eq_empty,
	.eq_sw_handler = swtest_eq_sw_handler,
	.eq_handler = swtest_eq_handler,
	.eq_ci_db_update = swtest_eq_ci_db_update,
};

struct yib_sf_ops swtest_sf_ops = {
	.host_type = YRDMA_TYPE_SWTEST,
	.priv_size = sizeof(swtest_sf_priv_t),

	.sf_pre_init = swtest_sf_pre_init,
	.sf_init = swtest_sf_init,

	.start_sf = swtest_start_sf,
	.stop_sf = swtest_stop_sf,

	//mac
	.add_mac = swtest_add_mac,
	.modify_mac = swtest_modify_mac,

	.set_gid = swtest_set_gid,

	//av
	.init_av = swtest_init_av,

	//mr
	.mrw_alloc = swtest_mrw_alloc,
	.mrw_destroy = swtest_mrw_destroy,
	.mr_mtt_init = swtest_mr_mtt_init,
	.mr_mpt_update = swtest_mr_mpt_update,
	.mr_debugfs = swtest_mr_debugfs,

	//cq
	.cq_info_init = swtest_cq_info_init,
	.cq_notify_update = swtest_cq_notify_update,
	.cq_debugfs = swtest_cq_debugfs,

	//qp
	.qp_info_init = swtest_qp_info_init,
	.qp_info_update = swtest_qp_info_update,
	.qp_query = swtest_qp_query,
	.qp_debugfs = swtest_qp_debugfs,

	//swtest no ops
	.rq_info_init = swtest_rq_info_init,
	.srq_debugfs = swtest_srq_debugfs,

	.sf_debugfs = swtest_sf_debugfs,
};

static const struct yib_hw_ops swtest_hwops = {
	.host_type = YRDMA_TYPE_SWTEST,
	.host_name = "SWTEST",
	.priv_size = sizeof(swtest_priv_t),

	.init_caps =  swtest_init_caps,
	.global_reset = swtest_global_reset,

	.start_host = swtest_start_host,
	.stop_host = swtest_stop_host,
	.shutdown_host = swtest_shutdown_host,

	.set_qos = swtest_set_qos,
	.set_rx_buf_size = swtest_set_rx_buf_size,
	.get_hw_counter = swtest_get_hw_counter,
	.get_counter_info = swtest_get_counter_info,

	.host_reg_mmap = swtest_host_reg_mmap,
	.host_def_mmap = swtest_host_def_mmap,

	.get_usable_channels = swtest_get_usable_channels,
	.get_queue_user_info = swtest_get_queue_user_info,
	.host_debugfs_reg = swtest_host_debugfs_reg,
	.host_debugfs_mem = swtest_host_debugfs_mem,
	.user_def_hw_debugfs = swtest_user_def_hw_debugfs,
	.smac_debugfs = swtest_smac_debugfs,
	.sgid_debugfs = swtest_sgid_debugfs,

	.sf_ops = &swtest_sf_ops,
	.eq_ops = &swtest_eq_ops,
	.queue_ops = &swtest_queue_ops,
	.uio_ops = &swtest_uio_ops,
};

const struct yib_hw_ops *swtest_get_host_ops(void)
{
	return &swtest_hwops;
}