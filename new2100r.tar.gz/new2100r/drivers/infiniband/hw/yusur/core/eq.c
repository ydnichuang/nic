#include "../include/basic.h"
#include "../include/os_api.h"
#include "../include/os_ds.h"
#include "../include/mem.h"
#include "../include/queue.h"
#include "../include/host.h"
#include "../include/verbs.h"
#include "../include/yusur_ib.h"

static int yib_eq_process(struct yib_sf *sf, struct yib_eq *yeq)
{
	int io_cnt = 0;
	struct yib_evts_occurs evts_occurs;

	memset(&evts_occurs, 0, sizeof(struct yib_evts_occurs));
	while(sf->eq_ops->check_eq_empty(sf, yeq) == false) {
		sf->eq_ops->eq_handler(sf, yeq, &evts_occurs);
		io_cnt++;
	}
	if(io_cnt > 0) {
		sf->eq_ops->eq_ci_db_update(sf, yeq, io_cnt);
	}

	if (evts_occurs.cq_cmpl_evts_occur)
		yib_hw_events_run(&sf->cq_cmpl_evts);
	if (evts_occurs.cq_err_evts_occur)
		yib_hw_events_run(&sf->cq_err_evts);
	if (evts_occurs.qp_fatal_evts_occur)
		yib_hw_events_run(&sf->qp_fatal_evts);
	if (evts_occurs.srq_err_evts_occur)
		yib_hw_events_run(&sf->srq_err_evts);
	if (evts_occurs.srq_lastwqe_evts_occur)
		yib_hw_events_run(&sf->srq_lastwqe_evts);
	if (evts_occurs.aeq_evts_occur)
		yib_hw_events_run(&sf->aeq_evts);
	return 0;
}

static int  yib_eq_thread_func(void *arg)
{
	struct yib_eq *yeq = arg;
	struct yib_sf *sf = yeq->ysf;
	int n = 0;

	msleep(20);
	while (!yeq->thread->thread_shutdown) {
		n = yib_eq_process(sf, yeq);
		if (n == 0)
			schedule();
	}
	complete(&yeq->thread->thread_finishing);
	return 0;
}

static irqreturn_t yib_eq_intr_func(int irq, void *arg)
{
	struct yib_eq *yeq = arg;
	int ret = 0;

	yeq->int_cnt++;
	ret = yib_eq_process(yeq->ysf, yeq);
	if (ret != 0)
		return IRQ_HANDLED;
	else
		return IRQ_NONE;
}

struct yib_eq *yib_eq_alloc(struct yib_sf *sf, host_verbs_t *verbs, int depth, bool use_thread, int int_vector)
{
	int ret = 0;

	struct yib_eq *yeq = yib_pool_alloc(&verbs->eq_pool);
	if (yeq == NULL) {
		os_printw(&sf->pdev->dev, "alloc eq from pool failed\n");
		return NULL;
	}

	yeq->priv = kzalloc(sf->eq_ops->priv_size, GFP_KERNEL);
	if (yeq->priv == NULL) {
		os_printw(&sf->pdev->dev, "alloc eq priv failed\n");
		goto err;
	}

	ret = sf->eq_ops->eq_info_init(sf, yeq, depth, false);
	if (ret) {
		os_printw(&sf->pdev->dev, "init eq info failed\n");
		goto err;
	}

	yeq->ysf = sf;
	yeq->int_vector = int_vector;
	if (sf->eq_ops->intr_enable)
		yeq->use_thread = use_thread;
	else
		yeq->use_thread = true;

	if (yeq->use_thread) {
		yeq->thread = os_thread_run(yib_eq_thread_func, yeq, "yib-eq", yeq->entry.index);
		if (yeq->thread == NULL)
			goto err;
	} else {
		ret = os_request_irq(sf, yeq, yib_eq_intr_func);
		if (ret) {
			yib_dbg_err("request irq:%d failed\n", yeq->int_vector);
			goto err;
		}		
	}

	return yeq;
err:
	yib_elem_drop_ref(&yeq->entry);
	return NULL;
}

void yib_pool_eq_cleanup(struct yib_pool_entry *arg)
{
	struct yib_eq *yeq= container_of(arg, struct yib_eq, entry);
	struct yib_sf *sf = yeq->ysf;

	if (yeq->use_thread) {
		os_thread_stop(yeq->thread);
		yeq->thread = NULL;
	}

	if (yeq->use_thread == false)
		os_free_irq(sf, yeq);
	
	sf->eq_ops->eq_info_init(sf, yeq, 0, true);

	if (yeq->priv) {
		kfree(yeq->priv);
		yeq->priv = NULL;
	}
}

void yib_aeq_func(void *arg)
{

}