#ifndef _YUSUR_PRIV_CORE_H_
#define _YUSUR_PRIV_CORE_H_


struct yib_wr_opcode_info {
	char			*name;
	enum yib_wr_mask	mask[IB_QPT_DRIVER+1];
};

int post_one_send_gsi(struct yusur_ib_dev *yib, struct yib_qp *yqp, const os_ib_send_wr *wr,
			    u32 mask, u32 length);

#endif /* end _YUSUR_PRIV_CORE_H_ */