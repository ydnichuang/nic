#include "../include/basic.h"
#include "../include/os_api.h"
#include "../include/os_ds.h"
#include "../include/mem.h"
#include "../include/queue.h"
#include "../include/host.h"
#include "../include/verbs.h"
#include "../include/yusur_ib.h"

void yib_ah_print_mac(char *s, u8 *mac)
{
	yib_dbg_info(YUSUR_IB_M_AH, YUSUR_IB_DBG_CREATE,"%s: %02X:%02X:%02X:%02X:%02X:%02X\n", s,
		mac[0], mac[1],mac[2], mac[3], mac[4], mac[5]);
}

void yib_ah_print_ip(char *s, bool ip_v4, u8 *gid_raw)
{
	int i = 0;
	if (ip_v4) i = 12;
	yib_dbg_info(YUSUR_IB_M_AH, YUSUR_IB_DBG_CREATE, "%s begin", s);
	for (; i < 16; i++) {
		yib_dbg_info(YUSUR_IB_M_AH, YUSUR_IB_DBG_CREATE, "ip[%d]=%02X", i, gid_raw[i]);
	}
	yib_dbg_info(YUSUR_IB_M_AH, YUSUR_IB_DBG_CREATE, "%s end", s);
}

static void yib_ah_print_ip2(char *s, bool ip_v4, u8 *sin_raw)
{
	int i = 0;
	int len = 16;
	if (ip_v4) len = 4;
	yib_dbg_info(YUSUR_IB_M_AH, YUSUR_IB_DBG_CREATE, "%s begin", s);
	for (; i < len; i++) {
		yib_dbg_info(YUSUR_IB_M_AH, YUSUR_IB_DBG_CREATE, "sinip[%d]=%02X", i, sin_raw[i]);
	}
	yib_dbg_info(YUSUR_IB_M_AH, YUSUR_IB_DBG_CREATE, "%s end", s);
}

void yib_ah_print(struct yib_av *av)
{
#if(YUSUR_IB_DBG_ON)
	yib_ah_print_ip("dip:", (av->network_type == RDMA_NETWORK_IPV6)? false: true,
		av->grh.dgid.raw);
	yib_ah_print_ip2("dip2:",  (av->network_type == RDMA_NETWORK_IPV6)?false:true,
		(av->network_type == RDMA_NETWORK_IPV6) ? 
			(u8*)&av->dgid_addr._sockaddr_in6.sin6_addr:(u8*)&av->dgid_addr._sockaddr_in.sin_addr);
	yib_ah_print_ip("sip:", (av->network_type == RDMA_NETWORK_IPV6)? false: true,
		av->sgid.raw);
	yib_ah_print_ip2("sip2:",  (av->network_type == RDMA_NETWORK_IPV6)? false:true,  
		(av->network_type == RDMA_NETWORK_IPV6) ?
			(u8*)&av->sgid_addr._sockaddr_in6.sin6_addr:(u8*)&av->sgid_addr._sockaddr_in.sin_addr);
	yib_ah_print_mac("dmac", av->dmac);
	yib_ah_print_mac("smac", av->smac);
	yib_dbg_info(YUSUR_IB_M_AH, YUSUR_IB_DBG_CREATE, "ip=%02X f=%04X h=%02X t=%02X vlan_id=%04X\n",
		av->network_type, av->grh.flow_label, av->grh.hop_limit, av->grh.traffic_class, av->vlan_id);
#endif
}

static void yib_av_fill_ip_info(struct yusur_ib_dev *yib, struct yib_av *av, struct rdma_ah_attr *attr,
									struct ib_gid_attr *sgid_attr, union ib_gid *sgid)
{
	int ibtype;
	int type;
	int ret = 0;
#ifdef IB_SGID_ATTR_NOTHAS_SGID
	struct ib_gid_attr *sgid_attr_use = NULL;
	memcpy(&av->sgid, sgid, sizeof(union ib_gid));
	os_rdma_gid2ip((struct sockaddr *)&av->sgid_addr, sgid);
	os_rdma_gid2ip((struct sockaddr *)&av->dgid_addr, &rdma_ah_read_grh(attr)->dgid);
	ibtype = ib_gid_to_network_type(sgid_attr->gid_type, sgid);
	sgid_attr_use = sgid_attr;
#else
	const struct ib_gid_attr *grh_sgid_attr = attr->grh.sgid_attr;
	const struct ib_gid_attr *sgid_attr_use = NULL;
	memcpy(&av->sgid, &grh_sgid_attr->gid, sizeof(union ib_gid));
	os_rdma_gid2ip((struct sockaddr *)&av->sgid_addr, &grh_sgid_attr->gid);
	os_rdma_gid2ip((struct sockaddr *)&av->dgid_addr, &rdma_ah_read_grh(attr)->dgid);
	ibtype = rdma_gid_attr_network_type(grh_sgid_attr);
	sgid_attr_use = attr->grh.sgid_attr;
#endif

#ifdef IB_HAS_READ_GID_L2_FIELDS
	av->vlan_id = 0xffff;
	ret = rdma_read_gid_l2_fields(sgid_attr_use, &av->vlan_id, av->smac);
#else 
{
	struct net_device *ndev;
	ndev = yib_get_netdev(&yib->ib_dev, av->port_num);
	av->vlan_id = rdma_vlan_dev_vlan_id(ndev);
	memcpy(av->smac, ndev->dev_addr, ETH_ALEN);
}
#endif
	if (ret) {
		pr_err("Failed to read gid l2 fields. err = %d\n", ret);
	}

	switch (ibtype) {
	case RDMA_NETWORK_IPV4:
		type = YIB_NETWORK_TYPE_IPV4;
		break;
	case RDMA_NETWORK_IPV6:
		type = YIB_NETWORK_TYPE_IPV6;
		break;
	default:
		/* not reached - checked in yib_av_chk_attr */
		pr_warn("err ibtype = %d\n", ibtype);
		type = 0;
		break;
	}

	av->network_type = type;
	if (av->vlan_id != 0xffff)
		av->vlan_pcp = yib_get_pcp_by_index(&yib->host, IPTOS_TOS(av->grh.traffic_class)>>2);
}

static void yib_av_from_attr(u8 port_num, struct yib_av *av, struct rdma_ah_attr *attr)
{
	const struct ib_global_route *grh = rdma_ah_read_grh(attr);

	memset(av, 0, sizeof(*av));
	memcpy(av->grh.dgid.raw, grh->dgid.raw, sizeof(grh->dgid.raw));
	av->grh.flow_label = grh->flow_label;
	av->grh.sgid_index = grh->sgid_index;
	av->grh.hop_limit = grh->hop_limit;
	av->grh.traffic_class = grh->traffic_class;
	av->port_num = port_num;
}


void yib_init_av(struct yusur_ib_dev *yib, struct rdma_ah_attr *attr, struct yib_av *av)
{
	union ib_gid sgid = {};
	struct ib_gid_attr sgid_attr = {};
#ifdef IB_SGID_ATTR_NOTHAS_SGID
	int err;
	err = ib_get_cached_gid(&yib->ib_dev, rdma_ah_get_port_num(attr),
				rdma_ah_read_grh(attr)->sgid_index, &sgid,
				&sgid_attr);
	if (err) {
		pr_err("Failed to query sgid. err = %d\n", err);
		return;
	} else {
		dev_put(sgid_attr.ndev);
	}
#endif

	yib_av_from_attr(rdma_ah_get_port_num(attr), av, attr);
	yib_av_fill_ip_info(yib, av, attr, &sgid_attr, &sgid);
	memcpy(av->dmac, attr->roce.dmac, ETH_ALEN);
	yib_ah_print(av);
}

int yib_av_chk_attr(struct yusur_ib_dev *yib, struct rdma_ah_attr *attr)
{
	const struct ib_global_route *grh = rdma_ah_read_grh(attr);
	int type;
#ifdef IB_SGID_ATTR_NOTHAS_SGID
	int err;
	union ib_gid sgid;
	struct ib_gid_attr sgid_attr;
	
	err = ib_get_cached_gid(&yib->ib_dev, rdma_ah_get_port_num(attr),
					rdma_ah_read_grh(attr)->sgid_index, &sgid,
					&sgid_attr);
	if (err) {
		pr_err("Failed to query sgid. err = %d\n", err);
		return err;
	} else {
		dev_put(sgid_attr.ndev);
	}
#endif

	if (rdma_ah_get_ah_flags(attr) & IB_AH_GRH) {
		if (grh->sgid_index >= YUSUR_RDMA_GID_TABLE_LEN) {
			os_printw(yib->dev, "invalid sgid index = %d\n", grh->sgid_index);
			return -EINVAL;
		}
#ifdef IB_SGID_ATTR_NOTHAS_SGID
		type = ib_gid_to_network_type(sgid_attr.gid_type, &sgid);
#else
		type = rdma_gid_attr_network_type(grh->sgid_attr);
#endif
		if (type < RDMA_NETWORK_IPV4 ||
		    type > RDMA_NETWORK_IPV6) {
			os_printw(yib->dev,"invalid network type for rdma_yib = %d\n",
					type);
			return -EINVAL;
		}
	}

	return 0;
}


void yib_av_to_attr(struct yib_av *av, struct rdma_ah_attr *attr)
{
	struct ib_global_route *grh = rdma_ah_retrieve_grh(attr);

	attr->type = RDMA_AH_ATTR_TYPE_ROCE;

	memcpy(grh->dgid.raw, av->grh.dgid.raw, sizeof(av->grh.dgid.raw));
	grh->flow_label = av->grh.flow_label;
	grh->sgid_index = av->grh.sgid_index;
	grh->hop_limit = av->grh.hop_limit;
	grh->traffic_class = av->grh.traffic_class;

	rdma_ah_set_ah_flags(attr, IB_AH_GRH);
	rdma_ah_set_port_num(attr, av->port_num);
}

struct yib_ah *yib_inner_create_ah(struct yib_sf *sf)
{
	struct yib_ah *ah = NULL;
#if IB_LAYER_ALLOC_AH
	int err;

	ah = kzalloc(sizeof(struct yib_ah), GFP_KERNEL);
	if (ah == NULL) {
		os_printw(sf->hw->dev, "ah kzalloc failed\n");
		return ERR_PTR(-ENOMEM);
	}

	err = yib_add_to_pool(&sf->hw->verbs.ah_pool, &ah->entry);
	if (err) {
		kfree(ah);
		os_printw(sf->hw->dev, "ah add to pool failed\n");
		return ERR_PTR(err);
	}
#else
	ah = yib_pool_alloc(&sf->hw->verbs.ah_pool);
	if (ah == NULL) {
		os_printw(sf->hw->dev, "ah yib_pool_alloc failed\n");
		return ERR_PTR(-ENOMEM);
	}
#endif
	return ah;
}

void yib_inner_destroy_ah(struct yib_ah *ah)
{
	if (ah == NULL)
		return;
	yib_elem_drop_ref(&ah->entry);
#if IB_LAYER_ALLOC_AH
	kfree(ah);
	ah = NULL;
#endif
	return;
}