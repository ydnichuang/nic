#include <linux/slab.h>
#include <linux/dma-mapping.h>
#include "../include/basic.h"
#include "../include/os_api.h"
#include "../include/os_ds.h"
#include "../include/mem.h"
#include "../include/queue.h"
#include "../include/host.h"
#include "../include/verbs.h"

void yib_queue_info_init(struct yib_queue_info *info)
{
	os_atomic_set(&info->ci, 0);
	os_atomic_set(&info->pi, 0);
	info->io_count = 0;
	info->err_count = 0;
	info->direct_cnt = 0;
	info->pi_toggle = false;
	info->ci_toggle = false;
}

int yib_queue_get_page_cnt(int item_size, int depth)
{
	return DIV_ROUND_UP(depth, (PAGE_SIZE / item_size));
}

void yib_queue_calc_depth(int item_size, int *cnt)
{
	//前提:一个4k能放整数个cqe,sqe, rqe
	u32 basic = 0;
	u32 page_size = PAGE_SIZE;

	basic = page_size / item_size;
	*cnt = os_align_any_up(*cnt, basic); //按basic对齐
	*cnt = os_numTo2n2(*cnt);//按2整数次幂对齐
}

void* yib_queue_get_vaddr_by_index(struct yib_queue_mem *queue, int index)
{
	if (queue->is_user)
		return NULL;

	return yib_frag_get_vaddr(queue->mem.kmem, queue->item_size, index);
}

void* yib_queue_get_pi_vaddr(struct yib_queue_mem *queue)
{
	int pi = os_atomic_read(&queue->info->pi);
	return yib_queue_get_vaddr_by_index(queue, pi);
}

void* yib_queue_get_ci_vaddr(struct yib_queue_mem *queue)
{
	int ci = os_atomic_read(&queue->info->ci);
	return yib_queue_get_vaddr_by_index(queue, ci);
}

int yib_queue_advance_pi(struct yib_queue_mem *queue, int diff)
{
	int pi = os_atomic_read(&queue->info->pi);
	if ((pi + diff) >= queue->depth) {
		os_atomic_set(&queue->info->pi, (pi + diff - queue->depth));
		queue->info->pi_toggle = (queue->info->pi_toggle)? 0 : 1;
		return (pi + diff - queue->depth);
	} else {
		os_atomic_add(&queue->info->pi, diff);
		return (pi + diff);
	}
}

int yib_queue_advance_ci(struct yib_queue_mem *queue, int diff)
{
	int ci = os_atomic_read(&queue->info->ci);
	if ((ci + diff) >= queue->depth) {
		os_atomic_set(&queue->info->ci, (ci + diff - queue->depth));
		queue->info->ci_toggle = (queue->info->ci_toggle)? 0 : 1;
		return (ci + diff - queue->depth);
	} else {
		os_atomic_add(&queue->info->ci, diff);
		return (ci + diff);
	}
}

struct yib_queue_mem *yib_create_queue(struct yib_sf *sf, int depth, int item_size, void *umem)
{
	struct yib_queue_mem *queue_mem = NULL;
	int size = 0;
	struct ib_umem *ib_umem;
	struct scatterlist *sglist;
	int npages;
	int ret = 0;
	bool l2_tbl_supp = (sf->hw->funcs.queue_l2_tbl == 0)? false : true;

	if (depth == 0 || item_size == 0)
		return NULL;

	queue_mem = kzalloc(sizeof(struct yib_queue_mem), GFP_KERNEL);
	if (queue_mem == NULL)
		return NULL;

	if (umem == NULL) {
		//内核态队列
		queue_mem->is_user = false;
		size = yib_queue_get_page_cnt(item_size, depth) * PAGE_SIZE;
		queue_mem->mem.kmem = yib_frag_buf_alloc_node(sf, size, true);
		if (queue_mem->mem.kmem == NULL) {
			kfree(queue_mem);
			return NULL;
		}

		ret =  yib_create_page_table_by_frag(sf, &queue_mem->tbl, queue_mem->mem.kmem, l2_tbl_supp);
		if (ret) {
			yib_frag_free_node(sf, queue_mem->mem.kmem);
			kfree(queue_mem);
			return NULL;
		}
	} else {
		//用户态队列
		queue_mem->is_user = true;
		queue_mem->mem.umem = umem;
		ib_umem = (struct ib_umem*)umem;
#if (IB_UMEM_SGITER)
		sglist = ib_umem->sgt_append.sgt.sgl;
#else
		sglist = ib_umem->sg_head.sgl;
#endif
		npages = ib_umem_num_pages(ib_umem);//按PAGE_SZIE计算的页数
		yib_sglist_dump(umem, npages, PAGE_SIZE);
		ret = yib_create_page_table_by_sg(sf, &queue_mem->tbl, sglist, npages, PAGE_SIZE, l2_tbl_supp);
		if (ret) {
			kfree(queue_mem);
			return NULL;
		}
	}

	queue_mem->depth = depth;
	queue_mem->item_size = item_size;
	return queue_mem;
}

void yib_destroy_queue(struct yib_sf *sf, struct yib_queue_mem *queue_mem)
{
	if (queue_mem == NULL)
		return;

	yib_destroy_page_table(sf, &queue_mem->tbl);

	if (queue_mem->is_user == false && queue_mem->mem.kmem != NULL) {
		yib_frag_free_node(sf, queue_mem->mem.kmem);
		queue_mem->mem.kmem = NULL;
	} else if (queue_mem->is_user == true && queue_mem->mem.umem != NULL){
		os_umem_release((struct ib_umem*)queue_mem->mem.umem);
		queue_mem->mem.umem = NULL;
	}

	kfree(queue_mem);
}