#include "../include/basic.h"
#include "../include/os_api.h"
#include "../include/os_ds.h"
#include "../include/mem.h"
#include "../include/queue.h"
#include "../include/host.h"
#include "../include/verbs.h"
#include "../include/yusur_ib.h"

#define YCQ_TASKLET_MAX_TIME_JIFFIES msecs_to_jiffies(2)

u32 yib_cq_align_size(struct yusur_ib_dev *yib, u32 *cnt)
{
	//前提:一个4k能放整数个cqe,sqe, rqe
	yib_queue_calc_depth(yib->host.hw_ops.queue_ops->cqe_isize, cnt);
	return yib_queue_get_page_cnt(yib->host.hw_ops.queue_ops->cqe_isize, *cnt) * PAGE_SIZE;
}

void yib_cq_poll_dbg_print(struct yib_cq *ycq, os_ib_wc *wc, bool bhw)
{
	yib_dbg_info(YUSUR_IB_M_CQ, YUSUR_IB_DBG_POLL, 
		"cq_poll cq_id=%d, opcode=0x%x status=0x%x byte_len=0x%x wc_flags=0x%x ci=0x%x wr_id=0x%llx imm_data=0x%x hw=%d\n",
		ycq->entry.index, wc->opcode, wc->status, wc->byte_len, wc->wc_flags,
		os_atomic_read(&ycq->queue->info->ci), (u64)wc->wr_id, wc->ex.imm_data, bhw?1:0);
}

void yib_clear_sw_cqe_list(struct yusur_ib_dev *yib, struct yib_cq *ycq, u64 handle, bool b_all)
{
	unsigned long flags;
	struct yib_sw_cqe *sw_cqe, *temp;

	os_spin_lock_irqsave(&ycq->cq_lock, flags);
	if (b_all) {
		list_for_each_entry_safe(sw_cqe, temp, &ycq->sw_done_list, node) {
			list_del(&sw_cqe->node);
			kfree(sw_cqe);
		}
		if (ycq->cur_sw_cqe) {
			kfree(ycq->cur_sw_cqe);
			ycq->cur_sw_cqe = NULL;
		}
	} else {
		list_for_each_entry_safe(sw_cqe, temp, &ycq->sw_done_list, node) {
			if (sw_cqe->handler == handle) {
				list_del(&sw_cqe->node);
				kfree(sw_cqe);
			}

			if (ycq->cur_sw_cqe) {
				if (ycq->cur_sw_cqe->handler == handle) {
					kfree(ycq->cur_sw_cqe);
					ycq->cur_sw_cqe = NULL;
				}
			}
		}
	}
	os_spin_unlock_restore(&ycq->cq_lock, flags);
}

int yib_sw_cqe_generate(struct yib_cq *ycq, struct yib_sw_cqe *input_sw_cqe,
			bool bsw, enum ib_wc_opcode sw_opcode, u64 sw_wr_id)
{
	struct yib_sw_cqe *sw_cqe = NULL;
	unsigned long flags;

	if (ycq == NULL)
		return -EINVAL;

	sw_cqe = kzalloc(sizeof(struct yib_sw_cqe), GFP_ATOMIC);
	if (sw_cqe == NULL) {
		yib_pr_warn("sw_cqe alloc failed\n");
		return -ENOMEM;
	}

	if (bsw) {
		sw_cqe->sw_opcode = sw_opcode;
		sw_cqe->sw_wr_id = sw_wr_id;
	}

	sw_cqe->type      = input_sw_cqe->type;
	sw_cqe->status    = input_sw_cqe->status;
	sw_cqe->start_pos = input_sw_cqe->start_pos;
	sw_cqe->end_pos   = input_sw_cqe->end_pos;
	sw_cqe->depth     = input_sw_cqe->depth;
	sw_cqe->handler   = input_sw_cqe->handler;

	os_spin_lock_irqsave(&ycq->cq_lock, flags);
	list_add_tail(&sw_cqe->node, &ycq->sw_done_list);
	os_spin_unlock_restore(&ycq->cq_lock, flags);
	return 0;
}

static int yib_cur_sw_cqe_process(struct yusur_ib_dev *yib, struct yib_cq *ycq, os_ib_wc *wc)
{
	if (yib->host.hw_ops.queue_ops->sw_fill_cqe(&yib->host, ycq, wc) != 0)
		return -1;
	ycq->cur_sw_cqe->start_pos = (ycq->cur_sw_cqe->start_pos + 1) % ycq->cur_sw_cqe->depth;
	if (ycq->cur_sw_cqe->start_pos == ycq->cur_sw_cqe->end_pos) {
		kfree(ycq->cur_sw_cqe);
		ycq->cur_sw_cqe = NULL;
	}
	return 0;
}

// return true if have sw cqe
static bool yib_sw_poll_cq(struct yusur_ib_dev *yib, struct yib_cq *ycq, os_ib_wc *wc_out)
{
	struct yib_sw_cqe *sw_cqe, *temp;

	if (ycq->cur_sw_cqe != NULL) {
		if (yib_cur_sw_cqe_process(yib, ycq, wc_out) != 0)
			return false;
		return true;
	}
	list_for_each_entry_safe(sw_cqe, temp, &ycq->sw_done_list, node) {
		list_del(&sw_cqe->node);
		ycq->cur_sw_cqe = sw_cqe;
		if (yib_cur_sw_cqe_process(yib, ycq, wc_out) != 0)
			return false;
		return true;
	}

	return false;
}

void yib_cq_cmpl_func(void *arg)
{
    struct yib_cq *ycq, *temp;
    struct yib_hw_events *evts = arg;
    unsigned long end = jiffies + YCQ_TASKLET_MAX_TIME_JIFFIES;
    unsigned long flags;
    
    list_for_each_entry_safe(ycq, temp, &evts->process_list, evt_comp_node) {
		os_spin_lock_irqsave(&evts->lock, flags);//If hw assure not duplicate we can remove this lock
		list_del_init(&ycq->evt_comp_node);
		os_spin_unlock_restore(&evts->lock, flags);

		ycq->int_handle++;
		// yib_dbg_info(YUSUR_IB_M_CQ, YUSUR_IB_DBG_COMP, "yib_cq_cmpl_func: cq=0x%llx\n", (u64)ycq);
		if (ycq->ib_cq.comp_handler)
			(*ycq->ib_cq.comp_handler)(&ycq->ib_cq, ycq->ib_cq.cq_context);
		yib_elem_drop_ref(&ycq->entry);
		if (time_after(jiffies, end))
			break;
	}
}

void yib_cq_err_func(void *arg)
{
    struct yib_cq *ycq, *temp;
    struct yib_hw_events *evts = arg;
    unsigned long end = jiffies + YCQ_TASKLET_MAX_TIME_JIFFIES;
    struct ib_event ev;
    
    list_for_each_entry_safe(ycq, temp, &evts->process_list, evt_err_node) {
		list_del_init(&ycq->evt_err_node);
		ycq->int_handle++;
		            
		if (ycq->ib_cq.event_handler) {
			ev.device = ycq->ib_cq.device;
			ev.element.cq = &ycq->ib_cq;
			ev.event = IB_EVENT_CQ_ERR;
			ycq->ib_cq.event_handler(&ev, ycq->ib_cq.cq_context);
		}

		yib_elem_drop_ref(&ycq->entry);
		if (time_after(jiffies, end))
			break;
	}
}

static int yib_cq_alloc_internal(struct yusur_ib_dev *yib, struct yib_cq *ycq, u32 cqe, struct ib_umem *umem, int comp_vector)
{
	u32 isize = yib->host.hw_ops.queue_ops->cqe_isize;

	os_list_init(&ycq->evt_comp_node);
	os_list_init(&ycq->evt_err_node);
	os_spin_lock_init(&ycq->cq_lock);
	os_list_init(&ycq->sw_done_list);

	yib_os_cq_cqe(ycq) = cqe;
	ycq->int_occur =  0;
	ycq->is_user = (umem == NULL)? false : true;
	ycq->comp_vector = comp_vector;

	ycq->cqid= yib_get_cq_sw_idx(ycq);
	yib_dbg_info(YUSUR_IB_M_CQ, YUSUR_IB_DBG_CREATE, "create cq:%d depth=%d isize=%d\n", 
			ycq->entry.index, cqe, isize);
	ycq->queue = yib_create_queue(&yib->host.sf, cqe, isize, umem);
	if (ycq->queue == NULL) {
		yib_dbg_err("alloc queue for cq error cqe=%d\n", cqe);
		return -ENOMEM;
	}
	ycq->queue->info = yib_frag_get_vaddr(yib->host.db_frag.cq_info, sizeof(struct yib_queue_info), yib_get_cq_sw_idx(ycq));
	yib_queue_info_init(ycq->queue->info);
	return 0;
}

#if IB_LAYER_ALLOC_CQ
int yib_cq_alloc_new(struct yusur_ib_dev *yib, struct yib_cq *ycq, u32 cqe, struct ib_umem *umem, int comp_vector)
{
	host_verbs_t *verbs = &yib->host.verbs;
	int ret = 0;

	if (yib_add_to_pool(&verbs->cq_pool, &ycq->entry) != 0) {
		os_printw(yib->dev, "add cq to pool failed\n");
		return -ENOMEM;
	}

	ret = yib_cq_alloc_internal(yib, ycq, cqe, umem, comp_vector);
	if (ret !=  0) {
		yib_elem_drop_ref(&ycq->entry);
		os_printw(yib->dev, "alloc cq failed\n");
		return ret;
	}

	return 0;
}
#else
struct yib_cq *yib_cq_alloc_new(struct yusur_ib_dev *yib, u32 cqe, struct ib_umem *umem, int comp_vector)
{
	host_verbs_t *verbs = &yib->host.verbs;
	struct yib_cq *ycq = yib_pool_alloc(&verbs->cq_pool);
	int ret;

	if (ycq == NULL) {
		os_printw(yib->dev, "alloc cq from pool failed\n");
		return NULL;
	}

	ycq->ib_cq.device = &yib->ib_dev;

	ret = yib_cq_alloc_internal(yib, ycq, cqe, umem, comp_vector);
	if (ret !=  0) {
		yib_elem_drop_ref(&ycq->entry);
		os_printw(yib->dev, "alloc cq failed\n");
		return NULL;
	}

	return ycq;
}
#endif

int yib_cq_poll(struct yusur_ib_dev *yib, struct yib_cq *ycq, int num, os_ib_wc *wc)
{
	int i;
	u8 *cqe = NULL;
	int poll_cnt = 0;
	unsigned long flags;
	struct yib_qp *qp_cache;
	qp_cache = NULL;

	os_spin_lock_irqsave(&ycq->cq_lock, flags);
	for (i = 0; i < num; i++) {
		if (ycq->cur_sw_cqe != NULL) {
			if (yib_cur_sw_cqe_process(yib, ycq, wc) != 0)
				goto next;
			yib_cq_poll_dbg_print(ycq, wc, false);
			ycq->queue->info->direct_cnt++;
			wc++;
			continue;
		}

next:
		cqe = yib_queue_get_ci_vaddr(ycq->queue);
		if (yib->host.hw_ops.queue_ops->check_cq_empty(&yib->host, ycq, cqe) == true) {
			if (yib_sw_poll_cq(yib, ycq, wc)) {
				yib_cq_poll_dbg_print(ycq, wc, false);
				ycq->queue->info->direct_cnt++;
				wc++;
				continue;
			}
			break;
		}

		yib->host.hw_ops.queue_ops->fill_cqe(&yib->host, ycq, &qp_cache, wc, cqe);
		if (unlikely(wc->status != 0))
			ycq->queue->info->err_count++;
		else
			ycq->queue->info->io_count++;

		yib_cq_poll_dbg_print(ycq, wc, true);
		yib_queue_advance_ci(ycq->queue, 1);
		wc++;
		poll_cnt++;
	}

	if (poll_cnt > 0) {
		os_smp_wmb();
		yib->host.hw_ops.queue_ops->cq_ci_db_update(&yib->host, ycq, poll_cnt);
	}
	os_spin_unlock_restore(&ycq->cq_lock, flags);
	return i;
}

//当用户态只有db时，wc为空
int yib_user_poll_cq(struct yusur_ib_dev *yib, struct yib_cq *ycq, int num, os_ib_wc *wc)
{
	bool db_only = (wc == NULL)? true : false;
	return yib->host.hw_ops.uio_ops->uio_poll_cq(&yib->host, ycq, num, (void*)wc, db_only);
}

void yib_cq_free(struct yusur_ib_dev *yib, struct yib_cq *ycq)
{
	unsigned long flags;
	yib->host.sf.sf_ops->cq_info_init(&yib->host.sf, ycq, false);

	os_spin_lock_irqsave(&ycq->cq_lock, flags);
	ycq->is_dying= true;
	os_spin_unlock_restore(&ycq->cq_lock, flags);

	yib_clear_sw_cqe_list(yib, ycq, 0, true);

	if (ycq->queue)
		yib_destroy_queue(&yib->host.sf, ycq->queue);
	
	ycq->queue = NULL;
}

struct yib_cq *yib_cq_get_from_cqc_index(struct yib_hw_host *hw, int index, bool lock)
{
	struct yib_pool_entry *elem = NULL;
	
	elem = yib_pool_get_by_index(&hw->verbs.cq_pool, index, lock);
	if (elem == NULL)
		return NULL;
	return container_of(elem, struct yib_cq, entry);
}

int yib_cq_notify(struct yusur_ib_dev *yib, struct yib_cq *ycq, enum ib_cq_notify_flags flags)
{
	int ret = 0;
	u8 *cqe = NULL;
	unsigned long irq_flags;

	u32 new_flag = (flags & IB_CQ_SOLICITED) ? 1:0;
	yib->host.sf.sf_ops->cq_notify_update(&yib->host.sf, ycq, new_flag);
	os_spin_lock_irqsave(&ycq->cq_lock, irq_flags);
	cqe = yib_queue_get_ci_vaddr(ycq->queue);
	if ((flags & IB_CQ_REPORT_MISSED_EVENTS) && !yib->host.hw_ops.queue_ops->check_cq_empty(&yib->host, ycq, cqe))
		ret = 1;
	os_spin_unlock_restore(&ycq->cq_lock, irq_flags);
	return ret;
}

void yib_run_cq_cmpl_evts(struct yib_sf *sf, struct yib_cq *ycq)
{
	bool bdup = false;

	if (ycq->ib_cq.poll_ctx == IB_POLL_DIRECT)
		return;
	yib_elem_add_ref(&ycq->entry);
	bdup = yib_hw_event_add(&sf->cq_cmpl_evts, &ycq->evt_comp_node);
	if (bdup) {
		yib_elem_drop_ref(&ycq->entry);
	}
	yib_hw_events_run(&sf->cq_cmpl_evts);
}
