#include "../include/basic.h"
#include "../include/os_api.h"
#include "../include/os_ds.h"
#include "../include/mem.h"
#include "../include/queue.h"
#include "../include/host.h"
#include "../include/verbs.h"
#include "../include/yusur_ib.h"
#include "../host/hwcomn.h"

void yib_global_resource_lock(struct yib_sf *sf, unsigned long *irq_flag)
{
	yib_aquire_hw_lock(sf, YIB_GBL_LOCK_RESOURCE);
}
void yib_global_resource_unlock(struct yib_sf *sf, unsigned long irq_flag)
{
	yib_release_hw_lock(sf, YIB_GBL_LOCK_RESOURCE);
}

void yib_sf_mutex_lock(struct yib_sf *sf)
{
	os_mutex_lock(sf->host_mutex);
}
void yib_sf_mutext_unlock(struct yib_sf *sf)
{
	os_mutex_unlock(sf->host_mutex);
}

void yusur_verbs_uninit(struct yib_hw_host *hw)
{
	yib_pool_cleanup(&hw->verbs.qp_pool);
	yib_pool_cleanup(&hw->verbs.mrw_pool);
	yib_pool_cleanup(&hw->verbs.cq_pool);
	yib_pool_cleanup(&hw->verbs.rq_pool);
	yib_pool_cleanup(&hw->verbs.pd_pool);
	yib_pool_cleanup(&hw->verbs.ah_pool);

	memset(&hw->verbs, 0, sizeof(host_verbs_t));
}

static int yusur_verbs_init(struct yib_hw_host *hw)
{
	int ret = 0;

	ret |= yib_pool_init(&hw->verbs.qp_pool, YIB_TYPE_QP, YIB_MAX_QPS, hw->caps.num_qps - 2);
	ret |= yib_pool_init(&hw->verbs.mrw_pool, YIB_TYPE_MR, YIB_MAX_MRS, hw->caps.max_mr);
	ret |= yib_pool_init(&hw->verbs.cq_pool, YIB_TYPE_CQ, YIB_MAX_CQS, hw->caps.num_cqs);
	ret |= yib_pool_init(&hw->verbs.rq_pool, YIB_TYPE_RQ, YIB_MAX_RQS, hw->caps.max_rqs);
	ret |= yib_pool_init(&hw->verbs.pd_pool, YIB_TYPE_PD, YIB_MAX_PDS, hw->caps.num_pds);
	ret |= yib_pool_init(&hw->verbs.ah_pool, YIB_TYPE_AH, YIB_MAX_AHS, hw->caps.max_ah);

	if (ret != 0) {
		os_printe(hw->dev, "yusur pool init failed");
		goto err;
	}

	return 0;
err:
	yusur_verbs_uninit(hw);
	return -ENOMEM;
}

static int yusur_sf_eq_init(struct yib_hw_host *hw)
{
	int ret = 0;
	int i = 0;
	bool use_thread = true;
	int eq_intr_num = 0;

	ret = yib_pool_init(&hw->verbs.eq_pool, YIB_TYPE_EQ, YIB_MAX_EQS, YIB_MAX_EQ_NUM);
	if (ret != 0) {
		os_printe(hw->dev, "yusur eq pool init failed");
		return -ENOMEM;
	}

	eq_intr_num = hw->sf.eq_ops->get_eq_intr_num(&hw->sf);
	if (eq_intr_num <= 0) {
		os_printw(hw->dev, "eq_intr_num is less than 0\n");
		return 0;
	}

	for (i = 0; i < eq_intr_num; i++ ) {
		if (i < hw->sf.irq_cnt)
			use_thread = false; //当中断向量不够用的时候走线程

		hw->sf.event_queue[i] =  yib_eq_alloc(&hw->sf, &hw->verbs, YIB_MAX_CQS*2, use_thread, hw->sf.irq_vector + i);
		if (hw->sf.event_queue[i] == NULL) {
			os_printe(hw->dev, "init eq:%d failed invalid\n", i);
			return -ENOMEM;
		}
	}

	return 0;
}

static void yusur_sf_eq_uninit(struct yib_hw_host *hw)
{
	int i = 0;
	int eq_intr_num = 0;

	eq_intr_num = hw->sf.eq_ops->get_eq_intr_num(&hw->sf);
	if (eq_intr_num <= 0)
		return;

	for (i = 0; i < eq_intr_num; i++) {
		if (hw->sf.event_queue[i] != NULL) {
			yib_elem_drop_ref(&hw->sf.event_queue[i]->entry);
			hw->sf.event_queue[i] = NULL;
		}
	}
	yib_pool_cleanup(&hw->verbs.eq_pool);
}

static void yusur_sw_sf_uninit(struct yib_hw_host *hw)
{
    hw->sf.sf_ops->sf_init(&hw->sf, true);
    hw->hw_ops.stop_host(hw);

	yusur_sf_eq_uninit(hw);

	yib_hw_events_cleanup(&hw->sf.cq_cmpl_evts);
	yib_hw_events_cleanup(&hw->sf.cq_err_evts);
	yib_hw_events_cleanup(&hw->sf.qp_fatal_evts);
	yib_hw_events_cleanup(&hw->sf.srq_err_evts);
	yib_hw_events_cleanup(&hw->sf.srq_lastwqe_evts);
	yib_hw_events_cleanup(&hw->sf.aeq_evts);

	if (hw->sf.sf_priv)
		os_free(hw->sf.sf_priv);

	memset(&hw->sf, 0, sizeof(struct yib_sf));
}

static int yusur_sf_init_internal(struct yib_hw_host *hw, struct yib_sf *sf)
{
	sf->sf_ops = hw->hw_ops.sf_ops;
	if (sf->sf_ops == NULL) {
		os_printe(hw->dev, "sf ops empty");
		goto err;
	}
	sf->queue_ops = hw->hw_ops.queue_ops;
	if (sf->queue_ops == NULL) {
		os_printe(hw->dev, "queue ops empty");
		goto err;
	}
	sf->eq_ops = hw->hw_ops.eq_ops;
	if (sf->eq_ops == NULL) {
		os_printe(hw->dev, "eq ops empty");
		goto err;
	}

	sf->hw = hw;
	sf->host_id = hw->host_id;
	sf->pf_id = hw->pf_id;
	sf->vf_id = hw->vf_id;
	sf->irq_cnt = hw->irq_cnt;
	sf->irq_vector = hw->irq_vector;
	sf->sf_priv = os_zalloc(sf->sf_ops->priv_size);
	if (sf->sf_priv == NULL) {
		os_printe(hw->dev, "yusur rdma sf init no mem");
		goto err;
	}

	return 0;
err:
	return -ENOMEM;
}

static int yusur_sf_init(struct yib_hw_host *hw)
{
	int ret = 0;

	yib_hw_events_init(&hw->sf.cq_cmpl_evts, yib_cq_cmpl_func, "cq_cmpl");
	yib_hw_events_init(&hw->sf.cq_err_evts, yib_cq_err_func, "cq_error");
	yib_hw_events_init(&hw->sf.qp_fatal_evts, yib_qp_fatal_func, "qp_fatal");
	yib_hw_events_init(&hw->sf.srq_err_evts, yib_srq_err_func, "srq_err");
	yib_hw_events_init(&hw->sf.srq_lastwqe_evts, yib_srq_lastwqe_func, "srq_lastwqe");
	yib_hw_events_init(&hw->sf.aeq_evts, yib_aeq_func, "aeq");

	ret = yusur_sf_init_internal(hw, &hw->sf);
	if (ret)
		goto err;

	ret = hw->sf.sf_ops->sf_pre_init(&hw->sf);
	if (ret) {
		os_printe(hw->dev, "sf_pre_init failed");
		goto err;
	}

	ret = yusur_sf_eq_init(hw);
	if (ret) {
		os_printe(hw->dev, "yusur_sf_eq_init failed");
		goto err;
	}

	ret = hw->hw_ops.start_host(hw);
	if (ret) {
		os_printe(hw->dev, "start host failed");
		goto err;
	}

	ret = hw->sf.sf_ops->sf_init(&hw->sf, false);
	if (ret) {
		os_printe(hw->dev, "sf_init failed");
		goto err;
	}

	ret = hw->hw_ops.init_caps(hw, &hw->sf);
	if (ret) {
		os_printe(hw->dev, "host init_caps failed");
		goto err;
	}

	return 0;
err:
	yusur_sw_sf_uninit(hw);
	return -ENOMEM;
}

static void yusur_sf_stop(struct yib_hw_host *hw)
{
	if (hw->sf.started)
		hw->sf.sf_ops->stop_sf(&hw->sf, false);

	hw->sf.started = false;
}

static int yusur_sf_start(struct yib_hw_host *hw)
{
	int ret = 0;
	struct yib_sf *sf = &hw->sf;

	if (sf->started == true)
		return 0;

	ret = sf->sf_ops->start_sf(sf);
	if (ret) {
		os_printe(hw->dev, "start sf failed");
		goto err;
	}

	sf->started = true;
	return 0;
err:
	return ret;
}

void yusur_core_ibdev_free(struct yusur_ib_dev *ibdev)
{
	yusur_hw_host_uinit(&ibdev->host);
	yusur_sf_stop(&ibdev->host);
	yusur_sw_sf_uninit(&ibdev->host);
	yusur_verbs_uninit(&ibdev->host);
	if (ibdev->host.hw_priv) {
		os_free(ibdev->host.hw_priv);
		ibdev->host.hw_priv = NULL;
	}
}

int yusur_core_ibdev_init(struct yusur_ib_dev *ibdev, enum yrdma_host_type host_type)
{
	int ret = 0;
	ret = yusur_hw_host_find(&ibdev->host.hw_ops, host_type);
	if (ret != 0) {
		os_printw(ibdev->dev, "Cant find host hw interface for %d", host_type);
		return -ENODEV;
	}

	ret = yusur_hw_host_pre_init(&ibdev->host);
	if (ret != 0)
		return ret;

	ret = yusur_sf_init(&ibdev->host);
	if (ret != 0) {
		os_printw(ibdev->dev, "yusur_sf_init failed");
		goto err;
	}

	ret = yusur_hw_cap_verify(&ibdev->host.caps);
	if (ret != 0) {
		os_printe(ibdev->dev, "Host cap Verify failed at:%d\n", ret);
		ret = -EINVAL;
		goto err;
	}

	ret = yusur_verbs_init(&ibdev->host);
	if (ret != 0) {
		os_printw(ibdev->dev, "yusur_verbs_init failed");
		yusur_sw_sf_uninit(&ibdev->host);
		goto err;
	}

	ret = yusur_sf_start(&ibdev->host);
	if (ret != 0) {
		os_printw(ibdev->dev, "yusur_sf_start failed");
		yusur_sw_sf_uninit(&ibdev->host);
		yusur_verbs_uninit(&ibdev->host);
		goto err;
	}

	ret = yusur_hw_host_init(&ibdev->host);
	if (ret != 0) {
		os_printw(ibdev->dev, "yusur_hw_host_init failed");
		yusur_sf_stop(&ibdev->host);
		yusur_sw_sf_uninit(&ibdev->host);
		yusur_verbs_uninit(&ibdev->host);
		goto err;
	}

	return ret;
err:
	ibdev->host.hw_ops.stop_host(&ibdev->host);
	if (ibdev->host.hw_priv) {
		os_free(ibdev->host.hw_priv);
		ibdev->host.hw_priv = NULL;
	}
	return ret;
}
