/*
//CNP包产生触发
void yib_dcqnc_limit_entry(struct yib_sf * sf, u32 qp_hwid, int cur_speed_mbps)
{
	//立即限速，
}

//硬件加一个接口，控制产生cnp eq后，多久不在产生。 
struct yib_dcqcn_stat //全局就用数组， 局部得硬件上送host_id/pf_id/vf_id (建议用全局管理的方式)
{
	u64 limit_tick; //上次限速的时间戳
	u64 last_limit_speed;
	int limited；
	
	

}  dcqcn_array[4096];


void yib_thread_dcqcn(struct yib_sf *sf)
{
	//每个1s，同步一次qp的状态。


	//for each qp: （limited == true)
        //read (cnp&speed)  cnp == 0 提速
	   
	       
}
*/
