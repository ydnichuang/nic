#include "../include/basic.h"
#include "../include/os_api.h"
#include "../include/os_ds.h"
#include "../include/mem.h"
#include "../include/queue.h"
#include "../include/host.h"
#include "../include/verbs.h"
#include "../include/yusur_ib.h"
#include "priv.h"

int yib_qp_chk_cap(struct yib_hw_host *hw, struct ib_qp_cap *cap, int has_rq, int has_sq)
{
    struct yib_roce_caps *hw_caps = &hw->caps;

	if (!has_sq) {
		if (cap->max_send_wr > hw_caps->max_qp_wr) {
			os_printw(hw->dev, "invalid send wr = %d > %d\n",
				cap->max_send_wr, hw_caps->max_qp_wr);
			goto err1;
		}

		if (cap->max_send_sge > hw_caps->max_sq_sg) {
			os_printw(hw->dev,"invalid send sge = %d > %d\n",
				cap->max_send_sge, hw_caps->max_sq_sg);
			goto err1;
		}
	}

	if (!has_rq) {
		if (cap->max_recv_wr > hw_caps->max_qp_wr) {
			os_printw(hw->dev,"invalid recv wr = %d > %d\n",
				cap->max_recv_wr, hw_caps->max_qp_wr);
			goto err1;
		}

		if (cap->max_recv_sge > hw_caps->max_rq_sg) {
			os_printw(hw->dev,"invalid recv sge = %d > %d\n",
				cap->max_recv_sge, hw_caps->max_rq_sg);
			goto err1;
		}
	}
	return 0;
err1:
	return -EINVAL;
}

static struct yib_rq *yib_alloc_rq(struct yusur_ib_dev *yib, void *parent,
		int max_recv_sge, int rq_depth, bool bqp, struct ib_umem *umem_rq)
{
	struct yib_rq *yrq = NULL;
	u32 isize = 0;

	yrq = yib_pool_alloc(&yib->host.verbs.rq_pool);
	if (yrq == NULL)
		return NULL;

	if (bqp) {
		((struct yib_qp*)parent)->type.yrq = yrq;
		yrq->bsrq = false;
		yrq->max_recv_sge = ((struct yib_qp*)parent)->cap.max_recv_sge;
	} else {
		((struct yib_srq*)parent)->yrq = yrq;
		yrq->bsrq = true;
		yrq->max_recv_sge = ((struct yib_srq*)parent)->attr.max_sge;
	}

	yrq->yib = yib;
	os_spin_lock_init(&yrq->rq_lock);

	yrq->sw_cmds = vmalloc(rq_depth * sizeof(struct yib_sw_cmd));
	if (yrq->sw_cmds == NULL) {
		yib_elem_drop_ref(&yrq->entry);
		return NULL;
	}
	memset(yrq->sw_cmds, 0, rq_depth * sizeof(struct yib_sw_cmd));
	isize = yib->host.sf.queue_ops->get_rq_item_size(&max_recv_sge);
	yib_dbg_info(YUSUR_IB_M_RQ, YUSUR_IB_DBG_CREATE, "create rq:%d depth=%d isize=%d\n", 
			yrq->entry.index, rq_depth, isize);
	yrq->queue = yib_create_queue(&yib->host.sf, rq_depth, isize, umem_rq);
	if (yrq->queue == NULL) {
		yib_dbg_err("alloc queue for rq error\n");
		yib_elem_drop_ref(&yrq->entry);
		return NULL;
	}

	yrq->queue->info = yib_frag_get_vaddr(yib->host.db_frag.rq_info, sizeof(struct yib_queue_info), yib_get_rq_sw_idx(yrq));
	yib_queue_info_init(yrq->queue->info);
	yrq->parent = parent;
	return yrq;
}

int yib_srq_init_buf(struct yusur_ib_dev *yib, struct yib_srq *ysrq, os_srq_attr *attr, struct yib_xrcd *yxrcd,
		struct ib_umem *umem_rq, struct yib_cq * ycq)
{
	struct yib_rq *yrq = NULL;
	int ret = 0;

	memcpy(&ysrq->attr, attr, sizeof(ysrq->attr));
	ysrq->limit = attr->srq_limit;
	yrq = yib_alloc_rq(yib, ysrq, attr->max_sge, attr->max_wr, false, umem_rq);
	if (yrq == NULL) {
		os_printw(yib->dev,"alloc rq for srq failed");
		return -ENOMEM;
	}

	ysrq->post_bitmap = kcalloc(BITS_TO_LONGS(attr->max_wr), sizeof(long), GFP_KERNEL);
	if (ysrq->post_bitmap == NULL) {
		os_printw(yib->dev,"alloc srq post bitmap failed");
		yib_elem_drop_ref(&yrq->entry);
		return -ENOMEM;
	}
	ysrq->db_bitmap = kcalloc(BITS_TO_LONGS(attr->max_wr), sizeof(long), GFP_KERNEL);
	if (ysrq->db_bitmap == NULL) {
		os_printw(yib->dev,"alloc srq db bitmap failed");
		yib_elem_drop_ref(&yrq->entry);
		return -ENOMEM;
	}
	ysrq->next_db = 0;
	ysrq->toggle = false;

	if (yxrcd != NULL) {
		ysrq->yrq->bxrc = 1;
		ysrq->yrq->xrcd_val = yxrcd->xrcd_val;
	}	

	if (ysrq->yrq->bxrc && ycq) {
		ysrq->yrq_cq = ycq;
		yib_elem_add_ref(&ycq->entry);
	}
	yrq->is_user = (umem_rq == NULL)? false : true;
	ret = yib->host.sf.sf_ops->rq_info_init(&yib->host.sf, yrq, true, true);
	if (ret) {
		os_printw(&yib->ib_dev.dev, "srq init rq info failed\n");
		yib_elem_drop_ref(&yrq->entry);
		return -ENOMEM;
	}
	return 0;
}

void yib_rq_free(struct yusur_ib_dev *yib, struct yib_rq *yrq)
{
	if (yrq == NULL) 
		return;

	if (yrq->bsrq) {
		struct yib_srq *ysrq = (struct yib_srq *)yrq->parent;
		if (ysrq) {
			yib->host.sf.sf_ops->rq_info_init(&yib->host.sf, yrq, false, true);
			if (ysrq->yrq_cq) {
				yib_elem_drop_ref(&ysrq->yrq_cq->entry);
				ysrq->yrq_cq = NULL;
			}
			if (ysrq->db_bitmap) {
				kfree(ysrq->db_bitmap);
				ysrq->db_bitmap = NULL;
			}
			if (ysrq->post_bitmap) {
				kfree(ysrq->post_bitmap);
				ysrq->post_bitmap = NULL;
			}
			ysrq->yrq = NULL;
#if IB_LAYER_ALLOC_SRQ == 0
			os_free(ysrq);
#endif
			yrq->parent = NULL;
		}
	} else {
		yrq->parent = NULL; //rq卸载请不要再用qp的信息了
		yib->host.sf.sf_ops->rq_info_init(&yib->host.sf, yrq, false, false);
	}

	if (yrq->queue) {
		yib_destroy_queue(&yib->host.sf, yrq->queue);
		yrq->queue = NULL;
	}

	if (yrq->sw_cmds) {
		vfree(yrq->sw_cmds);
		yrq->sw_cmds = NULL;
	}
}

/*
   软件必须保证GSI的index是1， 因此采用了控制器初始化时就分配gsi的方法来保证
    初始时只分配结构，但不关联数据
*/
#if IB_LAYER_ALLOC_QP
int yib_qp_alloc(struct yusur_ib_dev *yib, struct yib_qp *yqp, struct yib_pd *ypd, int qp_type,
				os_qp_cap *cap, struct yib_xrcd *yxrcd)
{
	int ret =0;

	if (qp_type == IB_QPT_GSI) {
		if (yib->host.sf.gsi) {
			os_printw(yib->dev, "gsi already existed");
			return EINVAL;
		}
		ret = yib_add_to_pool_special(&yib->host.verbs.qp_pool, &yqp->entry, true, 1);
	} else {
		ret = yib_add_to_pool(&yib->host.verbs.qp_pool, &yqp->entry);
	}

	if (ret != 0) {
		os_printw(yib->dev, "alloc qp failed");
		return ret;
	}

	if (qp_type == IB_QPT_GSI)
		yib->host.sf.gsi = yqp;

	if (yxrcd != NULL)
		yqp->type.xrcd_val = yxrcd->xrcd_val;

	yqp->qp_type = qp_type;
	memcpy(&yqp->cap, cap, sizeof(yqp->cap)); 
	os_list_init(&yqp->evt_fatal_node);
	yqp->attr.qp_state = IB_QPS_RESET;
	yib_os_qp_num(yqp) = yib_get_qp_sw_idx(yqp);
	yib_elem_add_ref(&ypd->entry);
	yqp->ypd = ypd;	
	return ret;
}
#else
struct yib_qp *yib_qp_alloc(struct yusur_ib_dev *yib, struct yib_pd *ypd, int qp_type,
				os_qp_cap *cap, struct yib_xrcd *yxrcd)
{
	struct yib_qp * yqp = NULL;

	if (qp_type == IB_QPT_GSI) {
		if (yib->host.sf.gsi) {
			os_printw(yib->dev, "gsi already existed");
			return NULL;
		}
		yqp = yib_pool_alloc_specify_index(&yib->host.verbs.qp_pool, 1);
	} else {
		yqp = yib_pool_alloc(&yib->host.verbs.qp_pool);
	}

	if (yqp == NULL) {
		os_printw(yib->dev, "alloc qp failed");
		return NULL;
	}

	if (qp_type == IB_QPT_GSI)
		yib->host.sf.gsi = yqp;

	if (yxrcd != NULL)
		yqp->type.xrcd_val = yxrcd->xrcd_val;

	yqp->qp_type = qp_type;
	memcpy(&yqp->cap, cap, sizeof(yqp->cap)); 
	os_list_init(&yqp->evt_fatal_node);
	yqp->attr.qp_state = IB_QPS_RESET;
	yib_os_qp_num(yqp) = yib_get_qp_sw_idx(yqp);
	if (ypd != NULL) {
		yib_elem_add_ref(&ypd->entry);
		yqp->ypd = ypd;
	}
	yqp->ib_qp.device = &yib->ib_dev;
	return yqp;
}
#endif

//This the last step of create qp
int yib_qp_attach_cq(struct yusur_ib_dev *yib, struct yib_qp *yqp, 
		      struct yib_srq *ysrq, struct yib_cq *ycq_send, struct yib_cq *ycq_recv)
{
	int ret = 0;

	yqp->yrq_cq= ycq_recv;
	yqp->ysq_cq = ycq_send;
	if (ycq_recv)
		yib_elem_add_ref(&ycq_recv->entry);
	if (ycq_send)
		yib_elem_add_ref(&ycq_send->entry);
	if((yqp->use_srq == false) && (yqp->type.yrq != NULL)) {
		ret = yib->host.sf.sf_ops->rq_info_init(&yib->host.sf, yqp->type.yrq, true, false);
		if (ret) {
			os_printw(&yib->ib_dev.dev, "qp: %d init rq info failed\n", yib_get_qp_sw_idx(yqp));
			return -ENOMEM;
		}
	}
	if (ysrq) {
		yqp->type.ysrq = ysrq;
		yib_elem_add_ref(&ysrq->yrq->entry);
	}
	return yib->host.sf.sf_ops->qp_info_init(&yib->host.sf, yqp, true);
}

void yib_qp_free(struct yusur_ib_dev *yib, struct yib_qp * yqp, struct yib_pd *ypd) 
{
	if (yqp->ysq_cq)
		yib_clear_sw_cqe_list(yib, yqp->ysq_cq, (u64)yqp, false);
	if (yqp->yrq_cq) {
		if (yqp->use_srq == false)
			yib_clear_sw_cqe_list(yib, yqp->yrq_cq, (u64)yqp->type.yrq, false);
		else
			yib_clear_sw_cqe_list(yib, yqp->yrq_cq, (u64)yqp->type.ysrq->yrq, false);
	}

	if ((yqp->use_srq == false) && (yqp->type.yrq != NULL)) {
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_DESTROY, "qp id:%d rq:%d destroyed\n",
			yib_get_qp_sw_idx(yqp), yib_get_rq_sw_idx(yqp->type.yrq));
		yib_elem_drop_ref(&yqp->type.yrq->entry);
		yqp->type.yrq = NULL;
	}

	if (yqp->use_srq && yqp->qp_type != IB_QPT_XRC_TGT) {
		if (yqp->type.ysrq->yrq != NULL) {
			yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_DESTROY, "qp id:%d srq:%d destroyed\n",
				yib_get_qp_sw_idx(yqp), yib_get_rq_sw_idx(yqp->type.ysrq->yrq));
			yib_elem_drop_ref(&yqp->type.ysrq->yrq->entry);
		}
		yqp->type.ysrq = NULL;
	}

	yib->host.sf.sf_ops->qp_info_init(&yib->host.sf, yqp, false);

	if (yqp->ysq.queue) {
		yib_destroy_queue(&yib->host.sf, yqp->ysq.queue);
		yqp->ysq.queue = NULL;
	}

	if (yqp->ysq.sw_posted) {
		vfree(yqp->ysq.sw_posted);
		yqp->ysq.sw_posted = NULL;
	}

	if (yqp->ysq.sw_cmds) {
		vfree(yqp->ysq.sw_cmds);
		yqp->ysq.sw_cmds = NULL;
	}

	yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_DESTROY, "qp sq destroyed\n");
	if (ypd)
		yib_elem_drop_ref(&ypd->entry);
		
	if (yqp->ysq_cq) {
		yib_elem_drop_ref(&yqp->ysq_cq->entry);
		yqp->ysq_cq = NULL;
	}
	if (yqp->yrq_cq) {
		yib_elem_drop_ref(&yqp->yrq_cq->entry);
		yqp->yrq_cq = NULL;
	}
}

int yib_qp_attach(struct yusur_ib_dev *yib, struct yib_qp *yqp, struct ib_umem *umem_sq, struct ib_umem *umem_rq)
{
	bool is_ud = (yqp->qp_type == IB_QPT_UD)? true : false;
	int isize = yib->host.sf.queue_ops->get_sq_item_size(&yqp->cap.max_inline_data, &yqp->cap.max_send_sge, is_ud);
	int sq_depth = yqp->cap.max_send_wr;

	yqp->is_user = (umem_sq == NULL)? false : true;

	if (yqp->cap.max_recv_wr > 0) {
		yqp->type.yrq = yib_alloc_rq(yib, yqp, yqp->cap.max_recv_sge, yqp->cap.max_recv_wr, true, umem_rq);
		if (yqp->type.yrq == NULL) {
			yib_dbg_err("alloc rq for qp error\n");
			return -ENOMEM;
		}
		yqp->use_srq = false;
	} else {
		yqp->type.yrq = NULL;
		yqp->use_srq = true;
	}
	
	os_spin_lock_init(&yqp->ysq.sq_lock);

	if (yqp->cap.max_send_wr > 0) {
		yqp->ysq.sw_cmds = vmalloc(sq_depth * sizeof(struct yib_sw_cmd));
		if (yqp->ysq.sw_cmds == NULL) {
			return -ENOMEM;
		}
		memset(yqp->ysq.sw_cmds, 0, sq_depth * sizeof(struct yib_sw_cmd));

		yqp->ysq.sw_posted = vmalloc(sq_depth * sizeof(u32));
		if (yqp->ysq.sw_posted == NULL) {
			return -ENOMEM;
		}
		memset(yqp->ysq.sw_posted, 0, sq_depth * sizeof(u32));

		yib_dbg_info(YUSUR_IB_M_SQ, YUSUR_IB_DBG_CREATE, "create sq:%d depth=%d isize=%d\n", 
			yqp->entry.index, sq_depth, isize);
		yqp->ysq.queue = yib_create_queue(&yib->host.sf, sq_depth, isize, umem_sq);
		if (yqp->ysq.queue == NULL) {
			yib_dbg_err("alloc queue for sq error\n");
			return -ENOMEM;
		}

		yqp->ysq.queue->info = yib_frag_get_vaddr(yib->host.db_frag.sq_info, sizeof(struct yib_queue_info), yib_get_qp_sw_idx(yqp));
		yib_queue_info_init(yqp->ysq.queue->info);
		yqp->valid = true;
	}
	return 0;
}

struct yib_qp *yib_qp_get_from_index(struct yib_hw_host *hw, u32 index, bool lock)
{
	struct yib_pool_entry *elem = NULL;

	elem = yib_pool_get_by_index(&hw->verbs.qp_pool, index, lock);//关键路径已经加锁
	if (elem == NULL)
		return NULL;
	return container_of(elem, struct yib_qp, entry);
}

struct yib_qp *yib_qp_get_by_id(struct yib_hw_host *hw, struct yib_qp **qp_cache, u32 index)
{
	if ((*qp_cache == NULL) || (*qp_cache)->entry.index != index) {
		*qp_cache = yib_qp_get_from_index(hw, index, false); //上层已加锁
	}

	return *qp_cache;
}

int yib_qp_chk_attr(struct yusur_ib_dev *yib, struct yib_qp *qp,
		    os_qp_attr *attr, int mask)
{
	enum ib_qp_state cur_state = (mask & IB_QP_CUR_STATE) ?
					attr->cur_qp_state : qp->attr.qp_state;
	enum ib_qp_state new_state = (mask & IB_QP_STATE) ?
					attr->qp_state : cur_state;

#if IB_MODIFY_QP_NEED_DEV_TYPE == 0
	if (!ib_modify_qp_is_ok(cur_state, new_state, qp->qp_type, mask)) {
#else
	if (!ib_modify_qp_is_ok(cur_state, new_state, qp->qp_type, mask, IB_LINK_LAYER_ETHERNET)) {
#endif		
		os_printw(yib->dev,"invalid mask or state for qp\n");
		goto err1;
	}

	if (new_state == IB_QPS_SQD) {
		os_printw(yib->dev,"current not support sqd\n");
		return -EPERM;
	}

	if (mask & IB_QP_PORT) {
		if (!rdma_is_port_valid(&yib->ib_dev, attr->port_num)) {
			os_printw(yib->dev,"invalid port %d\n", attr->port_num);
			goto err1;
		}
	}

	if (mask & IB_QP_PKEY_INDEX) {
		if (attr->pkey_index >= YUSUR_RDMA_PKEY_TABLE_LEN) {
			os_printw(yib->dev,"invalid pkey idx %d\n", attr->pkey_index);
			goto err1;
		}
	}

#if(0)
	if (mask & IB_QP_CAP)
		goto err1;
#endif

	if (mask & IB_QP_AV && yib_av_chk_attr(yib, &attr->ah_attr))
		goto err1;

	if (mask & IB_QP_ALT_PATH) {
		if (yib_av_chk_attr(yib, &attr->alt_ah_attr))
			goto err1;
		if (!rdma_is_port_valid(&yib->ib_dev, attr->alt_port_num)) {
			os_printw(yib->dev,"invalid alt port %d\n", attr->alt_port_num);
			goto err1;	
		}
	}

	if (mask & IB_QP_PATH_MTU) {
		enum ib_mtu max_mtu;
		enum ib_mtu mtu = attr->path_mtu;
		if (qp->attr.port_num == 0)
			qp->attr.port_num = 1;
		max_mtu = yib->host.ndev_info[qp->attr.port_num - 1].cur_max_mtu;
		if (mtu > max_mtu) {
			os_printw(yib->dev,"invalid mtu (%d) > (%d)\n",
				 ib_mtu_enum_to_int(mtu),
				 ib_mtu_enum_to_int(max_mtu));
			goto err1;
		}
	}
#if(0)
	if (mask & IB_QP_MAX_QP_RD_ATOMIC) {
		if (attr->max_rd_atomic > yib->host.caps.max_qp_rd_atom) {
			os_printw(yib->dev,"invalid max_rd_atomic %d > %d\n",
				attr->max_rd_atomic,
				yib->host.caps.max_qp_rd_atom);
			goto err1;
		}
	}
#endif
	return 0;

err1:
	return -EINVAL;
}

int yib_qp_to_init(struct yusur_ib_dev *yib, struct yib_qp *yqp, os_qp_init_attr *init)
{
	init->event_handler		= yqp->ib_qp.event_handler;
	init->qp_context		= yqp->ib_qp.qp_context;
	init->send_cq			= yqp->ib_qp.send_cq;
	init->recv_cq			= yqp->ib_qp.recv_cq;
	init->srq				= yqp->ib_qp.srq;

	init->cap.max_send_wr		= yqp->cap.max_send_wr;
	init->cap.max_send_sge		= yqp->cap.max_send_sge;
	init->cap.max_inline_data	= yqp->cap.max_inline_data;

	if ((yqp->use_srq == false) && (yqp->type.yrq != NULL)) {
		init->cap.max_recv_wr	= yqp->cap.max_recv_wr;
		init->cap.max_recv_sge	= yqp->cap.max_recv_sge;
	}

	init->sq_sig_type		= yqp->sq_sig_type;
	init->qp_type			= yqp->ib_qp.qp_type;
	init->port_num			= 1;
	return 0;
}

int yib_qp_to_attr(struct yusur_ib_dev *yib, struct yib_qp *yqp, os_qp_attr *attr, int mask)
{
	int ret = 0;
	*attr = yqp->attr;

	attr->cap.max_send_wr			= yqp->cap.max_send_wr;
	attr->cap.max_send_sge			= yqp->cap.max_send_sge;
	attr->cap.max_inline_data		= yqp->cap.max_inline_data;

	if ((yqp->use_srq == false) && (yqp->type.yrq != NULL)) {
		attr->cap.max_recv_wr		= yqp->cap.max_recv_wr;
		attr->cap.max_recv_sge		= yqp->cap.max_recv_sge;
	}

	yib_av_to_attr(&yqp->pri_av, &attr->ah_attr);
	yib_av_to_attr(&yqp->alt_av, &attr->alt_ah_attr);

	ret = yib->host.sf.sf_ops->qp_query(&yib->host.sf, yqp, attr, mask, false);
	if (ret)
		os_printw(yib->dev,"qp query failed");
	return ret;
}

static void yib_qp_print_state(struct yusur_ib_dev *yib, struct yib_qp *qp, os_qp_attr *attr)
{
	switch (attr->qp_state) {
		case IB_QPS_RESET:
			yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY,
				"qp#%d state -> RESET\n", yib_get_qp_sw_idx(qp));
			break;

		case IB_QPS_INIT:
			yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY,
				"qp#%d state -> INIT\n", yib_get_qp_sw_idx(qp));
			break;

		case IB_QPS_RTR:
			yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY,
				"qp#%d state -> RTR\n", yib_get_qp_sw_idx(qp));
			break;

		case IB_QPS_RTS:
			yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "qp#%d state -> RTS\n", yib_get_qp_sw_idx(qp));
			break;

		case IB_QPS_SQD:
			yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "qp#%d state -> SQD\n", yib_get_qp_sw_idx(qp));
			//rxe_qp_drain(qp); todo drain
			break;

		case IB_QPS_SQE:
			yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "qp#%d state -> SQE !!?\n", yib_get_qp_sw_idx(qp));
			/* Not possible from modify_qp. */
			break;

		case IB_QPS_ERR:
			yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY, "qp#%d state -> ERR\n", yib_get_qp_sw_idx(qp));
			//todo we need check internal qp is error or not, if not, we return -EINVAL
			break;
	}
}

void yib_qp_reset_sqd(struct yib_qp *qp)
{
	unsigned long flags;
	os_spin_lock_irqsave(&qp->ysq.sq_lock, flags);
	qp->attr.sq_draining = 0;
	os_spin_unlock_restore(&qp->ysq.sq_lock, flags);
}

int yib_qp_from_attr(struct yusur_ib_dev *yib, struct yib_qp *qp, os_qp_attr *attr, int mask,
			u32 cir, u32 cbs)
{
	os_qp_attr old_attr;
	struct yib_av old_av;
	bool ret = true;

	yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY,
				"qp: %d modify\n", yib_get_qp_sw_idx(qp));

	memcpy(&old_attr, &qp->attr, sizeof(os_qp_attr));
	memcpy(&old_av, &qp->pri_av, sizeof(struct yib_av));
	if (mask & IB_QP_MAX_QP_RD_ATOMIC) {
		int max_rd_atomic = attr->max_rd_atomic ?
			roundup_pow_of_two(attr->max_rd_atomic) : 0;

		qp->attr.max_rd_atomic = max_rd_atomic;
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY,
			"qp: %d max_rd_atomic = %d\n", yib_get_qp_sw_idx(qp),
			 qp->attr.max_rd_atomic);
	}

	if (mask & IB_QP_MAX_DEST_RD_ATOMIC) {
		int max_dest_rd_atomic = attr->max_dest_rd_atomic ?
			roundup_pow_of_two(attr->max_dest_rd_atomic) : 0;

		qp->attr.max_dest_rd_atomic = max_dest_rd_atomic;
		//our hw not support
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY,
			"qp: %d max_dest_rd_atomic = %d\n", yib_get_qp_sw_idx(qp),
			 qp->attr.max_dest_rd_atomic);
	}

	if (mask & IB_QP_CUR_STATE) {
		qp->attr.cur_qp_state = attr->qp_state;
	}

	if (mask & IB_QP_EN_SQD_ASYNC_NOTIFY)
		qp->attr.en_sqd_async_notify = attr->en_sqd_async_notify;

	if (mask & IB_QP_ACCESS_FLAGS)
		qp->attr.qp_access_flags = attr->qp_access_flags;

	if (mask & IB_QP_PKEY_INDEX) 
		qp->attr.pkey_index = attr->pkey_index;

	if (mask & IB_QP_PORT)
		qp->attr.port_num = attr->port_num;

	if (mask & IB_QP_QKEY)
		qp->attr.qkey = attr->qkey;

	if (mask & IB_QP_AV) {
		yib_init_av(yib, &attr->ah_attr, &qp->pri_av);
	}

	if (mask & IB_QP_ALT_PATH) {
		yib_init_av(yib, &attr->alt_ah_attr, &qp->alt_av);
		qp->attr.alt_port_num = attr->alt_port_num;
		qp->attr.alt_pkey_index = attr->alt_pkey_index;
		qp->attr.alt_timeout = attr->alt_timeout;
	}

	if (mask & IB_QP_PATH_MTU) {
		qp->attr.path_mtu = attr->path_mtu;
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY,
			"qp: %d path_mtu = %d\n", yib_get_qp_sw_idx(qp),
			 qp->attr.path_mtu);
	}

	if (mask & IB_QP_TIMEOUT) {
		qp->attr.timeout = attr->timeout;
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY,
			"qp: %d timeout= %d\n", yib_get_qp_sw_idx(qp),
			 qp->attr.timeout);		
	}

	if (mask & IB_QP_RETRY_CNT) {
		qp->attr.retry_cnt = attr->retry_cnt;
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY,
			"qp: %d set retry count = %d\n", yib_get_qp_sw_idx(qp),
			 attr->retry_cnt);
	}

	if (mask & IB_QP_RNR_RETRY) {
		qp->attr.rnr_retry = attr->rnr_retry;
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY,
			"qp: %d set rnr retry count = %d\n", yib_get_qp_sw_idx(qp),
			 attr->rnr_retry);
	}

	if (mask & IB_QP_RQ_PSN) {
		qp->attr.rq_psn = attr->rq_psn & 0xFFFFFF;
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY,
			"qp: %d set resp psn = 0x%x\n", yib_get_qp_sw_idx(qp), qp->attr.rq_psn);
	}

	if (mask & IB_QP_MIN_RNR_TIMER) {
		qp->attr.min_rnr_timer = attr->min_rnr_timer;
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY,
			 "qp: %d set min rnr timer = 0x%x\n", yib_get_qp_sw_idx(qp), attr->min_rnr_timer);
	}

	if (mask & IB_QP_SQ_PSN) {
		qp->attr.sq_psn = attr->sq_psn; 
		yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY,
			 "qp: %d set req psn = 0x%x\n", yib_get_qp_sw_idx(qp), qp->attr.sq_psn);
	}

	if (mask & IB_QP_PATH_MIG_STATE)
		qp->attr.path_mig_state = attr->path_mig_state;

	if (mask & IB_QP_DEST_QPN)
		qp->attr.dest_qp_num = attr->dest_qp_num;

	if (mask & IB_QP_RATE_LIMIT) {
		qp->attr.rate_limit = attr->rate_limit;

		if ((cir != 0) && (cbs != 0)) {
			if (attr->rate_limit) {
				struct yib_rdma_qos_info qos_info;
				qos_info.cir = cir;
				qos_info.cbs = cbs;
				qos_info.level = 1;
				qos_info.obj_index = yib_get_qp_sw_idx(qp);
				qos_info.is_multi_mode = 0;
				qos_info.inherit_mode = 0;
				qos_info.bypass = 0;
				ret = yib->host.hw_ops.set_qos(&yib->host, &qos_info);
				if (ret) {
					yib_dbg_err("qp: %d set_qos err\n", yib_get_qp_sw_idx(qp));
					return -EINVAL;
				}
				yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_MODIFY,
					"qp: %d set rate limit cir: %d, cbs: %d\n", yib_get_qp_sw_idx(qp), cir, cbs);
			} else {
				yib_dbg_err("qp: %d set rate limit err\n", yib_get_qp_sw_idx(qp));
				return -EINVAL;
			}
		}
	}

	if (mask & IB_QP_STATE) {
		unsigned long flags = 0;
		unsigned long flags2 = 0;
		int rq_lck = 0;
	
		if (attr->qp_state == qp->attr.qp_state) {
			ret = yib->host.sf.sf_ops->qp_info_update(&yib->host.sf, qp, mask, 0);
			if (ret == false)
				goto err;
			return 0;
		}
		yib_qp_print_state(yib, qp, attr);

		os_spin_lock_irqsave(&qp->ysq.sq_lock, flags);
		switch (attr->qp_state) {
		case IB_QPS_RESET:
			if ((qp->use_srq == false) && (qp->type.yrq != NULL)) {
				rq_lck = 1;
				os_spin_lock_irqsave(&qp->type.yrq->rq_lock, flags2);
				os_atomic_set(&qp->type.yrq->queue->info->pi, 0);
				os_atomic_set(&qp->type.yrq->queue->info->ci, 0);//this is done by hw or sw todo todo
			}
			mask = 0; //no need to handle other change
			//硬件会重置pi=ci=0,停止所有处理，软件也要保证mem和ddr中的指针清0
			os_atomic_set(&qp->ysq.queue->info->pi, 0);
			os_atomic_set(&qp->ysq.queue->info->ci, 0);
			break;

		case IB_QPS_INIT: //无特殊处理
			break;

		case IB_QPS_RTR://无特殊处理
			break;

		case IB_QPS_RTS://无特殊处理			
			break;

		case IB_QPS_SQD:
			qp->attr.sq_draining = 1;
			break;

		case IB_QPS_SQE: //modify qp 不支持该状态，可以不处理
			break;

		case IB_QPS_ERR://目前期望硬件能做成： 设置err后， 错误完成所有已提交的wr.新提交的也能错误完成
			if ((qp->use_srq == false) && (qp->type.yrq != NULL)) {
				rq_lck = 1;
				os_spin_lock_irqsave(&qp->type.yrq->rq_lock, flags2);
			}		
			mask = 0;
			break;
		}
		qp->attr.qp_state = attr->qp_state;
		if (rq_lck) {			
			os_spin_unlock_restore(&qp->type.yrq->rq_lock, flags2);
		}		
		os_spin_unlock_restore(&qp->ysq.sq_lock, flags);
		ret = yib->host.sf.sf_ops->qp_info_update(&yib->host.sf, qp, mask, true);
		if (ret == false)
			goto err;
		qp->attr.cur_qp_state = attr->qp_state;	
		return 0;
	}
	
	return 0;
err:
	memcpy(&qp->attr, &old_attr, sizeof(os_qp_attr));
	memcpy(&qp->pri_av, &old_av, sizeof(struct yib_av));
	return -EINVAL;
}

#define YQP_TASKLET_MAX_TIME_JIFFIES msecs_to_jiffies(4)
void yib_qp_fatal_func(void *arg)
{
	struct yib_qp *yqp, *temp;
	struct yib_hw_events *evts = arg;
	struct ib_event event;
	unsigned long end = jiffies + YQP_TASKLET_MAX_TIME_JIFFIES;

	list_for_each_entry_safe(yqp, temp, &evts->process_list, evt_fatal_node) {
		list_del_init(&yqp->evt_fatal_node);
		event.device = yqp->ib_qp.device;
		event.element.qp = &yqp->ib_qp;
		event.event = IB_EVENT_QP_FATAL;
		if (yqp->ib_qp.event_handler)
			yqp->ib_qp.event_handler(&event, yqp->ib_qp.qp_context);

		yib_elem_drop_ref(&yqp->entry);
		if (time_after(jiffies, end))
			break;
	}
}

int yib_packet_hdr_fill(struct yusur_ib_dev *yib, struct yib_av *av, u8 *buf, u32 datlen)
{
	bool is_udp = true, is_eth = true, is_grh = false;
	int ip_version = 0;
	int eth_type;
	int size = 0;
	struct ib_ud_header ud_hdr;
	os_net_device *ndev = yib_get_netdev(&yib->ib_dev, 1);


	if (av->network_type == RDMA_NETWORK_IPV6) {
		ip_version = 6;
		eth_type =  ETH_P_IPV6;
	} else {
		ip_version = 4;
		eth_type =  ETH_P_IP;
	}

	ib_ud_header_init(datlen, !is_eth, is_eth, false, is_grh,
		ip_version, is_udp, 0, &ud_hdr);

	/* MAC should be in BE */
	ether_addr_copy(ud_hdr.eth.dmac_h, av->dmac);
	ether_addr_copy(ud_hdr.eth.smac_h, ndev->dev_addr);
	ud_hdr.eth.type = cpu_to_be16(eth_type);

	if (ip_version == 4) {
		ud_hdr.ip4.id = 0;
		ud_hdr.ip4.frag_off = htons(IP_DF);
		ud_hdr.ip4.ttl = av->grh.hop_limit;
		ud_hdr.ip4.tos = av->grh.traffic_class;
		memcpy(&ud_hdr.ip4.daddr, av->grh.dgid.raw + 12, 4);
		memcpy(&ud_hdr.ip4.saddr, av->sgid.raw + 12, 4);//让ip变化时,gsi发送不受影响,从上层取sip,这样ip可以自动变过来
		ud_hdr.ip4.check = ib_ud_ip4_csum(&ud_hdr);
	} else {
		ud_hdr.grh.hop_limit = av->grh.hop_limit;;
		ud_hdr.grh.traffic_class = av->grh.traffic_class;
		ud_hdr.grh.flow_label= av->grh.flow_label;
		ud_hdr.grh.destination_gid = av->grh.dgid;
		memcpy(&ud_hdr.grh.source_gid, 
		&av->sgid, sizeof(union ib_gid));
	}

	if (is_udp) {
		ud_hdr.udp.dport = htons(ROCE_V2_UDP_DPORT);
		ud_hdr.udp.sport = htons(yib->host.sf.udp_port);
		ud_hdr.udp.csum = 0;
	}

	size = ib_ud_header_pack(&ud_hdr, buf);
	return size;
}
