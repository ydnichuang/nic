#include "../include/basic.h"
#include "../include/os_api.h"
#include "../include/os_ds.h"
#include "../include/mem.h"
#include "../include/queue.h"
#include "../include/host.h"
#include "../include/verbs.h"
#include "../include/yusur_ib.h"
#include "../include/user.h"

void mem_dbg_print_range(const char *title, struct yib_hw_host *hw, u32 key)
{
	printk("#########%s begin#######\n", title);
#if(0)
	for (i = 0; i < len; i+= 4) {

printk("offset (0x%llx): 0x%08X 0x%08X 0x%08X 0x%08X\n",
		   offset+i*4, yib_read_ddrl(hw, offset +   i*4),
		  (len> (i+1))? yib_read_ddrl(hw, offset +   i*4+4):0,
		  (len> (i+2))? yib_read_ddrl(hw, offset +   i*4+8):0,
		  (len> (i+3))? yib_read_ddrl(hw, offset +   i*4+12):0);
	}
#endif
	printk("########%s end######\n", title);
}

//len 为32bits个数
void reg_dbg_print_range(const char *title, void *vaddr, u32 len, u64 paddr)
{
	u32 i = 0;
	printk("#########%s begin#######\n", title);
	for (i = 0; i < len; i+= 4) {
		printk("va(0x%llx):pa(0x%llx): 0x%08X 0x%08X 0x%08X 0x%08X\n",
		 (u64)(vaddr + i*4), paddr + i*4, readl(vaddr +   i*4),
		  (len> (i+1))? readl(vaddr + i*4 +4):0,
		  (len> (i+2))? readl(vaddr + i*4 +8):0,
		  (len> (i+3))? readl(vaddr + i*4 +12):0);
	}
	printk("########%s end######\n", title);
}

void reg_dbg_print_eq(struct yusur_ib_dev *yib, struct yib_eq *yeq)
{
	yib_dbg_info(YUSUR_IB_M_EQ, YUSUR_IB_DBG_CREATE, "######### EQ dbg_print BEGIN #######\n");
	yib_dbg_info(YUSUR_IB_M_EQ, YUSUR_IB_DBG_CREATE, "eqid:%d: use_thread:%d\n",
		yeq->entry.index, yeq->use_thread);
	yib_dbg_info(YUSUR_IB_M_EQ, YUSUR_IB_DBG_CREATE, "int_vector:%d  assign_irq:%d  int_cnt:%d\n",
		yeq->int_vector, yeq->assign_irq, yeq->int_cnt);
	yib_dbg_info(YUSUR_IB_M_EQ, YUSUR_IB_DBG_CREATE, "######### EQ dbg_print END #######\n");
}

void reg_dbg_print_srq(struct yusur_ib_dev *yib, struct yib_srq *ysrq)
{
	struct yib_rq *yrq = ysrq->yrq;
	yib_dbg_info(YUSUR_IB_M_RQ, YUSUR_IB_DBG_CREATE, "######### SRQ dbg_print BEGIN #######\n");
	yib_dbg_info(YUSUR_IB_M_RQ, YUSUR_IB_DBG_CREATE, "rqid:%d: is_srq:%d  pi:%d  ci:%d  io_cnt:%lld  err_cnt:%lld  direct_cnt:%d\n",
		yrq->entry.index, yrq->bsrq?1:0, os_atomic_read(&yrq->queue->info->pi), os_atomic_read(&yrq->queue->info->pi),
		yrq->queue->info->io_count, yrq->queue->info->err_count, yrq->queue->info->direct_cnt);
	yib_dbg_info(YUSUR_IB_M_RQ, YUSUR_IB_DBG_CREATE, "tbl_levels:%d  rq_depth:%d  pbl_size:%d  page_size:%d\n",
		yrq->queue->tbl.levels, yrq->queue->depth, yrq->queue->tbl.pg_size, yrq->queue->tbl.pbl_pg_size);
	yib_dbg_info(YUSUR_IB_M_RQ, YUSUR_IB_DBG_CREATE, "pb1_pa_lsb:0x%X  pbl_pa_msb:0x%X\n",
		u64_lsb(yrq->queue->tbl.root_pa), u64_msb(yrq->queue->tbl.root_pa));
	yib_dbg_info(YUSUR_IB_M_RQ, YUSUR_IB_DBG_CREATE, "######### SRQ dbg_print END #######\n");
}

void reg_dbg_print_sf(struct yusur_ib_dev *yib)
{
	struct yib_sf *sf = &yib->host.sf;
	yib_dbg_info(YUSUR_IB_M_HOST_CMN, YUSUR_IB_DBG_CREATE, "######### SF dbg_print BEGIN #######\n");
	yib_dbg_info(YUSUR_IB_M_HOST_CMN, YUSUR_IB_DBG_CREATE, "started:%d bonding:%d\n",
		sf->started, sf->bonding);
	yib_dbg_info(YUSUR_IB_M_HOST_CMN, YUSUR_IB_DBG_CREATE, "reg_base:0x%08X  bar_size:%d  num_node:%d  udp_port:%d\n",
		sf->reg_base[0], sf->bar_size[0], sf->num_node, sf->udp_port);
	yib_dbg_info(YUSUR_IB_M_HOST_CMN, YUSUR_IB_DBG_CREATE, "vf_id:%d  pf_id:%d  host_id:%d  irq_vector:%d  irq_cnt\n",
		sf->vf_id, sf->pf_id, sf->host_id, sf->irq_vector, sf->irq_cnt);
	yib_dbg_info(YUSUR_IB_M_HOST_CMN, YUSUR_IB_DBG_CREATE, "cq_cmpl_evts:%d  cq_err_evts:%d  qp_fatal_evts:%d\n",
		sf->cq_cmpl_evts, sf->cq_err_evts, sf->qp_fatal_evts);
	yib_dbg_info(YUSUR_IB_M_HOST_CMN, YUSUR_IB_DBG_CREATE, "srq_err_evts:%d  srq_lastwqe_evts:%d  aeq_evts:%d\n",
		sf->srq_err_evts, sf->srq_lastwqe_evts, sf->aeq_evts);
	yib_dbg_info(YUSUR_IB_M_HOST_CMN, YUSUR_IB_DBG_CREATE, "######### SF dbg_print END #######\n");
}

void reg_dbg_print_qp(struct yusur_ib_dev *yib, struct yib_qp *yqp)
{
	struct yib_sq *ysq = &yqp->ysq;
	struct yib_rq *yrq = (yqp->use_srq)? yqp->type.ysrq->yrq : yqp->type.yrq;

	yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_CREATE, "######### QP dbg_print BEGIN #######\n");
	yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_CREATE, "qpid:%d: state:%d  type:%d  sig:%d  user:%d  pdnum:%d\n",
		yqp->entry.index, yqp->attr.qp_state, yqp->qp_type, yqp->sq_sig_type, yqp->is_user, yqp->ypd->entry.index);

	yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_CREATE, "----------SQ INFO----------\n");
	yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_CREATE, "pi:%d  ci:%d  io_cnt:%lld  err_cnt:%lld  direct_cnt:%d\n",
		os_atomic_read(&ysq->queue->info->pi), os_atomic_read(&ysq->queue->info->pi),
		ysq->queue->info->io_count, ysq->queue->info->err_count, ysq->queue->info->direct_cnt);
	yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_CREATE, "tbl_levels:%d  sq_depth:%d  pbl_size:%d  page_size:%d\n",
		ysq->queue->tbl.levels, ysq->queue->depth, ysq->queue->tbl.pg_size, ysq->queue->tbl.pbl_pg_size);
	yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_CREATE, "pb1_pa_lsb:0x%X  pbl_pa_msb:0x%X\n",
		u64_lsb(ysq->queue->tbl.root_pa), u64_msb(ysq->queue->tbl.root_pa));

	yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_CREATE, "----------RQ INFO----------\n");
	yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_CREATE, "rqid:%d: is_srq:%d  pi:%d  ci:%d  io_cnt:%lld  err_cnt:%lld  direct_cnt:%d\n",
		yrq->entry.index, yrq->bsrq?1:0, os_atomic_read(&yrq->queue->info->pi), os_atomic_read(&yrq->queue->info->pi),
		yrq->queue->info->io_count, yrq->queue->info->err_count, yrq->queue->info->direct_cnt);
	yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_CREATE, "tbl_levels:%d  rq_depth:%d  pbl_size:%d  page_size:%d\n",
		yrq->queue->tbl.levels, yrq->queue->depth, yrq->queue->tbl.pg_size, yrq->queue->tbl.pbl_pg_size);
	yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_CREATE, "pb1_pa_lsb:0x%X  pbl_pa_msb:0x%X\n",
		u64_lsb(yrq->queue->tbl.root_pa), u64_msb(yrq->queue->tbl.root_pa));

	yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_CREATE, "######### QP dbg_print END #######\n");
}

void reg_dbg_print_cq(struct yusur_ib_dev *yib, struct yib_cq *ycq)
{
	yib_dbg_info(YUSUR_IB_M_CQ, YUSUR_IB_DBG_CREATE, "######### CQ dbg_print BEGIN #######\n");
	yib_dbg_info(YUSUR_IB_M_CQ, YUSUR_IB_DBG_CREATE, "cqid:%d: cnt=%d  user:%d  dying:%d\n",
		ycq->entry.index, yib_os_cq_cqe(ycq), ycq->is_user, ycq->is_dying);
	yib_dbg_info(YUSUR_IB_M_CQ, YUSUR_IB_DBG_CREATE, "cqint occur:%llx  handle:%llx  dup:%llx\n",
		ycq->int_occur, ycq->int_handle, ycq->int_dup);
	yib_dbg_info(YUSUR_IB_M_CQ, YUSUR_IB_DBG_CREATE, "pi:%d  ci:%d  io_cnt:%lld  err_cnt:%lld  direct_cnt:%d\n",
		os_atomic_read(&ycq->queue->info->pi), os_atomic_read(&ycq->queue->info->ci),
		ycq->queue->info->io_count, ycq->queue->info->err_count, ycq->queue->info->direct_cnt);
	yib_dbg_info(YUSUR_IB_M_CQ, YUSUR_IB_DBG_CREATE, "tbl_levels:%d  cq_depth:%d  pbl_size:%d  page_size:%d\n",
		ycq->queue->tbl.levels, ycq->queue->depth, ycq->queue->tbl.pg_size, ycq->queue->tbl.pbl_pg_size);
	yib_dbg_info(YUSUR_IB_M_CQ, YUSUR_IB_DBG_CREATE, "pb1_pa_lsb:0x%X  pbl_pa_msb:0x%X\n",
		u64_lsb(ycq->queue->tbl.root_pa), u64_msb(ycq->queue->tbl.root_pa));
	yib_dbg_info(YUSUR_IB_M_CQ, YUSUR_IB_DBG_CREATE, "######### CQ dbg_print END #######\n");
}

void reg_dbg_print_mr(struct yusur_ib_dev *yib, struct yib_mr *ymr)
{
	yib_dbg_info(YUSUR_IB_M_MR, YUSUR_IB_DBG_CREATE, "######### MR dbg_print BEGIN #######\n");
	yib_dbg_info(YUSUR_IB_M_MR, YUSUR_IB_DBG_CREATE, "mrid:%d: dma:%d  mapped:%d  user:%d  va=%llx\n",
		ymr->entry.index, ymr->type.is_dma, ymr->type.is_mw, ymr->type.is_user, yib_os_mr_iova(ymr));
	yib_dbg_info(YUSUR_IB_M_MR, YUSUR_IB_DBG_CREATE, "######### MR dbg_print BEGIN #######\n");
}
