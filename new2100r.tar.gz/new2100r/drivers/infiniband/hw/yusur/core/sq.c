#include "../include/basic.h"
#include "../include/os_api.h"
#include "../include/os_ds.h"
#include "../include/mem.h"
#include "../include/queue.h"
#include "../include/host.h"
#include "../include/verbs.h"
#include "../include/yusur_ib.h"
#include "priv.h"

struct yib_wr_opcode_info yib_wr_opcode_info[] = { //IB_WR_REG_MR + 1
	[IB_WR_RDMA_WRITE]				= {
		.name	= "IB_WR_RDMA_WRITE",
		.mask	= {
			[IB_QPT_RC]	= WR_INLINE_MASK | WR_WRITE_MASK,
			[IB_QPT_UC] = WR_INLINE_MASK | WR_WRITE_MASK,
			[IB_QPT_XRC_INI] = WR_INLINE_MASK | WR_WRITE_MASK,
		},
	},
	[IB_WR_RDMA_WRITE_WITH_IMM]			= {
		.name	= "IB_WR_RDMA_WRITE_WITH_IMM",
		.mask	= {
			[IB_QPT_RC]	= WR_INLINE_MASK | WR_WRITE_MASK,
			[IB_QPT_UC] = WR_INLINE_MASK | WR_WRITE_MASK,
			[IB_QPT_XRC_INI] = WR_INLINE_MASK | WR_WRITE_MASK,
		},
	},
	[IB_WR_SEND]					= {
		.name	= "IB_WR_SEND",
		.mask	= {
			[IB_QPT_GSI]	= WR_INLINE_MASK | WR_SEND_MASK,
			[IB_QPT_RC]	= WR_INLINE_MASK | WR_SEND_MASK,
			[IB_QPT_UC] = WR_INLINE_MASK | WR_SEND_MASK,
			[IB_QPT_UD]	= WR_INLINE_MASK | WR_SEND_MASK,
			[IB_QPT_XRC_INI] = WR_INLINE_MASK | WR_SEND_MASK,
		},
	},
	[IB_WR_SEND_WITH_IMM]				= {
		.name	= "IB_WR_SEND_WITH_IMM",
		.mask	= {
			[IB_QPT_GSI]	= WR_INLINE_MASK | WR_SEND_MASK,
			[IB_QPT_RC]	= WR_INLINE_MASK | WR_SEND_MASK,
			[IB_QPT_UC]	= WR_INLINE_MASK | WR_SEND_MASK,
			[IB_QPT_UD]	= WR_INLINE_MASK | WR_SEND_MASK,
			[IB_QPT_XRC_INI] = WR_INLINE_MASK | WR_SEND_MASK,
		},
	},
	[IB_WR_RDMA_READ]				= {
		.name	= "IB_WR_RDMA_READ",
		.mask	= {
			[IB_QPT_RC]	= WR_READ_MASK,
			[IB_QPT_XRC_INI] = WR_READ_MASK,
		},
	},
	[IB_WR_ATOMIC_CMP_AND_SWP]			= {
		.name	= "IB_WR_ATOMIC_CMP_AND_SWP",
		.mask	= {
			[IB_QPT_RC]	= WR_ATOMIC_MASK,
			[IB_QPT_XRC_INI] = WR_ATOMIC_MASK,
		},
	},
	[IB_WR_ATOMIC_FETCH_AND_ADD]			= {
		.name	= "IB_WR_ATOMIC_FETCH_AND_ADD",
		.mask	= {
			[IB_QPT_RC]	= WR_ATOMIC_MASK,
			[IB_QPT_XRC_INI] = WR_ATOMIC_MASK,
		},
	},
	[IB_WR_SEND_WITH_INV]				= {
		.name	= "IB_WR_SEND_WITH_INV",
		.mask	= {
			[IB_QPT_RC]	= WR_INLINE_MASK | WR_SEND_MASK,
			[IB_QPT_XRC_INI] = WR_INLINE_MASK | WR_SEND_MASK,
		},
	},
	[IB_WR_RDMA_READ_WITH_INV]			= {
		.name	= "IB_WR_RDMA_READ_WITH_INV",
		.mask	= {
			[IB_QPT_RC]	= WR_READ_MASK,
			[IB_QPT_UC]	= WR_READ_MASK,
			[IB_QPT_XRC_INI]	= WR_READ_MASK,
		},
	},
	[IB_WR_LOCAL_INV]				= {
		.name	= "IB_WR_LOCAL_INV",
		.mask	= {
			[IB_QPT_RC]	= WR_REG_MASK ,
			[IB_QPT_XRC_INI]	= WR_REG_MASK ,
		},
	},
	[IB_WR_REG_MR]					= {
		.name	= "IB_WR_REG_MR",
		.mask	= {
			[IB_QPT_RC]	= WR_REG_MASK,
			[IB_QPT_XRC_INI]	= WR_REG_MASK,
		},
	},
};

static enum ib_wc_opcode yib_wr_to_wc_opcode(enum ib_wr_opcode opcode)
{
	switch (opcode) {
	case IB_WR_RDMA_WRITE:			return IB_WC_RDMA_WRITE;
	case IB_WR_RDMA_WRITE_WITH_IMM:		return IB_WC_RDMA_WRITE;
	case IB_WR_SEND:			return IB_WC_SEND;
	case IB_WR_SEND_WITH_IMM:		return IB_WC_SEND;
	case IB_WR_RDMA_READ:			return IB_WC_RDMA_READ;
	case IB_WR_ATOMIC_CMP_AND_SWP:		return IB_WC_COMP_SWAP;
	case IB_WR_ATOMIC_FETCH_AND_ADD:	return IB_WC_FETCH_ADD;
	case IB_WR_LSO:				return IB_WC_LSO;
	case IB_WR_SEND_WITH_INV:		return IB_WC_SEND;
	case IB_WR_RDMA_READ_WITH_INV:		return IB_WC_RDMA_READ;
	case IB_WR_LOCAL_INV:			return IB_WC_LOCAL_INV;
	case IB_WR_REG_MR:			return IB_WC_REG_MR;
#ifdef IB_HAS_BIND_MW
	case IB_WR_BIND_MW:			return IB_WC_BIND_MW;
#endif

	default:
		return 0xff;
	}
}

static int validate_send_wr(struct yib_hw_host *hw, struct yib_qp *yqp, const os_ib_send_wr *ibwr,
			    u32 mask, u32 length)
{
	int num_sge = ibwr->num_sge;

	if (ibwr->opcode > IB_WR_REG_MR)
		goto err1;

	if (unlikely(num_sge > yqp->cap.max_send_sge))
		goto err1;

	if (unlikely(mask & WR_ATOMIC_MASK)) {
		if (length < 8) {
			os_printw(hw->dev,"atomic op should be 8 byte\n");
			goto err1;
		}

		if (atomic_wr((const_ os_ib_send_wr*)ibwr)->remote_addr & 0x7) {
			os_printw(hw->dev,"atomic op should be 8 byte align\n");
			goto err1;
		}
	}

	if (unlikely((ibwr->send_flags & IB_SEND_INLINE) &&
		(length > yqp->cap.max_inline_data))) {
		os_printw(hw->dev,"inline length should less than:%d\n", yqp->cap.max_inline_data);
		goto err1;
	}

	if (unlikely((ibwr->send_flags & IB_SEND_INLINE) &&
				!(mask & WR_INLINE_MASK))) {
		os_printw(hw->dev, "qpid:%d op:%d not support inline\n",
				yib_get_qp_sw_idx(yqp), ibwr->opcode);
		goto err1;
	}
	return 0;
err1:
	return -EINVAL;
}

int yib_send_wr_check(struct yib_hw_host *hw, struct yib_qp *yqp, const os_ib_send_wr *ibwr, u32 *mask, u32 *length)
{
	int err = 0;
	int i;

	*mask = yib_wr_opcode_info[ibwr->opcode].mask[yqp->qp_type];
	if (unlikely(!mask)) {
		os_printw(hw->dev, "qpid:%d op:%d invalid\n",
			 yib_get_qp_sw_idx(yqp), ibwr->opcode);
		err = -EINVAL;
		goto exit;
	}

	for (i = 0; i < ibwr->num_sge; i++)
		*length += ibwr->sg_list[i].length;

	err = validate_send_wr(hw, yqp, ibwr, *mask, *length);
	if (unlikely(err))
		goto exit;
	
	return 0;
exit:
	return err;
}

//对应文档6.4.2中case2，在aeq中调用
void yib_aeq_generate_sq_sw_cqe(struct yib_sf *sf, struct yib_qp *yqp)
{
	unsigned long  flags;
	struct yib_sq *ysq = &yqp->ysq;
	struct yib_sw_cqe input_sw_cqe;

	if (sf->hw->funcs.quick_excep == 0)
		return;

	input_sw_cqe.type = YIB_CQE_SQ;
	input_sw_cqe.status = IB_WC_WR_FLUSH_ERR;
	input_sw_cqe.depth = ysq->queue->depth;
	input_sw_cqe.handler = (u64)yqp;

	os_spin_lock_irqsave(&ysq->sq_lock, flags);
	input_sw_cqe.start_pos = os_atomic_read(&ysq->queue->info->ci);
	input_sw_cqe.end_pos = os_atomic_read(&ysq->queue->info->pi);
	while ((input_sw_cqe.end_pos != input_sw_cqe.start_pos) && ysq->sw_cmds[input_sw_cqe.end_pos - 1].at_err) {
		input_sw_cqe.end_pos = queue_index_dec(input_sw_cqe.end_pos, input_sw_cqe.depth);
	}
	os_spin_unlock_restore(&ysq->sq_lock, flags);

	if (input_sw_cqe.end_pos != input_sw_cqe.start_pos) {
		yib_sw_cqe_generate(yqp->ysq_cq, &input_sw_cqe, false, 0, 0);
		yib_run_cq_cmpl_evts(sf, yqp->ysq_cq);
	}
}

//对应文档6.4.2中case3，在debug中调用
void yib_debug_generate_sq_sw_cqe(struct yib_qp *yqp, int index, u8 status)
{
	struct yib_sq *ysq = &yqp->ysq;
	struct yib_sw_cqe input_sw_cqe;

	input_sw_cqe.type = YIB_CQE_SQ;
	input_sw_cqe.status = status;
	input_sw_cqe.depth = ysq->queue->depth;
	input_sw_cqe.handler = (u64)yqp;
	input_sw_cqe.start_pos = index;
	input_sw_cqe.end_pos = queue_index_inc(index, input_sw_cqe.depth);
	yib_sw_cqe_generate(yqp->ysq_cq, &input_sw_cqe, false, 0, 0);
}

//对应文档6.4.2中case4，纯软件提交，在fill_wqe中调用
void yib_sw_generate_sq_sw_cqe(struct yib_qp *yqp, int index, u8 status,
		enum ib_wc_opcode opcode, u64 wr_id)
{
	struct yib_sq *ysq = &yqp->ysq;
	struct yib_sw_cqe input_sw_cqe;

	ysq->sw_posted[index]++;

	input_sw_cqe.type = YIB_CQE_SQ;
	input_sw_cqe.status = status;
	input_sw_cqe.depth = ysq->queue->depth;
	input_sw_cqe.handler = (u64)yqp;
	input_sw_cqe.start_pos = index;
	input_sw_cqe.end_pos = queue_index_inc(index, input_sw_cqe.depth);
	yib_sw_cqe_generate(yqp->ysq_cq, &input_sw_cqe, true, opcode, wr_id);
}

//在check_cq_empty(bsw = false)和sw_fill_cqe(bsw = true)中调用
int yib_sq_check_cqe(struct yusur_ib_dev *yib, struct yib_qp *yqp, int index, bool bsw)
{
	struct yib_sq *ysq = &yqp->ysq;
	u32 ci = 0;
	u32 pi = 0;

	if (index >= ysq->queue->depth) {
		os_printw(yib->dev,"qpn:%d, index:%d err, out of range\n", yib_get_qp_sw_idx(yqp), index);
		return -EINVAL;
	}

	//如果为纯软件提交，仅在软件填写cqe时返回成功
	if (ysq->sw_posted[index] > 0)
		return bsw? 0 : -EINVAL;

	ci = os_atomic_read(&ysq->queue->info->ci);
	pi = os_atomic_read(&ysq->queue->info->pi);
	if (ysq->queue->info->ci_toggle == ysq->queue->info->pi_toggle) {//未翻转
		if (index < ci || index >= pi) {
			os_printw(yib->dev,"qpn:%d, index:%d err, not between ci and pi\n", yib_get_qp_sw_idx(yqp), index);
			return -EINVAL;
		}
	} else {//翻转
		if (index < ci && index >= pi) {
			os_printw(yib->dev,"qpn:%d, index:%d err, not between ci and pi\n", yib_get_qp_sw_idx(yqp), index);
			return -EINVAL;
		}
	}

	if (ysq->sw_cmds[index].posted == 0 ) {
		os_printw(yib->dev,"qpn:%d, get an err sq cqe at %d, no posted\n", yib_get_qp_sw_idx(yqp), index);
		return -EINVAL;
	}

	return 0;
}

//在fill cqe中调用
void yib_sq_swcmd_done(struct yusur_ib_dev *yib, struct yib_qp *yqp, int index, bool bsw)
{
	struct yib_sq *ysq = &yqp->ysq;
	int cmpl_cnt = 1;

#if (YIB_DEBUG_IO_DONE == 1)
	int i = queue_index_dec(index, ysq->queue->depth);

	if (bsw) {
		if (ysq->sw_posted[index] > 0)
			ysq->sw_posted[index]--;
		else
			os_printw(yib->dev,"qpn:%d, comp an err sq at %d, no sw posted\n", yib_get_qp_sw_idx(yqp), index);
		return;
	}

	if (ysq->sw_cmds[index].posted == 0 ) {
		os_printw(yib->dev,"qpn:%d, comp an err sq at %d, no posted\n", yib_get_qp_sw_idx(yqp), index);
		goto end;
	}
	//fill cqe时根据wc填写at_err状态
	if (ysq->sw_cmds[index].bsignal== 0 && ysq->sw_cmds[index].at_err == 0) {
		os_printw(yib->dev,"qpn:%d, comp an err sq at %d, no signal, no err\n", yib_get_qp_sw_idx(yqp), index);
		goto end;
	}

	while (true) {
		if (ysq->sw_cmds[i].posted==0)
			break;
		if (ysq->sw_cmds[i].bsignal == 1 || ysq->sw_cmds[i].at_err == 1) {
			os_printe(yib->dev,"qpn:%d, sq comp seq err at %d\n", yib_get_qp_sw_idx(yqp), index);
			break;
		}
		memset(&ysq->sw_cmds[i], 0, sizeof(struct yib_sw_cmd));
		i = queue_index_dec(i, ysq->queue->depth);
		cmpl_cnt++;
	}

end:
	memset(&ysq->sw_cmds[index], 0, sizeof(struct yib_sw_cmd));
	yib_queue_advance_ci(ysq->queue, cmpl_cnt);
#else
	//默认index合法，即在ci与pi之间，此处不做校验
	u32 ci = os_atomic_read(&yqp->ysq.queue->info->ci);
	if (index >= ci) {
		cmpl_cnt = index - ci + 1;
		memset(&ysq->sw_cmds[ci], 0, cmpl_cnt * sizeof(struct yib_sw_cmd));
		yib_queue_advance_ci(ysq->queue, cmpl_cnt);
	} else {
		cmpl_cnt = index + ysq->queue->depth - ci + 1;
		memset(&ysq->sw_cmds[ci], 0, (ysq->queue->depth - ci) * sizeof(struct yib_sw_cmd));
		memset(&ysq->sw_cmds[0], 0, index * sizeof(struct yib_sw_cmd));
		yib_queue_advance_ci(ysq->queue, cmpl_cnt);
	}
#endif
}

static int post_one_send(struct yusur_ib_dev *yib, struct yib_qp *yqp, const os_ib_send_wr *wr,
			    u32 mask, u32 length) 
{
	int err = 0;
	u8 *wqe = NULL;
	struct yib_sq *ysq = &yqp->ysq;
	int pos = os_atomic_read(&ysq->queue->info->pi);;

	if (yib->host.sf.queue_ops->check_sq_full(&yib->host, ysq)) {
		ysq->queue->info->err_count++;
		os_printw(yib->dev, "sq queue is full\n");
		err = -ENOMEM;
		goto exit;
	}

	yib_dbg_info(YUSUR_IB_M_SQ, YUSUR_IB_DBG_SEND, 
		"post_one_send opcode=0x%x send_flags=0x%x pi=0x%x num_sge=0x%x wr_id=0x%llx imm_data=0x%x length=0x%x qpn=0x%x\n",
		wr->opcode, wr->send_flags, os_atomic_read(&ysq->queue->info->pi), 
		wr->num_sge, (u64)wr->wr_id, wr->ex.imm_data, length, yqp->entry.index);

	wqe = yib_queue_get_pi_vaddr(ysq->queue);
	err = yib->host.sf.queue_ops->fill_wqe(&yib->host, yqp, (const void*)wr, wqe, length, mask);
	if (unlikely(err)) {
		ysq->queue->info->direct_cnt++;
		goto exit;
	}

	ysq->sw_cmds[pos].wrid = wr->wr_id;
	ysq->sw_cmds[pos].opcode = yib_wr_to_wc_opcode(wr->opcode);
	ysq->sw_cmds[pos].at_err = 0;
	 if ((wr->send_flags & IB_SEND_SIGNALED) || (yqp->sq_sig_type == IB_SIGNAL_ALL_WR))
		ysq->sw_cmds[pos].bsignal = 1;
	ysq->sw_cmds[pos].posted = 1;
	pos = yib_queue_advance_pi(ysq->queue, 1);
	ysq->queue->info->io_count++;

exit:
	return err;
}

static int yib_sq_send_wr_when_err(struct yusur_ib_dev *yib, struct yib_qp *yqp, const_ os_ib_send_wr *wr,
		   struct yib_sw_cqe *input_sw_cqe)
{
	int io_cnt = 0;
	struct yib_sq *ysq = &yqp->ysq;
	int pos = os_atomic_read(&ysq->queue->info->pi);

	input_sw_cqe->start_pos = pos;
	while (wr) {
		if (yib->host.sf.queue_ops->check_sq_full(&yib->host, ysq)) {
			os_printw(yib->dev, "sq queue is full at err state\n");
			return -ENOMEM;
		}

		ysq->sw_cmds[pos].wrid = wr->wr_id;
		ysq->sw_cmds[pos].opcode = yib_wr_to_wc_opcode(wr->opcode);
		ysq->sw_cmds[pos].at_err = 1;
		ysq->sw_cmds[pos].bsignal = 1;
		ysq->sw_cmds[pos].posted = 1;

		pos = yib_queue_advance_pi(ysq->queue, 1);
		io_cnt++;
		wr = wr->next;
	}

	input_sw_cqe->type = YIB_CQE_SQ;
	input_sw_cqe->status = IB_WC_WR_FLUSH_ERR;
	input_sw_cqe->depth = ysq->queue->depth;
	input_sw_cqe->end_pos = (input_sw_cqe->start_pos + io_cnt) % input_sw_cqe->depth;
	input_sw_cqe->handler = (u64)yqp;
	return 0;
}

int yib_sq_send_wr(struct yusur_ib_dev *yib, struct yib_qp *yqp, const_ os_ib_send_wr *wr,
		   const_ os_ib_send_wr **bad_wr)
{
	u32 mask = 0;
	int err = 0;
	u32 length = 0;
	unsigned long  flags;
	int io_cnt = 0;

	if (unlikely(!yqp->valid)) {
		*bad_wr = wr;
		return -EINVAL;
	}

	if(yqp->qp_type >= IB_QPT_DRIVER) {
		*bad_wr = wr;
		return -EINVAL;
	}

	os_spin_lock_irqsave(&yqp->ysq.sq_lock, flags);

	if (unlikely(yqp->attr.qp_state < IB_QPS_RTS)) {
		os_printw(yib->dev, "qpid:%d state:%d send before rts\n",
			yib_get_qp_sw_idx(yqp), yqp->attr.qp_state);
		err = -EINVAL;
		goto exit;
	}

	//如果硬件有能力，在err时将提交的wr错误完成，则不需要err的判断，可以直接提交到队列中
	if (unlikely(yqp->attr.qp_state == IB_QPS_ERR) && (yib->host.funcs.sw_err_flush)) {
		struct yib_sw_cqe input_sw_cqe;
		err = yib_sq_send_wr_when_err(yib, yqp, wr, &input_sw_cqe);
		os_spin_unlock_restore(&yqp->ysq.sq_lock, flags);
		if (input_sw_cqe.end_pos != input_sw_cqe.start_pos) {
			yib_sw_cqe_generate(yqp->ysq_cq, &input_sw_cqe, false, 0, 0);
			yib_run_cq_cmpl_evts(&yib->host.sf, yqp->ysq_cq);
		}
		goto end;
	}

	while (wr) {
		length = 0;
		err = yib_send_wr_check(&yib->host, yqp, wr, &mask, &length);
		if (err) {
			yqp->ysq.queue->info->direct_cnt++;
			goto exit;
		}

		err = post_one_send(yib, yqp, wr, mask, length);
		if (err) {
			goto exit;
		}

		io_cnt++;
		wr = wr->next;
	}

exit:
	if (io_cnt > 0) {
		os_smp_wmb();
		yib->host.sf.queue_ops->sq_pi_db_update(&yib->host, yqp, io_cnt);
	}
	os_spin_unlock_restore(&yqp->ysq.sq_lock, flags);

end:
	if (err) {
		*bad_wr = wr;
	}
	return err;
}


int yib_user_post_send(struct yusur_ib_dev *yib, struct yib_qp *yqp, const_ os_ib_send_wr *wr,
		   const_ os_ib_send_wr **bad_wr)
{
	int err = 0;

	if (unlikely(!yqp->valid)) {
		*bad_wr = wr;
		return -EINVAL;
	}

	if(yqp->qp_type >= IB_QPT_DRIVER) {
		*bad_wr = wr;
		return -EINVAL;
	}

	if (unlikely(yqp->attr.qp_state < IB_QPS_RTS)) {
		os_printw(yib->dev, "qpid:%d state:%d send before rts\n",
			yib_get_qp_sw_idx(yqp), yqp->attr.qp_state);
		err = -EINVAL;
		goto exit;
	}

 	if (wr == NULL)
		err = yib->host.hw_ops.uio_ops->uio_post_send(&yib->host, yqp, (const void*)wr, true);
	else
		err = yib->host.hw_ops.uio_ops->uio_post_send(&yib->host, yqp, (const void*)wr, false);

exit:
	if (err) {
		*bad_wr = wr;
	}
	return err;
}
