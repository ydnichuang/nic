#include "../include/basic.h"
#include "../include/os_api.h"
#include "../include/os_ds.h"
#include "../include/mem.h"
#include "../include/queue.h"
#include "../include/host.h"
#include "../include/verbs.h"
#include "../include/yusur_ib.h"

static void yib_frag_dump(struct yib_frag_buf *tbl_frag, int npages)
{
	int i = 0;
	char buffer[128];
	int buf_pos = 0;
	int offset = 0;
	void *frag_va = NULL;

	for (i = 0; i < npages; i++) {
		if (i % 4 == 0) {
			buf_pos = 0;
			memset(buffer, 0, sizeof(buffer));
			buf_pos += snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%04X:  ", offset);
			offset += 32;
		}
		frag_va = yib_frag_get_vaddr(tbl_frag, sizeof(u64), i);
		buf_pos += snprintf(buffer + buf_pos, sizeof(buffer) - buf_pos, "0x%llX  ", readq(frag_va));
		if (((i + 1) % 4 == 0) || (i == npages - 1)) {
			yib_dbg_info(YUSUR_IB_M_MR_MTT, YUSUR_IB_DBG_SGLIST, "%s\n", buffer);
		}
	}
}

static void yib_page_tbl_dump(struct yib_page_tbl *tbl, int npages)
{
	int i = 0;
	void *frag_va = NULL;
	int frag_dump_num;

	yib_dbg_info(YUSUR_IB_M_MR_MTT, YUSUR_IB_DBG_INIT, 
		"######### pbl_pg_size %d pg_size %d levels %d dump BEGIN#####\n", 	
		tbl->pbl_pg_size, tbl->pg_size, tbl->levels);
	if (tbl->levels == 0) {
		yib_dbg_info(YUSUR_IB_M_MR_MTT, YUSUR_IB_DBG_INIT, "root_pa: 0x%llX\n", tbl->root_pa);
	} else if (tbl->levels == 1) {
		yib_dbg_info(YUSUR_IB_M_MR_MTT, YUSUR_IB_DBG_INIT, "root_pa: 0x%llX, npages: %d\n", tbl->root_pa, npages);
		yib_frag_dump(tbl->tbl_frag, npages);
	} else if (tbl->levels == 2) {
		yib_dbg_info(YUSUR_IB_M_MR_MTT, YUSUR_IB_DBG_INIT, "root_pa: 0x%llX, npages: %d\n", tbl->root_pa, npages);
		for (i = 0; i < tbl->tbl_frag->npages; i++) {
			frag_va = yib_frag_get_vaddr(tbl->root_frag, sizeof(u64), i);
			yib_dbg_info(YUSUR_IB_M_MR_MTT, YUSUR_IB_DBG_SGLIST,
					 "------ root_frag%d: 0x%llX ------\n", i+1, readq(frag_va));
			if (i == (tbl->tbl_frag->npages-1))
				frag_dump_num = npages - (PAGE_SIZE / sizeof(u64))*i;
			else
				frag_dump_num = PAGE_SIZE / sizeof(u64);
			yib_frag_dump(tbl->tbl_frag, frag_dump_num);
		}
	}
	yib_dbg_info(YUSUR_IB_M_MR_MTT, YUSUR_IB_DBG_INIT, 
		"######### pbl_pg_size %d pg_size %d levels %d dump END#######\n", 
		tbl->pbl_pg_size, tbl->pg_size, tbl->levels);
}

static void yib_fill_page_tbl_info(struct yib_page_tbl *tbl, int level, int pg_size, int pg_count, u64 root_pa,
			struct yib_frag_buf *tbl_frag, struct yib_frag_buf *root_frag, int pbl_pg_size)
{
	tbl->levels = level;
	tbl->pg_size = pg_size;
	tbl->pg_count = pg_count;
	tbl->root_pa = root_pa;
	tbl->tbl_frag = tbl_frag;
	tbl->root_frag = root_frag;
	tbl->pbl_pg_size = os_numTo2n2(pbl_pg_size);
}

// 根据hw_pages判断页表级别为1级还是2级，0级页表在上层处理
static int yib_create_sub_page_table(struct yib_sf *sf, struct yib_page_tbl *tbl, int page_size, int hw_pages, bool l2_tbl_supp)
{
	struct yib_frag_buf *tbl_frag = NULL;
	struct yib_frag_buf *root_frag = NULL;
	int tbl_size = hw_pages * sizeof(u64);

	tbl_frag = yib_frag_buf_alloc_node(sf, os_align_up(tbl_size, PAGE_SIZE), true);
	if (tbl_frag == NULL)
		return -ENOMEM;

	if (tbl_frag->npages == 1) {
		//1级页表
		yib_fill_page_tbl_info(tbl, 1, page_size, hw_pages, tbl_frag->frags->dma_addr, tbl_frag, NULL, yib_frag_get_pagesz(tbl_frag));
	} else {
		//2级页表
		if (l2_tbl_supp == false) {
			yib_frag_free_node(sf, tbl_frag);
			return -ENOMEM;
		}

		root_frag = yib_frag_buf_alloc_node(sf, yib_frag_get_pagesz(tbl_frag), true);
		if (root_frag == NULL) {
			yib_frag_free_node(sf, tbl_frag);
			return -ENOMEM;
		}

		//根页框超过1页，或者1个页放不下所有1级页框，则报错
		if (root_frag->npages > 1 || (root_frag->size < tbl_frag->npages * sizeof(u64))) {
			os_printe(sf->hw->dev, "root_frag->npages:%d tbl_frag->npages:%d tbl_frag->npages:%d\n", 
					root_frag->npages, tbl_frag->npages, tbl_frag->npages);
			yib_frag_free_node(sf, root_frag);
			yib_frag_free_node(sf, tbl_frag);
			return -ENOMEM;
		}

		yib_fill_page_tbl_info(tbl, 2, page_size, hw_pages, root_frag->frags->dma_addr, tbl_frag, root_frag, yib_frag_get_pagesz(tbl_frag));
	}

	return 0;
}

/*
	for Fast MR
	软件限制该场景仅有0级或1级页表，根据npages选择
*/
int yib_create_page_table_by_pages(struct yib_sf *sf, struct yib_page_tbl *tbl, u64 pages[], int npages)
{
	struct yib_frag_buf *tbl_frag = NULL;
	int size = PAGE_SIZE;
	void *tbl_frag_va = NULL;
	int i;

	if (npages == 1) {
		//0级页表
		yib_fill_page_tbl_info(tbl, 0, size, npages, pages[0], NULL, NULL, 0);
	} else {
		//1级页表
		tbl_frag = yib_frag_buf_alloc_node(sf, size, true);
		if (tbl_frag == NULL)
			return -ENOMEM;

		if (tbl_frag->npages > 1) {//必须为1个页表框，否则报错
			yib_frag_free_node(sf, tbl_frag);
			return -ENOMEM;
		}

		yib_fill_page_tbl_info(tbl, 1, size, npages, tbl_frag->frags->dma_addr, tbl_frag, NULL, size);

		//fill tbl
		for (i = 0; i < npages; i++) {
			tbl_frag_va = yib_frag_get_vaddr(tbl_frag, sizeof(u64), i);

			writeq(pages[i], tbl_frag_va);
		}
	}

	return 0;
}

static void yib_fill_root_frag(struct yib_page_tbl *tbl)
{
	struct yib_frag_buf *tbl_frag = tbl->tbl_frag;
	struct yib_frag_buf *root_frag = tbl->root_frag;
	int i;
	void *root_frag_va = NULL;
	u64 tbl_frag_pa;

	for (i = 0; i < tbl_frag->npages; i++) {
		root_frag_va = yib_frag_get_vaddr(root_frag, sizeof(u64), i);
		tbl_frag_pa = yib_frag_get_paddr(tbl_frag, yib_frag_get_pagesz(tbl_frag), i);

		writeq(tbl_frag_pa, root_frag_va);
	}
}

int yib_create_page_table_by_frag(struct yib_sf *sf, struct yib_page_tbl *tbl, struct yib_frag_buf *dat_frag, bool l2_tbl_supp)
{
	int page_table_item_cnt;
	int i;
	void *tbl_frag_va = NULL;
	u64 dat_frag_pa;
	int ret = 0;

	if (dat_frag->npages == 1) {
		//0级页表
		yib_fill_page_tbl_info(tbl, 0, dat_frag->real_size, dat_frag->npages, dat_frag->frags->dma_addr, NULL, NULL, 0);
	} else {
		page_table_item_cnt = dat_frag->npages;
		ret = yib_create_sub_page_table(sf, tbl, yib_frag_get_pagesz(dat_frag), page_table_item_cnt, l2_tbl_supp);
		if (ret)
			goto err;
	}

	//fill tbl
	if (tbl->levels > 0) {
		//fill root
		if (tbl->levels == 2)
			yib_fill_root_frag(tbl);

		for (i = 0; i < dat_frag->npages; i++) {
			tbl_frag_va = yib_frag_get_vaddr(tbl->tbl_frag, sizeof(u64), i);
			dat_frag_pa = yib_frag_get_paddr(dat_frag, yib_frag_get_pagesz(dat_frag), i);

			writeq(dat_frag_pa, tbl_frag_va);
		}
	}

	yib_dbg_info(YUSUR_IB_M_MR_MTT, YUSUR_IB_DBG_INIT, "######### data frag dump BEGIN#####\n");
	yib_frag_dump(dat_frag, dat_frag->npages);
	yib_dbg_info(YUSUR_IB_M_MR_MTT, YUSUR_IB_DBG_INIT, "######### data frag dump END#######\n");
err:
	return ret;
}

int yib_create_page_table_by_sg(struct yib_sf *sf, struct yib_page_tbl *tbl, struct scatterlist *sglist,
			int npages, u32 page_size, bool l2_tbl_supp)
{
	struct scatterlist *sg;
	void *tbl_frag_va = NULL;
	u64 sg_page_pa;
	int i, page_count_in_sg;

	int ret = 0;

	if (npages == 1) {
		//0级页表
		yib_fill_page_tbl_info(tbl, 0, page_size, npages, sg_dma_address(sglist), NULL, NULL, 0);
	} else {
		ret = yib_create_sub_page_table(sf, tbl, page_size, npages, l2_tbl_supp);
		if (ret) {
			os_printe(sf->hw->dev, "yib_create_sub_page_table failed");
			goto err;
		}
	}

	//fill tbl
	if (tbl->levels > 0) {
		//fill root
		if (tbl->levels == 2)
			yib_fill_root_frag(tbl);

		sg = sglist;
		page_count_in_sg = 0;
		for (i = 0; i < npages; i++) {
			tbl_frag_va = yib_frag_get_vaddr(tbl->tbl_frag, sizeof(u64), i);
			sg_page_pa = (sg_dma_address(sg) + page_count_in_sg * page_size) & ~((u64)(page_size - 1));

			writeq(sg_page_pa, tbl_frag_va);

			if (sg_page_pa + page_size >= (sg_dma_address(sg) + sg_dma_len(sg))) {
				page_count_in_sg = 0;
				sg = sg_next(sg);
			} else {
				page_count_in_sg++;
			}
		}
	}

	yib_page_tbl_dump(tbl, npages);
err:
	return ret;
}

void yib_destroy_page_table(struct yib_sf *sf, struct yib_page_tbl *tbl)
{
	if (tbl->levels == 1) {
		if (tbl->tbl_frag)
			yib_frag_free_node(sf, tbl->tbl_frag);
	} else if (tbl->levels == 2) {
		if (tbl->tbl_frag)
			yib_frag_free_node(sf, tbl->tbl_frag);
		if (tbl->root_frag)
			yib_frag_free_node(sf, tbl->root_frag);
	}

	memset(tbl, 0, sizeof(struct yib_page_tbl));
}

u64 yib_mem_get_pa(struct yib_page_tbl *tbl, int index)
{
	struct yib_frag_buf *tbl_frag = NULL;
	void *tbl_frag_va = NULL;
	if (tbl->levels == 0) {
		if (index != 0)
			return -EINVAL;
		return tbl->root_pa;
	} else {
		if (tbl->tbl_frag == NULL)
			return -EINVAL;
		tbl_frag = tbl->tbl_frag;
		tbl_frag_va = yib_frag_get_vaddr(tbl_frag, sizeof(u64), index);
		return readq(tbl_frag_va);
	}
}

int yib_get_4kpages_from_pagetbl(struct yib_page_tbl *tbl, int max_items, u64 *array)
{
	struct yib_frag_buf *tbl_frag = tbl->tbl_frag;
	int array_page_sz = 4096;
	void *tbl_frag_va = NULL;
	int i = 0, array_item_cnt = 0;
	int temp = 0;

	if (tbl->levels == 0) {
		array_item_cnt = tbl->pg_size / array_page_sz;
		if (array_item_cnt > max_items) {
			yib_dbg_err("yib_get_4kpages_from_pagetbl failed");
			return -EINVAL;
		}

		for (i = 0; i < array_item_cnt; i++) {
			array[i] = tbl->root_pa + array_page_sz * i;
		}
	} else if (tbl->levels == 1) {
		if (tbl_frag == NULL)
			return -EINVAL;

		array_item_cnt = tbl->pg_count * (tbl->pg_size / array_page_sz);
		if (array_item_cnt > max_items) {
			yib_dbg_err("yib_get_4kpages_from_pagetbl failed");
			return -EINVAL;
		}

		for (i = 0; i < array_item_cnt; i++) {
			temp = i % (tbl->pg_size / array_page_sz);
			if (temp == 0) {
				tbl_frag_va = yib_frag_get_vaddr(tbl_frag, sizeof(u64), (i / (tbl->pg_size / array_page_sz)));
				array[i] = readq(tbl_frag_va);
			} else {
				array[i] = array[i-1] + array_page_sz * temp;
			}
		}
	}

	return array_item_cnt;
}