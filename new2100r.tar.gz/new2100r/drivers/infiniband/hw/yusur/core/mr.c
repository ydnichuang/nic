#include "../include/basic.h"
#include "../include/os_api.h"
#include "../include/os_ds.h"
#include "../include/mem.h"
#include "../include/queue.h"
#include "../include/host.h"
#include "../include/verbs.h"
#include "../include/yusur_ib.h"

#define YIB_MR_TYPE_DMA   (BIT(31) | BIT(30))
#define YIB_MR_TYPE_MW     (BIT(30))
#define YIB_MR_TYPE_NORMAL  (0x0)

static u8 gen_key(void)
{
	static u32 key = 1;

	key = key << 1;

	key |= (0 != (key & 0x100)) ^ (0 != (key & 0x10))
		^ (0 != (key & 0x80)) ^ (0 != (key & 0x40));

	key &= 0xff;

	return key;
}

//底层alloc时调用
void yib_mr_helper_get_key(u32 hw_index, u32 *lkey, u32 *rkey)
{

	*lkey = (hw_index << 8) & 0xFFFFFF00;
	*lkey |= gen_key();
	*rkey = *lkey;
}

struct yib_mr *yib_mw_alloc_new(struct yusur_ib_dev *yib, struct yib_mw *ymw, struct yib_pd *ypd, bool buser)
{
	struct yib_mr *mr = NULL;
	int ret = 0;
	host_verbs_t *verbs = &yib->host.verbs;

	if (yib_pool_check_index(&verbs->pd_pool, ypd->entry.index, false) == false) {
		os_printw(yib->dev, "alloc mr not exist index:%d\n", ypd->entry.index);
		return ERR_PTR(-EINVAL);
	}

	mr = yib_pool_alloc(&verbs->mrw_pool);
	if (!mr) {
		os_printw(yib->dev, "alloc mr no memory");
		return ERR_PTR(-ENOMEM);
	}

	yib_elem_add_ref(&ypd->entry);
	mr->pd_num = ypd->entry.index;

	mr->type.is_mw = true;
	mr->type.is_user = buser;
	mr->type.is_peer = 0;
	mr->type.is_fast = 0;
	mr->type.is_dma = 0;

	mr->priv.pmw = ymw;
	ret = yib->host.sf.sf_ops->mrw_alloc(&yib->host.sf, mr, &mr->ib_mr.lkey, &mr->ib_mr.rkey);
	if (ret) {
		os_printw(yib->dev, "mrw_alloc falied");
		yib_elem_drop_ref(&ypd->entry);
		yib_elem_drop_ref(&mr->entry);
		return ERR_PTR(-EFAULT);
	}

	return mr;
}

struct yib_mr *yib_mr_alloc_new(struct yusur_ib_dev *yib, struct yib_pd *ypd, bool buser, bool bdma, bool bfast)
{
	struct yib_mr *mr = NULL;
	int ret = 0;
	host_verbs_t *verbs = &yib->host.verbs;

	if (ypd) { //global key pd =null
		if (yib_pool_check_index(&verbs->pd_pool, ypd->entry.index, false) == false) {
			os_printw(yib->dev, "alloc mr not exist index:%d\n", ypd->entry.index);
			return ERR_PTR(-EINVAL);
		}
	}

	mr = yib_pool_alloc(&verbs->mrw_pool);
	if (!mr) {
		os_printw(yib->dev, "alloc mr no memory");
		return ERR_PTR(-ENOMEM);
	}

	if (ypd) {
		yib_elem_add_ref(&ypd->entry);
		mr->pd_num = ypd->entry.index;
	}
	mr->type.is_dma = bdma;
	mr->type.is_user = buser;
	mr->type.is_fast = bfast;
	mr->type.is_mw = 0;
	mr->access = 0;
	if (bdma)
		mr->access = IB_ACCESS_REMOTE_READ | IB_ACCESS_LOCAL_WRITE;

	ret = yib->host.sf.sf_ops->mrw_alloc(&yib->host.sf, mr, &mr->ib_mr.lkey, &mr->ib_mr.rkey);
	if (ret) {
		os_printw(yib->dev, "mrw_alloc falied");
		if (ypd)
			yib_elem_drop_ref(&ypd->entry);
		yib_elem_drop_ref(&mr->entry);
		return ERR_PTR(-EFAULT);
	}

	yib_dbg_info(YUSUR_IB_M_MR, YUSUR_IB_DBG_CREATE,"alloc mr:%d lkey=0x%08X rkey=0x%08X\n",
		yib_get_mr_sw_idx(mr), mr->ib_mr.lkey, mr->ib_mr.rkey);
	return mr;
}

void yib_mr_dealloc(struct yib_mr *mr, struct yib_pd *ypd)
{
	if (ypd)
		yib_elem_drop_ref(&ypd->entry);
	yib_elem_drop_ref(&mr->entry);
}

/////////////////////////////////////////////////
/*
 *               This is for MR MTT operation
 *
 */
///////////////////////////////////////////
static void yib_fmr_uninit(struct yusur_ib_dev *yib, struct yib_mr *ymr)
{
	struct yib_hw_host *hw = &yib->host;

	if (ymr->priv.fmr) {
		if (ymr->priv.fmr->descs_alloc) {
			dma_unmap_single(&hw->sf.pdev->dev,
				ymr->priv.fmr->desc_map, ymr->priv.fmr->max_descs * ymr->priv.fmr->desc_size, DMA_TO_DEVICE);
			kfree(ymr->priv.fmr->descs_alloc);
			ymr->priv.fmr->descs_alloc = NULL;
		}
		kfree(ymr->priv.fmr);
	}

	ymr->priv.fmr = NULL;
}

//cleanup
void yib_mr_info_disable(struct yusur_ib_dev *yib, struct yib_mr *ymr)
{
	yib->host.sf.sf_ops->mrw_destroy(&yib->host.sf, ymr);

	if (ymr->type.is_fast) {
		yib_fmr_uninit(yib, ymr);
	} else if (ymr->type.is_mw) {
#if IB_LAYER_ALLOC_MW == 0
		if (ymr->priv.pmw)
			kfree(ymr->priv.pmw);
#endif
		ymr->priv.pmw = NULL;
	} else if (ymr->type.is_dma) {
		return;
	} else if (ymr->type.is_user) {
		if(ymr->umem != NULL) {
#ifdef GDR_PEER_MEMORY
			if(ymr->type.is_peer)
				ib_umem_release_peer(ymr->umem);
			else
#endif
				ib_umem_release(ymr->umem);
			ymr->umem = NULL;
		}
	}
}

int yib_fmr_init(struct yusur_ib_dev *yib, struct yib_mr *ymr)
{
	struct yib_hw_host *hw = &yib->host;

	ymr->priv.fmr = kzalloc(sizeof(struct yib_fmr), GFP_KERNEL);
	if (ymr->priv.fmr == NULL)
		return -ENOMEM;

	ymr->priv.fmr->max_descs = YUSUR_RDMA_FAST_MR_SG_LEN;
	ymr->priv.fmr->desc_size = sizeof(u64);
	ymr->priv.fmr->descs_alloc = kzalloc(ymr->priv.fmr->max_descs * ymr->priv.fmr->desc_size + PAGE_SIZE, GFP_KERNEL);
	if (!ymr->priv.fmr->descs_alloc) {
		kfree(ymr->priv.fmr);
		ymr->priv.fmr = NULL;
		return -ENOMEM;
	}

	ymr->priv.fmr->descs = PTR_ALIGN(ymr->priv.fmr->descs_alloc, PAGE_SIZE);

	ymr->priv.fmr->desc_map = dma_map_single(&hw->sf.pdev->dev,
			ymr->priv.fmr->descs, ymr->priv.fmr->max_descs * ymr->priv.fmr->desc_size, DMA_TO_DEVICE);
	if (dma_mapping_error(&hw->sf.pdev->dev, ymr->priv.fmr->desc_map)) {
		kfree(ymr->priv.fmr->descs_alloc);
		kfree(ymr->priv.fmr);
		ymr->priv.fmr = NULL;
		return -ENOMEM;
	}

	return 0;
}

struct yib_mr *yib_mr_get_from_index(struct yusur_ib_dev *yib, int index, bool lock)
{
	struct yib_pool_entry *elem = NULL;

	elem = yib_pool_get_by_index(&yib->host.verbs.mrw_pool, index, lock);
	if (elem == NULL)
		return NULL;
	return container_of(elem, struct yib_mr, entry);
}
