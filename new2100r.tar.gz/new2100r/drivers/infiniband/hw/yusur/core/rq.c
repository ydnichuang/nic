#include "../include/basic.h"
#include "../include/os_api.h"
#include "../include/os_ds.h"
#include "../include/mem.h"
#include "../include/queue.h"
#include "../include/host.h"
#include "../include/verbs.h"
#include "../include/yusur_ib.h"
#include "priv.h"

void yib_run_srq_limit_evts(struct yusur_ib_dev *yib, struct yib_srq *ysrq)
{
#if 0 //new_new todo
	bool dup = false;
	dup = yib_hw_event_add(&yib->host.srq_limit_evts, &ysrq->evt_limit_node);
	if (!dup) {
		yib_elem_add_ref(&ysrq->yrq->entry);
		yib_hw_events_run(&yib->host.srq_limit_evts);
	}
#endif
}

//对应文档6.4.2中case2，在aeq中调用
void yib_aeq_generate_rq_sw_cqe(struct yib_sf *sf, struct yib_qp *yqp)
{
	unsigned long  flags;
	struct yib_rq *yrq = yqp->type.yrq;
	struct yib_sw_cqe input_sw_cqe;

	if (sf->hw->funcs.quick_excep == 0)
		return;

	input_sw_cqe.type = YIB_CQE_RQ;
	input_sw_cqe.status = IB_WC_WR_FLUSH_ERR;
	input_sw_cqe.depth = yrq->queue->depth;
	input_sw_cqe.handler = (u64)yqp;

	os_spin_lock_irqsave(&yrq->rq_lock, flags);
	input_sw_cqe.start_pos = os_atomic_read(&yrq->queue->info->ci);
	input_sw_cqe.end_pos = os_atomic_read(&yrq->queue->info->pi);
	os_spin_unlock_restore(&yrq->rq_lock, flags);

	while ((input_sw_cqe.end_pos != input_sw_cqe.start_pos) && yrq->sw_cmds[input_sw_cqe.end_pos - 1].at_err) {
		input_sw_cqe.end_pos = queue_index_dec(input_sw_cqe.end_pos, input_sw_cqe.depth);
	}	

	if (input_sw_cqe.end_pos != input_sw_cqe.start_pos) {
		yib_sw_cqe_generate(yqp->yrq_cq, &input_sw_cqe, false, 0, 0);
		yib_run_cq_cmpl_evts(sf, yqp->yrq_cq);
	}
}

//对应文档6.4.2中case3，在debug中调用
void yib_debug_generate_rq_sw_cqe(struct yib_qp *yqp, int index, u8 status)
{
	struct yib_sw_cqe input_sw_cqe;
	struct yib_rq *yrq = yqp->type.yrq;

	input_sw_cqe.type = YIB_CQE_RQ;
	input_sw_cqe.status = status;
	input_sw_cqe.depth = yrq->queue->depth;
	input_sw_cqe.handler = (u64)yqp;
	input_sw_cqe.start_pos = index;
	input_sw_cqe.end_pos = queue_index_inc(index, input_sw_cqe.depth);
	yib_sw_cqe_generate(yqp->yrq_cq, &input_sw_cqe, false, 0, 0);
}

//在check cq empty中调用
int yib_rq_check_hwcqe(struct yusur_ib_dev *yib, struct yib_rq *yrq, int index)
{
	if (index >= yrq->queue->depth) {
		os_printw(yib->dev,"rqn:%d, index:%d err\n", yib_get_rq_sw_idx(yrq), index);
		return -EINVAL;
	}

	if (yrq->sw_cmds[index].posted == 0) {
		os_printe(yib->dev,"rqn:%d, get an rq cqe err at %d\n", yib_get_rq_sw_idx(yrq), index);
		return -EINVAL;
	}
	return 0;
}

//在fill cqe中调用
void yib_srq_swcmd_done(struct yusur_ib_dev *yib, struct yib_srq *ysrq, int index)
{
	if (ysrq->yrq->sw_cmds[index].posted == 0) {
		os_printe(yib->dev,"srqn:%d, comp srq err at %d\n", yib_get_rq_sw_idx(ysrq->yrq), index);
	}

	memset(&ysrq->yrq->sw_cmds[index], 0, sizeof(struct yib_sw_cmd));
	clear_bit(index, ysrq->post_bitmap);
	clear_bit(index, ysrq->db_bitmap);
}

//在fill cqe中调用
void yib_rq_swcmd_done(struct yusur_ib_dev *yib, struct yib_rq *yrq, int index)
{
	if (yrq->sw_cmds[index].posted == 0) {
		os_printe(yib->dev,"rqn:%d, comp rq err at %d\n", yib_get_rq_sw_idx(yrq), index);
	}

	memset(&yrq->sw_cmds[index], 0, sizeof(struct yib_sw_cmd));
	yib_queue_advance_ci(yrq->queue, 1);
}

int yib_srq_find_useable_pos(struct yib_srq *ysrq)
{
	int pos = 0;

	pos = find_next_zero_bit(ysrq->post_bitmap, ysrq->yrq->queue->depth, ysrq->next_db);
	if (pos >= ysrq->yrq->queue->depth) {
		pos = find_first_zero_bit(ysrq->post_bitmap, ysrq->yrq->queue->depth);
		if (pos >= ysrq->yrq->queue->depth)
			return -ENOMEM;
	}
	return pos;
}

//返回true表示可以db, 否则不能db
bool yib_srq_db_helper(struct yib_srq *ysrq, int pos)
{
	int temp = 0;
	u32 pi = 0;

	if (pos == ysrq->next_db) {
		while (test_bit(pos, ysrq->post_bitmap) && (test_bit(pos, ysrq->db_bitmap) == 0))
		{
			__set_bit(pos, ysrq->db_bitmap);
			temp = pos + 1;
			pos = queue_index_inc(pos, ysrq->yrq->queue->depth);
			ysrq->next_db = pos;
			if (temp != pos)
				ysrq->toggle = ysrq->toggle? false: true;
		}

		pi = queue_index_dec(ysrq->next_db, ysrq->yrq->queue->depth);
		os_atomic_set(&ysrq->yrq->queue->info->pi, pi);
		return true;
	}

	return false;
}

static int srq_post_one_recv(struct yusur_ib_dev *yib, struct yib_srq *ysrq, const os_ib_recv_wr *wr)
{
	int err;
	int i;
	u32 length;
	u8 *rqe = NULL;
	int num_sge = wr->num_sge;
	struct yib_rq *yrq = ysrq->yrq;
	int pos = 0;

	if (unlikely(num_sge > yrq->max_recv_sge)) {
		yrq->queue->info->direct_cnt++;
		os_printw(yib->dev, "recv failed for sge:%d > max_recv_sge:%d\n", num_sge, yrq->max_recv_sge);
		err = -EINVAL;
		goto exit;
	}

	length = 0;
	for (i = 0; i < num_sge; i++)
		length += wr->sg_list[i].length;

	if (yib->host.sf.queue_ops->check_srq_full(&yib->host, ysrq, &pos)) {
		yrq->queue->info->err_count++;
		os_printw(yib->dev, "srq queue is full\n");
		err = -ENOMEM;
		goto exit;
	}

#if (0) //当前版本不支持srq limit,后面再扩展
	if (yrq->bsrq) {
		struct yib_srq *ysrq = yrq->parent;
		if (yib_queue_get_count(&yrq->queue, YIB_RQ_QUEUE_MASK) >= ysrq->limit && ysrq->limit > 0) {
			yib_run_srq_limit_evts(yib, ysrq);
		}
	}
#endif

	rqe = yib_queue_get_vaddr_by_index(yrq->queue, pos);
	err = yib->host.sf.queue_ops->fill_srqe(&yib->host, yrq, (const void*)wr, rqe, length, pos);
	if (unlikely(err)) {
		yrq->queue->info->direct_cnt++;
		goto exit;
	}

	yrq->sw_cmds[pos].wrid = wr->wr_id;
	yrq->sw_cmds[pos].opcode = IB_WC_RECV;
	yrq->sw_cmds[pos].at_err = 0;
	yrq->sw_cmds[pos].bsignal = 1;
	yrq->sw_cmds[pos].posted = 1;
	yrq->queue->info->io_count++;

	__set_bit(pos, ysrq->post_bitmap);
	os_smp_wmb();
	yib->host.sf.queue_ops->srq_pi_db_update(&yib->host, ysrq, pos);

exit:
	return err;
}

int yib_recv_wr_check(struct yib_hw_host *hw, struct yib_rq *yrq, const os_ib_recv_wr *wr)
{
	int num_sge = wr->num_sge;
	struct yib_qp *yqp = (struct yib_qp*)yrq->parent;
	//再次检查，状态不对退出
	if (unlikely(yqp->attr.qp_state < IB_QPS_INIT)) {
		os_printw(hw->dev, "qp: %d recv in wrong state:%d valid=%d\n",
			yib_get_qp_sw_idx(yqp), yqp->attr.qp_state, yqp->valid);
		return -EINVAL;
	}
	if (unlikely(num_sge > yrq->max_recv_sge)) {
		yrq->queue->info->direct_cnt++;
		os_printw(hw->dev, "recv failed for sge:%d > max_recv_sge:%d\n", num_sge, yrq->max_recv_sge);
		return -EINVAL;
	}
	return 0;
}

static int post_one_recv(struct yusur_ib_dev *yib, struct yib_rq *yrq, const os_ib_recv_wr *wr)
{
	int err;
	int i;
	u32 length;
	u8 *rqe = NULL;
	int num_sge = wr->num_sge;
	int pos = os_atomic_read(&yrq->queue->info->pi);

	length = 0;
	for (i = 0; i < num_sge; i++)
		length += wr->sg_list[i].length;

	if (yib->host.sf.queue_ops->check_rq_full(&yib->host, yrq)) {
		yrq->queue->info->err_count++;
		os_printw(yib->dev, "rq queue is full\n");
		err = -ENOMEM;
		goto exit;
	}

	rqe = yib_queue_get_pi_vaddr(yrq->queue);
	err = yib->host.sf.queue_ops->fill_rqe(&yib->host, yrq, (const void*)wr, rqe, length);
	if (unlikely(err)) {
		yrq->queue->info->direct_cnt++;
		goto exit;
	}

	yrq->sw_cmds[pos].wrid = wr->wr_id;
	yrq->sw_cmds[pos].opcode = IB_WC_RECV;
	yrq->sw_cmds[pos].at_err = 0;
	yrq->sw_cmds[pos].bsignal = 1;
	yrq->sw_cmds[pos].posted = 1;
	pos = yib_queue_advance_pi(yrq->queue, 1);
	yrq->queue->info->io_count++;

exit:
	return err;
}

int yib_srq_recv_wr(struct yusur_ib_dev *yib, struct yib_srq *ysrq, const_ os_ib_recv_wr *wr,
			 const_ os_ib_recv_wr **bad_wr)
{
	unsigned long flags;
	struct yib_rq *yrq = ysrq->yrq;
	int err = -EINVAL;

	os_spin_lock_irqsave(&yrq->rq_lock, flags);

	while (wr) {
		err = srq_post_one_recv(yib, ysrq, wr); //gsi硬件接收产生cq
		if (unlikely(err)) {
			*bad_wr = wr;
			break;
		}
		wr = wr->next;
	}

	os_spin_unlock_restore(&yrq->rq_lock, flags);
	if (err)
		*bad_wr = wr;
	return err; 
}

static int yib_rq_recv_wr_when_err(struct yusur_ib_dev *yib, struct yib_qp *yqp, const_ os_ib_recv_wr *wr,
		   struct yib_sw_cqe *input_sw_cqe)
{
	int io_cnt = 0;
	struct yib_rq *yrq = yqp->type.yrq;
	int pos = os_atomic_read(&yrq->queue->info->pi);

	input_sw_cqe->start_pos = pos;
	while (wr) {
		if (yib->host.sf.queue_ops->check_rq_full(&yib->host, yrq)) {
			os_printw(yib->dev, "rq queue is full at err state\n");
			return -ENOMEM;
		}

		yrq->sw_cmds[pos].wrid = wr->wr_id;
		yrq->sw_cmds[pos].at_err = 1;
		yrq->sw_cmds[pos].opcode = IB_WC_RECV;
		yrq->sw_cmds[pos].bsignal = 1;
		yrq->sw_cmds[pos].posted = 1;

		pos = yib_queue_advance_pi(yrq->queue, 1);
		io_cnt++;
		wr = wr->next;
	}

	input_sw_cqe->type = 1;
	input_sw_cqe->status = IB_WC_WR_FLUSH_ERR;
	input_sw_cqe->depth = yrq->queue->depth;
	input_sw_cqe->end_pos = (input_sw_cqe->start_pos + io_cnt) % input_sw_cqe->depth;
	input_sw_cqe->handler = (u64)yqp;
	return 0;
}

int yib_rq_recv_wr(struct yusur_ib_dev *yib, struct yib_qp *yqp, const_ os_ib_recv_wr *wr,
			 const_ os_ib_recv_wr **bad_wr)
{
	unsigned long flags;
	struct yib_rq *yrq = yqp->type.yrq;
	int err = 0;
	int io_cnt = 0;

 	if (unlikely(!yrq)) {
		os_printw(yib->dev, "qp: %d rq is null\n", yib_get_qp_sw_idx(yqp));
		*bad_wr = wr;
		return -EINVAL;
	}

	os_spin_lock_irqsave(&yrq->rq_lock, flags);

	if ((yqp->attr.qp_state < IB_QPS_INIT) || unlikely(!yqp->valid))  {
		os_printw(yib->dev, "qp: %d recv in wrong state:%d valid=%d\n",
				yib_get_qp_sw_idx(yqp), yqp->attr.qp_state, yqp->valid);
		err = -EINVAL;
		goto exit;
	}

	//如果硬件有能力，在err时将提交的wr错误完成，则不需要err的判断
	if (unlikely(yqp->attr.qp_state == IB_QPS_ERR) && (yib->host.funcs.sw_err_flush)) {
		struct yib_sw_cqe input_sw_cqe;
		err = yib_rq_recv_wr_when_err(yib, yqp, wr, &input_sw_cqe);
		os_spin_unlock_restore(&yrq->rq_lock, flags);
		if (input_sw_cqe.end_pos != input_sw_cqe.start_pos) {
			yib_sw_cqe_generate(yqp->yrq_cq, &input_sw_cqe, false, 0, 0);
			yib_run_cq_cmpl_evts(&yib->host.sf, yqp->yrq_cq);
		}
		goto end;
	}

	while (wr) {
		err = yib_recv_wr_check(&yib->host, yrq, wr);
		if (unlikely(err)) {
			yrq->queue->info->direct_cnt++;
			goto exit;
		}

		err = post_one_recv(yib, yrq, wr); //gsi硬件接收产生cq
		if (unlikely(err)) {
			*bad_wr = wr;
			break;
		}

		io_cnt++;
		wr = wr->next;
	}

exit:
	if (io_cnt > 0) {
		os_smp_wmb();
		yib->host.sf.queue_ops->rq_pi_db_update(&yib->host, yrq, io_cnt);
	}
	os_spin_unlock_restore(&yrq->rq_lock, flags);

end:
	if (err)
		*bad_wr = wr;
	return err;
}

int yib_user_post_recv(struct yusur_ib_dev *yib, struct yib_qp *yqp, const_ os_ib_recv_wr *wr,
			 const_ os_ib_recv_wr **bad_wr)
{
	struct yib_rq *yrq = yqp->type.yrq;
	int err = 0;

 	if (unlikely(!yrq)) {
		os_printw(yib->dev, "qp: %d rq is null\n", yib_get_qp_sw_idx(yqp));
		*bad_wr = wr;
		return -EINVAL;
	}

	if ((yqp->attr.qp_state < IB_QPS_INIT) || unlikely(!yqp->valid))  {
		os_printw(yib->dev, "qp: %d recv in wrong state:%d valid=%d\n",
				yib_get_qp_sw_idx(yqp), yqp->attr.qp_state, yqp->valid);
		err = -EINVAL;
		goto exit;
	}

 	if (wr == NULL)
		err = yib->host.hw_ops.uio_ops->uio_post_recv(&yib->host, yrq, (const void*)wr, true);
	else
		err = yib->host.hw_ops.uio_ops->uio_post_recv(&yib->host, yrq, (const void*)wr, false);

exit:
	if (unlikely(err)) {
		*bad_wr = wr;
	}		
	return err;
}

int yib_srq_chk_attr(struct yusur_ib_dev *yib, struct yib_srq *srq,
		     struct ib_srq_init_attr *init, enum ib_srq_attr_mask mask, int *u_srq_len)
{
	int rq_isize;
	struct ib_srq_attr *attr = &init->attr;

	if (init->srq_type == IB_SRQT_XRC) {
		if (init->ext.xrc.xrcd == NULL) {
			os_printw(yib->dev,"xsrq xrcd is NULL\n");
			goto err1;
		}
		if (init->ext.cq == NULL) {
			os_printw(yib->dev,"xsrq cq is NULL\n");
			goto err1;
		}
	}

	if (mask & IB_SRQ_MAX_WR) {
		if (attr->max_wr > yib->host.caps.max_srqes) {
			os_printw(yib->dev,"max_wr(%d) > max_srq_wr(%d)\n",
				attr->max_wr, yib->host.caps.max_srqes);
			goto err1;
		}

		if (srq && srq->limit && (attr->max_wr < srq->limit)) {
			os_printw(yib->dev,"max_wr (%d) < srq->limit (%d)\n",
				attr->max_wr, srq->limit);
			goto err1;
		}

		if (attr->max_wr < 1)
			attr->max_wr = 1;
	}

	if (mask & IB_SRQ_LIMIT) {
		if (attr->srq_limit > yib->host.caps.max_srqs) {
			os_printw(yib->dev,"srq_limit(%d) > max_srq_wr(%d)\n",
				attr->srq_limit, yib->host.caps.max_srqs);
			goto err1;
		}
	}

	if (mask == IB_SRQ_INIT_MASK) {
		if (attr->max_sge > yib->host.caps.max_rq_sg) {
			os_printw(yib->dev,"max_sge(%d) > max_srq_sge(%d)\n",
				attr->max_sge, yib->host.caps.max_rq_sg);
			goto err1;
		}

		if (attr->max_sge < yib->host.caps.max_rq_sg)
			attr->max_sge = yib->host.caps.max_rq_sg;
	}

	rq_isize = yib->host.sf.queue_ops->get_rq_item_size(&attr->max_sge);
	yib_queue_calc_depth(rq_isize, &attr->max_wr);
	*u_srq_len = attr->max_wr * rq_isize;
	return 0;
err1:
	return -EINVAL;
}

void yib_srq_limit_func(void *arg)
{
	struct yib_srq *ysrq, *temp;
	struct yib_hw_events *evts = arg;
	unsigned long flags;
	struct ib_event ev;

	list_for_each_entry_safe(ysrq, temp, &evts->process_list, evt_limit_node) {
		os_spin_lock_irqsave(&evts->lock, flags);//If hw assure not duplicate we can remove this lock
		list_del_init(&ysrq->evt_limit_node);
		os_spin_unlock_restore(&evts->lock, flags);

		ev.device = ysrq->ib_srq.device;
		ev.element.srq = &ysrq->ib_srq;
		ev.event = IB_EVENT_SRQ_LIMIT_REACHED;
		ysrq->ib_srq.event_handler(&ev, ysrq->ib_srq.srq_context);
		yib_elem_drop_ref(&ysrq->yrq->entry);
	}
}

void yib_srq_err_func(void *arg)
{
	struct yib_srq *ysrq, *temp;
	struct yib_hw_events *evts = arg;
	unsigned long flags;
	struct ib_event ev;

	list_for_each_entry_safe(ysrq, temp, &evts->process_list, evt_err_node) {
		os_spin_lock_irqsave(&evts->lock, flags);//If hw assure not duplicate we can remove this lock
		list_del_init(&ysrq->evt_err_node);
		os_spin_unlock_restore(&evts->lock, flags);

		ev.device = ysrq->ib_srq.device;
		ev.element.srq = &ysrq->ib_srq;
		ev.event = IB_EVENT_SRQ_ERR;
		ysrq->ib_srq.event_handler(&ev, ysrq->ib_srq.srq_context);
		yib_elem_drop_ref(&ysrq->yrq->entry);
	}
}

void yib_srq_lastwqe_func(void *arg)
{
	struct yib_srq *ysrq, *temp;
	struct yib_hw_events *evts = arg;
	unsigned long flags;
	struct ib_event ev;

	list_for_each_entry_safe(ysrq, temp, &evts->process_list, evt_lastwqe_node) {
		os_spin_lock_irqsave(&evts->lock, flags);//If hw assure not duplicate we can remove this lock
		list_del_init(&ysrq->evt_lastwqe_node);
		os_spin_unlock_restore(&evts->lock, flags);

		ev.device = ysrq->ib_srq.device;
		ev.element.srq = &ysrq->ib_srq;
		ev.event = IB_EVENT_QP_LAST_WQE_REACHED;
		ysrq->ib_srq.event_handler(&ev, ysrq->ib_srq.srq_context);
		yib_elem_drop_ref(&ysrq->yrq->entry);
	}
}

struct yib_rq *yib_rq_get_from_index(struct yib_hw_host *hw, u32 index, bool lock)
{
	struct yib_pool_entry *elem = NULL;

	elem = yib_pool_get_by_index(&hw->verbs.rq_pool, index, lock);//关键路径已经加锁
	if (elem == NULL)
		return NULL;
	return container_of(elem, struct yib_rq, entry);
}
