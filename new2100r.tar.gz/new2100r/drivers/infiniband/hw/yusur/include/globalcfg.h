/*
    This File  is used define Global Macro, and included by basic.h
*/

#ifndef _YUSUR_IB_GLB_H_
#define _YUSUR_IB_GLB_H_

#ifdef __linux__
#define CFG_OS_LINUX	1	//
#else
#define CFG_OS_WINDOWS 	1  	// Cfg to Windows platform 
#endif

#endif /* end _YUSUR_IB_GLB_H_ */
