#ifndef _YUSUR_IB_HOST_H_
#define _YUSUR_IB_HOST_H_

#define YIB_HOSTNAME_MAXLEN 32
#define YIB_MAX_MAC_TBL_LEN 8
#define YIB_MAX_EQ_NUM 8

#define YIB_DSCP_ARRAY_SIZE 64
#define YIB_PCP_ARRAY_SIZE  16
#define YIB_RX_BUF_ARRAY_SIZE 8
#define YIB_PFC_ENABLE_ARRAY_SIZE 8
#define YIB_PFC_LOW_ARRAY_SIZE 8
#define YIB_PFC_HIGH_ARRAY_SIZE 8

struct yib_sf;
struct yib_hw_host;
struct yusur_ib_dev;
struct yib_av;
struct yib_mr;
struct yib_cq;
struct yib_qp;
struct yib_srq;
struct yib_rq;
struct yib_sq;
struct yib_eq;
struct yib_evts_occurs;

struct yib_mac_tbl_item {
	u8 mac[6];  
	u16 ref_cnt;
	u8 port_num;
	u8 is_init; //init的不用引用计数
}; 

struct yib_mac_tbl {
	int max_items;
	struct yib_mac_tbl_item mac_tbl_item[YIB_MAX_MAC_TBL_LEN];
};

struct yib_rdma_qos_info {
	uint32_t cir;			//用户输入
	uint32_t cbs;			//用户输入
	uint32_t level;			//第几级的class 0:qp 1:cos 2:channel 3:host 4:port
	uint32_t obj_index;		//qpnx,cosx,hostx
	uint32_t is_multi_mode;
	uint32_t inherit_mode;	//继承模式，仅用于multi_mode
	uint32_t bypass;		//为1表示bypass
};

struct yib_queue_ops {
	int cqe_isize;
	int (*fill_rqe)(struct yib_hw_host *hw, struct yib_rq *rq, const void *os_wq, u8 *buf, u32 length);
	int (*fill_srqe)(struct yib_hw_host *hw, struct yib_rq *rq, const void *os_wq, u8 *buf, u32 length, int pos);
	int (*fill_wqe)(struct yib_hw_host *hw, struct yib_qp *qp, const void *os_wq, u8 *buf, u32 length,  u32 mask);
	//qp_cache是否使用，由底层的情况决定，当底层硬件有能力在cq中返回qp地址信息时不使用， 否则底层硬件可返回qpn(这时需要使用qp_cache)
	void (*fill_cqe)(struct yib_hw_host *hw, struct yib_cq *cq, struct yib_qp **qp_cache, void *os_cq, u8 *buf);
	int(*sw_fill_cqe)(struct yib_hw_host *hw, struct yib_cq *cq, void *os_cq);//返回0表示处理成功，小于0表示不保序

	bool (*check_sq_full)(struct yib_hw_host *hw, struct yib_sq *sq);
	bool (*check_rq_full)(struct yib_hw_host *hw, struct yib_rq *rq);
	bool (*check_srq_full)(struct yib_hw_host *hw, struct yib_srq *srq, int *pos);
	bool (*check_cq_empty)(struct yib_hw_host *hw, struct yib_cq *cq, u8 *cqe);
	//bool (*is_resize_cq)(u8 *buf);

	//若上层填入的inline_len/max_sg 超过了硬件最大能力，硬件按最大能力上报
	int (*get_sq_item_size)(int *inline_len, int *max_sg, bool is_ud);//inline_len和max_sg为输入输出参数
	int (*get_rq_item_size)(int *max_sg);

	//db update
	void (*sq_pi_db_update)(struct yib_hw_host *hw, struct yib_qp *qp, int io_cnt);
	void (*rq_pi_db_update)(struct yib_hw_host *hw, struct yib_rq *rq, int io_cnt);
	void (*srq_pi_db_update)(struct yib_hw_host *hw, struct yib_srq *srq, int pos);
	void (*cq_ci_db_update)(struct yib_hw_host *hw, struct yib_cq *cq, int poll_cnt);
};

struct yib_eq_ops {
	bool intr_enable;
	int priv_size;
	int (*get_eq_intr_num)(struct yib_sf *sf);
	int (*eq_info_init)(struct yib_sf *sf, struct yib_eq *eq, int depth, bool b_del);
	int (*eq_debugfs)(struct yib_sf *sf, struct yib_eq *yeq);
	bool (*check_eq_empty)(struct yib_sf *sf, struct yib_eq *eq);
	void (*eq_sw_handler)(struct yib_sf *sf, struct yib_eq *eq, u8 *buf);
	void (*eq_handler)(struct yib_sf *sf, struct yib_eq *eq, struct yib_evts_occurs *evts_occurs);//中断中执行,返回是否提交到了event 队列中
	void (*eq_ci_db_update)(struct yib_sf *sf, struct yib_eq *eq, int io_cnt);
};

//fill from buf to os_cqe
struct yib_sf_ops { //这个方法内只能使用sf信息,不能使用host的信息
	enum yrdma_host_type host_type;
	const int priv_size;

	int (*sf_pre_init)(struct yib_sf *sf); //sf静态初始信息赋值
	int (*sf_init)(struct yib_sf *sf, bool b_del);

	int (*start_sf)(struct yib_sf *sf); //sf初始化
	void (*stop_sf)(struct yib_sf *sf, bool is_shutdown); //sf卸载

	void (*add_mac)(struct yib_sf *sf, u8 *mac, int index, u8 port_num);// 配置网卡mac
	void (*modify_mac)(struct yib_sf *sf, u8 *mac, int index, u8 port_num, bool bdel);

	void (*set_gid)(struct yib_sf *sf, bool brocev2, bool bipv4, int index, u8 *raw, bool bdel);

	void (*init_av)(struct yib_sf *sf, struct yib_av *av, int index, bool b_del);

	int (*mrw_alloc)(struct yib_sf *sf, struct yib_mr *mr, u32 *lkey, u32 *rkey);
	void (*mrw_destroy)(struct yib_sf *sf, struct yib_mr *mr);
	int (*mr_mtt_init)(struct yib_sf *sf, struct yib_mr *mr, struct scatterlist *sg, int npages, u32 page_size, u64 pa0); //仅noamal_mr使用
	int (*mr_mpt_update)(struct yib_sf *sf, struct yib_mr *mr); //操作mpt表
	int (*mr_debugfs)(struct yib_sf *sf, struct yib_mr *mr);
	
	//cq
	int (*cq_info_init)(struct yib_sf *sf, struct yib_cq *cq,  bool b_del);
	void (*cq_notify_update)(struct yib_sf *sf, struct yib_cq *cq, u32 solicited_only);
	int (*cq_debugfs)(struct yib_sf *sf, struct yib_cq *cq);

	//qp
	int (*qp_info_init)(struct yib_sf *sf, struct yib_qp *yqp, bool enable);
	bool (*qp_info_update)(struct yib_sf *sf, struct yib_qp *yqp, u32 mask, bool state_chg);
	int (*qp_query)(struct yib_sf *sf, struct yib_qp *qp, os_qp_attr *attr, int mask, bool bdebug);
	int (*qp_debugfs)(struct yib_sf *sf, struct yib_qp *qp);

	//srq & rq
	int (*rq_info_init)(struct yib_sf *sf, struct yib_rq *yrq, bool enable, bool bsrq);//srq和rq都会调用这个步骤，rq时需要在qp_info_init之前
	int (*srq_debugfs)(struct yib_sf *sf, struct yib_srq *ysrq);

	void (*sf_debugfs)(struct yib_sf *sf);
};

struct yib_uio_ops {
	//db与指针都在底层维护, 当db_only为true时，表示只下门铃
	//对user_io场景，上层不加锁，底层加锁
	int (*uio_post_send)(struct yib_hw_host *hw, struct yib_qp *qp, const void* wr, bool db_only);
	int (*uio_post_recv)(struct yib_hw_host *hw, struct yib_rq *rq, const void* wr, bool db_only);
	int (*uio_poll_cq)(struct yib_hw_host *hw, struct yib_cq *cq, int num, void *wc, bool db_only);
};

struct yib_hw_ops {
	enum yrdma_host_type host_type;
	const int priv_size;
	char host_name[YIB_HOSTNAME_MAXLEN];

	//if need call sf, we use port_num0, because spped, counter ,caps are all the same with different sf
	void (*global_reset)(struct yib_hw_host *hw); //第1个被调用硬件全局复位，整个host/pf/vf级别只能做一次
	int (*init_caps)(struct yib_hw_host *hw, struct yib_sf *sf);	//第2个被调用的方法，该方法仅返回硬件的能力

	int (*start_host)(struct yib_hw_host *hw); //全局初始化
	void (*stop_host)(struct yib_hw_host *hw); //全局卸载
	void (*shutdown_host)(struct yib_hw_host *hw);

	int (*set_qos)(struct yib_hw_host *hw, struct yib_rdma_qos_info *qos_info);
	int (*set_rx_buf_size)(struct yib_hw_host *hw);
	void (*get_hw_counter)(struct yib_hw_host *hw, u64 *value, u32 port_num); //填充counter信息
	int (*host_reg_mmap)(struct yib_hw_host *hw, struct vm_area_struct *vma, ssize_t length, u64 offset);
	int (*host_def_mmap)(struct yib_hw_host *hw, struct vm_area_struct *vma, ssize_t length, u64 offset, int type);
	#if (COUNTER_STAT_DESC)	
	const struct rdma_stat_desc  *(*get_counter_info)(struct yib_hw_host *hw, u32 *count);
	#else
	const char * const *(*get_counter_info)(struct yib_hw_host *hw, u32 *count);
	#endif

	int (*get_usable_channels)(struct yib_hw_host *hw);//用于pcie sriov en前检测vf数量是否满足。
	void (*get_queue_user_info)(struct yib_hw_host *hw, enum yib_elem_type type, void *verbs, u32 hw_id, u8 *res, int *len);
	void (*host_debugfs_reg)(struct yib_hw_host *hw);
	void (*host_debugfs_mem)(struct yib_hw_host *hw, u32 len, u64 addr);
	int (*user_def_hw_debugfs)(struct yib_hw_host *hw, u8 *buf);
	void (*smac_debugfs)(struct yib_hw_host *hw);//打印整个smac表
	void (*sgid_debugfs)(struct yib_hw_host *hw);//打印整个sgid表
	struct yib_sf_ops *sf_ops;
	struct yib_eq_ops *eq_ops;
	struct yib_queue_ops *queue_ops;
	struct yib_uio_ops *uio_ops;
};

struct yib_db_frag { //存在的目的是为了能让用户态使用，这样内核dbg能获取到用户态的值
	struct yib_frag_buf *cq_info;
	struct yib_frag_buf *sq_info;
	struct yib_frag_buf *rq_info;
};

struct yib_sf {
	struct yib_hw_host *hw;
	struct mutex	*host_mutex;//pcie层分配
	bool			bonding;
	bool			started;

	void __iomem	*reg_base[BAR_SPACES_MAX];//pcie设备bar空间基址，不加偏移
	u32				bar_size[BAR_SPACES_MAX];//每个sf用到的bar空间大小
	struct pci_dev	*pdev;
	int				num_node;
	int				udp_port;

	u16				vf_id;
	u8				pf_id;
	u8				host_id;
	u32				irq_vector;
	int				irq_cnt;

	struct yib_sf_ops		*sf_ops;
	struct yib_queue_ops	*queue_ops;
	void					*sf_priv;
	struct yib_qp			*gsi;

	struct yib_eq_ops		*eq_ops;
	struct yib_hw_events	cq_cmpl_evts;
	struct yib_hw_events	cq_err_evts;
	struct yib_hw_events	qp_fatal_evts;
	struct yib_hw_events	srq_err_evts;
	struct yib_hw_events	srq_lastwqe_evts;
	struct yib_hw_events	aeq_evts;
	struct yib_eq			*event_queue[YIB_MAX_EQ_NUM];
};

typedef struct  
{
	struct yib_pool 	qp_pool;
	struct yib_pool 	mrw_pool;
	struct yib_pool 	rq_pool;
	struct yib_pool 	cq_pool;
	struct yib_pool 	eq_pool;
	struct yib_pool 	pd_pool;
	struct yib_pool 	ah_pool;
} host_verbs_t;

struct yib_ndev_info {
	os_net_device		*netdev;
	int					link_down;
	enum ib_mtu			cur_max_mtu;
	int					port_id;
};

struct yib_hw_host {
	os_device				*dev;
	struct net_device		*net_dev[YIB_MAX_DEV_PORTS]; //临时缓存，便于代码形式统一
	void __iomem			*reg_base[BAR_SPACES_MAX];
	u32						bar_size[BAR_SPACES_MAX];
	u32						irq_vector;
	int						irq_cnt;    //临时缓存，便于代码形式统一

	host_verbs_t			verbs;
	struct yib_db_frag		db_frag;
	struct yib_ndev_info	ndev_info[YIB_MAX_DEV_PORTS];
	struct yib_sf			sf;
	int						sf_per_port;

	struct yib_mac_tbl		mac_tbl;
	struct yib_hw_ops		hw_ops;
	struct yib_roce_caps	caps;
	struct yib_dev_funcs	funcs;
	void					*hw_priv;
	void					*yib;

	u16						vf_id;
	u8						pf_id;
	u8						host_id;
	u32						chip_subtype;//扩展使用目前填0
	u32 					hw_counter_cnt;
	os_cdma_t 				prio_array;
	u8						rx_buf_mode;
};

void yusur_hw_host_register(void);
int yusur_hw_host_find(struct yib_hw_ops *ops, enum yrdma_host_type host_type);
void yusur_hw_mactbl_item_change(struct yib_hw_host *hw, u8 *mac, int index, u8 port_num);
int yusur_hw_mactbl_search(struct yib_hw_host *hw, u8 *mac, u8 port_num, bool b_add);
int yusur_dev_update_mtu(struct yib_hw_host *host, struct net_device *ndev, int port_num);
int yusur_hw_host_pre_init(struct yib_hw_host *host);
int yusur_hw_cap_verify(struct yib_roce_caps *caps);

int  yusur_hw_host_init(struct yib_hw_host *host);
void  yusur_hw_host_uinit(struct yib_hw_host *host);
u64 yusur_hw_get_bar_pa_by_off(struct yib_hw_host *hw, int bar_idx, u32 offset);
u64 yusur_hw_get_bar_va_by_off(struct yib_hw_host *hw, int bar_idx, u32 offset);
u32 yib_get_dscp_by_index(struct yib_hw_host *hw, u32 index);
u32 yib_get_pcp_by_index(struct yib_hw_host *hw, u32 index);

void reg_dbg_print_range(const char *title, void *vaddr, u32 len, u64 paddr);
void mem_dbg_print_range(const char *title, struct yib_hw_host *hw, u32 key);
void reg_dbg_print_eq(struct yusur_ib_dev *yib, struct yib_eq *yeq);
void reg_dbg_print_srq(struct yusur_ib_dev *yib, struct yib_srq *srq);
void reg_dbg_print_sf(struct yusur_ib_dev *yib);
void reg_dbg_print_qp(struct yusur_ib_dev *yib, struct yib_qp *yqp);
void reg_dbg_print_cq(struct yusur_ib_dev *yib, struct yib_cq *ycq);
void reg_dbg_print_mr(struct yusur_ib_dev *yib, struct yib_mr *ymr);

void yib_global_mcast_lock(struct yib_sf *sf, unsigned long *irq_flag);
void yib_global_mcast_unlock(struct yib_sf *sf, unsigned long irq_flag);
void yib_global_resource_lock(struct yib_sf *sf, unsigned long *irq_flag);
void yib_global_resource_unlock(struct yib_sf *sf, unsigned long irq_flag);
void yib_sf_mutex_lock(struct yib_sf *sf);
void yib_sf_mutext_unlock(struct yib_sf *sf);
void yib_sf_ddr_lock(struct yib_sf *sf, unsigned long *irq_flag);
void yib_sf_ddr_unlock(struct yib_sf *sf, unsigned long irq_flag);
#endif /* end _YRDMA_IB_HOST_H_ */
