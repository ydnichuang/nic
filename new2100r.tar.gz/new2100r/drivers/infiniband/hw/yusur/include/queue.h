#ifndef __QUEUE_H
#define __QUEUE_H
#include <linux/pci.h>

#define u64_lsb(a) ((u32)((a) & 0xFFFFFFFF))
#define u64_msb(a) ((u32)((a) >> 32))
#define os_align_any_up(x, a)   (((x) + (a) - 1) / (a) * (a))
#define queue_index_dec(index, depth) ((index + depth - 1) % depth)
#define queue_index_inc(index, depth) ((index + depth + 1) % depth)

struct yib_queue_info//sq rc,cq
{
	os_atomic  pi;
	os_atomic  ci;
	u64        io_count; // 完成或提交次数
	u64        err_count; //完成错误个数, 【rq,sq 为队列满的次数】 cq为wc->err的个数
	u32        direct_cnt; //[sq,rq]为直接返回失败的次数， cq为软件完成次数
	u16        pi_toggle; //翻转位
	u16        ci_toggle;
};

struct yib_queue_mem
{
	union {
		void *umem;    //用户态用这个
		struct yib_frag_buf *kmem;//内核态用这个
	} mem;
	int		depth;
	u16		item_size;
	bool	is_user;//用户态还是内核态队列
	struct yib_queue_info  *info;
	struct yib_page_tbl    tbl;
};

void yib_queue_info_init(struct yib_queue_info *info);

int yib_queue_get_page_cnt(int item_size, int depth);
void yib_queue_calc_depth(int item_size, int *cnt);

void* yib_queue_get_vaddr_by_index(struct yib_queue_mem *queue, int index);
void* yib_queue_get_pi_vaddr(struct yib_queue_mem *queue); //for sq rq, srq  vaddr
void* yib_queue_get_ci_vaddr(struct yib_queue_mem *queue); //for cq ,eq   vaddr

int yib_queue_advance_pi(struct yib_queue_mem *queue, int diff);
int yib_queue_advance_ci(struct yib_queue_mem *queue, int diff);

struct yib_queue_mem *yib_create_queue(struct yib_sf *sf, int depth, int item_size, void *umem);//当umem为NULL时为内核态。
void yib_destroy_queue(struct yib_sf *sf, struct yib_queue_mem *queue);
#endif /* __QUEUE_H */
