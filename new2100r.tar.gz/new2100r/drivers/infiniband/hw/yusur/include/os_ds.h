#ifndef _YUSUR_IB_OSDS_H_
#define _YUSUR_IB_OSDS_H_

#define XIB_MAX_BMAP_NAME	(16)

struct yib_bmap {
	unsigned long *bitmap;
	u32 max_count;
	bool bglobal;
	char name[XIB_MAX_BMAP_NAME];
};

void yib_bmap_free(struct yib_bmap *bmap);
int yib_bmap_alloc(struct yib_bmap *bmap, bool bglobal, unsigned long *buf, u32 max_count, char *name);
int yib_bmap_alloc_id(struct yib_bmap *bmap, u32 *id_num);
void yib_bmap_release_id(struct yib_bmap *bmap, u32 id_num);

#define YIB_POOL_ALIGN		(16)
#define YIB_POOL_CACHE_FLAGS	(0)

enum yib_pool_flags {
	//If set use GFP_ATOMIC for kzalloc
	YIB_POOL_ATOMIC			= BIT(0),
	YIB_POOL_INDEX			= BIT(1), //使用BITMAP 分配index
	 //NO_ALLOC的资源是上层分配ib资源， 不调用yib_pool_alloc, 直接调用yib_pool_add 
	//(infinband core层维护引用计数)， 这里维护形式上的代码统一也用内部的ref
	YIB_POOL_NO_ALLOC		= BIT(2),
	YIB_POOL_ARRAY_IDX		= BIT(3),
};

struct yib_pool_entry;

struct yib_type_info {
	const char	*name;
	size_t		size;
	void		(*cleanup)(struct yib_pool_entry *obj);
	u32			flags;
	u32			max_index;
	u32			min_index;
};

extern struct yib_type_info yib_type_info[];

enum yib_pool_state {
	YIB_POOL_STATE_INVALID,
	YIB_POOL_STATE_VALID,
};

struct yib_pool_entry {
	struct yib_pool		*pool;
	os_ref				ref_cnt;
	//os_list_head		list;

	/* only used if indexed or keyed */
	struct rb_node		node;
	u32					index:31;
	u32					special:1;
};

struct yusur_ib_dev;

struct yib_pool {
	os_rwlock			pool_lock; /* protects pool add/del/search */
	size_t				elem_size;
	os_ref				ref_cnt;
	void				(*cleanup)(struct yib_pool_entry *obj);
	enum yib_pool_state	state;
	u32					flags;
	enum yib_elem_type	type;

	unsigned int		max_elem;
	unsigned int		max_real_elem;  //max_real_elem must <= max_elem
	os_atomic			num_elem;

	/* only used if indexed or keyed */
	struct yib_pool_entry   **array;

	unsigned long		*table;
	size_t				table_size;
	u32					max_index;
	u32					min_index;
	u32					last;
};

/* initialize a pool of objects with given limit on
 * number of elements. gets parameters from yib_type_info
 * pool elements will be allocated out of a slab cache
 */
int yib_pool_init(struct yib_pool *pool, enum yib_elem_type type, unsigned int max_elem,
					unsigned int max_real_cnt);

void yib_set_pool_max_cnt(struct yib_pool *pool, unsigned int max_real_cnt);
/* free resources from object pool */
void yib_pool_cleanup(struct yib_pool *pool);

/* allocate an object from pool */
void *yib_pool_alloc(struct yib_pool *pool);
void *yib_pool_alloc_specify_index(struct yib_pool *pool, int index);

/* connect already allocated object to pool */
int yib_add_to_pool(struct yib_pool *pool, struct yib_pool_entry *elem);
int yib_add_to_pool_special(struct yib_pool *pool, struct yib_pool_entry *elem, bool specify, int sindex);

/* lookup an indexed object from index. takes a reference on object */
void *yib_pool_get_by_index(struct yib_pool *pool, u32 index, bool ref_inc);//在非锁的环境下要ref_inc=true

/* lookup keyed object from key. takes a reference on the object */
void *yib_pool_get_by_key(struct yib_pool *pool, void *key);

/* cleanup an object when all references are dropped */
void yib_pool_elem_release(struct kref *kref);

/* check whether index is in pool	*/
bool yib_pool_check_index(struct yib_pool *pool, u32 index, bool special);

/* take a reference on an object */
#define yib_elem_add_ref(elem) os_ref_get(&(elem)->ref_cnt)

/* drop a reference on an object */
#define yib_elem_drop_ref(elem) os_ref_put(&(elem)->ref_cnt, yib_pool_elem_release)

#endif /* end _YUSUR_IB_OSAPI_H_ */
