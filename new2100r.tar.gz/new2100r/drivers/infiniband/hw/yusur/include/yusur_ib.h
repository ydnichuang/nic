#ifndef _YUSUR_IB_MAIN_H_
#define _YUSUR_IB_MAIN_H_

enum yib_counters {
	YIB_CNT_LINK_DOWN = 0,
}; //todo according hw

struct yusur_ib_dbg_dentry {
	struct dentry	*dbg_sf;
	struct dentry	*dbg_srq;
	struct dentry	*dbg_qp;
	struct dentry	*dbg_cq;
	struct dentry	*dbg_mr;
	struct dentry	*dbg_eq;
	struct dentry	*dbg_host_reg;
	struct dentry   *dbg_host_mem;
	struct dentry   *dbg_smac;
	struct dentry	*dbg_sgid;
	struct dentry   *dbg_stat;
	struct dentry   *dbg_cq_evt_inject;
	struct dentry	*dbg_cq_inject;
	struct dentry   *dbg_user_def;
};

struct yusur_ib_dev {
	os_ib_device			ib_dev;
	os_device				*dev;
	bool 					bonding;
	os_spinlock_t			lock;
	os_net_notifier			netdev_notifier;
	struct yib_hw_host		host;
	void					*yrdev;
	void					*global_mr;

	struct yusur_ib_dbg_dentry dbg_dentry;
#if IB_DEV_HAS_SYS == 0
	struct kobject	sys_kobj;
	bool            sys_ok;
#endif	
};


#endif /* end _YRDMA_IB_MAIN_H_ */