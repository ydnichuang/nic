#ifndef _YUSUR_IB_BASIC_H_
#define _YUSUR_IB_BASIC_H_


#include "globalcfg.h"


#ifdef CFG_OS_LINUX
#include <asm/io.h>
#include <linux/device.h>
#include <linux/string.h>
#if !defined(__mips64)
#include <asm/uaccess.h>
#endif
#include <asm/page.h>
#include <asm/byteorder.h>
#include <linux/stddef.h>
#include <linux/string.h>
#include <linux/errno.h>
#include <linux/kernel.h>
#include <linux/ioport.h>
#include <linux/slab.h>
#include <linux/delay.h>
#include <linux/pci.h>
#include <linux/spinlock.h>
#include <linux/proc_fs.h>
#include <linux/reboot.h>
#include <linux/interrupt.h>
#include <linux/types.h>
#include <linux/stat.h>
#include <linux/spinlock.h>
#include <linux/sched.h>
#include <linux/spinlock_types.h>
#include <linux/semaphore.h>
#include <linux/completion.h>
#include <linux/delay.h>
#include <linux/kdev_t.h>
#include <linux/export.h>
#include <linux/kthread.h>
#include <linux/wait.h>
#include <linux/etherdevice.h>
#include <linux/netdevice.h>
#include <linux/inetdevice.h>
#include <net/addrconf.h>
#include <rdma/ib_verbs.h>
#include <rdma/ib_addr.h>
#include <rdma/ib_umem.h>
#include <rdma/ib_pack.h>
#include <rdma/ib_cache.h>
#include <linux/kref.h>
#include <linux/rwlock_types.h>
#include <linux/rwlock.h>

#include <linux/yusur/yrdma_model.h>
#include "debug.h"

typedef struct ib_device		os_ib_device;
typedef struct pci_dev			os_pci_device;
typedef struct device			os_device;
typedef struct net_device		os_net_device;
#define os_spinlock_t			spinlock_t
typedef struct notifier_block	os_net_notifier;
typedef struct scatterlist		os_sg;
typedef struct ib_wc			os_ib_wc;
typedef struct ib_qp_attr		os_qp_attr; 
typedef struct ib_qp_init_attr	os_qp_init_attr;
typedef struct ib_qp_cap		os_qp_cap;
typedef struct ib_srq_attr		os_srq_attr;
typedef struct ib_recv_wr		os_ib_recv_wr;
typedef struct ib_send_wr		os_ib_send_wr;

enum yib_wr_mask {
	WR_INLINE_MASK			= BIT(0),
	WR_ATOMIC_MASK			= BIT(1),
	WR_SEND_MASK			= BIT(2),
	WR_READ_MASK			= BIT(3),
	WR_WRITE_MASK			= BIT(4),
	WR_LOCAL_MASK			= BIT(5),
	WR_REG_MASK				= BIT(6),
	WR_MW_MASK				= BIT(7),

	WR_READ_OR_WRITE_MASK		= WR_READ_MASK | WR_WRITE_MASK,
	WR_READ_WRITE_OR_SEND_MASK	= WR_READ_OR_WRITE_MASK | WR_SEND_MASK,
	WR_WRITE_OR_SEND_MASK		= WR_WRITE_MASK | WR_SEND_MASK,
	WR_ATOMIC_OR_READ_MASK		= WR_ATOMIC_MASK | WR_READ_MASK,
};


#define os_for_each_sg(sglist, sg, nr, __i) for_each_sg(sglist, sg, nr, __i)
#define os_sg_dma_addr(x) 	sg_dma_address(x)	
#define os_sg_dma_len(x) 	sg_dma_len(x)	


//适用于2的整数次放
#define os_align(x,s) ((x) & ~((s) - 1))
#define os_align_up(x,s) (((x) + (s) -1) & ~((s) -1))
#define os_align_any(x, a)  ((x)  / (a) * (a))
#define os_align_any_up(x, a)   (((x) + (a) - 1) / (a) * (a))

#else //windows
#endif

struct yib_dev_funcs {
	uint32_t    ud_multicast:1;
	uint32_t    srq_supp:1;
	uint32_t    srq_modify:1;
	uint32_t    srq_limit:1;
	uint32_t    mw_supp:1;
	uint32_t    atomic_supp:1;
	uint32_t    ud_supp:1;
	uint32_t    uc_supp:1;
	uint32_t    xrc_supp:1;
	uint32_t    quick_excep:1;
	uint32_t    sw_err_flush:1;
	uint32_t    srq_seq:1;//设置为1表明框架层实现srq保序
	uint32_t    queue_l2_tbl:1;//队列是否支持二级页表
	uint32_t    mr_l2_tbl:1;//mr是否支持二级页表
};

typedef enum {
	YIB_CQ_EVENT_COMP = 0, //CQ cqe complete
	YIB_QP_EVENT_FATAL,
	YIB_CQ_EVENT_FULL,
	YIB_QP_EVENT_QP_ERR,  //QP enter error state
	YIB_QP_EVENT_RESET_DONE, //QP enter reset done
	YIB_SRQ_EVENT_WARN,
	YIB_QP_EVENT_LIMIT_SPEED,
	YIB_SQ_EVENT_RETRANS,
	YIB_QP_EVENT_END,
} yib_eq_event;

enum yib_elem_type {
	YIB_TYPE_PD,
	YIB_TYPE_AH,
	YIB_TYPE_RQ,
	YIB_TYPE_QP,
	YIB_TYPE_CQ,
	YIB_TYPE_MR,
	YIB_TYPE_EQ,
	YIB_TYPE_MC_GRP,
	YIB_NUM_TYPES,		/* keep me last */
};

struct yib_roce_caps {
	u64		fw_ver;
	u64		hw_ver;
	u32		num_ports;//最大port数
	u32		num_qps; //最大支持的qp, 
	u32		num_cqs;//最大支持的cq
	u32		max_qp_wr;//一个qp的最大队列深度
	u32		max_rq_sg; //一个rqe的最大sg数
	u32		max_sq_sg; //一个sqe的最大sg数
	u32		max_sq_inline; //sq max inline的大小

	u32		max_mr;	//最多mr数量
	u32		page_size_cap;
	u32		num_comp_vector; //cq完成向量个数，和msix相关，目前为1

	u32		max_cqes;//cq队列最大深度
	u32		max_srqes; //srq队列深度

	u32		max_qp_init_rd_atom; //最大同时提交的wqe数
	u32		max_qp_rd_atom;
	u32		max_res_rd_atom;
	u32		max_mr_sgs; //一个mr最多的sg数量
	u32		max_rqs;
	u32		max_eqs;
	u32		max_mtu;

	u32		num_pds;//最大支持的pd
	u32		max_ah; //ah最大个数
	u32		max_srqs; //srq最大个数
	u64		max_mr_size;//一个mr最多的内存数
	u32		max_mcast_qps;  //最大广播qp数
	u32		max_mcast_grp; //最大广播组数
};

static inline u32 os_align_to_pow_n(u32 cqe, int n)
{
	while (cqe > n) {
		n *= n;
	}
	return n;
}

#endif /* end _YRDMA_IB_BASIC_H_ */
