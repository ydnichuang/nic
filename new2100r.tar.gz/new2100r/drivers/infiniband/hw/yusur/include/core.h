#ifndef _YUSUR_IB_CORE_H_
#define _YUSUR_IB_CORE_H_

int yusur_core_ibdev_init(struct yusur_ib_dev *ibdev, enum yrdma_host_type host_type);
void yusur_core_ibdev_free(struct yusur_ib_dev *ibdev);




#endif /* end _YUSUR_IB_CORE_H_ */

