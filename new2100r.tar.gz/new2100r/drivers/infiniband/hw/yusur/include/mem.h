#ifndef __MEM_H
#define __MEM_H
#include <linux/pci.h>

struct yib_page_tbl{
	int levels;
	int pg_size;//页表大小， 4k的2^n倍
	int pg_count;
	//物理页面个数
	u64 root_pa;
	//入口pa地址
	//0级页表，入口地址直接就是数据内容，即物理页面首地址
	//1级页表，入口地址为最终页框的地址，即tbl_frag->frags->dma_addr
	//2级页表，入口地址为根页框的地址，即root_page->desc_map

	struct yib_frag_buf *tbl_frag;	//1级页表框，需dma分配，0级页表时该项为空
	struct yib_frag_buf *root_frag; //2级根页框，需dma分配，0级或1级时该项为空，大小与1级页表框大小一致

	int pbl_pg_size;
	//1级页表框的大小，4k的2^n倍，为系统能分出的最大fragment
};

int yib_create_page_table_by_pages(struct yib_sf *sf, struct yib_page_tbl *tbl, u64 pages[], int npages);
int yib_create_page_table_by_frag(struct yib_sf *sf, struct yib_page_tbl *tbl,
			struct yib_frag_buf *dat_frag, bool l2_tbl_supp);
int yib_create_page_table_by_sg(struct yib_sf *sf, struct yib_page_tbl *tbl, struct scatterlist *sglist,
			int npages, u32 page_size, bool l2_tbl_supp);
void yib_destroy_page_table(struct yib_sf *sf, struct yib_page_tbl *tbl);
u64 yib_mem_get_pa(struct yib_page_tbl *tbl, int index);
int yib_get_4kpages_from_pagetbl(struct yib_page_tbl *tbl, int max_items, u64 *array);
#endif /* __MEM_H */
