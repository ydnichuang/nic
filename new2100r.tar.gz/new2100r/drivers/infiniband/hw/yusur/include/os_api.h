#ifndef _YUSUR_IB_OSAPI_H_
#define _YUSUR_IB_OSAPI_H_

#ifdef CFG_OS_LINUX
#include <linux/yusur/compiler.h>
#include "../linux/linux_api.h"
#define MAC_ADDR_LEN ETH_ALEN
#else
#endif

#if(0)
typedef struct {
        os_dma_addr_t dma_addr;
        void *vaddr;
        os_dma_dir dir;
        int order;
        int size;
} os_pdma_t;
#endif

typedef union {
	struct sockaddr_in  _sockaddr_in;
	struct sockaddr_in6 _sockaddr_in6;
} os_ipaddr_t;

typedef struct {
	os_dma_addr_t	dma_addr;
	void 			*vaddr;
	int				size;
} os_cdma_t;

void os_get_netdev_mac(os_net_device * ndev, u8 *mac);
int os_get_netdev_ip(os_net_device * ndev, u32 *ip, bool is_ipv6);
int os_get_netdev_mtu(os_net_device * ndev);
enum ib_mtu os_get_ib_mtu(os_net_device * ndev);
u16 os_get_pcidev_vendor(os_pci_device *pdev);
u16 os_get_pcidev_device(os_pci_device *pdev);
u64 os_get_pci_bar_start(os_pci_device *pdev, int bar);
u64 os_get_pci_bar_end(os_pci_device *pdev, int bar);

//os_pdma_t os_alloc_paged_dma(os_pci_device *pdev, u32 size, os_dma_dir dir);
//void os_free_paged_dma(os_pci_device *pdev, os_pdma_t *dma);

//if mutex is not null, it will alloc dma for pci numa_node
os_cdma_t os_alloc_coherent_dma(os_pci_device *pdev, u32 size, int num_node, os_mutex_t *mutex);
void os_free_coherent_dma(os_pci_device *pdev, os_cdma_t *dma);

#define u64_lsb(a) ((u32)((a) & 0xFFFFFFFF))
#define u64_msb(a) ((u32)((a) >> 32))

struct os_thread_t {
	volatile u32		thread_shutdown;
	struct task_struct	*task;
	struct completion	thread_finishing;
};

int os_request_irq(struct yib_sf *sf, void *arg, irq_handler_t thread_fn);
void os_free_irq(struct yib_sf *sf, void *arg);

u32 os_numTo2n2(u32 x);
int os_log2n(u32 x);

#endif /* end _YUSUR_IB_OSAPI_H_ */
