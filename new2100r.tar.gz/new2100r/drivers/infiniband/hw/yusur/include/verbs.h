#ifndef _YUSUR_IB_VERBS_H_
#define _YUSUR_IB_VERBS_H_

#define YIB_DEBUG_IO_DONE 1
#define RDMA_DRIVER_ID_YUSUR 1000
#define YUSUR_RDMA_GID_TABLE_LEN 128
#define YUSUR_RDMA_PKEY_TABLE_LEN 128
#define YUSUR_RDMA_FAST_MR_SG_LEN   (PAGE_SIZE / sizeof(u64))

//资源最小粒度为32个
#define YIB_MAX_QPS		4096
#define YIB_MAX_RQS		YIB_MAX_QPS
#define YIB_MAX_CQS		(2 * YIB_MAX_QPS)
#define YIB_MAX_MRS		(2 * YIB_MAX_QPS)
#define YIB_MAX_DDR_RESOURCES (YIB_MAX_QPS + YIB_MAX_CQS + YIB_MAX_RQS + YIB_MAX_MRS)
#define YIB_MAX_MCAST    128  //MCAST NOT IN DDR
#define YIB_MAX_EQS		32
#define YIB_MAX_PDS		65536
#define YIB_MAX_AHS		65536
#define YIB_MAX_SMACS	8

#define YIB_MAX_HOST_CNT	4
#define YIB_MAX_HOST_PF		4
#define YIB_MAX_PF_VF		256

extern u16 g_yib_pkey_table[YUSUR_RDMA_PKEY_TABLE_LEN];

enum yib_cqe_type {
    YIB_CQE_SQ,
    YIB_CQE_RQ,
    YIB_CQE_SRQ,
};

#if(0)
union yib_gid {
	__u8	raw[16];
	struct {
		__be64	subnet_prefix;
		__be64	interface_id;
	} global;
};
#endif
struct net_device *yib_get_netdev(struct ib_device *ibdev, tPortInt port_num);

struct yib_global_route {
	union ib_gid	dgid;
	__u32			flow_label;
	__u8			sgid_index;
	__u8			hop_limit;
	__u8			traffic_class;
};

enum yib_network_type{
	YIB_NETWORK_TYPE_IPV4 = 1,
	YIB_NETWORK_TYPE_IPV6 = 2,
};

struct yib_av {
	__u8					port_num;
	__u8					network_type;
	__u8					dmac[6];
	__u8					smac_idx;
	__u8					smac[6];
	__u16					vlan_id;
	__u8					vlan_pcp;
	struct yib_global_route	grh;
	union ib_gid			sgid;
	union {
		struct sockaddr_in	_sockaddr_in;
		struct sockaddr_in6	_sockaddr_in6;
	} sgid_addr, dgid_addr;
};

struct yib_mr_type {
	uint32_t is_user:1;
	uint32_t is_dma:1;
	uint32_t is_fast:1;
	uint32_t is_peer:1;
	uint32_t is_mw:1;
};

enum yib_mr_state {
	YIB_MR_INVALID,
	YIB_MR_FREE,
	YIB_MR_VALID,
};

struct yib_mw {
	os_ib_mw		ib_mw;
	struct yib_mr	*pmr;
};//其他信息bind时从上层传下来

struct yib_fmr {
	void *descs;//对齐后的虚拟地址
	void *descs_alloc;//真实的分配虚拟地址
	dma_addr_t desc_map;//对齐后的物理地址
	int max_descs;
	int ndescs;
	int desc_size;
	u64 pa;
};

struct yib_mr {
	struct yib_pool_entry	entry;
	os_ib_mr				ib_mr;//mw 不能用该字段
	struct yib_mr_type		type;
	enum yib_mr_state		state;
	u8						access;
	os_ib_umem				*umem;
	u32						pd_num;
	void					*privdata; //extension for doe
	u64						u_mr_handler;

	union {
		void				*page_tbl;
		struct yib_mw		*pmw;
		struct yib_fmr		*fmr;
	} priv;
};

#define yib_os_mr_rkey(ymr)	(ymr->ib_mr.rkey)
#define yib_os_mr_iova(ymr)	(ymr->ib_mr.iova)
#define yib_os_mr_length(ymr) (ymr->ib_mr.length)

static inline struct yib_mr *os_get_yib_mr(struct ib_mr *ibmr)
{
	return container_of(ibmr, struct yib_mr, ib_mr);
}

struct yib_pd {
#if IB_LAYER_ALLOC_PD	
	os_ib_pd				ib_pd;
	struct yib_pool_entry	entry;	
#else
	struct yib_pool_entry	entry;	
	os_ib_pd				ib_pd;
#endif
};

struct yib_xrcd
{
	os_ib_xrcd	ib_xrcd;
	u32			xrcd_val;
};

struct yib_ah {
#if IB_LAYER_ALLOC_AH		
	os_ib_ah				ib_ah;
	struct yib_pool_entry	entry;
#else
	struct yib_pool_entry	entry;
	os_ib_ah				ib_ah;
#endif
	struct yib_av			av;
	bool					is_user;
	int						ah_num;
};

struct yib_sw_cqe {
	enum yib_cqe_type type;//sq:0 rq:1 srq:2
	u8 status;
	enum ib_wc_opcode sw_opcode;//仅软件注入时使用,纯软件注入时sq只赋值sw_opcode及sw_wr_id, 然后对sw_posted递增
	u32 start_pos;
	u32 end_pos;  // [start_pos, end_pos)
	u32 depth;
	u64 handler; //sq:填写yqp地址，rq、srq:填写yrq地址
	u64 sw_wr_id;//仅软件注入时使用
	struct list_head node;
};

struct yib_cq {
#if IB_LAYER_ALLOC_CQ	
	os_ib_cq				ib_cq;
	struct yib_pool_entry	entry;	
#else
	struct yib_pool_entry	entry;
	os_ib_cq				ib_cq;	
#endif
	os_spinlock				cq_lock;
	os_list_head			evt_comp_node;
	os_list_head			evt_err_node;
	u64						u_cq_handler;

	bool					is_user;
	bool					nvme_off;
	u32						comp_vector;
	u32						cqid;

	struct list_head		sw_done_list;
	struct yib_sw_cqe		*cur_sw_cqe;

	struct yib_queue_mem	*queue;

	bool					is_dying;

	u64						int_dup;
	u64						int_occur;
	u64						int_handle;
	void					*privdata; //extension for doe
};

#define yib_os_cq_cqe(ycq)	ycq->ib_cq.cqe

//在fill_wqe里赋值
struct yib_sw_cmd 
{
	u8                bsignal:1; //正常完成是否会产生cqe，rq固定为1
	u8                at_err:1;  //是否处于err，err时一定产生cqe
	u8                posted:1;  //是否已提交
	enum ib_wc_opcode opcode;    //对应的wc的opcode
	u64               wrid;
};

struct yib_sq
{
	struct yib_queue_mem	*queue;
	os_spinlock				sq_lock;
	struct yib_sw_cmd		*sw_cmds;
	u32						*sw_posted;
};

struct yib_rq 
{
	struct yib_pool_entry	entry;

	struct yib_queue_mem	*queue;
	u64						u_rq_handler;
	os_spinlock				rq_lock;
	bool					bsrq:1;
	bool					bxrc:1;
	bool					is_user:1;
	void					*yib;
	u32						xrcd_val;
	void*					parent;
	u32						max_recv_sge;
	struct yib_sw_cmd		*sw_cmds;
	void					*privdata; //extension for doe
};

#define IB_SRQ_INIT_MASK (~IB_SRQ_LIMIT)
struct yib_srq {
	os_ib_srq		ib_srq;
	u64				u_srq_handler;
	struct yib_rq 	*yrq;
	struct yib_cq	*yrq_cq; //use for xrc mode only
	os_srq_attr		attr;
	unsigned long	*post_bitmap;
	unsigned long	*db_bitmap;
	bool            toggle;
	u32				next_db;
	volatile u32 	limit;
	os_list_head	evt_limit_node;
	os_list_head	evt_err_node;
	os_list_head	evt_lastwqe_node;
};

#define YIB_QP_STATE_NONE          0ul
#define YIB_QP_STATE_FATAL_ERR   BIT(0)ul //硬件产生严重错误， 等待软件modify_qp to err state

struct yib_qp {
#if IB_LAYER_ALLOC_QP	
	os_ib_qp				ib_qp;
	struct yib_pool_entry	entry;
#else
	struct yib_pool_entry	entry;	
	os_ib_qp				ib_qp;
#endif	
	enum ib_qp_type			qp_type;
	u64						u_qp_handler;
	struct yib_sq			ysq;
	/*
		qp有四种rq使用方式（写寄存器的人要了解）:
		a.对xrc_init使用xrcd_val,没有rq/srq
		b.xrc_tgt没有rq,使用srq xrcd_val
		c.rq使用srq
		d.rq使用rq
	*/
	union {
		struct yib_rq			*yrq;
		struct yib_srq			*ysrq;  //有srq时使用
		u32				xrcd_val; //XRC_INIT类别使用
	} type;
	struct yib_pd			*ypd;
	bool					is_user;
	bool					nvme_off;
	bool					valid;
	bool					use_srq;
	os_atomic				resetting;
	os_qp_attr				attr;
	os_qp_cap				cap;
	struct yib_av			pri_av;
	struct yib_av			alt_av;	
	enum ib_sig_type		sq_sig_type;
	u32						internal_state; 
	struct yib_cq			*ysq_cq;
	struct yib_cq			*yrq_cq;
	u32						sq_psn;
	os_list_head			evt_fatal_node;
	void					*privdata; //extension for doe
};

struct yib_evts_occurs
{
	int cq_cmpl_evts_occur;
	int cq_err_evts_occur;
	int qp_fatal_evts_occur;
	int srq_err_evts_occur;
	int srq_lastwqe_evts_occur;
	int aeq_evts_occur;
};

struct yib_eq
{
	struct yib_pool_entry	entry;
	struct yib_sf    		*ysf;
	int						int_vector;
	bool					use_thread;
	int						assign_irq;//是否已分配好irq	
	struct os_thread_t		*thread;
	void					*priv;

	u64						int_cnt; //产生中断的总次数
};

#define yib_os_qp_num(yqp)	yqp->ib_qp.qp_num	
#define yib_os_qp(yqp)		(&yqp->ib_qp)

struct yib_ucontext {
	os_ib_ucontext	ib_uc;
};

void yib_av_to_attr(struct yib_av *av, struct rdma_ah_attr *attr);
struct yib_ah *yib_inner_create_ah(struct yib_sf *sf);
void yib_inner_destroy_ah(struct yib_ah *ah);
void yib_init_av(struct yusur_ib_dev *yib, struct rdma_ah_attr *attr, struct yib_av *av);
int yib_av_chk_attr(struct yusur_ib_dev *yib, struct rdma_ah_attr *attr);
void yib_ah_print(struct yib_av *av);
void yib_ah_print_mac(char *s, u8 *mac);
void yib_ah_print_ip(char *s, bool ip_v4, u8 *gid_raw);

void yib_mr_helper_get_key(u32 hw_index, u32 *lkey, u32 *rkey);
struct yib_mr *yib_mw_alloc_new(struct yusur_ib_dev *yib, struct yib_mw *ymw, struct yib_pd *ypd, bool buser);
struct yib_mr *yib_mr_alloc_new(struct yusur_ib_dev *yib, struct yib_pd *pd, bool buser, bool bdma, bool bfast);
void yib_mr_dealloc(struct yib_mr *mr, struct yib_pd *ypd);
int yib_dealloc_mw(struct ib_mw *ibmw);

void yib_mr_info_disable(struct yusur_ib_dev *yib, struct yib_mr *mr);
int yib_fmr_init(struct yusur_ib_dev *yib, struct yib_mr *ymr);
int yib_mr_set_page(struct yusur_ib_dev *yib, struct yib_mr *ymr, u64 addr);
struct yib_mr *yib_mr_get_from_index(struct yusur_ib_dev *yib, int index, bool lock);

u32 yib_cq_align_size(struct yusur_ib_dev *yib, u32 *cnt);
void yib_clear_sw_cqe_list(struct yusur_ib_dev *yib, struct yib_cq *ycq, u64 handle, bool b_all);
struct yib_cq *yib_cq_get_from_cqc_index(struct yib_hw_host *hw, int index, bool lock);
#if IB_LAYER_ALLOC_CQ
int yib_cq_alloc_new(struct yusur_ib_dev *yib, struct yib_cq *ycq, u32 cqe, struct ib_umem *umem, int comp_vector);
#else
struct yib_cq *yib_cq_alloc_new(struct yusur_ib_dev *yib, u32 cqe, struct ib_umem *umem, int comp_vector);
#endif
void yib_cq_free(struct yusur_ib_dev *yib, struct yib_cq *ycq);
int yib_cq_poll(struct yusur_ib_dev *yib, struct yib_cq *ycq, int num, os_ib_wc *wc);
int yib_user_poll_cq(struct yusur_ib_dev *yib, struct yib_cq *ycq, int num, os_ib_wc *wc);
int yib_cq_notify(struct yusur_ib_dev *yib, struct yib_cq *ycq, enum ib_cq_notify_flags flags);
void yib_run_cq_cmpl_evts(struct yib_sf *sf, struct yib_cq *ycq);

struct yib_eq *yib_eq_alloc(struct yib_sf *sf, host_verbs_t *verbs, int depth, bool use_thread, int int_vector);

void yib_run_srq_limit_evts(struct yusur_ib_dev *yib, struct yib_srq *ysrq);
void yib_srq_limit_func(void *arg);
void yib_cq_cmpl_func(void *arg);
void yib_cq_err_func(void *arg);
int yib_qp_chk_cap(struct yib_hw_host *hw, struct ib_qp_cap *cap, int has_rq, int has_sq);
void yib_qp_fatal_func(void *arg);
void yib_srq_err_func(void *arg);
void yib_srq_lastwqe_func(void *arg);
void yib_aeq_func(void *arg);

int yib_packet_hdr_fill(struct yusur_ib_dev *yib, struct yib_av *av, u8 *buf, u32 datlen);
#if IB_LAYER_ALLOC_QP
int yib_qp_alloc(struct yusur_ib_dev *yib, struct yib_qp *yqp, struct yib_pd *ypd, int qp_type,
				os_qp_cap *cap, struct yib_xrcd *yxrcd);
#else
struct yib_qp *yib_qp_alloc(struct yusur_ib_dev *yib, struct yib_pd *ypd, int qp_type,
				os_qp_cap *cap, struct yib_xrcd *yxrcd);
#endif

int yib_qp_attach(struct yusur_ib_dev *yib, struct yib_qp *yqp, struct ib_umem *umem_sq, struct ib_umem *umem_rq);
struct yib_qp *yib_qp_get_from_index(struct yib_hw_host *hw, u32 hw_id, bool lock);
void yib_qp_free(struct yusur_ib_dev *yib, struct yib_qp * yqp, struct yib_pd *ypd);
int yib_qp_attach_cq(struct yusur_ib_dev *yib, 
		struct yib_qp *yqp, struct yib_srq *ysrq, struct yib_cq *ycq_send, struct yib_cq *ycq_recv);

int yib_qp_chk_attr(struct yusur_ib_dev *yib, struct yib_qp *qp,
		    os_qp_attr *attr, int mask);

int yib_qp_to_init(struct yusur_ib_dev *yib, struct yib_qp *qp, os_qp_init_attr *init);
int yib_qp_to_attr(struct yusur_ib_dev *yib, struct yib_qp *qp, os_qp_attr *attr, int mask);
int yib_qp_from_attr(struct yusur_ib_dev *yib, struct yib_qp *qp, os_qp_attr *attr, int mask,
			u32 cir, u32 cbs);

int yib_srq_find_useable_pos(struct yib_srq *ysrq);
bool yib_srq_db_helper(struct yib_srq *ysrq, int pos);
int yib_recv_wr_check(struct yib_hw_host *hw, struct yib_rq *yrq, const os_ib_recv_wr *wr);
int yib_send_wr_check(struct yib_hw_host *hw, struct yib_qp *yqp, const os_ib_send_wr *ibwr, u32 *mask, u32 *length);
int yib_sq_send_wr(struct yusur_ib_dev *yib, struct yib_qp *yqp, const_ os_ib_send_wr *wr,
			 const_ os_ib_send_wr **bad_wr);
int yib_rq_recv_wr(struct yusur_ib_dev *yib, struct yib_qp *yqp, const_ os_ib_recv_wr *wr,
			 const_ os_ib_recv_wr **bad_wr);
int yib_user_post_send(struct yusur_ib_dev *yib, struct yib_qp *yqp, const_ os_ib_send_wr *wr,
			 const_ os_ib_send_wr **bad_wr);
int yib_user_post_recv(struct yusur_ib_dev *yib, struct yib_qp *yqp, const_ os_ib_recv_wr *wr,
			 const_ os_ib_recv_wr **bad_wr);

void os_ibqp_event(struct yib_qp * qp, enum ib_event_type type);
int os_ip_ud_fill(struct yusur_ib_dev *yib, struct yib_qp *yqp, u8 *buf,  u32 datlen, const_ os_ib_send_wr *wr);

struct yib_rq *yib_rq_get_from_index(struct yib_hw_host *hw, u32 index, bool lock);
int yib_srq_chk_attr(struct yusur_ib_dev *yib, struct yib_srq *srq,
		     struct ib_srq_init_attr *init, enum ib_srq_attr_mask mask, int *u_srq_len);
void yib_rq_free(struct yusur_ib_dev *yib, struct yib_rq *yrq);
int yib_srq_recv_wr(struct yusur_ib_dev *yib, struct yib_srq *ysrq, const_ os_ib_recv_wr *wr,
			 const_ os_ib_recv_wr **bad_wr);
int yib_srq_init_buf(struct yusur_ib_dev *yib, struct yib_srq *ysrq, os_srq_attr *attr, struct yib_xrcd *yxrcd, 
		struct ib_umem *umem_rq, struct yib_cq *cq);

int yib_sw_cqe_generate(struct yib_cq *ycq, struct yib_sw_cqe *input_sw_cqe,
			bool bsw, enum ib_wc_opcode sw_opcode, u64 wr_id);

void yib_aeq_generate_rq_sw_cqe(struct yib_sf *sf, struct yib_qp *yqp);
void yib_debug_generate_rq_sw_cqe(struct yib_qp *yqp, int index, u8 status);
void yib_aeq_generate_sq_sw_cqe(struct yib_sf *sf, struct yib_qp *yqp);
void yib_debug_generate_sq_sw_cqe(struct yib_qp *yqp, int index, u8 status);
void yib_sw_generate_sq_sw_cqe(struct yib_qp *yqp,
			int index, u8 status, enum ib_wc_opcode opcode, u64 wr_id);
void yib_sq_swcmd_done(struct yusur_ib_dev *yib, struct yib_qp *yqp, int index, bool bsw);
void yib_rq_swcmd_done(struct yusur_ib_dev *yib, struct yib_rq *yrq, int index);
void yib_srq_swcmd_done(struct yusur_ib_dev *yib, struct yib_srq *ysrq, int index);
int yib_sq_check_cqe(struct yusur_ib_dev *yib, struct yib_qp *yqp, int index, bool bsw);
int yib_rq_check_hwcqe(struct yusur_ib_dev *yib, struct yib_rq *yrq, int index);

u32 yib_get_qp_sw_idx(struct yib_qp *yqp);
u32 yib_get_cq_sw_idx(struct yib_cq *ycq);
u32 yib_get_rq_sw_idx(struct yib_rq *yrq);
u32 yib_get_mr_sw_idx(struct yib_mr *ymr);
#endif /* end _YUSUR_IB_VERBS_H_ */
