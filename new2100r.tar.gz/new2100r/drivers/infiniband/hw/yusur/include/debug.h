#ifndef _YUSUR_IB_DBG_H_
#define _YUSUR_IB_DBG_H_

#define YUSUR_IB_DBG_ON    1

#define YUSUR_IB_M_LINUX_MAIN      0x1
#define YUSUR_IB_M_LINUX_IB        0x2
#define YUSUR_IB_M_LINUX_API       0x4
#define YUSUR_IB_M_CORE_DEV        0x8
#define YUSUR_IB_M_CORE_VERBS      0x10
#define YUSUR_IB_M_HOST_CMN        0x20
#define YUSUR_IB_M_HOST_INTR       0x40
#define YUSUR_IB_M_TEST            0x80
#define YUSUR_IB_M_MR_MTT          0x100
#define YUSUR_IB_M_EQ              0x200
#define YUSUR_IB_M_MR              0x400
#define YUSUR_IB_M_CQ              0x800
#define YUSUR_IB_M_RQ              0x1000
#define YUSUR_IB_M_SQ              0x2000
#define YUSUR_IB_M_QP              0x4000
#define YUSUR_IB_M_AH              0x8000
#define YUSUR_IB_M_DOE             0x10000
#define YUSUR_IB_M_HQOS            0x20000

#define YUSUR_IB_DBG_INIT          0x1
#define YUSUR_IB_DBG_SEND          0x2
#define YUSUR_IB_DBG_RECV          0x4
#define YUSUR_IB_DBG_POLL          0x8
#define YUSUR_IB_DBG_CREATE        0x10
#define YUSUR_IB_DBG_DESTROY       0x20
#define YUSUR_IB_DBG_UINIT         0x40
#define YUSUR_IB_DBG_CHANGE        0x80
#define YUSUR_IB_DBG_QUERY         0x100
#define YUSUR_IB_DBG_NOTIFY        0x200
#define YUSUR_IB_DBG_COMP          0x400
#define YUSUR_IB_DBG_MODIFY        0x800
#define YUSUR_IB_DBG_TEST          0x1000
#define YUSUR_IB_DBG_DB            0x2000
#define YUSUR_IB_DBG_SGLIST        0x4000
#define YUSUR_IB_DBG_FWCMD         0x8000
#define YUUSR_IB_DBG_SYS           0x10000

#define YUSUR_IB_DBG_MODULES      (YUSUR_IB_M_LINUX_MAIN | YUSUR_IB_M_DOE | YUSUR_IB_M_EQ | YUSUR_IB_M_QP | \
YUSUR_IB_M_CORE_VERBS | YUSUR_IB_M_MR | YUSUR_IB_M_CQ | YUSUR_IB_M_MR_MTT | YUSUR_IB_M_AH)
#define YUSUR_IB_DBG_FEATURES     (YUSUR_IB_DBG_INIT | YUSUR_IB_DBG_CREATE | YUSUR_IB_DBG_DESTROY)

#if(YUSUR_IB_DBG_ON)
void yib_dbg_info(u32 module, u32 feature, u8 *fmt, ...);
void yib_dbg_err(u8 *fmt, ...);
#else
#define yib_dbg_info(module, feature, fmt,  ...) do {} while(0)
#define yib_dbg_err(fmt, ...) do {} while(0)
#endif

void yib_pr_info(u32 feature, u8 *fmt, ...);
void yib_pr_warn(u8* fmt, ...);  //不带dev时用yib_pr_warn
#endif /* end  _YUSUR_IB_DBG_H_*/
