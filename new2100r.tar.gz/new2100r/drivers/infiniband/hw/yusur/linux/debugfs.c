#include "../include/basic.h"
#include <linux/debugfs.h>
#include "../include/os_api.h"
#include "../include/os_ds.h"
#include "../include/mem.h"
#include "../include/queue.h"
#include "../include/host.h"
#include "../include/verbs.h"
#include "../include/yusur_ib.h"
#include "../include/core.h"

static struct dentry *debugfs_root = NULL;
//全局打印
static struct dentry *debugfs_sf = NULL;
//参数：srq_id
static struct dentry *debugfs_srq = NULL;
//全局打印
static struct dentry *debugfs_qp = NULL;
//全局打印
static struct dentry *debugfs_cq = NULL;
//全局打印
static struct dentry *debugfs_mr = NULL;
//全局打印
static struct dentry *debugfs_eq = NULL;
//参数: type: (bar0:0 bar2:1 bar4:2)
static struct dentry *debugfs_host_reg = NULL;
//参数: type:(主机内存:0 设备内存:1), len_in_4byte(4字节整数倍), addr(4字节对齐)
static struct dentry *debugfs_host_mem = NULL;
//全局打印
static struct dentry *debugfs_smac = NULL;
//全局打印
static struct dentry *debugfs_sgid = NULL;
//dbg控制
static struct dentry *debugfs_debug = NULL;
//debug注入
static struct dentry *debugfs_cq_evt_inject = NULL;
static struct dentry *debugfs_cq_inject = NULL;
//用户自定义debugfs接口
static struct dentry *debugfs_user_def = NULL;

extern u32 g_dbg_module;
extern u32 g_dbg_feature;
static ssize_t dbg_debug_write(struct file *f, const char __user *data,
				size_t count, loff_t *ppos)
{
	u8 buf[64];
	int ret, rc;
	u32 feature = 0;
	u32 module = 0;

	memset(buf, 0, sizeof(buf));
	ret =  simple_write_to_buffer(buf, min(count, sizeof(buf)), ppos, data, count);
	if (ret < 0) {
		printk("dbg_debug_write failed:%d\n", ret);
		return ret;
	}
	rc = sscanf(buf, "%x:%x", &module, &feature);
	if (rc != 2) {
		printk("dbg_debug_write failed for parse arg\n");
		return -EINVAL;
	}
	g_dbg_module = module;
	g_dbg_feature = feature;
	printk("new dbg value is 0x%08x:0x%08x\n", module, feature);
	return -EACCES;
}

static const struct file_operations dbg_debug_ops = {
	.owner = THIS_MODULE,
	.open = simple_open,
	.write = dbg_debug_write,
};

void yib_init_debugfs(void)
{
	debugfs_root = debugfs_create_dir("yusur_rdma", NULL);

	if (debugfs_root)
		debugfs_sf = debugfs_create_dir("sf", debugfs_root);

	if (debugfs_root)
		debugfs_srq = debugfs_create_dir("srq", debugfs_root);

	if (debugfs_root)
		debugfs_qp = debugfs_create_dir("qp", debugfs_root);

	if (debugfs_root)
		debugfs_cq = debugfs_create_dir("cq", debugfs_root);

	if (debugfs_root)
		debugfs_mr = debugfs_create_dir("mr", debugfs_root);

	if (debugfs_root)
		debugfs_eq = debugfs_create_dir("eq", debugfs_root);

	if (debugfs_root)
		debugfs_host_reg = debugfs_create_dir("host_reg", debugfs_root);

	if (debugfs_root)
		debugfs_host_mem = debugfs_create_dir("host_mem", debugfs_root);

	if (debugfs_root)
		debugfs_smac = debugfs_create_dir("smac", debugfs_root);

	if (debugfs_root)
		debugfs_sgid = debugfs_create_dir("sgid", debugfs_root);

	if (debugfs_root)
		debugfs_cq_evt_inject = debugfs_create_dir("cq_evt_inject", debugfs_root);

	if (debugfs_root)
		debugfs_cq_inject = debugfs_create_dir("cq_inject", debugfs_root);

	if (debugfs_root)
		debugfs_user_def = debugfs_create_dir("user_def", debugfs_root);

	if (debugfs_root)
		debugfs_debug = debugfs_create_file("debug_ctl", S_IWUGO, debugfs_root, NULL, &dbg_debug_ops);
}

static ssize_t dbg_sf_write(struct file *f, const char __user *data,
				size_t count, loff_t *ppos)
{
	struct yusur_ib_dev *yib = f->private_data;

	reg_dbg_print_sf(yib);
	if (yib->host.sf.sf_ops->sf_debugfs)
		yib->host.sf.sf_ops->sf_debugfs(&yib->host.sf);
	return -EACCES;
}

static const struct file_operations dbg_sf_ops = {
	.owner = THIS_MODULE,
	.open = simple_open,
	.write = dbg_sf_write,
};

static ssize_t dbg_srq_write(struct file *f, const char __user *data,
				size_t count, loff_t *ppos)
{
	u8 buf[32];
	u32 value;
	int ret;
	struct yusur_ib_dev *yib = f->private_data;
	struct yib_srq *ysrq = NULL;
	struct yib_rq *yrq = NULL;

	memset(buf, 0, sizeof(buf));
	ret =  simple_write_to_buffer(buf, min(count, sizeof(buf)), ppos, data, count);

	if (ret < 0) {
		os_printw(yib->dev, "dbg_srq_write failed:%d\n", ret);
		return ret;
	}

	if (kstrtoint(buf, 10, &value)) {
		os_printw(yib->dev, "dbg_srq_write failed for parse int\n");
		return -EINVAL;
	}

	yrq = yib_rq_get_from_index(&yib->host, value, false);
	if (yrq == NULL || (yrq->bsrq == false)) {
		os_printw(yib->dev, "srq:%d not exist\n", value);
		return -EINVAL;
	}

	ysrq = (struct yib_srq *)yrq->parent;
	reg_dbg_print_srq(yib, ysrq);
	if (yib->host.sf.sf_ops->srq_debugfs)
		yib->host.sf.sf_ops->srq_debugfs(&yib->host.sf, ysrq);
	return ret;
}

static const struct file_operations dbg_srq_ops = {
	.owner = THIS_MODULE,
	.open = simple_open,
	.write = dbg_srq_write,
};

static ssize_t dbg_qp_write(struct file *f, const char __user *data,
				size_t count, loff_t *ppos)
{
	u8 buf[32];
	u32 value;
	int ret;
	struct yusur_ib_dev *yib = f->private_data;
	struct yib_qp *yqp = NULL;

	memset(buf, 0, sizeof(buf));
	ret =  simple_write_to_buffer(buf, min(count, sizeof(buf)), ppos, data, count);

	if (ret < 0) {
		os_printw(yib->dev, "dbg_qp_write failed:%d\n", ret);
		return ret;
	}

	if (kstrtoint(buf, 10, &value)) {
		os_printw(yib->dev, "dbg_qp_write failed for parse int\n");
		return -EINVAL;
	}

	yqp = yib_qp_get_from_index(&yib->host, value, false);
	if (yqp == NULL) {
		os_printw(yib->dev, "qp:%d not exist\n", value);
		return -EINVAL;
	}

	reg_dbg_print_qp(yib, yqp);
	if (yib->host.sf.sf_ops->qp_debugfs)
		yib->host.sf.sf_ops->qp_debugfs(&yib->host.sf, yqp);
	return ret;
}

static const struct file_operations dbg_qp_ops = {
	.owner = THIS_MODULE,
	.open = simple_open,
	.write = dbg_qp_write,
};

static ssize_t dbg_cq_write(struct file *f, const char __user *data,
				size_t count, loff_t *ppos)
{
	u8 buf[32];
	u32 value;
	int ret;
	struct yusur_ib_dev *yib = f->private_data;
	struct yib_cq *ycq = NULL;

	memset(buf, 0, sizeof(buf));
	ret =  simple_write_to_buffer(buf, min(count, sizeof(buf)), ppos, data, count);

	if (ret < 0) {
		os_printw(yib->dev, "dbg_cq_write failed:%d\n", ret);
		return ret;
	}

	if (kstrtoint(buf, 10, &value)) {
		os_printw(yib->dev, "dbg_cq_write failed for parse int\n");
		return -EINVAL;
	}

	ycq = yib_cq_get_from_cqc_index(&yib->host, value, false);
	if (ycq == NULL) {
		os_printw(yib->dev, "cq:%d not exist\n", value);
		return -EINVAL;
	}

	reg_dbg_print_cq(yib, ycq);
	if (yib->host.sf.sf_ops->cq_debugfs)
		yib->host.sf.sf_ops->cq_debugfs(&yib->host.sf, ycq);
	return ret;
}

static const struct file_operations dbg_cq_ops = {
	.owner = THIS_MODULE,
	.open = simple_open,
	.write = dbg_cq_write,
};

static ssize_t dbg_mr_write(struct file *f, const char __user *data,
				size_t count, loff_t *ppos)
{
	u8 buf[32];
	u32 value;
	int ret;
	struct yusur_ib_dev *yib = f->private_data;
	struct yib_mr *ymr = NULL;

	memset(buf, 0, sizeof(buf));
	ret =  simple_write_to_buffer(buf, min(count, sizeof(buf)), ppos, data, count);

	if (ret < 0) {
		os_printw(yib->dev, "dbg_mr_write failed:%d\n", ret);
		return ret;
	}

	if (kstrtoint(buf, 10, &value)) {
		os_printw(yib->dev, "dbg_mr_write failed for parse int\n");
		return -EINVAL;
	}

	ymr = yib_mr_get_from_index(yib, value, false);
	if (ymr == NULL) {
		os_printw(yib->dev, "mr:%d not exist\n", value);
		return -EINVAL;
	}

	reg_dbg_print_mr(yib, ymr);
	if (yib->host.sf.sf_ops->mr_debugfs)
		yib->host.sf.sf_ops->mr_debugfs(&yib->host.sf, ymr);
	return ret;
}

static const struct file_operations dbg_mr_ops = {
	.owner = THIS_MODULE,
	.open = simple_open,
	.write = dbg_mr_write,
};

static ssize_t dbg_eq_write(struct file *f, const char __user *data,
				size_t count, loff_t *ppos)
{
	int eq_intr_num = 0;
	u8 buf[32];
	u32 value;
	int ret;
	struct yusur_ib_dev *yib = f->private_data;
	struct yib_eq *yeq = NULL;

	memset(buf, 0, sizeof(buf));
	ret = simple_write_to_buffer(buf, min(count, sizeof(buf)), ppos, data, count);
	if (ret < 0) {
		os_printw(yib->dev, "dbg_eq_write failed:%d\n", ret);
		return ret;
	}

	if (kstrtoint(buf, 10, &value)) {
		os_printw(yib->dev, "dbg_eq_write failed for parse int\n");
		return -EINVAL;
	}

	eq_intr_num = yib->host.sf.eq_ops->get_eq_intr_num(&yib->host.sf);
	if (value >= eq_intr_num)
		return -EINVAL;

	yeq = yib->host.sf.event_queue[value];
	reg_dbg_print_eq(yib, yeq);
	if (yib->host.sf.eq_ops->eq_debugfs)
		yib->host.sf.eq_ops->eq_debugfs(&yib->host.sf, yeq);
	return ret;
}

static const struct file_operations dbg_eq_ops = {
	.owner = THIS_MODULE,
	.open = simple_open,
	.write = dbg_eq_write,
};

static ssize_t dbg_host_reg_write(struct file *f, const char __user *data,
				size_t count, loff_t *ppos)
{
	u8 buf[128];
	int type;
	int ret, rc;
	struct yusur_ib_dev *yib = f->private_data;

	memset(buf, 0, sizeof(buf));
	ret =  simple_write_to_buffer(buf, min(count, sizeof(buf)), ppos, data, count);
	if (ret < 0) {
		os_printw(yib->dev, "dbg_host_reg_write failed:%d\n", ret);
		return ret;
	}

	rc = sscanf(buf, "%d", &type);
	if (rc != 1) {
		os_printw(yib->dev, "dbg_host_reg_write failed for parse arg\n");
		return -EINVAL;
	}

	if (type == 0) {//bar 0
		if (yib->host.hw_ops.host_debugfs_reg)
			yib->host.hw_ops.host_debugfs_reg(&yib->host);
	}

	return ret;
}

static const struct file_operations dbg_host_reg_ops = {
	.owner = THIS_MODULE,
	.open = simple_open,
	.write = dbg_host_reg_write,
};

static ssize_t dbg_host_mem_write(struct file *f, const char __user *data,
				size_t count, loff_t *ppos)
{
	u8 buf[128];
	int type;
	int arg_len = 0;
	u64 arg_addr = 0;
	int ret, rc;
	struct yusur_ib_dev *yib = f->private_data;

	memset(buf, 0, sizeof(buf));
	ret =  simple_write_to_buffer(buf, min(count, sizeof(buf)), ppos, data, count);
	if (ret < 0) {
		os_printw(yib->dev, "dbg_host_mem_write failed:%d\n", ret);
		return ret;
	}

	rc = sscanf(buf, "%d %d %llx", &type, &arg_len, &arg_addr);
	if (rc != 3) {
		os_printw(yib->dev, "dbg_host_mem_write failed for parse arg\n");
		return -EINVAL;
	}

	if (type == 0) {//主机内存
		//new_new todo
	} else if (type == 1) {//物理内存
		if (yib->host.hw_ops.host_debugfs_mem)
			yib->host.hw_ops.host_debugfs_mem(&yib->host, arg_len, arg_addr);
	}

	return ret;
}

static const struct file_operations dbg_host_mem_ops = {
	.owner = THIS_MODULE,
	.open = simple_open,
	.write = dbg_host_mem_write,
};

static ssize_t dbg_smac_write(struct file *f, const char __user *data,
				size_t count, loff_t *ppos)
{
	u8 buf[32];
	u32 value;
	int ret;
	int i = 0;
	struct yusur_ib_dev *yib = f->private_data;
	struct yib_mac_tbl_item *mac_tbl_item = NULL;

	memset(buf, 0, sizeof(buf));
	ret = simple_write_to_buffer(buf, min(count, sizeof(buf)), ppos, data, count);

	if (ret < 0) {
		os_printw(yib->dev, "dbg_smac_write failed:%d\n", ret);
		return ret;
	}

	if (kstrtoint(buf, 10, &value)) {
		os_printw(yib->dev, "dbg_smac_write failed for parse int\n");
		return -EINVAL;
	}
	if (value > YIB_MAX_MAC_TBL_LEN)
		return -EINVAL;

	yib_dbg_info(YUSUR_IB_M_AH, YUSUR_IB_DBG_CREATE, "#########smac debug print begin#######\n");
	if (value == 0) {
		for (i = 0; i < YIB_MAX_MAC_TBL_LEN; i++) {
			mac_tbl_item = &yib->host.mac_tbl.mac_tbl_item[i];
			yib_dbg_info(YUSUR_IB_M_AH, YUSUR_IB_DBG_CREATE,"smac[%d]: ref_cnt:%d  port_num:%d  is_init:%d\n",
				i, mac_tbl_item->ref_cnt, mac_tbl_item->port_num, mac_tbl_item->is_init);
			yib_dbg_info(YUSUR_IB_M_AH, YUSUR_IB_DBG_CREATE,"smac[%d]: %02X:%02X:%02X:%02X:%02X:%02X\n",
				i, mac_tbl_item->mac[0], mac_tbl_item->mac[1], mac_tbl_item->mac[2], mac_tbl_item->mac[3],
				mac_tbl_item->mac[4], mac_tbl_item->mac[5]);
		}
	} else {
		mac_tbl_item = &yib->host.mac_tbl.mac_tbl_item[value - 1];
		yib_dbg_info(YUSUR_IB_M_AH, YUSUR_IB_DBG_CREATE,"smac[%d]: ref_cnt:%d  port_num:%d  is_init:%d\n",
			value - 1, mac_tbl_item->ref_cnt, mac_tbl_item->port_num, mac_tbl_item->is_init);
		yib_dbg_info(YUSUR_IB_M_AH, YUSUR_IB_DBG_CREATE,"smac[%d]: %02X:%02X:%02X:%02X:%02X:%02X\n",
			value - 1, mac_tbl_item->mac[0], mac_tbl_item->mac[1], mac_tbl_item->mac[2], mac_tbl_item->mac[3],
			mac_tbl_item->mac[4], mac_tbl_item->mac[5]);
	}
	yib_dbg_info(YUSUR_IB_M_AH, YUSUR_IB_DBG_CREATE, "#########smac debug print end#######\n");

	if (yib->host.hw_ops.smac_debugfs)
		yib->host.hw_ops.smac_debugfs(&yib->host);
	return ret;
}

static const struct file_operations dbg_smac_ops = {
	.owner = THIS_MODULE,
	.open = simple_open,
	.write = dbg_smac_write,
};


static ssize_t dbg_sgid_write(struct file *f, const char __user *data,
				size_t count, loff_t *ppos)
{
	struct yusur_ib_dev *yib = f->private_data;
	if (yib->host.hw_ops.sgid_debugfs)
		yib->host.hw_ops.sgid_debugfs(&yib->host);
	return -EACCES;
}

static const struct file_operations dbg_sgid_ops = {
	.owner = THIS_MODULE,
	.open = simple_open,
	.write = dbg_sgid_write,
};

static ssize_t dbg_cq_evt_inject_write(struct file *f, const char __user *data,
				size_t count, loff_t *ppos)
{
	u8 buf[32];
	int cq_index;
	int ret;
	struct yusur_ib_dev *yib = f->private_data;
	struct yib_cq *ycq = NULL;

	memset(buf, 0, sizeof(buf));
	ret =  simple_write_to_buffer(buf, min(count, sizeof(buf)), ppos, data, count);
	if (ret < 0) {
		os_printw(yib->dev, "dbg_cq_evt_inject_write failed:%d\n", ret);
		return ret;
	}

	if (kstrtoint(buf, 10, &cq_index)) {
		os_printw(yib->dev, "dbg_cq_evt_inject_write failed for parse arg\n");
		return -EINVAL;
	}

	ycq = yib_cq_get_from_cqc_index(&yib->host, cq_index, false);
	if (ycq == NULL) {
		os_printw(yib->dev, "dbg_cq_evt_inject_write failed for cq_index:%d\n", cq_index);
        return -EINVAL;
	}

	yib_run_cq_cmpl_evts(&yib->host.sf, ycq);
	yib_elem_drop_ref(&ycq->entry);
	return ret;
}

static const struct file_operations dbg_cq_evt_inject_ops = {
	.owner = THIS_MODULE,
	.open = simple_open,
	.write = dbg_cq_evt_inject_write,
};

static ssize_t dbg_cq_inject_write(struct file *f, const char __user *data,
				size_t count, loff_t *ppos)
{
	//struct yusur_ib_dev *yib = f->private_data;
	//yib_debug_generate_sq_sw_cqe
	//new_new todo
	return -EACCES;
}

static const struct file_operations dbg_cq_inject_ops = {
	.owner = THIS_MODULE,
	.open = simple_open,
	.write = dbg_cq_inject_write,
};

static ssize_t dbg_user_def_write(struct file *f, const char __user *data,
				size_t count, loff_t *ppos)
{
	struct yusur_ib_dev *yib = f->private_data;
	u8 buf[32];
	int ret;

	memset(buf, 0, sizeof(buf));
	ret = simple_write_to_buffer(buf, min(count, sizeof(buf)), ppos, data, count);

	if (ret < 0) {
		os_printw(yib->dev, "dbg_user_def_write failed:%d\n", ret);
		return ret;
	}

	if (yib->host.hw_ops.user_def_hw_debugfs)
		return yib->host.hw_ops.user_def_hw_debugfs(&yib->host, buf);
	return -EACCES;
}

static const struct file_operations dbg_user_def_ops = {
	.owner = THIS_MODULE,
	.open = simple_open,
	.write = dbg_user_def_write,
};

void yib_uinit_debugfs(void)
{
	if (debugfs_root) {
		debugfs_remove_recursive(debugfs_root);
		debugfs_root = NULL;
		debugfs_debug = NULL;
	}
}

void yusur_debugfs_add(struct yusur_ib_dev *yib)
{
	yib->dbg_dentry.dbg_sf = debugfs_create_file(yib->ib_dev.name, S_IWUGO,
					debugfs_sf, yib, &dbg_sf_ops);
	yib->dbg_dentry.dbg_srq = debugfs_create_file(yib->ib_dev.name, S_IWUGO,
					debugfs_srq, yib, &dbg_srq_ops);
	yib->dbg_dentry.dbg_qp = debugfs_create_file(yib->ib_dev.name, S_IWUGO,
					debugfs_qp, yib, &dbg_qp_ops);
	yib->dbg_dentry.dbg_cq = debugfs_create_file(yib->ib_dev.name, S_IWUGO,
					debugfs_cq, yib, &dbg_cq_ops);
	yib->dbg_dentry.dbg_mr = debugfs_create_file(yib->ib_dev.name, S_IWUGO,
					debugfs_mr, yib, &dbg_mr_ops);
	yib->dbg_dentry.dbg_eq = debugfs_create_file(yib->ib_dev.name, S_IWUGO,
					debugfs_eq, yib, &dbg_eq_ops);
	yib->dbg_dentry.dbg_host_reg = debugfs_create_file(yib->ib_dev.name, S_IWUGO,
					debugfs_host_reg, yib, &dbg_host_reg_ops);
	yib->dbg_dentry.dbg_host_mem = debugfs_create_file(yib->ib_dev.name, S_IWUGO,
					debugfs_host_mem, yib, &dbg_host_mem_ops);
	yib->dbg_dentry.dbg_smac = debugfs_create_file(yib->ib_dev.name, S_IWUGO,
					debugfs_smac, yib, &dbg_smac_ops);
	yib->dbg_dentry.dbg_sgid = debugfs_create_file(yib->ib_dev.name, S_IWUGO,
					debugfs_sgid, yib, &dbg_sgid_ops);
	yib->dbg_dentry.dbg_cq_evt_inject = debugfs_create_file(yib->ib_dev.name, S_IWUGO,
					debugfs_cq_evt_inject, yib, &dbg_cq_evt_inject_ops);
	yib->dbg_dentry.dbg_cq_inject = debugfs_create_file(yib->ib_dev.name, S_IWUGO,
					debugfs_cq_inject, yib, &dbg_cq_inject_ops);
	yib->dbg_dentry.dbg_user_def = debugfs_create_file(yib->ib_dev.name, S_IWUGO,
					debugfs_user_def, yib, &dbg_user_def_ops);
}

void yusur_debugfs_remove(struct yusur_ib_dev *yib)
{
	if (yib->dbg_dentry.dbg_sf) {
		debugfs_remove(yib->dbg_dentry.dbg_sf);
		yib->dbg_dentry.dbg_sf = NULL;
	}
	if (yib->dbg_dentry.dbg_srq) {
		debugfs_remove(yib->dbg_dentry.dbg_srq);
		yib->dbg_dentry.dbg_srq = NULL;
	}
	if (yib->dbg_dentry.dbg_eq) {
		debugfs_remove(yib->dbg_dentry.dbg_eq);
		yib->dbg_dentry.dbg_eq= NULL;
	}
	if (yib->dbg_dentry.dbg_host_reg) {
		debugfs_remove(yib->dbg_dentry.dbg_host_reg);
		yib->dbg_dentry.dbg_host_reg = NULL;
	}
	if (yib->dbg_dentry.dbg_host_mem) {
		debugfs_remove(yib->dbg_dentry.dbg_host_mem);
		yib->dbg_dentry.dbg_host_mem = NULL;
	}
	if (yib->dbg_dentry.dbg_smac) {
		debugfs_remove(yib->dbg_dentry.dbg_smac);
		yib->dbg_dentry.dbg_smac = NULL;
	}
	if (yib->dbg_dentry.dbg_sgid) {
		debugfs_remove(yib->dbg_dentry.dbg_sgid);
		yib->dbg_dentry.dbg_sgid = NULL;
	}
	if (yib->dbg_dentry.dbg_cq_evt_inject) {
		debugfs_remove(yib->dbg_dentry.dbg_cq_evt_inject);
		yib->dbg_dentry.dbg_cq_evt_inject = NULL;
	}
	if (yib->dbg_dentry.dbg_cq_inject) {
		debugfs_remove(yib->dbg_dentry.dbg_cq_inject);
		yib->dbg_dentry.dbg_cq_inject = NULL;
	}
	if (yib->dbg_dentry.dbg_user_def) {
		debugfs_remove(yib->dbg_dentry.dbg_user_def);
		yib->dbg_dentry.dbg_user_def = NULL;
	}
}
