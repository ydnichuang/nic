#include "../include/basic.h"
#include <net/addrconf.h>
#include <linux/of_address.h>
#include <linux/inetdevice.h>
#include <rdma/ib_addr.h>
#include <linux/interrupt.h>
#include <linux/hardirq.h>
#include "../include/basic.h"
#include "../include/os_api.h"
#include "../include/os_ds.h"
#include "../include/mem.h"
#include "../include/queue.h"
#include "../include/host.h"
#include "../include/verbs.h"
#include "../include/yusur_ib.h"
#if HAS_ASM_SET_MEMORY
#include <asm/set_memory.h>
#endif

u32 g_dbg_module = YUSUR_IB_DBG_MODULES;
u32 g_dbg_feature = YUSUR_IB_DBG_FEATURES;

/* 
 *
 *        First Part Basic API
 *     
*/

void * os_zalloc(int data_size)
{
	return kzalloc(data_size, GFP_KERNEL);
}

os_cdma_t os_alloc_coherent_dma(os_pci_device *pdev, u32 size, int node, os_mutex_t *mutex)
{
	os_cdma_t cdma;
	int org_node = node;
	cdma.size = size;

	if (mutex) {
		if (node == NUMA_NO_NODE)
			node = numa_mem_id();
		os_mutex_lock(mutex);
		if (node != org_node)
			set_dev_node(&pdev->dev, node);
	}
	cdma.vaddr = dma_alloc_coherent(&pdev->dev, size, &cdma.dma_addr, GFP_KERNEL);
	if (mutex) {
		if (node != org_node)
			set_dev_node(&pdev->dev, org_node);
		os_mutex_unlock(mutex);
	}
	if (cdma.vaddr == NULL)
		cdma.dma_addr = 0;
	else 
		memset(cdma.vaddr, 0, size);
	return cdma;
}

void os_free_coherent_dma(os_pci_device *pdev, os_cdma_t *dma)
{
	if (dma->vaddr == NULL)
		return;
	dma_free_coherent(&pdev->dev, dma->size, dma->vaddr, dma->dma_addr);
	dma->vaddr = NULL;
}

#if(0)
os_pdma_t  os_alloc_paged_dma(os_pci_device *pdev, u32 size, os_dma_dir dir)
{
	int order;
	void *buf;
	dma_addr_t addr;
	os_pdma_t dma;
	dma.vaddr = NULL;
	dma.dma_addr = 0; 
	dma.dir = dir;
	
	order = get_order(PAGE_ALIGN(size));
	buf = (void *)__get_free_pages(GFP_KERNEL, order);
	dma.order = order;
	dma.size = PAGE_ALIGN(size);
	dma.vaddr = buf;
	if (!buf) {
		os_printe(&pdev->dev, "failed to alloc paged dma buf order %d\n", order);
		return dma;
	}

	addr = dma_map_single(&pdev->dev, buf, dma.size, dma.dir);

	if (dma_mapping_error(&pdev->dev, addr)) {
		os_printe(&pdev->dev, "failed to alloc for dma mapping buffers order:%d\n", order);
		free_pages((u64)buf, dma.order);
		dma.vaddr = NULL;
		return dma;
	}

	dma.dma_addr = addr;
	return dma;
}

void os_free_paged_dma(os_pci_device *pdev, os_pdma_t *dma)
{
	if (dma->dma_addr != 0) {
		dma_unmap_single(&pdev->dev, dma->dma_addr,  dma->size, dma->dir);
		dma->dma_addr = 0;
	}

	if (dma->vaddr != NULL) {
		free_pages((u64)dma->vaddr, dma->order);
		dma->vaddr = NULL;
	}
}
#endif

void os_get_netdev_mac(os_net_device * ndev, u8 *mac)
{
	memcpy(mac, ndev->dev_addr, ETH_ALEN);
}

int os_get_netdev_mtu(os_net_device * ndev)
{
	return ndev->mtu;
}

enum ib_mtu os_get_ib_mtu(os_net_device * ndev)
{
	return iboe_get_mtu(ndev->mtu);
}

u64 os_get_pci_bar_start(os_pci_device *pdev, int bar)
{
	return pdev->resource[bar].start;
}

u64 os_get_pci_bar_end(os_pci_device *pdev, int bar)
{
	return pdev->resource[bar].end;
}

int os_get_netdev_ip(os_net_device * ndev, u32 *ip, bool is_ipv6)
{
	if (!ndev) {
		return -ENODEV;
	}

	if (is_ipv6 == false) {
		struct in_device *inet_dev = (struct in_device *)ndev->ip_ptr;
		u32 ipv4_addr = 0;
		if (!inet_dev) {
			return -EFAULT;
		}                
		if (inet_dev->ifa_list) {
			ipv4_addr = inet_dev->ifa_list->ifa_address;
			if (!ipv4_addr) 
				return -EINVAL;
			*ip = ipv4_addr;
		} else {
			return -EFAULT; 
		}
	} else {
                struct inet6_dev *idev;
                struct inet6_ifaddr *ifp, *tmp;
                u32 ip_avail = 0;

                idev = __in6_dev_get(ndev);
                if (!idev) {
                        return -EFAULT;
                }

                list_for_each_entry_safe(ifp, tmp, &idev->addr_list, if_list) {
                        ip_avail = 1;
                        memcpy(ip, (u32 *)ifp->addr.s6_addr, 16);
                        break;
                }

                if (!ip_avail) {
                        return -EFAULT;
                }

	}   
	return 0;
}

u16 os_get_pcidev_vendor(os_pci_device *pdev)
{
	return pdev->vendor;
}

u16 os_get_pcidev_device(os_pci_device *pdev)
{
	return pdev->device;
}

void os_rdma_gid2ip(struct sockaddr *out, const union ib_gid *gid)
{
	return rdma_gid2ip(out, gid);
}

/* 
 *
 *        Send Part Print APIs
 *     
*/

#if YUSUR_IB_DBG_ON
#define DBG_PREFIX_INFO "YIB-DBGINFO: "
#define DBG_PREFIX_ERR  "YIB-DBGERR : "
void yib_dbg_err(u8 *fmt, ...)
{
	u8 dbgbuf[512];
	u8 *buffer;
	va_list ap;
	int len = strlen(DBG_PREFIX_ERR);

	va_start(ap, fmt);
	buffer = dbgbuf;
	memcpy(buffer, DBG_PREFIX_ERR, len);
	buffer += len;
	vsnprintf(buffer, sizeof(dbgbuf) - len, fmt, ap);
	va_end(ap);
	printk(dbgbuf);
}
void yib_dbg_info(u32 module, u32 feature, u8 *fmt, ...)
{
	u8 dbgbuf[512];
	va_list ap;
	u8 *buffer;
	int len = strlen(DBG_PREFIX_INFO);
	if ((module & g_dbg_module) == 0 || (g_dbg_feature & feature) ==0)
		return;

	va_start(ap, fmt);
	buffer = dbgbuf;
	memcpy(buffer, DBG_PREFIX_INFO, len);
	buffer += len;
	vsnprintf(buffer, sizeof(dbgbuf) - len, fmt, ap);
	va_end(ap);
	printk(dbgbuf);
}
#endif

#define PR_PREFIX_INFO "YIB-PRINFO: "
#define PR_PREFIX_WARN "YIB-PRWARN: "
void yib_pr_info(u32 feature, u8 *fmt, ...)
{
	u8 dbgbuf[512];
	va_list ap;
	u8 *buffer;

	int len = strlen(PR_PREFIX_INFO);
	if ((g_dbg_feature & feature) ==0)
		return;

	va_start(ap, fmt);
	buffer = dbgbuf;
	memcpy(buffer, PR_PREFIX_INFO, len);
	buffer += len;
	vsnprintf(buffer, sizeof(dbgbuf) - len, fmt, ap);
	va_end(ap);
	pr_info("%s", dbgbuf);
}
void yib_pr_warn(u8 *fmt, ...)
{
	u8 dbgbuf[512];
	va_list ap;
	u8 *buffer;

	int len = strlen(PR_PREFIX_INFO);

	va_start(ap, fmt);
	buffer = dbgbuf;
	memcpy(buffer, PR_PREFIX_WARN, len);
	buffer += len;
	vsnprintf(buffer, sizeof(dbgbuf) - len, fmt, ap);
	va_end(ap);
	pr_warn("%s", dbgbuf);    
}

/* 
 *
 *        Third Part Mem Reg APIs
 *     
*/

inline  static u32 yib_frag_get_sz(struct yib_frag_buf *buf ,int i, u32 page_sz)
{
	if (i != (buf->npages - 1))
		return page_sz;
	else
		return page_sz - (buf->size - buf->real_size);
}

static int yib_frag_buf_alloc_try(os_pci_device *pdev, struct yib_frag_buf *buf, u64 size, u32 page_sz, os_mutex_t *mutex, int node)
{
	int i;
	int org_node = node;

	if (size <= page_sz) {
		 //在一个page_sz内能放下，则按实际size来分配
		page_sz = buf->size = buf->real_size = size;
	} else {
		buf->size = buf->npages * page_sz;  
		buf->real_size = size;
	}

	buf->frags = os_zalloc(buf->npages * sizeof(struct yib_buf_list));
	if (!buf->frags)
		goto err_out;

	for (i = 0; i < buf->npages; i++) {
		struct yib_buf_list *frag = &buf->frags[i];
		u32 sz = yib_frag_get_sz(buf, i, page_sz);
		if (mutex) {
			if (node == NUMA_NO_NODE)
				node = numa_mem_id();
			os_mutex_lock(mutex);
			if (node != org_node)
				set_dev_node(&pdev->dev, node);
		}
	
		frag->vaddr = dma_alloc_coherent(&pdev->dev, sz, &frag->dma_addr, GFP_KERNEL);
		if (mutex) {
			if (node != org_node)
				set_dev_node(&pdev->dev, org_node);
			os_mutex_unlock(mutex);
		}
		if (!frag->vaddr || (frag->dma_addr & (sz - 1)))
			goto err_free_buf;
		if ((u64)frag->vaddr & 0x3)
			os_printw(&pdev->dev, "vaddr=%p alloc not aligned\n", frag->vaddr);
#ifdef CONFIG_X86_64
#if             MMAP_MEM_SET_UC
                set_memory_uc((u64)frag->vaddr, sz/PAGE_SIZE);
#endif
#endif
	}

	return 0;

err_free_buf:
	while (i--)
		dma_free_coherent(&pdev->dev, yib_frag_get_sz(buf, i, page_sz), buf->frags[i].vaddr,
				  buf->frags[i].dma_addr);
	os_free(buf->frags);
	buf->frags = NULL;
err_out:
	return -ENOMEM;
}

//upper level check buf invalid
void yib_frag_zero_buf(struct yib_frag_buf *buf)
{
	int i,size;

	if (buf->frags == NULL)
		return;
	size = buf->size / buf->npages;
	for (i = 0; i < buf->npages; i++) {	
		memset(buf->frags[i].vaddr, 0, yib_frag_get_sz(buf, i, size));
	}
}

u32 yib_frag_get_pagesz(struct yib_frag_buf *buf)
{
	return buf->size / buf->npages;
}

u32 yib_frag_get_lastsz(struct yib_frag_buf *buf)
{
	return yib_frag_get_pagesz(buf) - (buf->size - buf->real_size);
}

/*
	调用者保证size按4k对齐

	从page_size = min(MAX_FRAG_PAGE, ((MAX_ORDER_NR_PAGES) << PAGE_SHIFT))开始尝试分配,即能分配的最大连续的内存。
	若分配失败，则page_size = page_size/2，继续尝试，直到成功

	yib_buf_list 中的frag除最后一个外，所有的va的长度都是buf->page_size.
	最后一个的frag长度是 buf->page_size - (buf->size - buf->real_size)
*/
struct yib_frag_buf * yib_frag_buf_alloc_node(struct yib_sf *sf, u64 size, bool init_zero)
{
	u64 max_one_size = (MAX_ORDER_NR_PAGES) << PAGE_SHIFT; //4MB
	struct yib_frag_buf *buf = os_zalloc(sizeof(struct yib_frag_buf));
	if (buf == NULL)
		return NULL;
	
	if (size == 0) {
		os_free(buf);
		return NULL;
	}

	//查找恰好比size大的max_one_page
	while (((max_one_size / 2) >= size) && max_one_size >= PAGE_SIZE) {
		max_one_size = max_one_size >> 1;
	}

	for ( ; max_one_size >= PAGE_SIZE; max_one_size = max_one_size/2) {
		buf->npages = DIV_ROUND_UP(size, max_one_size); //size 4K对齐
		if (yib_frag_buf_alloc_try(sf->pdev, buf, size, max_one_size, sf->host_mutex, sf->num_node) == 0) {
			if (init_zero)
				yib_frag_zero_buf(buf);
			return buf;		
		}
	}
	os_free(buf);
	return NULL;
}

static void yib_frag_buf_free(struct yib_sf *sf, struct yib_frag_buf *buf)
{
	int i,size;

	if (buf->frags == NULL)
		return;
	size = buf->size / buf->npages;
	for (i = 0; i < buf->npages; i++) {	
		dma_free_coherent(&sf->pdev->dev, yib_frag_get_sz(buf, i, size), buf->frags[i].vaddr,
				  buf->frags[i].dma_addr);

		buf->frags[i].vaddr = NULL;
	}
	os_free(buf->frags);
	buf->frags = NULL;
}

void yib_frag_free_node(struct yib_sf *sf, struct yib_frag_buf *buf)
{
	if (buf == NULL)
		return;
	yib_frag_buf_free(sf, buf);
	os_free(buf);
}

/*
	item_size shoule be smaller than 4k, and 4k % item_size =0,such as 128, 256, 512
	the upper layer to verify buf
*/
inline static u32 yib_frag_get_pos(struct yib_frag_buf *buf, int item_size, int index, u32 *offset)
{
	int page_size = buf->size / buf->npages;
	u64  start = (item_size * index);
	int start_idx = start  / page_size;
	*offset = start - (start_idx * page_size);

	return start_idx;
}

void *yib_frag_get_vaddr(struct yib_frag_buf *buf, int item_size, int index)
{
	u32 offset = 0;
	u32 start_idx = yib_frag_get_pos(buf, item_size, index, &offset);
	return buf->frags[start_idx].vaddr + offset;
}

u64 yib_frag_get_paddr(struct yib_frag_buf *buf, int item_size, int index)
{
	u32 offset = 0;
	u32 start_idx = yib_frag_get_pos(buf, item_size, index, &offset);

	return buf->frags[start_idx].dma_addr + offset;
}

//offset必须为item_size整数倍
void *yib_frag_get_vaddr_with_offset(struct yib_frag_buf *buf, int item_size, int index, u32 offset)
{
	u32 inline_offset = 0;
	u32 start_idx = 0;

	index += (offset / item_size);
	start_idx = yib_frag_get_pos(buf, item_size, index, &inline_offset);
	return buf->frags[start_idx].vaddr + inline_offset;
}

//offset必须为item_size整数倍
u64 yib_frag_get_paddr_with_offset(struct yib_frag_buf *buf, int item_size, int index, u32 offset)
{
	u32 inline_offset = 0;
	u32 start_idx = 0;

	index += (offset / item_size);
	start_idx = yib_frag_get_pos(buf, item_size, index, &inline_offset);
	return buf->frags[start_idx].dma_addr + inline_offset;
}
//目前硬件只有一套intcq, todo后续有多套时再增加代码，根据vector选在intcq
int os_request_irq(struct yib_sf *sf, void *arg, irq_handler_t thread_fn)
{
	struct yib_eq *data = (struct yib_eq*)arg;
	int ret = 0;
	if (data->assign_irq)
		return -EEXIST;

	ret = pci_request_irq(sf->pdev, data->int_vector, thread_fn,
				NULL, data, "yusur_q%d", data->int_vector);
	if (ret < 0) {
		os_printe(&sf->pdev->dev, "req irq failed ret=%d", ret);
		return ret;
	}

	data->assign_irq = 1;	
	return 0;
}

void os_free_irq(struct yib_sf *sf, void *arg)
{
	struct yib_eq *data = (struct yib_eq*)arg;
	if (data->assign_irq)  {
		pci_free_irq(sf->pdev, data->int_vector, data);
		data->assign_irq = 0;
	}
}


#if TASKLET_NO_SETUP
static void yib_do_hw_events(unsigned long data)
#else
void yib_do_hw_events(os_task *t)
#endif
{
	unsigned long flags;
#if TASKLET_NO_SETUP
	struct yib_hw_events *evts = (struct yib_hw_events *)data;
#else	
	struct yib_hw_events *evts = from_tasklet(evts, t, tasklet);
#endif

	os_spin_lock_irqsave(&evts->lock, flags);
	list_splice_tail_init(&evts->list, &evts->process_list);
	os_spin_unlock_restore(&evts->lock, flags);

	evts->func(evts->arg);

	if (!list_empty(&evts->process_list))
		tasklet_schedule(&evts->tasklet);
}

/*
	func：函数返回值说明， 返回0，表示数据没处理完， 需要继续调度处理。 非0， 则不会再次调度处理
	如果已经被调度执行，又来了一次do_task, 则会继续被调度，不管func的返回值。 如果还没开始执行，则根据func的返回看是否继续
*/
int yib_hw_events_init(struct yib_hw_events * evts, void (*func)(void *), char *name)
{
	evts->arg	= evts;
	evts->func	= func;
	snprintf(evts->name, sizeof(evts->name), "%s", name);
	evts->destroyed	= false;

#if TASKLET_NO_SETUP 
	tasklet_init(&evts->tasklet, yib_do_hw_events, (unsigned long)evts);
#else
	tasklet_setup(&evts->tasklet, yib_do_hw_events);
#endif
	os_list_init(&evts->list);
	os_list_init(&evts->process_list);
	os_spin_lock_init(&evts->lock);

	return 0;
}

void yib_hw_events_cleanup(struct yib_hw_events * evts)
{
	if (evts->destroyed)
		return;

	evts->destroyed = true;

	tasklet_disable(&evts->tasklet);
	tasklet_kill(&evts->tasklet);
}

void yib_hw_events_run(struct yib_hw_events * evts)
{
	unsigned long flags;
	bool brun = false;
	if (evts->destroyed)
		return;

	os_spin_lock_irqsave(&evts->lock, flags);
	if (!list_empty_careful(&evts->list))
		brun = true;
	os_spin_unlock_restore(&evts->lock, flags);

	if (brun)
		tasklet_schedule(&evts->tasklet);
}


bool yib_hw_event_add(struct yib_hw_events * evts, os_list_head *node)
{
	unsigned long flags;
	bool bdup = false;

	os_spin_lock_irqsave(&evts->lock, flags);//If hw assure not duplicate we can remove this lock

	if (list_empty_careful(node)) {
		list_add_tail(node, &evts->list);
	} else {
		bdup = true;
	}
	os_spin_unlock_restore(&evts->lock, flags);
	return bdup;
}

u32 os_numTo2n2(u32  x)
{
	int i = 1;
	int tmp = x;
	while (x >>= 1) {
		i <<= 1;
	}
	return (i < tmp)? i << 1: i;
}

int os_log2n(u32 x)
{
	int n = 0;
	while (1 < x) {
		n++;
		x >>= 1;
	}	
	return n;
}

struct os_thread_t *os_thread_run(int (*func)(void *), void* data, char* name, int task_id)
{
	struct os_thread_t *thread = kzalloc(sizeof(struct os_thread_t), GFP_KERNEL);
	if (thread == NULL)
		return NULL;
	thread->task = kthread_run(func, data, "%s_%d", name, task_id);
	if (thread->task == NULL) {
		kfree(thread);
		return NULL;
	}
	init_completion(&thread->thread_finishing);
	thread->thread_shutdown = 0;
	return thread;
}

void os_thread_stop(struct os_thread_t *thread)
{
	if (thread == NULL)
		return;
	thread->thread_shutdown = 1;
	if (thread->task) {
		wait_for_completion(&thread->thread_finishing);
		thread->task = NULL;
	}
	kfree(thread);
}
