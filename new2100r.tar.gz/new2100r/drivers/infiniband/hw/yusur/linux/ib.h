#ifndef _YUSUR_OS_IB_H_
#define _YUSUR_OS_IB_H_
void yusur_ib_unregister(struct yusur_ib_dev *ibdev);
int yusur_ib_register(struct yusur_ib_dev *ibdev);
void yib_pool_mr_cleanup(struct yib_pool_entry *arg);
void yib_pool_cq_cleanup(struct yib_pool_entry *arg);
void yib_pool_qp_cleanup(struct yib_pool_entry *arg);
void yib_pool_rq_cleanup(struct yib_pool_entry *arg);
void yib_pool_eq_cleanup(struct yib_pool_entry *arg);
#if IBDEV_NO_OPS == 0
extern const struct ib_device_ops yib_dev_ops;
#else
void yib_init_ib_ops(struct ib_device *dev);
#endif
struct rdma_hw_stats *yib_ib_alloc_hw_stats(struct ib_device *ibdev, tPortInt port_num);
int yib_ib_get_hw_stats(struct ib_device *ibdev,
			struct rdma_hw_stats *stats,
			tPortInt port, int index);

struct ib_mr *yib_reg_user_mr(struct ib_pd *ibpd, u64 start, u64 length,
				     u64 iova, int access, struct ib_udata *udata);
int yib_map_mr_sg(struct ib_mr *ibmr, struct scatterlist *sg,
			 int sg_nents, unsigned int *sg_offset);
int yib_mmap(struct ib_ucontext *ibucontext, struct vm_area_struct *vma);

int yib_query_device(struct ib_device *ibdev, struct ib_device_attr *props,
			    struct ib_udata *uhw);

int yib_query_port(struct ib_device *ibdev,
			  tPortInt port_num, struct ib_port_attr *props);

#ifdef IB_SGID_ATTR_NOTHAS_SGID
int yib_query_gid(struct ib_device *device,
			u8 port_num, int index, union ib_gid *gid);
#endif
#if IB_ADD_GID_HAVE_GID
int yib_add_gid(const union ib_gid *gid, const struct ib_gid_attr *attr, 
				void **context);
#else
int yib_add_gid(const struct ib_gid_attr *attr, void **context);
#endif
int yib_del_gid(const struct ib_gid_attr *attr, void **context);

int yib_port_immutable(struct ib_device *ibdev, tPortInt port_num,
			      struct ib_port_immutable *immutable);

int yib_query_pkey(struct ib_device *ibdev, tPortInt port, u16 index, u16 *pkey);

#endif /* end _YUSUR_OS_PRIV_H_*/

