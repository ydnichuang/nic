#include "../include/basic.h"
#include "../include/os_api.h"
#include "../include/os_ds.h"
#include "../include/mem.h"
#include "../include/queue.h"
#include "../include/host.h"
#include "../include/verbs.h"
#include "../include/yusur_ib.h"
#include "../include/core.h"

#define K2PRO_REG_ABORMAL_CFG	0x00000220
#define K2PRO_REG_PFC_CTL	0x00000224

enum YIB_RDMA_MAP_TYPE {
	MAP_TYPE_DSCP = 0,
	MAP_TYPE_PCP,
	MAP_TYPE_RX_BUF,
	MAP_TYPE_PFC_ENABLE,
	MAP_TYPE_PFC_LOW,
	MAP_TYPE_PFC_HIGH,
};

struct yib_rdma_map_info {
	uint32_t type;
};

static ssize_t dev_info_show_internal(struct yusur_ib_dev * yib, char *buf)
{
	struct yib_hw_host * hw = &yib->host;

	switch ((int)hw->hw_ops.host_type) {
		case YRDMA_TYPE_R2100:
			return sprintf(buf, "R2100 %04X", hw->sf.pdev->device);
		case YRDMA_TYPE_NP:
			return sprintf(buf, "NP %04X", hw->sf.pdev->device);
		default:
			break;

	}
	return sprintf(buf, "NA NA");
}

static ssize_t pci_info_show_internal(struct yusur_ib_dev * yib, char *buf)
{
	struct yib_hw_host * hw = &yib->host;
	u8 bus, dev, devfn;
	int domain;

	bus = hw->sf.pdev->bus->number;
	dev = (hw->sf.pdev->devfn >> 3) & 0x3ff;
	devfn =  hw->sf.pdev->devfn & 0x07;
	domain = pci_domain_nr(hw->sf.pdev->bus);
	return sprintf(buf, "%04x:%02x:%02x.%01x", domain & 0xFFFF, bus, dev, devfn);
}

#if IB_DEV_HAS_SYS

static ssize_t dev_info_show(struct device *device, struct device_attribute *attr, char *buf)
{
	struct yusur_ib_dev * yib = rdma_device_to_drv_device(device, struct yusur_ib_dev, ib_dev);
	return dev_info_show_internal(yib, buf);
}

static ssize_t pci_info_show(struct device *device, struct device_attribute *attr, char *buf)
{
	struct yusur_ib_dev * yib = rdma_device_to_drv_device(device, struct yusur_ib_dev, ib_dev);
	return pci_info_show_internal(yib,buf);
}

static ssize_t rdma_rx_buf_show(struct device *device, struct device_attribute *attr, char *buf)
{
	struct yusur_ib_dev *yib = rdma_device_to_drv_device(device, struct yusur_ib_dev, ib_dev);
	return sprintf(buf, "%d", yib->host.rx_buf_mode);
}

static ssize_t rdma_rx_buf_store(struct device *device, struct device_attribute *attr,
				const char *buf, size_t count)
{
	struct yusur_ib_dev *yib = rdma_device_to_drv_device(device, struct yusur_ib_dev, ib_dev);

	memcpy(&yib->host.rx_buf_mode, buf, sizeof(yib->host.rx_buf_mode));
	yib_pr_info(YUUSR_IB_DBG_SYS, "host rx_buf_mode: %d\n", yib->host.rx_buf_mode);
	return count;
}
static ssize_t rdma_qos_store(struct device *device, struct device_attribute *attr,
				const char *buf, size_t count)
{
	struct yusur_ib_dev *yib = rdma_device_to_drv_device(device, struct yusur_ib_dev, ib_dev);
	struct yib_rdma_qos_info qos_info;
	int ret = 0;

	memset(&qos_info, 0, sizeof(struct yib_rdma_qos_info));
	memcpy(&qos_info, buf, count);

	yib_pr_info(YUUSR_IB_DBG_SYS,
		"%s: "
		"qos_info.cir: %d "
		"qos_info.cbs: %d "
		"qos_info.level: %d "
		"qos_info.obj_index: %d "
		"qos_info.is_multi_mode: %d "
		"qos_info.inherit_mode: %d "
		"qos_info.bypass: %d\n",
		__func__, qos_info.cir, qos_info.cbs, qos_info.level,
		qos_info.obj_index, qos_info.is_multi_mode, qos_info.inherit_mode,
		qos_info.bypass);

	ret = yib->host.hw_ops.set_qos(&yib->host, &qos_info);
	if (ret) {
		yib_pr_warn("Failed to set qos\n");
        return -EIO;
	}
	return count;
}

static void yib_rdma_map_dump(struct yusur_ib_dev *yib, int item_num, int item_size, char *item_name, int offset)
{
	int i = 0;
	void *frag_va = NULL;

	for (i = 0; i < item_num; i++) {
		frag_va = yib->host.prio_array.vaddr + offset + i * item_size;
		yib_pr_info(YUUSR_IB_DBG_SYS, "%s[%d] : %x\n", item_name, i, readl(frag_va));
	}
}

static ssize_t rdma_map_store(struct device *device, struct device_attribute *attr,
				const char *buf, size_t count)
{
	struct yusur_ib_dev *yib = rdma_device_to_drv_device(device, struct yusur_ib_dev, ib_dev);
	struct yib_rdma_map_info map_info;
	enum YIB_RDMA_MAP_TYPE map_type;
	int ret = 0;

	memset(&map_info, 0, sizeof(struct yib_rdma_map_info));
	memcpy(&map_info, buf, count);
	map_type = map_info.type;
	switch (map_type) {
		case MAP_TYPE_DSCP:
			yib_rdma_map_dump(yib, YIB_DSCP_ARRAY_SIZE, 4, "DSCP", 0);
			break;
		case MAP_TYPE_PCP:
			yib_rdma_map_dump(yib, YIB_PCP_ARRAY_SIZE, 4, "PCP", 256);
			break;
		case MAP_TYPE_RX_BUF:
			yib_rdma_map_dump(yib, YIB_RX_BUF_ARRAY_SIZE, 4, "RX_BUF", 320);
			ret = yib->host.hw_ops.set_rx_buf_size(&yib->host);
			if (ret) {
				yib_pr_warn("Failed to set rx buffer size\n");
                return -EIO;
			}
			break;
		case MAP_TYPE_PFC_ENABLE:
			yib_rdma_map_dump(yib, YIB_PFC_ENABLE_ARRAY_SIZE / 4, 4, "PFC_ENABLE", 352);
			break;
		case MAP_TYPE_PFC_LOW:
			yib_rdma_map_dump(yib, YIB_PFC_LOW_ARRAY_SIZE, 4, "PFC_LOW", 360);
			break;
		case MAP_TYPE_PFC_HIGH:
			yib_rdma_map_dump(yib, YIB_PFC_HIGH_ARRAY_SIZE, 4, "PFC_HIGH", 392);
			break;
		default:
			break;
	}
	return count;
}

static DEVICE_ATTR_RO(pci_info);
static DEVICE_ATTR_RO(dev_info);
static DEVICE_ATTR_RW(rdma_rx_buf);
static DEVICE_ATTR_WO(rdma_qos);
static DEVICE_ATTR_WO(rdma_map);

static struct attribute *yib_dev_attributes[] = {
	&dev_attr_dev_info.attr,
	&dev_attr_pci_info.attr,
	&dev_attr_rdma_rx_buf.attr,
	&dev_attr_rdma_qos.attr,
	&dev_attr_rdma_map.attr,
	NULL,
};

const struct attribute_group yib_sys_attr_group = {
	.attrs = yib_dev_attributes,
};

#else
static ssize_t k2pro_attr_show(struct kobject *kobj, struct attribute *attr,
			      char *buf)
{
	struct kobj_attribute *kattr;
	ssize_t ret = -EIO;

	kattr = container_of(attr, struct kobj_attribute, attr);
	if (kattr->show)
		ret = kattr->show(kobj, kattr, buf);
	return ret;
}

static ssize_t k2pro_attr_store(struct kobject *kobj, struct attribute *attr,
			       const char *buf, size_t count)
{
	struct kobj_attribute *kattr;
	ssize_t ret = -EIO;

	kattr = container_of(attr, struct kobj_attribute, attr);
	if (kattr->store)
		ret = kattr->store(kobj, kattr, buf, count);
	return ret;
}

struct sysfs_ops k2pro_sysfs_ops = {
	.show = k2pro_attr_show,
	.store = k2pro_attr_store,
};

static ssize_t pci_info_show(struct kobject *kobj,
		        struct kobj_attribute *attr, char *buf)
{
	struct yusur_ib_dev *yib = container_of(kobj, struct yusur_ib_dev, sys_kobj);
	return pci_info_show_internal(yib, buf);
}

static ssize_t dev_info_show(struct kobject *kobj,
		        struct kobj_attribute *attr, char *buf)
{
	struct yusur_ib_dev *yib = container_of(kobj, struct yusur_ib_dev, sys_kobj);
	return dev_info_show_internal(yib, buf);
}

static struct kobj_attribute dev_attr_pci_info =
__ATTR(pci_info, 0660, pci_info_show, NULL);

static struct kobj_attribute dev_attr_dev_info =
__ATTR(dev_info, 0660, dev_info_show, NULL);

static struct attribute *yib_dev_attributes[] = {
	&dev_attr_pci_info.attr,
	&dev_attr_dev_info.attr,
	NULL,
};

const struct attribute_group yib_sys_attr_group = {
	.attrs = yib_dev_attributes,
};

struct kobj_type k2pro_ktype = {
	.sysfs_ops = &k2pro_sysfs_ops,
	.default_attrs = yib_dev_attributes,
};


int yib_create_sysfs_entries(const char *name,
				struct kobject *parent,
				const struct attribute_group *grp,
				struct kobject *kobj)
{
	int ret = 0;

	struct yusur_ib_dev *yib = container_of(kobj, struct yusur_ib_dev, sys_kobj);

	if(kobj == NULL ){
		pr_err(" %s sysfs create failed", name);
		return -ENOMEM;
	}

	ret = kobject_init_and_add(kobj,&k2pro_ktype, parent,"%s", name);
	yib = container_of(kobj, struct yusur_ib_dev, sys_kobj);
	if (ret < 0) {
		pr_err(" %s sysfs create failed", name);
		return -ENOMEM;
	}

#if 0
	ret = sysfs_create_group(kobj, grp);
	if (ret < 0) {
		kobject_del(kobj);
		pr_err("%s unable to create  %s sysfs entries\n",
				__func__, name);
		return ret;
	}
#endif

	return 0;
}
#endif