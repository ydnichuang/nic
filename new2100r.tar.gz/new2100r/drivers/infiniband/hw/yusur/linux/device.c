#include "../include/basic.h"
#include <linux/yusur/yrdma_model.h>
#include <linux/skbuff.h>
#include <linux/if_arp.h>
#include <linux/netdevice.h>
#include <linux/if.h>
#include <linux/if_vlan.h>
#include <net/udp_tunnel.h>
#include <net/sch_generic.h>
#include <linux/netfilter.h>
#include <rdma/ib_addr.h>
#include <rdma/ib_mad.h>
#include <rdma/ib_cache.h>
#include "../include/os_api.h"
#include "../include/os_ds.h"
#include "../include/mem.h"
#include "../include/queue.h"
#include "../include/host.h"
#include "../include/verbs.h"
#include "../include/yusur_ib.h"
#include "../include/core.h"
#include "priv.h"
#include "ib.h"

//IB_EVENT_SQ_DRAINED;
void os_ibqp_event(struct yib_qp * qp, enum ib_event_type type) 
{
	if (qp->ib_qp.event_handler) {
		struct ib_event ev;
		ev.device = qp->ib_qp.device;
		ev.element.qp = &qp->ib_qp;
		ev.event = type; 
		qp->ib_qp.event_handler(&ev, qp->ib_qp.qp_context);
	}
}

static void yib_port_event(struct yusur_ib_dev *yib,
			   enum ib_event_type event)
{
	struct ib_event ev;

	ev.device = &yib->ib_dev;
	ev.element.port_num = 1;
	ev.event = event;
	ib_dispatch_event(&ev);
}

static void yusur_dev_port_chg(struct yusur_ib_dev *yib, struct net_device *ndev, int port_num)
{
	if (netif_running(ndev) && netif_carrier_ok(ndev))
		yib_port_event(yib, IB_EVENT_PORT_ACTIVE);
	else {
		yib->host.ndev_info[port_num].link_down++;
		yib_port_event(yib, IB_EVENT_PORT_ERR);
	}
}

static int handle_netdev_notifier(struct notifier_block *notifier,
				       unsigned long event, void *ptr)
{
	struct net_device *ndev;
	u8 mac[ETH_ALEN];
	struct yusur_ib_dev *ibdev = NULL;
	int i = 0;
	ndev = netdev_notifier_info_to_dev(ptr);

	ibdev = container_of(notifier, struct yusur_ib_dev, netdev_notifier);
	if (ibdev == NULL)
		return 0;

#if IB_DEV_HAS_NETDEV
	ib_device_try_get(&ibdev->ib_dev);
#endif

	for (i = 0; i < YIB_MAX_DEV_PORTS; i++) {
		if (ibdev->host.ndev_info[i].netdev == ndev) {
		switch (event) {
			case NETDEV_CHANGEADDR:
				os_get_netdev_mac(ndev, mac);
				yusur_hw_mactbl_item_change(&ibdev->host, mac, i, i + 1);
				break;
			case NETDEV_CHANGEMTU:
				yusur_dev_update_mtu(&ibdev->host, ndev, i+1);
				break;
			//case NETDEV_CHANGE:
			case NETDEV_DOWN:
			case NETDEV_UP:
				yusur_dev_port_chg(ibdev, ndev, i);
				break;
			default:
				break;
			}
		}
	}

#if IB_DEV_HAS_NETDEV
	ib_device_put(&ibdev->ib_dev);
#endif
	return 0;
}

static int yusur_ib_register_net_notifier(struct yusur_ib_dev *ibdev)
{
	ibdev->netdev_notifier.notifier_call = handle_netdev_notifier;
	if (register_netdevice_notifier(&ibdev->netdev_notifier) != 0) {
		ibdev->netdev_notifier.notifier_call = NULL;
	}

	return 0;
}

static void yusur_ib_unregister_net_notifier(struct yusur_ib_dev *ibdev)
{
	if (ibdev->netdev_notifier.notifier_call != NULL) {
		unregister_netdevice_notifier(&ibdev->netdev_notifier);
		ibdev->netdev_notifier.notifier_call = NULL;
	}
}

void yusur_ib_unregister(struct yusur_ib_dev *ibdev)
{
	yusur_ib_unregister_net_notifier(ibdev);
#if IB_DEV_HAS_SYS == 0
       if (ibdev->sys_ok) {
               sysfs_remove_group(&ibdev->sys_kobj, &yib_sys_attr_group);
               kobject_del(&ibdev->sys_kobj);
               ibdev->sys_ok = false;
       }
#endif
	ib_unregister_device(&ibdev->ib_dev);
	yib_mr_dealloc(ibdev->global_mr, NULL);
}

int yusur_ib_register(struct yusur_ib_dev *ibdev)
{
	const char *name;
	struct ib_device *ib_dev = &ibdev->ib_dev;
	u64 dma_mask;
	char node_desc[64];
	int ret;

	if (ibdev->bonding)
		name = "yusur_bond_%d";
	else
		name = "yusur_%d";

	ib_dev->node_type = RDMA_NODE_IB_CA;
	ib_dev->dev.parent = ibdev->dev;
	ib_dev->phys_port_cnt = 1;
	ib_dev->num_comp_vectors = ibdev->host.caps.num_comp_vector;

	memset(node_desc, 0, sizeof(node_desc));
	snprintf(node_desc, sizeof(node_desc), "%s(%02X:%02X)",
		ibdev->host.hw_ops.host_name, ibdev->host.sf.pdev->vendor, ibdev->host.sf.pdev->device);
	strlcpy(ib_dev->node_desc, node_desc, sizeof(ib_dev->node_desc));

	addrconf_addr_eui48((unsigned char *)&ib_dev->node_guid,
			    ibdev->host.ndev_info[0].netdev->dev_addr);
	dma_set_max_seg_size(&ib_dev->dev, UINT_MAX);
	dma_mask = IS_ENABLED(CONFIG_64BIT) ? DMA_BIT_MASK(64) : DMA_BIT_MASK(32);
	dma_coerce_mask_and_coherent(&ib_dev->dev, dma_mask);
	{
		struct yib_mr *mr;
		mr = yib_mr_alloc_new(ibdev, NULL, false, true, false);
		if (IS_ERR(mr)) {
			yib_pr_warn("alloc global lkey failed\n");
			return -ENOMEM;
		}

		mr->ib_mr.device = ib_dev;
		mr->state = YIB_MR_VALID;
		ibdev->host.sf.sf_ops->mr_mpt_update(&ibdev->host.sf, mr);
		ibdev->global_mr = mr;
		ib_dev->local_dma_lkey = mr->ib_mr.lkey;
		yib_dbg_info(YUSUR_IB_M_MR, YUSUR_IB_DBG_CREATE, "global  mr:%d alloc\n", yib_get_mr_sw_idx(mr));
	}

	ib_dev->uverbs_cmd_mask = BIT_ULL(IB_USER_VERBS_CMD_GET_CONTEXT)
	    | BIT_ULL(IB_USER_VERBS_CMD_CREATE_COMP_CHANNEL)
	    | BIT_ULL(IB_USER_VERBS_CMD_QUERY_DEVICE)
	    | BIT_ULL(IB_USER_VERBS_CMD_QUERY_PORT)
	    | BIT_ULL(IB_USER_VERBS_CMD_ALLOC_PD)
	    | BIT_ULL(IB_USER_VERBS_CMD_DEALLOC_PD)
	    | BIT_ULL(IB_USER_VERBS_CMD_DESTROY_SRQ)
	    | BIT_ULL(IB_USER_VERBS_CMD_CREATE_QP)
	    | BIT_ULL(IB_USER_VERBS_CMD_MODIFY_QP)
	    | BIT_ULL(IB_USER_VERBS_CMD_QUERY_QP)
	    | BIT_ULL(IB_USER_VERBS_CMD_DESTROY_QP)
	    | BIT_ULL(IB_USER_VERBS_CMD_POST_SEND)
	    | BIT_ULL(IB_USER_VERBS_CMD_POST_RECV)
	    | BIT_ULL(IB_USER_VERBS_CMD_CREATE_CQ)
	    | BIT_ULL(IB_USER_VERBS_CMD_RESIZE_CQ)
	    | BIT_ULL(IB_USER_VERBS_CMD_DESTROY_CQ)
	    | BIT_ULL(IB_USER_VERBS_CMD_POLL_CQ)
	    | BIT_ULL(IB_USER_VERBS_CMD_REQ_NOTIFY_CQ)
	    | BIT_ULL(IB_USER_VERBS_CMD_REG_MR)
	    | BIT_ULL(IB_USER_VERBS_CMD_DEREG_MR)
	    | BIT_ULL(IB_USER_VERBS_CMD_CREATE_AH)
	    | BIT_ULL(IB_USER_VERBS_CMD_MODIFY_AH)
	    | BIT_ULL(IB_USER_VERBS_CMD_QUERY_AH)
	    | BIT_ULL(IB_USER_VERBS_CMD_DESTROY_AH);

#if IBDEV_NO_OPS == 0
	ib_set_device_ops(ib_dev, &yib_dev_ops);   
#else
	yib_init_ib_ops(ib_dev);
#endif 
	register_yib_ioctl(ibdev);
	if (ibdev->host.funcs.srq_supp) {
		ib_dev->uverbs_cmd_mask |= BIT_ULL(IB_USER_VERBS_CMD_CREATE_SRQ)
	    				| BIT_ULL(IB_USER_VERBS_CMD_QUERY_SRQ)
					| BIT_ULL(IB_USER_VERBS_CMD_POST_SRQ_RECV);
		if (ibdev->host.funcs.srq_modify)
			ib_dev->uverbs_cmd_mask |= BIT_ULL(IB_USER_VERBS_CMD_MODIFY_SRQ); 
	}	

	if (ibdev->host.funcs.ud_multicast) {
		ib_dev->uverbs_cmd_mask |= BIT_ULL(IB_USER_VERBS_CMD_ATTACH_MCAST)
	    				| BIT_ULL(IB_USER_VERBS_CMD_DETACH_MCAST);
	}

	if (ibdev->host.funcs.xrc_supp) {
		ib_dev->uverbs_cmd_mask |= BIT_ULL(IB_USER_VERBS_CMD_OPEN_XRCD);
		ib_dev->uverbs_cmd_mask |= BIT_ULL(IB_USER_VERBS_CMD_CLOSE_XRCD);
		if (ibdev->host.funcs.srq_supp)
			ib_dev->uverbs_cmd_mask |= BIT_ULL(IB_USER_VERBS_CMD_CREATE_XSRQ);
	}

	if (ibdev->host.funcs.mw_supp) {
		ib_dev->uverbs_cmd_mask |= BIT_ULL(IB_USER_VERBS_CMD_ALLOC_MW);
		ib_dev->uverbs_cmd_mask |= BIT_ULL(IB_USER_VERBS_CMD_BIND_MW);
		ib_dev->uverbs_cmd_mask |= BIT_ULL(IB_USER_VERBS_CMD_DEALLOC_MW);
	}

#if IB_DEV_HAS_SYS
        #if IB_HAS_SYS_GROUP == 0
        rdma_set_device_sysfs_group(&ibdev->ib_dev, &yib_sys_attr_group);
        #endif
#endif
#if IB_DEV_HAS_NETDEV
	ib_device_set_netdev(&ibdev->ib_dev, ibdev->host.ndev_info[0].netdev, 1);
#endif
#if IBDEV_NO_OPS == 0
	#if IBDEV_REGIST_NEED2PARAM == 1
	ibdev->ib_dev.dev.parent = &ibdev->host.pdev->dev;
	ret = ib_register_device(&ibdev->ib_dev, name);
	#else
	ret = ib_register_device(&ibdev->ib_dev, name, &ibdev->host.sf.pdev->dev);
	#endif
#else
        ibdev->ib_dev.dev.parent = &ibdev->host.sf.pdev->dev;
	strlcpy(ibdev->ib_dev.name, name , IB_DEVICE_NAME_MAX);
	dev_set_name(&ibdev->ib_dev.dev, name);
	#ifdef IB_DEV_HAS_DRIVERID
	ibdev->ib_dev.driver_id = RDMA_DRIVER_ID_YUSUR;
	#endif
	#if IBDEV_REGIST_NEED2PARAM == 1
	ret = ib_register_device(&ibdev->ib_dev,  NULL);
	#else
	ret = ib_register_device(&ibdev->ib_dev, name, NULL);//for kunpeng
	#endif
#endif

#if IB_DEV_HAS_SYS == 0
	if (yib_create_sysfs_entries("yibsys", &ibdev->ib_dev.dev.kobj, &yib_sys_attr_group, &ibdev->sys_kobj) == 0) {
			ibdev->sys_ok = true;
	} else
			ibdev->sys_ok = false;
#endif

	if (ret != 0) {
		goto end;
	}
	ret = yusur_ib_register_net_notifier(ibdev);

end:
	if (ret !=0) {
		yusur_ib_unregister(ibdev);
	}
	return ret;
} 

int yib_query_pkey(struct ib_device *ibdev, tPortInt port, u16 index, u16 *pkey)
{
	if (index >=  YUSUR_RDMA_PKEY_TABLE_LEN)
		return -EINVAL;
	*pkey = g_yib_pkey_table[index]; 
	return 0;
}


int yib_port_immutable(struct ib_device *ibdev, tPortInt port_num,
			      struct ib_port_immutable *immutable)
{
	struct ib_port_attr attr;
	int ret;


	ret = ib_query_port(ibdev, port_num, &attr);
	if (ret)
	{
		os_printw(&ibdev->dev, "ib_query_port failed, port number:%d!\n", port_num);
		return ret;
	}

	immutable->pkey_tbl_len = attr.pkey_tbl_len;
	immutable->gid_tbl_len = attr.gid_tbl_len;
	immutable->max_mad_size = IB_MGMT_MAD_SIZE;
	immutable->core_cap_flags = RDMA_CORE_PORT_IBA_ROCE_UDP_ENCAP;
	return 0;
}

struct net_device *yib_get_netdev(struct ib_device *ibdev, tPortInt port_num)
{
	struct yusur_ib_dev *yib = to_yib(ibdev);
	struct net_device *netdev = NULL;


	rcu_read_lock();
	netdev = yusur_get_net_dev_from_yib(yib, port_num);
	/* dev_put shall be called by whoever calls get_netdev */
	if (netdev)
		dev_hold(netdev);

	rcu_read_unlock();
	return netdev;
}

#ifdef IB_SGID_ATTR_NOTHAS_SGID
int yib_query_gid(struct ib_device *device,
			 u8 port_num, int index, union ib_gid *gid)
{
	int ret;
	struct ib_gid_attr sgid_attr = {};

	if (index > YUSUR_RDMA_GID_TABLE_LEN)
		return -EINVAL;

	ret = ib_get_cached_gid(device, port_num, index, gid, &sgid_attr);
	if (ret == -EAGAIN) {
		memcpy(gid, &zgid, sizeof(*gid));
		return 0;
	} else if (ret == 0) {
		dev_put(sgid_attr.ndev);
	}

	return ret;
}
#endif

#if IB_ADD_GID_HAVE_GID
int yib_add_gid(const union ib_gid *gid, const struct ib_gid_attr *attr, 
				void **context)
#else
int yib_add_gid(const struct ib_gid_attr *attr, void **context)
#endif
{
	struct yusur_ib_dev *yib = to_yib(attr->device);
	u16 vlan_id = 0xffff;
	u8 mac[ETH_ALEN];
	u8 gid_raw[16];
	bool brocev2 = false, bipv4 = false;
	int ret;

	if (attr->port_num - 1 >= yib->host.caps.num_ports)
		return -EINVAL;

	if (attr->gid_type == IB_GID_TYPE_ROCE)
		brocev2 = false;
	else if (attr->gid_type == IB_GID_TYPE_ROCE_UDP_ENCAP) {
		brocev2 = true;
		#if IB_ADD_GID_HAVE_GID
		if (ipv6_addr_v4mapped((void *)gid))
		#else
		if (ipv6_addr_v4mapped((void *)&attr->gid))
		#endif
			bipv4 = true;
		else
			bipv4 = false;
	}

#ifdef IB_HAS_READ_GID_L2_FIELDS
	ret = rdma_read_gid_l2_fields(attr, &vlan_id, &mac[0]);
	if (ret)
		return ret;
#else 
{
	struct net_device *ndev;
	ndev = yib_get_netdev(&yib->ib_dev, attr->port_num);
	vlan_id = rdma_vlan_dev_vlan_id(ndev);
	memcpy(mac, ndev->dev_addr, ETH_ALEN);
}
#endif

	ret = yusur_hw_mactbl_search(&yib->host, mac, attr->port_num, true);
	if (ret) {
		yib_pr_warn("gid mac add to mactbl failed\n");
		return ret;
	}
#if IB_ADD_GID_HAVE_GID
	memcpy(gid_raw, gid->raw, 16);
#else
	memcpy(gid_raw, attr->gid.raw, 16);
#endif
	yib->host.sf.sf_ops->set_gid(&yib->host.sf, brocev2, bipv4, attr->index, gid_raw, false);

	return 0;
}
 
int yib_del_gid(const struct ib_gid_attr *attr, void **context)
{
	struct yusur_ib_dev *yib = to_yib(attr->device);
	u16 vlan_id = 0xffff;
	u8 mac[ETH_ALEN];
	u8 gid_raw[16];
	int ret;
#ifdef IB_SGID_ATTR_NOTHAS_SGID
	struct ib_gid_attr sgid_attr;
	union ib_gid sgid;
#endif

	if (attr->port_num - 1 >= yib->host.caps.num_ports)
		return -EINVAL;

#ifdef IB_HAS_READ_GID_L2_FIELDS
	ret = rdma_read_gid_l2_fields(attr, &vlan_id, &mac[0]);
	if (ret)
		return ret;
#else 
{
	struct net_device *ndev;
	ndev = yib_get_netdev(&yib->ib_dev, attr->port_num);
	vlan_id = rdma_vlan_dev_vlan_id(ndev);
	memcpy(mac, ndev->dev_addr, ETH_ALEN);
}
#endif

	ret = yusur_hw_mactbl_search(&yib->host, mac, attr->port_num, false);
	if (ret) {
		yib_pr_warn("gid mac del from mactbl failed\n");
		return 0;
	}
#ifdef IB_SGID_ATTR_NOTHAS_SGID
	ib_get_cached_gid(attr->device, attr->port_num, attr->index, &sgid, &sgid_attr);
	memcpy(gid_raw, sgid.raw, 16);
#else
	memcpy(gid_raw, attr->gid.raw, 16);
#endif
	yib->host.sf.sf_ops->set_gid(&yib->host.sf, true, true, attr->index, gid_raw, true);

	return 0;
}

int yib_query_port(struct ib_device *ibdev,
			  tPortInt port_num, struct ib_port_attr *props)
{
	struct yusur_ib_dev *yib = to_yib(ibdev);
	os_net_device *ndev = yusur_get_net_dev_from_yib(yib, port_num);

	if (ndev == NULL) {
		return -ENODEV;
	}
	memset(props, 0, sizeof(struct ib_port_attr));

	if (netif_running(ndev) && netif_carrier_ok(ndev)) {
		props->state = IB_PORT_ACTIVE;
		props->phys_state = 5;
	}
	else
	{
		props->state = IB_PORT_DOWN;
		props->phys_state = 3;
	}

	props->gid_tbl_len = YUSUR_RDMA_GID_TABLE_LEN;
	props->max_mtu = IB_MTU_4096;
	props->lid = 0;
	props->lmc = 0;
	props->sm_lid = 0;
	props->sm_sl = 0;
	props->max_vl_num = 1;
	props->active_mtu = iboe_get_mtu(ndev->mtu);
	props->port_cap_flags = RDMA_CORE_CAP_PROT_ROCE_UDP_ENCAP;
	ib_get_eth_speed(ibdev, port_num, &props->active_speed, &props->active_width);
	props->max_msg_sz = 0x80000000;
	props->bad_pkey_cntr = 0;
	props->qkey_viol_cntr = 0;
	props->subnet_timeout = 0;
	props->init_type_reply = 0;
	props->pkey_tbl_len = YUSUR_RDMA_PKEY_TABLE_LEN; 

	return 0;
}

int yib_query_device(struct ib_device *ibdev, struct ib_device_attr *props,
			    struct ib_udata *uhw)
{
	struct yusur_ib_dev *yib = to_yib(ibdev);

	memset(props, 0, sizeof(*props));

	props->hw_ver = yib->host.caps.hw_ver;
	props->fw_ver = yib->host.caps.fw_ver;
	props->vendor_id = os_get_pcidev_vendor(yib->host.sf.pdev);
	props->vendor_part_id = os_get_pcidev_device(yib->host.sf.pdev);
	props->sys_image_guid = yib->ib_dev.node_guid;
	
	props->max_qp = yib->host.caps.num_qps;
	props->page_size_cap = 0xfffff000;
	props->max_qp_wr =  yib->host.caps.max_qp_wr;
	props->max_qp_rd_atom = yib->host.caps.max_qp_rd_atom;
	props->max_qp_init_rd_atom = yib->host.caps.max_qp_init_rd_atom;
#ifdef IB_DEV_HAS_SEND_SGE
	props->max_send_sge = yib->host.caps.max_sq_sg;
	props->max_recv_sge = yib->host.caps.max_rq_sg;
#else
	props->max_sge = yib->host.caps.max_sq_sg;
#endif
	props->max_sge_rd = yib->host.caps.max_sq_sg;
	props->max_pd = yib->host.caps.num_pds;
	props->max_cq = yib->host.caps.num_cqs;
	props->max_cqe = yib->host.caps.max_cqes;
	props->max_ah = yib->host.caps.max_ah;
	props->max_mr = yib->host.caps.max_mr;
	props->atomic_cap = IB_ATOMIC_NONE;
	props->max_pkeys = 128;
	props->max_fast_reg_page_list_len = YUSUR_RDMA_FAST_MR_SG_LEN;
	props->max_mr_size = yib->host.caps.max_mr_size;
	props->local_ca_ack_delay = 16;
	props->max_res_rd_atom = yib->host.caps.max_res_rd_atom;

	props->device_cap_flags =         IB_DEVICE_BAD_PKEY_CNTR
					| IB_DEVICE_CHANGE_PHY_PORT
					| IB_DEVICE_UD_AV_PORT_ENFORCE
					| IB_DEVICE_PORT_ACTIVE_EVENT
					| IB_DEVICE_SYS_IMAGE_GUID
					| IB_DEVICE_RC_RNR_NAK_GEN
					| IB_DEVICE_MEM_MGT_EXTENSIONS;
					//| IB_DEVICE_ALLOW_USER_UNREG

#if IB_HAS_KERNEL_CAP == 0
	props->device_cap_flags |= IB_DEVICE_LOCAL_DMA_LKEY;
#else
	props->kernel_cap_flags = IBK_LOCAL_DMA_LKEY;
#endif 

	props->max_qp_init_rd_atom = yib->host.caps.max_qp_init_rd_atom;  

	if (yib->host.funcs.atomic_supp)
		props->atomic_cap = IB_ATOMIC_HCA;

	if (yib->host.funcs.mw_supp) {
		props->max_mw = yib->host.caps.max_mr;
		props->device_cap_flags |=  IB_DEVICE_MEM_WINDOW;
	}

	if (yib->host.funcs.srq_supp) {
		props->max_srq = yib->host.caps.max_srqs;
		props->max_srq_sge = yib->host.caps.max_rq_sg;
		props->max_srq_wr = yib->host.caps.max_srqes;
	}

	if (yib->host.funcs.ud_multicast) {
		props->max_mcast_grp = yib->host.caps.max_mcast_grp;
		props->max_mcast_qp_attach = yib->host.caps.max_mcast_qps;
		props->max_total_mcast_qp_attach =  yib->host.caps.max_mcast_grp * yib->host.caps.max_mcast_qps;
	}

	if (yib->host.funcs.xrc_supp) {
		props->device_cap_flags |= IB_DEVICE_XRC;
	}

	yib_pr_info(YUSUR_IB_DBG_QUERY,
			"%s: "
			"props->max_qp: %d "
			"props->max_send_sge: %d "
			"props->max_recv_sge: %d "
			"props->max_sge_rd: %d "
			"props->max_qp_wr: %d "
			"props->max_recv_sge: %d "
			"props->max_pd: %d "
			"props->max_mr: %d\n",
#ifdef IB_DEV_HAS_SEND_SGE
			__func__, props->max_qp, props->max_send_sge,
			props->max_recv_sge, props->max_sge_rd, props->max_qp_wr,
			props->max_recv_sge, props->max_pd, props->max_mr);
#else
			__func__, props->max_qp, props->max_sge,
			props->max_sge, props->max_sge_rd, props->max_qp_wr,
			props->max_sge, props->max_pd, props->max_mr);
#endif

	return 0;
}

int yusur_get_left_sfs(struct yusur_rdma_dev *yrdev)
{
	struct yusur_ib_dev *ibdev = yrdev->priv_data;
	if (yrdev->priv_data == NULL)
		return 0;
	
	return ibdev->host.hw_ops.get_usable_channels(&ibdev->host);
}

void yusur_ib_dev_uninit(struct yusur_ib_dev *ibdev) 
{
	yusur_core_ibdev_free(ibdev);
}

static void yusur_ib_host_init(struct yusur_ib_dev *ibdev, struct yusur_rdma_dev *yrdev)
{
	int i = 0;

	ibdev->bonding = yrdev->bonding_mode;
	os_spin_lock_init(&ibdev->lock);
	ibdev->yrdev = yrdev;

	yrdev->get_left_sfs = yusur_get_left_sfs;

	ibdev->host.dev = ibdev->dev;
	ibdev->host.reg_base[0] = yrdev->global_bar_virtual_addr[0];
	ibdev->host.bar_size[0] = yrdev->bar_size[0];
	ibdev->host.irq_cnt = yrdev->irq_cnt;
	ibdev->host.irq_vector = yrdev->irq_vector;
	ibdev->host.yib = ibdev;
	ibdev->host.sf_per_port = YIB_MAX_DEV_PORTS;
	ibdev->host.chip_subtype = yrdev->chip_subtype;

	for (i = 0; i < YIB_MAX_DEV_PORTS; i++) {
		ibdev->host.net_dev[i] = yrdev->ndev[i];
	}

	ibdev->host.sf.pdev = yrdev->pdev;
	ibdev->host.sf.host_mutex = yrdev->glb_mutex;
	ibdev->host.sf.bonding = yrdev->bonding_mode;
	ibdev->host.sf.num_node = dev_to_node(&yrdev->pdev->dev);
	ibdev->host.sf.udp_port = 4791;
}

int yusur_ib_dev_init(struct yusur_ib_dev *ibdev, struct yusur_rdma_dev *yrdev)
{
	int ret = 0;

	yusur_ib_host_init(ibdev, yrdev);//在这个函数以后，就能访问寄存器了

	ret = yusur_core_ibdev_init(ibdev, yrdev->host_type);

	return ret;
}

