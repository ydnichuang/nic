#include <rdma/ib_mad.h>
#include <rdma/ib_addr.h>
#include <rdma/ib_user_verbs.h>
#include <rdma/ib_cache.h>
#include <rdma/ib_umem.h>
#include <rdma/ib_verbs.h>
#include <rdma/uverbs_ioctl.h>
#if defined(__mips64)
#include <linux/vmalloc.h>
#endif

#include "../include/basic.h"
#include "../include/os_api.h"
#include "../include/os_ds.h"
#include "../include/mem.h"
#include "../include/queue.h"
#include "../include/host.h"
#include "../include/verbs.h"
#include "../include/yusur_ib.h"
#include "ib.h"

#define YIB_ALLOC_ID_FROM_LAST	0

int yib_bmap_alloc(struct yib_bmap *bmap, bool bglobal, unsigned long *buf, u32 max_count, char *name)
{
	unsigned long *bitmap;

	if (bglobal == false) {
		bitmap = kcalloc(BITS_TO_LONGS(max_count), sizeof(long),
				GFP_KERNEL);
		if(!bitmap) {
			return -ENOMEM;
		}
	} else {
		bitmap = buf;
	}

	bmap->bglobal = bglobal;
	bmap->bitmap = bitmap;
	bmap->max_count = max_count;
	snprintf(bmap->name, XIB_MAX_BMAP_NAME, "%s", name);

	return 0;
}

void yib_bmap_free(struct yib_bmap *bmap)
{
	if (bmap && bmap->bitmap) {
		if (bmap->bglobal == false)
			kfree(bmap->bitmap);
		bmap->bitmap = NULL;
	}
}

int yib_bmap_alloc_id(struct yib_bmap *bmap, u32 *id_num)
{
	*id_num = find_first_zero_bit(bmap->bitmap, bmap->max_count);
	if (*id_num > bmap->max_count)
		return -EINVAL;

	__set_bit(*id_num, bmap->bitmap);

	return 0;
}

void yib_bmap_release_id(struct yib_bmap *bmap, u32 id_num)
{
	test_and_clear_bit(id_num, bmap->bitmap);
}

struct yib_type_info yib_type_info[YIB_NUM_TYPES] = {
	[YIB_TYPE_PD] = {
		.name		= "yib-pd",
		.size		= sizeof(struct yib_pd),
#if IB_LAYER_ALLOC_PD		
		.flags		= YIB_POOL_NO_ALLOC | YIB_POOL_INDEX, 
#else
		.flags		= YIB_POOL_INDEX, 
#endif
		.min_index	= 0,
	},
	[YIB_TYPE_AH] = {
		.name		= "yib-ah",
		.size		= sizeof(struct yib_ah),
#if IB_LAYER_ALLOC_AH		
		.flags		= YIB_POOL_ATOMIC | YIB_POOL_NO_ALLOC | YIB_POOL_INDEX,
#else
		.flags		= YIB_POOL_ATOMIC | YIB_POOL_INDEX,
#endif
		.min_index	= 0,
	},
	[YIB_TYPE_RQ] = {
		.name		= "yib-rq",
		.size		= sizeof(struct yib_rq),
		.flags		= YIB_POOL_INDEX | YIB_POOL_ARRAY_IDX,
		.cleanup	= yib_pool_rq_cleanup,
		.min_index	= 0,
	},
	[YIB_TYPE_EQ] = {
		.name		= "yib-eq",
		.size		= sizeof(struct yib_eq),
		.flags		= YIB_POOL_INDEX | YIB_POOL_ARRAY_IDX,
		.cleanup	= yib_pool_eq_cleanup,
		.min_index	= 0,
	},	
	[YIB_TYPE_QP] = {
		.name		= "yib-qp",
		.size		= sizeof(struct yib_qp),
		.cleanup	= yib_pool_qp_cleanup,
#if IB_LAYER_ALLOC_QP
		.flags		= YIB_POOL_NO_ALLOC | YIB_POOL_INDEX | YIB_POOL_ARRAY_IDX,
#else		
		.flags		= YIB_POOL_INDEX | YIB_POOL_ARRAY_IDX,
#endif		
		.min_index	= 2, //hw qpn must equal to qpc table index, we have no smi. so it is from 1; sw must assure index1 is gsi
	},
	[YIB_TYPE_CQ] = {
		.name		= "yib-cq",
		.size		= sizeof(struct yib_cq),
#if IB_LAYER_ALLOC_CQ		
		.flags		= YIB_POOL_NO_ALLOC | YIB_POOL_INDEX | YIB_POOL_ARRAY_IDX,
#else
		.flags		= YIB_POOL_INDEX | YIB_POOL_ARRAY_IDX,
#endif
		.cleanup	= yib_pool_cq_cleanup,
		.min_index	= 0,
	},
	[YIB_TYPE_MR] = {
		.name		= "yib-mr",
		.size		= sizeof(struct yib_mr),
		.flags		= YIB_POOL_INDEX | YIB_POOL_ARRAY_IDX,
		.cleanup	= yib_pool_mr_cleanup,
		.min_index	= 0,
	},
	[YIB_TYPE_MC_GRP] = {
		.name		= "yib-mc_grp",
		//.size		= sizeof(struct yib_mc_grp),
		//.cleanup	= yib_mc_cleanup,
		.flags		= 0,
	},
};

static inline const char *pool_name(struct yib_pool *pool)
{
	return yib_type_info[pool->type].name;
}

u32 yib_pool_get_elem_count(struct yib_pool *pool)
{
	return os_atomic_read(&pool->num_elem);
}

static void yib_pool_write_lock(struct yib_pool *pool, unsigned long *flags)
{
	write_lock_irqsave(&pool->pool_lock, *flags);
}

static void yib_pool_write_unlock(struct yib_pool *pool, unsigned long flags)
{
	write_unlock_irqrestore(&pool->pool_lock, flags);
}

static void yib_pool_read_lock(struct yib_pool *pool, unsigned long *flags)
{
	read_lock_irqsave(&pool->pool_lock, *flags);
}

static void yib_pool_read_unlock(struct yib_pool *pool, unsigned long flags)
{
	read_unlock_irqrestore(&pool->pool_lock, flags);
}

static int yib_pool_init_index(struct yib_pool *pool, u32 max, u32 min)
{
	int err = 0;
	size_t size;

	if ((max - min + 1) < pool->max_elem) {
		pr_warn("not enough indices for max_elem\n");
		err = -EINVAL;
		goto out;
	}

	pool->max_index = max;
	pool->min_index = min;
	if (pool->flags & YIB_POOL_ARRAY_IDX) {
		pool->array = vmalloc(sizeof(struct yib_pool_entry*) * pool->max_index);
		if (pool->array == NULL) {
			yib_pr_warn("alloc array for pool failed\n");
			err = -ENOMEM;
			goto out;
		}
		memset(pool->array, 0, sizeof(struct yib_pool_entry*) * pool->max_index);
	}

	size = BITS_TO_LONGS(max - min + 1) * sizeof(long);
	pool->table = kmalloc(size, GFP_KERNEL);
	if (!pool->table) {
		err = -ENOMEM;
		goto out;
	}

	pool->table_size = size;
	bitmap_zero(pool->table, max - min + 1);

out:
	return err;
}

int yib_pool_init(struct yib_pool	*pool,
	enum yib_elem_type	type,
	unsigned int		max_elem,
	unsigned int		max_real_cnt)
{
	int			err = 0;
	size_t			size = yib_type_info[type].size;

	memset(pool, 0, sizeof(*pool));
	if (max_elem == 0)
		return 0;	

	if (max_real_cnt > max_elem) {
		return -EINVAL;
	}

	pool->type		= type;
	pool->max_elem		= max_elem;
	pool->max_real_elem	= max_real_cnt;
	pool->elem_size		= ALIGN(size, YIB_POOL_ALIGN);
	pool->flags		= yib_type_info[type].flags;
	pool->cleanup		= yib_type_info[type].cleanup;
	pool->array = NULL;

	atomic_set(&pool->num_elem, 0);

	kref_init(&pool->ref_cnt);

	rwlock_init(&pool->pool_lock);

	if (yib_type_info[type].flags & YIB_POOL_INDEX) {
		yib_type_info[type].max_index = yib_type_info[type].min_index + max_elem;
		err = yib_pool_init_index(pool,
					  yib_type_info[type].max_index,
					  yib_type_info[type].min_index);
		if (err)
			goto out;
	}

	pool->state = YIB_POOL_STATE_VALID;

out:
	return err;
}

void yib_set_pool_max_cnt(struct yib_pool *pool, unsigned int max_real_cnt)
{
	if (max_real_cnt <= pool->max_real_elem)
		pool->max_real_elem = max_real_cnt;
}

static void yib_pool_release(struct kref *kref)
{
	struct yib_pool *pool = container_of(kref, struct yib_pool, ref_cnt);

	pool->state = YIB_POOL_STATE_INVALID;
	if ((pool->flags & YIB_POOL_ARRAY_IDX) && pool->array) {
		vfree(pool->array);
		pool->array = NULL;
	}

	kfree(pool->table);
}

static void yib_pool_put(struct yib_pool *pool)
{
	kref_put(&pool->ref_cnt, yib_pool_release);
}

void yib_pool_cleanup(struct yib_pool *pool)
{
	unsigned long flags;
	if (pool->state == YIB_POOL_STATE_INVALID)
		return;
	yib_pool_write_lock(pool, &flags);
	pool->state = YIB_POOL_STATE_INVALID;
	if (atomic_read(&pool->num_elem) > 0)
		yib_pr_warn("%s pool destroyed with unfree'd elem\n",
			pool_name(pool));
	yib_pool_write_unlock(pool, flags);

	yib_pool_put(pool);
}

static u32 alloc_index(struct yib_pool *pool)
{
	u32 index;
	u32 range = pool->max_index - pool->min_index + 1;

#if YIB_ALLOC_ID_FROM_LAST
	index = find_next_zero_bit(pool->table, range, pool->last);
	if (index >= range)
		index = find_first_zero_bit(pool->table, range);
#else
		index = find_first_zero_bit(pool->table, range);
#endif

	WARN_ON_ONCE(index >= range);
	set_bit(index, pool->table);
	pool->last = index+1;
	if (pool->last >= range)
		pool->last = 0;
	return index + pool->min_index;
}

static void yib_add_index(struct yib_pool_entry *elem)
{
	struct yib_pool *pool = elem->pool;
	unsigned long flags;

	if (!(pool->flags & YIB_POOL_INDEX))
		return;
	
	yib_pool_write_lock(pool, &flags);
	if (elem->special == false)
		elem->index = alloc_index(pool);
	if (pool->flags & YIB_POOL_ARRAY_IDX) {
		pool->array[elem->index] = elem;
	} 
	yib_pool_write_unlock(pool, flags);
}

static void yib_drop_index(void *arg)
{
	struct yib_pool_entry *elem = arg;
	struct yib_pool *pool = elem->pool;
	unsigned long flags;

	if (!(pool->flags & YIB_POOL_INDEX))
		return;

	yib_pool_write_lock(pool, &flags);
	if (elem->special == 0) {
		clear_bit(elem->index - pool->min_index, pool->table);
	}
	if (pool->flags & YIB_POOL_ARRAY_IDX) {
		pool->array[elem->index] = NULL;
	}
	yib_pool_write_unlock(pool, flags);
}

static void *yib_pool_alloc_internal(struct yib_pool *pool, bool specify)
{
	struct yib_pool_entry *elem;
	unsigned long flags;

	if (pool->flags & YIB_POOL_NO_ALLOC)
		return NULL;

	might_sleep_if(!(pool->flags & YIB_POOL_ATOMIC));

	yib_pool_read_lock(pool, &flags);
	if (pool->state != YIB_POOL_STATE_VALID) {
		yib_pool_read_unlock(pool, flags);
		return NULL;
	}
	kref_get(&pool->ref_cnt);
	yib_pool_read_unlock(pool, flags);

	if (specify == false) {
		if (atomic_inc_return(&pool->num_elem) > pool->max_real_elem)
			goto out_cnt;
	}

	elem = kzalloc(yib_type_info[pool->type].size,
				 (pool->flags & YIB_POOL_ATOMIC) ?
				 GFP_ATOMIC : GFP_KERNEL);
	if (!elem)
		goto out_cnt;

	elem->pool = pool;
	elem->special = (specify == true)?1:0;
	kref_init(&elem->ref_cnt);
	return elem;
out_cnt:
	atomic_dec(&pool->num_elem);

	yib_pool_put(pool);
	return NULL;	
}

//for gsi usage, upper level should 
void *yib_pool_alloc_specify_index(struct yib_pool *pool, int index)
{
	struct yib_pool_entry *elem = NULL;
	int ret = 0;

	if (!(pool->flags & YIB_POOL_INDEX))
		return NULL;
	
	if (index >= pool->min_index) //只能对min index以下的做特殊处理如gsi1, smi0
		return NULL;

	elem = yib_pool_alloc_internal(pool, true);
	if (elem == NULL)
		return NULL;
		
	elem->index = index;

	if (pool->flags & YIB_POOL_ARRAY_IDX) {
		if (pool->array[index] != NULL)
			ret = -EEXIST;
		else
			pool->array[index] = elem;
	} 

	if (ret != 0) {
		yib_pr_warn("specified index exists\n");
		kfree(elem);

		yib_pool_put(pool);
		return NULL;
	}
	return elem;	
}

void *yib_pool_alloc(struct yib_pool *pool)
{
	struct yib_pool_entry *elem = yib_pool_alloc_internal(pool, false);
	if (elem == NULL)
		return NULL;
	yib_add_index(elem);
	return elem;
}

int yib_add_to_pool_special(struct yib_pool *pool, struct yib_pool_entry *elem, bool specify, int sindex)
{
	unsigned long flags;
	if (!(pool->flags & YIB_POOL_NO_ALLOC)) {
		yib_pr_warn("yib pool add flag err\n");
		return -EINVAL;
	}

	memset(elem, 0 , sizeof(struct yib_pool_entry));
	might_sleep_if(!(pool->flags & YIB_POOL_ATOMIC));

	if (specify && (pool->flags & YIB_POOL_ARRAY_IDX)) {
		if (pool->array[sindex] != NULL)
			return -EEXIST;
		else
			pool->array[sindex] = elem;
		elem->index = sindex;
	} 	

	yib_pool_read_lock(pool, &flags);
	if (pool->state != YIB_POOL_STATE_VALID) {
		yib_pool_read_unlock(pool, flags);
		yib_pr_warn("yib pool add state err\n");
		return -EINVAL;
	}
	kref_get(&pool->ref_cnt);
	yib_pool_read_unlock(pool, flags);

	if (specify == false) {
		if (atomic_inc_return(&pool->num_elem) > pool->max_real_elem) {
			yib_pr_warn("yib pool use exceed max=%d\n", pool->max_real_elem);
			goto out_cnt;
		}
	}

	elem->pool = pool;
	elem->special = specify;
	kref_init(&elem->ref_cnt);
	yib_add_index(elem);
	return 0;

out_cnt:
	atomic_dec(&pool->num_elem);

	yib_pool_put(pool);
	return -EINVAL;
}

int yib_add_to_pool(struct yib_pool *pool, struct yib_pool_entry *elem)
{
	return yib_add_to_pool_special(pool, elem, false, 0);
}

void yib_pool_elem_release(struct kref *kref)
{
	struct yib_pool_entry *elem =
		container_of(kref, struct yib_pool_entry, ref_cnt);
	struct yib_pool *pool = elem->pool;

	if (pool->cleanup)
		pool->cleanup(elem);

	yib_drop_index(elem);

	if (elem->special == false)
		atomic_dec(&pool->num_elem);

	if (!(pool->flags & YIB_POOL_NO_ALLOC))
		kfree(elem);

	yib_pool_put(pool);
}

bool yib_pool_check_index(struct yib_pool *pool, u32 index, bool special)
{
	bool ret = false;
	unsigned long flags;

	if (!(pool->flags & YIB_POOL_INDEX))
		return false;

	if (special)
		return true; //特殊的认为已经存�?

	yib_pool_write_lock(pool, &flags);
	if (test_bit(index, pool->table))
		ret = true;
	yib_pool_write_unlock(pool, flags);
	return ret;
}

void *yib_pool_get_by_index(struct yib_pool *pool, u32 index, bool ref_inc)
{
	struct yib_pool_entry *elem = NULL;
	unsigned long flags;

	if (!(pool->flags & YIB_POOL_ARRAY_IDX))
		return NULL;
	if (!(pool->flags & YIB_POOL_INDEX))
		return NULL;

	yib_pool_read_lock(pool, &flags);

	if (pool->state != YIB_POOL_STATE_VALID)
		goto out;

	if (pool->flags & YIB_POOL_ARRAY_IDX) {
		if (index < 0 || index >= pool->max_index)
			goto out;
		elem  = pool->array[index];
		if (elem && ref_inc)
			kref_get(&elem->ref_cnt);
		yib_pool_read_unlock(pool, flags);
		return elem;
	}

out:
	yib_pool_read_unlock(pool, flags);
	return NULL;
}
