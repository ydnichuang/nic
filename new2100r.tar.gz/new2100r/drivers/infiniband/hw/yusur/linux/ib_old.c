#if IB_LAYER_ALLOC_AH == 0
static struct ib_ah *yib_create_ah(struct ib_pd *ibpd,
				struct rdma_ah_attr *attr,
				   struct ib_udata *udata)
{
	int err;
	struct ib_device *ibdev = ibpd->device;
	struct yib_ib_create_ah_resp *uresp = NULL;
	struct yib_ib_create_ah_resp ah_resp;
	struct yusur_ib_dev *yib = to_yib(ibdev);
	struct yib_ah *ah =  NULL;

	err = yib_av_chk_attr(yib, attr);
	if (err)
		return ERR_PTR(-err);

	ah = yib_pool_alloc(&yib->host.verbs.ah_pool);
	if (ah == NULL) {
		os_printw(yib->dev, "ah add to pool failed\n");
		return ERR_PTR(-ENOMEM);
	}

	if (udata) {
		if (udata->outlen >= sizeof(*uresp))
			uresp = udata->outbuf;
		ah->is_user = true;
	} else {
		ah->is_user = false;
	}
	ah->ah_num = ah->entry.index;

	if (uresp) {
		/* only if new user provider */
		ah_resp.ah_num = ah->ah_num;
		ah_resp.vlan_id = ah->av.vlan_id;
		ah_resp.vlan_pcp = ah->av.vlan_pcp;
		ah_resp.smac_idx = ah->av.smac_idx;
		memcpy(ah_resp.smac, ah->av.smac, ETH_ALEN);

		err = copy_to_user(uresp, &ah_resp, sizeof(struct yib_ib_create_ah_resp));
		if (err) {
			yib_elem_drop_ref(&ah->entry);
			os_printw(yib->dev, "ah copy to user failed\n");
			return ERR_PTR(-EFAULT);
		}
	} else if (ah->is_user) {
		/* only if old user provider */
		ah->ah_num = 0;
	}
	yib_dbg_info(YUSUR_IB_M_AH, YUSUR_IB_DBG_CREATE, "AH:%d u:%d\n", ah->ah_num, ah->is_user);
	yib_init_av(yib, attr, &ah->av);
	return &ah->ib_ah;
}
#endif

#if IB_LAYER_ALLOC_PD == 0
static struct ib_pd *yib_alloc_pd(struct ib_device *ibdev,
				  struct ib_ucontext *context,
				  struct ib_udata *udata)
{
	struct yusur_ib_dev *yib = to_yib(ibdev);
	struct yib_pd *pd = NULL;
	int ret;

	pd  = yib_pool_alloc(&yib->host.verbs.pd_pool);
	if (pd == NULL)
		return ERR_PTR(-ENOMEM);

	if (udata && context) {
		struct yib_ib_alloc_pd_resp uresp;

		uresp.pdn = pd->entry.index;
		ret = ib_copy_to_udata(udata, &uresp, sizeof(uresp));
		if (ret) {
			os_printw(&ibdev->dev, "user data for pd is two small\n");
			yib_elem_drop_ref(&pd->entry);
			return ERR_PTR(-EINVAL);
		}
	}

	yib_dbg_info(YUSUR_IB_M_CORE_VERBS,YUSUR_IB_DBG_CREATE, "pd:%d alloc\n", pd->entry.index);
	return &pd->ib_pd;
}


#endif

#if IB_LAYER_ALLOC_UD == 0
static struct ib_ucontext *yib_alloc_ucontext(struct ib_device *dev, struct ib_udata *udata)
{
	struct ib_device *ib_dev = dev;
        struct ib_ucontext *ibucontext = NULL;
	struct yusur_ib_dev *yib = to_yib(ib_dev);
	int uresp_len = 0;
	char uresp[128];

	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_CREATE, "ucontext alloc\n");
        ibucontext = os_zalloc(sizeof(struct ib_ucontext));
	if (udata) {
		yib->host.hw_ops.get_queue_user_info(&yib->host, YIB_TYPE_PD, NULL, 0, uresp, &uresp_len);
		ib_copy_to_udata(udata, uresp, (uresp_len > sizeof(uresp))? sizeof(uresp): uresp_len);

	}
	return ibucontext? ibucontext:ERR_PTR(-ENOMEM);
}

static int yib_dealloc_ucontext(struct ib_ucontext *ibucontext)
{
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_DESTROY, "ucontext dealloc\n");
        if (ibucontext)
                os_free(ibucontext); 
        return 0;       
}  
#endif

#if IB_LAYER_ALLOC_CQ == 0
static struct ib_cq *yib_create_cq(struct ib_device *dev,
				   const struct ib_cq_init_attr *attr,
				   struct ib_ucontext *context,
				   struct ib_udata *udata)
{
	struct yusur_ib_dev *yib = to_yib(dev);
	struct yib_cq *ycq = NULL;
	u32 cqe_size, cqe;
	u8 ures[128];
	struct ib_umem *umem = NULL;
	bool nvme_off = false;
	int ures_len = 0;
	int ret;
	if (udata) {
		if (udata->outlen < sizeof(struct yib_ib_create_cq_resp)) {
			os_printw(&dev->dev, "cq udata is not enough\n");
			return ERR_PTR(-EINVAL);
		}
	}	

	cqe = attr->cqe;
	if (cqe > yib->host.caps.max_cqes)
	{
		os_printw(&dev->dev, "Failed to create CQ -max exceeded\n");
		return ERR_PTR(-EINVAL);
	}
	if (attr->comp_vector > (yib->host.caps.num_comp_vector - 1)) {
		os_printw(&dev->dev, "Failed to create CQ - comp vector execeeded\n");
		return ERR_PTR(-EINVAL);
	}
	
	cqe_size = yib_cq_align_size(yib, &cqe);

	if (cqe > yib->host.caps.max_cqes) {
		os_printw(&dev->dev, "Failed to create CQ -max exceeded aligned\n");
		return ERR_PTR(-EINVAL);
	}
	
	if (udata) {
		struct yib_ib_create_cq ureq;
		if (ib_copy_from_udata((void *)&ureq, udata, sizeof(ureq))) {
			os_printw(&dev->dev, "cq create failed for copy from udata\n");
			return ERR_PTR(-ENOMEM);	
		}
		nvme_off = ureq.nvme_off?true:false;
		os_printw(&dev->dev, "=====[%s][%d]=====\n",__func__, cqe_size);
		umem = yib_umem_get_mem(&yib->ib_dev, context, udata, ureq.cq_va, cqe_size, IB_ACCESS_REMOTE_READ | IB_ACCESS_LOCAL_WRITE);
		if (IS_ERR(umem)) {
			os_printw(&dev->dev,
				  "failed to get ib umem for cq dma mem, error: %ld, bytes:%d\n",
				   PTR_ERR(umem), cqe_size);
			return ERR_PTR(-ENOMEM);
		}   
	} 

	ycq = yib_cq_alloc_new(yib, cqe, umem, attr->comp_vector);
	if (ycq == NULL) {
		return ERR_PTR(-ENOMEM);
	}

	ycq->nvme_off = nvme_off;
	ret = yib->host.sf.sf_ops->cq_info_init(&yib->host.sf, ycq, true);
	if (ret) {
		os_printw(&dev->dev, "Failed to init CQ info\n");
		goto end;
	}
	if (ycq->is_user) {
		yib->host.hw_ops.get_queue_user_info(&yib->host, YIB_TYPE_CQ, ycq, yib_get_cq_sw_idx(ycq), ures, &ures_len);
		ret = ib_copy_to_udata(udata, ures, ures_len > sizeof(ures)? sizeof(ures): ures_len);
		if (ret != 0) {
			os_printw(&dev->dev, "cq create failed for copy to udata\n");
			goto end;
		}
	}
	yib_dbg_info(YUSUR_IB_M_CQ, YUSUR_IB_DBG_CREATE, "cq create id:%d u:%d nvme=%d inputcqe=%d cqe=%d\n",
		yib_get_cq_sw_idx(ycq), ycq->is_user, ycq->nvme_off?1:0, attr->cqe, cqe);
	return &ycq->ib_cq;

end:	
	yib_elem_drop_ref(&ycq->entry);
	return ERR_PTR(-ENOMEM);
}
#endif

#if IB_LAYER_ALLOC_QP	
int yib_create_qp(struct ib_qp *ibqp, struct ib_qp_init_attr *init,
			 struct ib_udata *udata)
{
	struct ib_device *ib_dev = ibqp->device;
	struct yusur_ib_dev *yib = to_yib(ib_dev);
	struct yib_pd *ypd = to_yib_pd(ibqp->pd);
	struct yib_qp *yqp  = to_yib_qp(ibqp);
	struct yib_xrcd *yxrcd = NULL;
	struct yib_ib_create_qp ureq;
	struct ib_umem *umem_sq = NULL;
	struct ib_umem *umem_rq = NULL;
	int u_sq_len = 0, u_rq_len = 0;
	int uresp_len;
	u8 uresp[128];
	int ret;

	yqp->nvme_off = false;
	yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_CREATE, "create qp begin type=%d swr=%d rwr=%d", 
			init->qp_type, init->cap.max_send_wr, init->cap.max_recv_wr);

	ret = yib_create_qp_chk(ib_dev, init, udata, &u_sq_len, &u_rq_len);
	if (ret) {
		return ret;
	}

	yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_CREATE, "create qp afterchk type=%d swr=%d rwr=%d", 
			init->qp_type, init->cap.max_send_wr, init->cap.max_recv_wr);

	if (udata) {
		if (ib_copy_from_udata((void *)&ureq, udata, sizeof(ureq)))
			return -ENOMEM;

		umem_sq = yib_umem_get_mem(&yib->ib_dev, ibqp->pd->uobject->context, udata, ureq.sq_va, u_sq_len, IB_ACCESS_REMOTE_READ | IB_ACCESS_LOCAL_WRITE);
		if (IS_ERR(umem_sq)) {
			os_printw(&ibqp->device->dev,
				  "failed to get ib umem for sq dma mem, error: %ld, bytes:%d\n",
				   PTR_ERR(umem_sq), u_sq_len);
			return -ENOMEM;
		}

		if (init->srq == NULL) {
			umem_rq = yib_umem_get_mem(&yib->ib_dev, ibqp->pd->uobject->context, udata, ureq.rq_va, u_rq_len, IB_ACCESS_REMOTE_READ | IB_ACCESS_LOCAL_WRITE);
			if (IS_ERR(umem_rq)) {
				os_printw(&ibqp->device->dev,
					"failed to get ib umem for rq dma mem, error: %ld, bytes:%d\n",
					PTR_ERR(umem_rq), u_rq_len);
				os_umem_release(umem_sq);
				return -ENOMEM;
			}
		}
	}

	yxrcd = (yqp->qp_type == IB_QPT_XRC_TGT)? (to_yib_xrcd(init->xrcd)) : NULL;
	ret = yib_qp_alloc(yib, yqp, ypd, init->qp_type, &init->cap, yxrcd);
	if (ret) {
		os_umem_release(umem_rq);
		os_umem_release(umem_sq);
		return ret;
	}

	ret = yib_qp_attach(yib, yqp, umem_sq, umem_rq);
	if (ret != 0) {
		os_printw(&ibqp->device->dev, "qp: %d attach user:%d failed\n", yib_get_qp_sw_idx(yqp), yqp->is_user);
		goto fail;
	}

	if (udata) {
		yqp->nvme_off = ureq.nvme_off?true:false;
		yqp->u_qp_handler = ureq.u_qp_handler;
		if (init->srq == NULL && ureq.u_rq_handler != 0)
			yqp->type.yrq->u_rq_handler = ureq.u_rq_handler;
	} else
		yqp->nvme_off = false;

	yqp->sq_sig_type   = init->sq_sig_type;
	if (!rdma_is_port_valid(ib_dev, init->port_num))
		yqp->attr.port_num  = 1;
	else
		yqp->attr.port_num  = init->port_num;
	
	yqp->attr.path_mtu = yib->host.ndev_info[yqp->attr.port_num - 1].cur_max_mtu;
	ret = yib_qp_attach_cq(yib, yqp, init->srq?to_yib_srq(init->srq):NULL, 
		init->send_cq? to_yib_cq(init->send_cq):NULL, init->recv_cq? to_yib_cq(init->recv_cq):NULL);
	if (ret != 0) {
		os_printw(&yib->ib_dev.dev, "qp: %d attach cq failed\n", yib_get_qp_sw_idx(yqp));
		goto fail;
	}

	if (yqp->is_user) {
		yib->host.hw_ops.get_queue_user_info(&yib->host, YIB_TYPE_QP, yqp, yib_get_qp_sw_idx(yqp), uresp, &uresp_len);
		ret = ib_copy_to_udata(udata, uresp, (uresp_len > sizeof(uresp))? sizeof(uresp): uresp_len);
		if (ret != 0)
			goto fail;
	}
	yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_CREATE, "create ok qp: %d sqe=%d rqe=%d nvme=%d\n",
		yib_get_qp_sw_idx(yqp), yqp->cap.max_send_wr, yqp->use_srq? 0:yqp->cap.max_recv_sge, yqp->nvme_off?1:0);
	return 0;
fail:
	yib_dbg_err("create failed qp: %d\n", yib_get_qp_sw_idx(yqp));
	yib_elem_drop_ref(&yqp->entry);
	return ret;
}
#endif

#if IB_DESTROY_NO_UDATA  
static int yib_destroy_ah(struct ib_ah *ibah)
{
	struct yib_ah *ah = to_yib_ah(ibah);

	yib_elem_drop_ref(&ah->entry);
	return 0;
}

static int yib_dealloc_pd(struct ib_pd *ibpd)
{
	struct yib_pd *pd = to_yib_pd(ibpd);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS,YUSUR_IB_DBG_DESTROY, "pd:%d dealloc\n", pd->entry.index);
	yib_elem_drop_ref(&pd->entry);
	return 0;
}



static int yib_destroy_qp(struct ib_qp *ibqp)
{
	struct yib_qp *yqp = to_yib_qp(ibqp);
	yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_DESTROY, "qp: %d destroy is_user:%d\n", yib_get_qp_sw_idx(yqp), yqp->is_user);
	yqp->valid = false;
	yib_elem_drop_ref(&yqp->entry);
	return 0;
}

static int yib_dereg_mr(struct ib_mr *ibmr)
{
	struct yib_mr *mr = to_yib_mr(ibmr);
	struct yib_pd *ypd = mr_ypd(mr);

	yib_dbg_info(YUSUR_IB_M_MR, YUSUR_IB_DBG_DESTROY, "mr dereg:%d\n", yib_get_mr_sw_idx(mr));
	yib_mr_dealloc(mr, ypd);
	return 0;
}

static int yib_destroy_cq(struct ib_cq *ibcq)
{
	struct yib_cq *ycq = to_yib_cq(ibcq);
	yib_dbg_info(YUSUR_IB_M_CQ, YUSUR_IB_DBG_DESTROY, "cq destroy:%d\n", yib_get_cq_sw_idx(ycq));
	yib_elem_drop_ref(&ycq->entry);
	return 0;
}

static int yib_destroy_srq(struct ib_srq *ibsrq)
{
	struct yib_srq *ysrq = to_yib_srq(ibsrq);
	struct yib_pd *ypd = to_yib_pd(ibsrq->pd);

	yib_elem_drop_ref(&ysrq->yrq->entry);
	if (ypd)
		yib_elem_drop_ref(&ypd->entry);
	return 0;
}
#endif

#if IB_LAYER_ALLOC_SRQ == 0
static struct ib_srq *yib_create_srq(struct ib_pd *ibpd, struct ib_srq_init_attr *init,
			  struct ib_udata *udata)
{
	struct yusur_ib_dev *yib = to_yib(ibpd->device);
	struct yib_srq *ysrq = NULL;
	struct yib_pd *ypd = to_yib_pd(ibpd);
	struct yib_xrcd *yxrcd = NULL;
	struct ib_umem *umem_srq = NULL;
	int u_srq_len = 0;
	u8 ures[128];
	int ures_len = 0;
	int ret = 0;
	if (udata) {
		if (udata->outlen < 16) {
			os_printw(&ibpd->device->dev, "create srq udata is not enough\n");
			return ERR_PTR(-EINVAL);
		}
	}

	ysrq = os_zalloc(sizeof(*ysrq));
	if (ysrq == NULL) {
		return ERR_PTR(-ENOMEM);
	}

	yib_dbg_info(YUSUR_IB_M_RQ, YUSUR_IB_DBG_CREATE, "create srq begin  wr=%d sge=%d", 
			 init->attr.max_wr, init->attr.max_sge);
	ret = yib_srq_chk_attr(yib, ysrq, init, IB_SRQ_INIT_MASK, &u_srq_len);
	if (ret != 0) {
		os_free(ysrq);
		return ERR_PTR(-EINVAL);
	}
	yib_dbg_info(YUSUR_IB_M_RQ, YUSUR_IB_DBG_CREATE, "create srq afterchk  wr=%d sge=%d", 
			 init->attr.max_wr, init->attr.max_sge);

	yxrcd = (init->srq_type == IB_SRQT_XRC)? (to_yib_xrcd(init->ext.xrc.xrcd)) : NULL;
	ysrq->ib_srq.event_handler = init->event_handler;

	if (udata) {
		struct yib_ib_create_srq ureq;	
		if (ib_copy_from_udata((void *)&ureq, udata, sizeof(ureq))) {
			os_printw(&ibpd->device->dev, "sirq create failed for copy from udata");
			os_free(ysrq);
			return ERR_PTR(-ENOMEM);
		}

		umem_srq = yib_umem_get_mem(&yib->ib_dev, ibpd->uobject->context, udata, ureq.srq_va, u_srq_len, IB_ACCESS_REMOTE_READ | IB_ACCESS_LOCAL_WRITE);
		if (IS_ERR(umem_srq)) {
			os_printw(&ibpd->device->dev,
				  "failed to get ib umem for srq dma mem, error: %ld, bytes:%d\n",
				   PTR_ERR(umem_srq), u_srq_len);
			return ERR_PTR(-ENOMEM);
		}

		ret  = yib_srq_init_buf(yib, ysrq, &init->attr, yxrcd, umem_srq,
				 init->ext.cq? to_yib_cq(init->ext.cq):NULL);
		if (ret) {
			os_printw(&ibpd->device->dev, "sirq create failed init user buf\n");
			os_umem_release(umem_srq);
			os_free(ysrq);
			return ERR_PTR(-ENOMEM);
		}
		yib->host.hw_ops.get_queue_user_info(&yib->host, YIB_TYPE_RQ, ysrq, yib_get_rq_sw_idx(ysrq->yrq), ures, &ures_len);
		ret = ib_copy_to_udata(udata, ures, ures_len > sizeof(ures)? sizeof(ures): ures_len);	
		if (ret != 0) {
			os_printw(&ibpd->device->dev, "srq create failed for copy to udata\n");
			goto end;
		}
	} else {
		ret = yib_srq_init_buf(yib, ysrq, &init->attr, yxrcd, NULL,
				init->ext.cq? to_yib_cq(init->ext.cq):NULL);
		if (ret) {
			os_printw(&ibpd->device->dev, "srq create failed init kernel buf\n");
			os_free(ysrq);
			return ERR_PTR(-ENOMEM);
		}
	}

	yib_elem_add_ref(&ypd->entry);
	return &ysrq->ib_srq;
end:
	yib_elem_drop_ref(&ysrq->yrq->entry);
	return ERR_PTR(-ENOMEM);
}
extern int yib_modify_srq(struct ib_srq *ibsrq, struct ib_srq_attr *attr,
		       enum ib_srq_attr_mask attr_mask, struct ib_udata *udata);
#if(0)

int yib_modify_srq(struct ib_srq *ibsrq, struct ib_srq_attr *attr,
		       enum ib_srq_attr_mask attr_mask, struct ib_udata *udata)
{
	struct yusur_ib_dev *yib = to_yib(ibsrq->device);
	struct yib_srq *ysrq = to_yib_srq(ibsrq);
	struct yib_ib_modify_srq ureq;

	/* don't support resizing SRQs */
	if (attr_mask & IB_SRQ_MAX_WR)
		return -EINVAL;

	ureq.generate = 0;
	if (udata) {
		if (ib_copy_from_udata((void *)&ureq, udata, sizeof(ureq))) {
			os_printw(&ibsrq->device->dev, "cq resize failed for copy from udata\n");
			return -ENOMEM;
		}
	}

	if (ureq.generate == 0) {
		if (attr_mask & IB_SRQ_LIMIT) {
			ysrq->limit = attr->srq_limit;
		}
	} else {
		yib_run_srq_limit_evts(yib, ysrq);
	}
	return 0;
}
#endif

#endif

#if IB_LAYER_ALLOC_XRCD == 0
static struct ib_xrcd *yib_alloc_xrcd(struct ib_device *ibdev, struct ib_ucontext *ucontext, struct ib_udata *udata)
{
#if 0
	struct yusur_ib_dev *yib = to_yib(ibdev);
	struct yib_xrcd *yxrcd = NULL;

	yxrcd = os_zalloc(sizeof(*yxrcd));
	if (yxrcd == NULL) {
		return ERR_PTR(-ENOMEM);
	}
	//newtodo get xrcd_val
	yib_bmap_alloc_id(&yib->verbs.xrcd_map, &yxrcd->xrcd_val);

	return &yxrcd->ib_xrcd;
#else
	return NULL;
#endif
}

static int yib_dealloc_xrcd(struct ib_xrcd *ibxrcd)
{
#if 0
	struct yusur_ib_dev *yib = to_yib(ibxrcd->device);
	struct yib_xrcd *yxrcd = to_yib_xrcd(ibxrcd);
	yib_bmap_release_id(&yib->verbs.xrcd_map, yxrcd->xrcd_val);
	os_free(yxrcd);
	return 0;
#else
	return 0;
#endif
}
#endif

#if IB_LAYER_ALLOC_MW == 0
static struct ib_mw *yib_alloc_mw(struct ib_pd *pd, enum ib_mw_type type,
			       struct ib_udata *udata)
{
	struct yusur_ib_dev *yib = to_yib(pd->device);
	struct yib_pd *ypd = to_yib_pd(pd);
	struct yib_mw *ymw = NULL;
	struct yib_mr *ymr = NULL;
	bool buser = (udata)? true : false;

	if (type != IB_MW_TYPE_1) {
		os_printw(&pd->device->dev, "mw type is not support\n");
		return ERR_PTR(-ENOMEM);
	}

	ymw = kzalloc(sizeof(struct yib_mw), GFP_KERNEL);
	if (ymw == NULL) {
		os_printw(&pd->device->dev, "mw alloc failed\n");
		return ERR_PTR(-ENOMEM);
	}
	ymw->ib_mw.pd = pd;

	ymr = yib_mw_alloc_new(yib, ymw, ypd, buser);
	if (ymr == NULL) {
		kfree(ymw);
		os_printw(&pd->device->dev, "yib_mw_alloc_new failed\n");
		return ERR_PTR(-ENOMEM);
	}

	ymr->state = YIB_MR_FREE;
	yib->host.sf.sf_ops->mr_mpt_update(&yib->host.sf, ymr);
	return &ymw->ib_mw;
}
#endif

#if IBDEV_NO_OPS 
void yib_init_ib_ops(struct ib_device *dev)
{
#ifdef IB_DEV_HAS_DRIVERID
        dev->driver_id = RDMA_DRIVER_ID_YUSUR;
#endif
        dev->owner = THIS_MODULE;
        strlcpy(dev->node_desc, "yusur", sizeof(dev->node_desc));
#ifdef IB_SGID_ATTR_NOTHAS_SGID
	dev->query_gid = yib_query_gid;
	dev->add_gid = yib_add_gid;
	dev->del_gid = yib_del_gid;
#endif
	dev->query_device = yib_query_device;
	dev->query_port = yib_query_port;
	dev->get_link_layer = yib_get_link_layer;
	dev->get_netdev = yib_get_netdev;
	dev->query_pkey = yib_query_pkey;
	dev->alloc_ucontext = yib_alloc_ucontext;
	dev->dealloc_ucontext = yib_dealloc_ucontext;
	dev->mmap = yib_mmap;
	dev->get_port_immutable = yib_port_immutable;
	dev->alloc_pd = yib_alloc_pd;
	dev->dealloc_pd = yib_dealloc_pd;
	dev->create_ah = yib_create_ah;
	dev->modify_ah = yib_modify_ah;
	dev->query_ah = yib_query_ah;
	dev->destroy_ah = yib_destroy_ah;
	dev->create_srq = yib_create_srq; //todo late
	dev->modify_srq = yib_modify_srq;
	dev->query_srq = yib_query_srq;
	dev->destroy_srq = yib_destroy_srq;
	dev->post_srq_recv = yib_post_srq_recv;
	dev->create_qp = yib_create_qp;
	dev->modify_qp = yib_modify_qp;
	dev->query_qp = yib_query_qp;
	dev->destroy_qp = yib_destroy_qp;
	dev->post_send = yib_post_send;
	dev->post_recv = yib_post_recv;
	dev->create_cq = yib_create_cq;
	dev->destroy_cq = yib_destroy_cq;
	dev->resize_cq = yib_resize_cq;
	dev->poll_cq = yib_poll_cq;
	dev->req_notify_cq = yib_notify_cq;
	dev->get_dma_mr = yib_get_dma_mr;
	dev->reg_user_mr = yib_reg_user_mr;
	dev->dereg_mr = yib_dereg_mr;
	dev->alloc_mr = yib_alloc_mr;
	dev->map_mr_sg = yib_map_mr_sg;
	dev->alloc_xrcd = yib_alloc_xrcd,
	dev->dealloc_xrcd = yib_dealloc_xrcd,
	dev->alloc_mw = yib_alloc_mw,
	dev->dealloc_mw = yib_dealloc_mw,
    dev->get_dev_fw_str = yib_get_dev_fw_str;
	dev->get_hw_stats = yib_ib_get_hw_stats;
	dev->alloc_hw_stats = yib_ib_alloc_hw_stats;
}
#endif
