#include <linux/init.h>
#include <linux/module.h>
#include <linux/mod_devicetable.h>

#include "../include/basic.h"
#include <linux/yusur/yrdma_model.h>
#include "../include/os_api.h"
#include "../include/os_ds.h"
#include "../include/mem.h"
#include "../include/queue.h"
#include "../include/host.h"
#include "../include/verbs.h"
#include "../include/yusur_ib.h"
#include "../include/core.h"
#include "priv.h"
#include "ib.h"

#if(0)
#include <rdma/ib_user_verbs.h>
#include <rdma/ib_verbs.h>
#include <rdma/uverbs_types.h>
#include <rdma/uverbs_ioctl.h>
#include <rdma/mlx5_user_ioctl_cmds.h>
#include <rdma/mlx5_user_ioctl_verbs.h>
#define UVERBS_MODULE_NAME yusur_ib
#include <rdma/uverbs_named_ioctl.h>

typedef struct 
{
        u8 mem_type; //0:mem 1:reg 2:ddr
        u8 dir;  //0:read 1:write
        u64 mem_addr; //mem is absolute value, reg is offset, ddr is offset
        u32 value;
}yib_debug_cmd;

typedef struct 
{
        u32 qpid;
        u8 bio; //io or admin for nvme
}yib_nvme_cmd;

struct yib_ext_in_cmd_hdr {
	u8         opcode; //1:debug  2:nvmne 3:todo
        union {
		yib_debug_cmd dbg_cmd;
		yib_nvme_cmd nvme_cmd;
	};
};

struct yib_ext_out_cmd_hdr {
	u32         status;
};

enum yusur_ib_objects {
	YIB_IB_OBJECT_EXT_OBJ = (1U << UVERBS_ID_NS_SHIFT),
};

enum yusur_ib_ext_methods {
	YIB_IB_METHOD_EXT_CMD = (1U << UVERBS_ID_NS_SHIFT),    
};

enum  yib_ib_ext_cmd_attrs {
	YIB_IB_ATTR_EXT_CMD_IN = (1U << UVERBS_ID_NS_SHIFT),
	YIB_IB_ATTR_EXT_CMD_OUT,
};

static int UVERBS_HANDLER(YIB_IB_METHOD_EXT_CMD)(
	struct uverbs_attr_bundle *attrs)
{
        struct ib_ucontext *uctx = ib_uverbs_get_ucontext(attrs);
        struct yusur_ib_dev *yib = NULL;
	struct yib_ext_in_cmd_hdr *cmd_in = uverbs_attr_get_alloced_ptr(attrs, YIB_IB_ATTR_EXT_CMD_IN);
	int cmd_out_len = uverbs_attr_get_len(attrs, YIB_IB_ATTR_EXT_CMD_OUT);
	struct yib_ext_out_cmd_hdr *cmd_out;

	if (IS_ERR(uctx))
		return PTR_ERR(uctx);

	cmd_out = uverbs_zalloc(attrs, cmd_out_len);
	if (IS_ERR(cmd_out))
		return PTR_ERR(cmd_out);

	yib = to_yib(uctx->device);

        switch (cmd_in->opcode) {
                case 0:
                        printk("%p %02X %02X %llX %x\n", yib,
                                cmd_in->dbg_cmd.mem_type, cmd_in->dbg_cmd.dir,
                                cmd_in->dbg_cmd.mem_addr, cmd_in->dbg_cmd.value);
                        cmd_out->status = 0;
                        break;
                default:
                        return -EINVAL;
        }

	return uverbs_copy_to(attrs, YIB_IB_ATTR_EXT_CMD_OUT, cmd_out, cmd_out_len);
}

DECLARE_UVERBS_NAMED_METHOD(
	YIB_IB_METHOD_EXT_CMD,
	UVERBS_ATTR_PTR_IN(
		YIB_IB_ATTR_EXT_CMD_IN,
		UVERBS_ATTR_MIN_SIZE(sizeof(struct yib_ext_in_cmd_hdr)),
		UA_MANDATORY,
		UA_ALLOC_AND_COPY),
	UVERBS_ATTR_PTR_OUT(
		YIB_IB_ATTR_EXT_CMD_OUT,
		UVERBS_ATTR_MIN_SIZE(sizeof(struct yib_ext_out_cmd_hdr)),
		UA_MANDATORY));

DECLARE_UVERBS_GLOBAL_METHODS(YIB_IB_OBJECT_EXT_OBJ,
			      &UVERBS_METHOD(YIB_IB_METHOD_EXT_CMD));


static bool ext_is_supported(struct ib_device *device)
{
        return true;
}

const struct uapi_definition  yusur_ib_ext_defs[] = {
	UAPI_DEF_CHAIN_OBJ_TREE_NAMED(
		YIB_IB_OBJECT_EXT_OBJ,
		UAPI_DEF_IS_OBJ_SUPPORTED(ext_is_supported)),
	{},
};

static const struct uapi_definition yusur_ib_defs[] = {
	UAPI_DEF_CHAIN(yusur_ib_ext_defs),
        {}
};

void register_yib_ioctl(struct yusur_ib_dev *yib)
{
        if (IS_ENABLED(CONFIG_INFINIBAND_USER_ACCESS))
		yib->ib_dev.driver_def = yusur_ib_defs;
}

#else

void register_yib_ioctl(struct yusur_ib_dev *yib)
{

}

#endif
