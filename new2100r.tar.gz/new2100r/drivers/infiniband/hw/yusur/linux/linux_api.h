#ifndef _YUSUR_IB_LINUX_H_
#define _YUSUR_IB_LINUX_H_

typedef enum dma_data_direction os_dma_dir;
typedef dma_addr_t		os_dma_addr_t;
typedef atomic_t		os_atomic;
typedef atomic64_t		os_atomic64;
typedef struct mutex	os_mutex_t;
typedef rwlock_t		os_rwlock;
typedef spinlock_t		os_spinlock;


typedef struct ib_mr		os_ib_mr;
typedef struct ib_mw		os_ib_mw;
typedef	struct ib_pd		os_ib_pd;
typedef	struct ib_ah		os_ib_ah;
typedef	struct ib_cq		os_ib_cq;
typedef struct ib_srq		os_ib_srq;
typedef struct ib_qp		os_ib_qp;
typedef struct ib_xrcd		os_ib_xrcd;
typedef struct ib_ucontext	os_ib_ucontext;
typedef struct ib_umem		os_ib_umem;

typedef struct rb_root		os_rb_root;
typedef struct kref			os_ref;
typedef struct list_head	os_list_head;

#define os_smp_wmb()               smp_wmb()

#define os_umem_release(m)      ib_umem_release(m)

typedef struct tasklet_struct	os_task;
struct yib_hw_events {
	void			(*func)(void *arg);
	void			*arg;
	os_task			tasklet;
	char			name[16];
	struct list_head      list;
	struct list_head      process_list;
	struct tasklet_struct task;
	spinlock_t            lock; /* lock completion tasklet list */	
	bool			destroyed;
};

int yib_hw_events_init(struct yib_hw_events * evts, void (*func)(void *), char *name);
void yib_hw_events_cleanup(struct yib_hw_events * evts);
void yib_hw_events_run(struct yib_hw_events * evts);
bool yib_hw_event_add(struct yib_hw_events * evts, os_list_head *node);
struct os_thread_t *os_thread_run(int (*func)(void *), void* data, char* name, int task_id);
void os_thread_stop(struct os_thread_t *thread);

#define os_spin_lock_init(l)	spin_lock_init(l)
#define os_spin_lock_bh(l)		spin_lock_bh(l)
#define os_spin_unlock_bh(l)	spin_unlock_bh(l)
#define os_spin_lock(l)			spin_lock(l)
#define os_spin_unlock(l)		spin_unlock(l)
#define os_spin_lock_irqsave(l, flags)	spin_lock_irqsave(l, flags)
#define os_spin_unlock_restore(l,flags)	spin_unlock_irqrestore(l, flags)
#define os_mutex_lock(l)	mutex_lock(l)
#define os_mutex_unlock(l)	mutex_unlock(l)
#define os_mutex_init(l)	mutex_init(l)
#define os_mutex_destroy(l)	mutex_destroy(l)
#define os_rwlock_init(l)						rwlock_init(l)
#define os_read_lock_irqsave(l, flags)			read_lock_irqsave(l, flags)
#define os_read_unlock_irqrestore(l, flags)		read_unlock_irqrestore(l, flags)
#define os_write_lock_irqsave(l, flags)			write_lock_irqsave(l, flags)
#define os_write_unlock_irqrestore(l, flags)	write_unlock_irqrestore(l, flags)

#define os_atomic_set(x, y)	atomic_set(x, y)
#define os_atomic_add(x, y)	atomic_add(y, x)
#define os_atomic_sub(x, y)	atomic_sub(y, x)
#define os_atomic_read(x)	atomic_read(x)

#define os_atomic64_set(x, y)	atomic64_set(x, y)
#define os_atomic64_add(x, y)	atomic64_add(y, x)
#define os_atomic64_sub(x, y)	atomic64_sub(y, x)
#define os_atomic64_read(x)	atomic64_read(x)


#define os_dma_addr_to_u64(x)	(x)

#define os_ref_get(x) kref_get(x)
/* drop a reference on an object */
#define os_ref_put(x, y) kref_put(x, y)

#define os_printw(dev, fmt, ...) dev_warn(dev, fmt, ##__VA_ARGS__)
#define os_printe(dev, fmt, ...) dev_err(dev, fmt, ##__VA_ARGS__)
#define os_msleep(n)	msleep(n)
#define os_udelay(n)	udelay(n)

#define os_llist_init(x)				init_llist_head(x)
#define os_list_init(x)					INIT_LIST_HEAD(x)
#define os_list_add_tail(node, list)	list_add_tail(node, list)
#define os_list_del(node)				list_del(node)

void os_rdma_gid2ip(struct sockaddr *out, const union ib_gid *gid);

static inline u32 yib_read32(void __iomem *base, off_t offset)
{
	u32 val;
	val = readl(base + offset);
	return val;
}
static inline void yib_write32(void __iomem *base, off_t offset, u32 val)
{
	writel(val, base + offset);
}

static inline u64 yib_read64(void __iomem *base, off_t offset)
{
	u64 val;
	val = readq(base + offset);
	return val;
}
static inline void yib_write64(void __iomem *base, off_t offset, u64 val)
{
	writeq(val, base + offset);
}

#define yib_read_regl(xl, offset) yib_read32(xl->reg_base[0], offset)
#define yib_write_regl(xl, offset, val) yib_write32(xl->reg_base[0], offset, val)
#define yib_reg_orl(xl, offset, val) yib_write32(xl->reg_base, offset, (val) | yib_read_regl(xl, offset))
#define yib_reg_andl(xl, offset, val) yib_write32(xl->reg_base, offset, (val) & yib_read_regl(xl, offset))


#define os_cpu_to_be32(x) cpu_to_be32(x)

#define os_wmb()	wmb()

void * os_zalloc(int data_size);
#define os_free(buf) 	kfree(buf);

#define MAX_FRAG_PAGE	(MAX_ORDER_NR_PAGES << PAGE_SHIFT)

struct yib_buf_list {
	os_dma_addr_t dma_addr;
	void *vaddr;
};

struct yib_frag_buf {
	struct yib_buf_list	*frags;
	int					npages;
	u64					size;
	u64					real_size;
};

struct  yib_sf;

void yib_frag_free_node(struct yib_sf *sf, struct yib_frag_buf *buf);
void *yib_frag_get_vaddr(struct yib_frag_buf *buf, int item_size, int index);
u64 yib_frag_get_paddr(struct yib_frag_buf *buf, int item_size, int index);
void *yib_frag_get_vaddr_with_offset(struct yib_frag_buf *buf, int item_size, int index, u32 offset);
u64 yib_frag_get_paddr_with_offset(struct yib_frag_buf *buf, int item_size, int index, u32 offset);
struct yib_frag_buf * yib_frag_buf_alloc_node(struct yib_sf *sf, u64 size, bool init_zero);
void yib_frag_zero_buf(struct yib_frag_buf *buf);
u32 yib_frag_get_pagesz(struct yib_frag_buf *buf);
u32 yib_frag_get_lastsz(struct yib_frag_buf *buf);

int os_get_gsi_item_len(void);
void yib_sglist_dump(struct ib_umem *umem, int npages, u32 page_size);
struct ib_umem *yib_umem_get_mem(struct ib_device *device, struct ib_ucontext *context, struct ib_udata *udata,
								unsigned long addr, size_t size, int access);
#endif /* end _YUSUR_IB_LINUX_H_ */