#ifndef _YUSUR_OS_PRIV_H_
#define _YUSUR_OS_PRIV_H_

void register_yib_ioctl(struct yusur_ib_dev *yib);
int yusur_ib_dev_init(struct yusur_ib_dev *ibdev, struct yusur_rdma_dev *yrdev);
void yusur_ib_dev_uninit(struct yusur_ib_dev *ibdev) ;
struct net_device *yusur_get_net_dev_from_yib(struct yusur_ib_dev *yib, int port_num);
extern const struct attribute_group yib_sys_attr_group;
int yib_create_sysfs_entries(const char *name,
				struct kobject *parent,
				const struct attribute_group *grp,
				struct kobject *kobj);

static inline struct yusur_ib_dev *to_yib(struct ib_device *ibdev)
{
	return container_of(ibdev, struct yusur_ib_dev, ib_dev);
}

static inline struct yib_pd *to_yib_pd(struct ib_pd *ibpd)
{
	return container_of(ibpd, struct yib_pd, ib_pd);
}

static inline struct yib_ah *to_yib_ah(struct ib_ah *ibah)
{
	return container_of(ibah, struct yib_ah, ib_ah);
}

static inline struct yib_mr *to_yib_mr(struct ib_mr *ibmr)
{
	return container_of(ibmr, struct yib_mr, ib_mr);
}

static inline struct yib_pd *mr_ypd(struct yib_mr *mr)
{
	return to_yib_pd(mr->ib_mr.pd);
}

static inline struct yib_pd *qp_ypd(struct yib_qp *qp)
{
	return to_yib_pd(qp->ib_qp.pd);
}

static inline struct yib_cq *to_yib_cq(struct ib_cq *ibcq)
{
	return container_of(ibcq, struct yib_cq, ib_cq);
}

static inline struct yib_qp *to_yib_qp(struct ib_qp *ibqp)
{
	return container_of(ibqp, struct yib_qp, ib_qp);
}

static inline struct yib_srq *to_yib_srq(struct ib_srq *ibsrq)
{
	return container_of(ibsrq, struct yib_srq, ib_srq);
}

static inline struct yib_xrcd *to_yib_xrcd(struct ib_xrcd *ibxrcd)
{
	return container_of(ibxrcd, struct yib_xrcd, ib_xrcd);
}

static inline struct yib_mw *to_yib_mw(struct ib_mw *ib_mw)
{
	return container_of(ib_mw, struct yib_mw, ib_mw);
}
#endif /* end _YUSUR_OS_PRIV_H_*/