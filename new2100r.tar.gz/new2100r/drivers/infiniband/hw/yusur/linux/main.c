#include <linux/init.h>
#include <linux/module.h>
#include <linux/mod_devicetable.h>

#include "../include/basic.h"
#include <linux/yusur/yrdma_model.h>
#include "../include/os_api.h"
#include "../include/os_ds.h"
#include "../include/mem.h"
#include "../include/queue.h"
#include "../include/host.h"
#include "../include/verbs.h"
#include "../include/yusur_ib.h"
#include "../include/core.h"
#include "priv.h"
#include "ib.h"

#ifdef pr_fmt
#undef pr_fmt
#endif

#define pr_fmt(fmt) "%s:%s: " fmt, KBUILD_MODNAME, __func__

#define DRV_VER	__stringify(DRV_VER_MAJOR) "."		\
	__stringify(DRV_VER_MINOR) "." __stringify(DRV_VER_BUILD)

#define PKEY_ID 0xffff
u16 g_yib_pkey_table[YUSUR_RDMA_PKEY_TABLE_LEN] = { PKEY_ID };

extern void yib_init_debugfs(void);
extern void yib_uinit_debugfs(void);
extern void yusur_debugfs_add(struct yusur_ib_dev *yib);
extern void yusur_debugfs_remove(struct yusur_ib_dev *yib);

void yib_pkey_table_init(void)
{
	int i;
	for (i = 0; i < YUSUR_RDMA_PKEY_TABLE_LEN; i++) {
		g_yib_pkey_table[i] = PKEY_ID - 1;
	}
}

int yib_get_pkey_idx_by_value(int value)
{
	if (value > PKEY_ID || value < (PKEY_ID - YUSUR_RDMA_PKEY_TABLE_LEN + 1))
		return -1;
	return PKEY_ID - value;
}

static int yusur_ib_mp_probe(struct yrdma_device *ydev, const struct yrdma_device_id *id)
{
	struct yusur_ib_dev *ibdev;
	int ret;
	struct yusur_rdma_dev *yrdev = container_of(ydev, struct yusur_rdma_dev, ydev);
	yib_dbg_info(YUSUR_IB_M_LINUX_MAIN, YUSUR_IB_DBG_INIT, "mp probe %p \n", ydev);
#if IBDEV_ALLOC_OEN_ARG == 0
	ibdev = (struct yusur_ib_dev *)ib_alloc_device(yusur_ib_dev, ib_dev);
#else
	ibdev = (struct yusur_ib_dev *)ib_alloc_device(sizeof(*ibdev));
#endif
	if (!ibdev)
		return -ENOMEM;	
	ibdev->dev = &ydev->dev;
	ret = yusur_ib_dev_init(ibdev, yrdev);
	if (ret) {
		os_printe(&ydev->dev, "Init Yusur Ib failed for init\n");
		ib_dealloc_device(&ibdev->ib_dev);
		return ret;
	}
	ret = yusur_ib_register(ibdev);
	if (ret != 0) {
		os_printe(&ydev->dev, "Register Yusur ibdev failed\n");
		yusur_ib_dev_uninit(ibdev);
		ib_dealloc_device(&ibdev->ib_dev);
		return ret;
	}

	yrdev->priv_data = ibdev;
	yusur_debugfs_add(ibdev); 	
	return 0; 
}

static void yusur_ib_mp_remove(struct yrdma_device *ydev)
{
	struct yusur_rdma_dev *yrdev = container_of(ydev, struct yusur_rdma_dev, ydev);
	struct yusur_ib_dev *ibdev = yrdev->priv_data;
	yib_dbg_info(YUSUR_IB_M_LINUX_MAIN, YUSUR_IB_DBG_UINIT,  "mp remove %p \n", ydev);
	if (!ibdev)
		return;

	yusur_debugfs_remove(ibdev); 
	yusur_ib_unregister(ibdev);	
	yusur_ib_dev_uninit(ibdev); 
	ib_dealloc_device(&ibdev->ib_dev);
}

static struct yusur_rdma_dev *yusur_get_parent_dev(struct yusur_ib_dev *ibdev)
{
	struct yrdma_device *ydev = container_of(ibdev->dev, struct yrdma_device, dev);
	return container_of(ydev, struct yusur_rdma_dev, ydev);
}

struct net_device *yusur_get_net_dev_from_yib(struct yusur_ib_dev *yib, int port_num)
{
	if (port_num < 1 || port_num > YIB_MAX_DEV_PORTS)
		return NULL;
	port_num--;
	if (yib->bonding == false)
		return yib->host.ndev_info[port_num].netdev;
	else {
		return yusur_intf_get_netdev_from_bonding(yusur_get_parent_dev(yib));
	}
}

static int yusur_ib_probe(struct yrdma_device *ydev, const struct yrdma_device_id *id)
{
	struct yusur_ib_dev *ibdev;
	int ret;
	struct yusur_rdma_dev *yrdev = container_of(ydev, struct yusur_rdma_dev, ydev);
	yib_dbg_info(YUSUR_IB_M_LINUX_MAIN, YUSUR_IB_DBG_INIT, "single probe %p\n", ydev);
#if IBDEV_ALLOC_OEN_ARG == 0
	ibdev = (struct yusur_ib_dev *)ib_alloc_device(yusur_ib_dev, ib_dev);
#else
	ibdev = (struct yusur_ib_dev *)ib_alloc_device(sizeof(*ibdev));
#endif
	if (!ibdev)
		return -ENOMEM;

	ibdev->dev = &ydev->dev;
	ret = yusur_ib_dev_init(ibdev, yrdev);
	if (ret) {
		os_printe(&ydev->dev, "Init Yusur Ib failed for init\n");
		ib_dealloc_device(&ibdev->ib_dev);
		return ret;
	}
	ret = yusur_ib_register(ibdev);
	if (ret != 0) {
		os_printe(&ydev->dev, "Register Yusur ibdev failed\n");
		yusur_ib_dev_uninit(ibdev);
		ib_dealloc_device(&ibdev->ib_dev);
		return ret;
	}

	yrdev->priv_data = ibdev;
	yusur_debugfs_add(ibdev); 
	return 0; 
}

static void yusur_ib_remove(struct yrdma_device *ydev)
{
	struct yusur_rdma_dev *yrdev = container_of(ydev, struct yusur_rdma_dev, ydev);
	struct yusur_ib_dev *ibdev = yrdev->priv_data;
	yib_dbg_info(YUSUR_IB_M_LINUX_MAIN, YUSUR_IB_DBG_UINIT, "single remove %p \n", ydev);
	if (!ibdev)
		return;

	yusur_debugfs_remove(ibdev); 
	yusur_ib_unregister(ibdev);	
	yusur_ib_dev_uninit(ibdev); 
	ib_dealloc_device(&ibdev->ib_dev);	
}

static void yusur_ib_shutdown(struct yrdma_device *ydev)
{
	struct yusur_rdma_dev *yrdev = container_of(ydev, struct yusur_rdma_dev, ydev);
	struct yusur_ib_dev *ibdev = yrdev->priv_data;

	if (ibdev == NULL)
		return;

	if (ibdev->host.hw_ops.shutdown_host)
		ibdev->host.hw_ops.shutdown_host(&ibdev->host);
}

static const struct yrdma_device_id yusur_ib_mp_id_table[] = {
	{ .name = YRDMA_BOND_DEV_NAME, },
	{},
};

static const struct yrdma_device_id yusur_ib_id_table[] = {
	{ .name =  YRDMA_DEV_NAME, },
	{},
};

static struct yrdma_driver yusur_ib_mp_driver = {
	.name = YRDMA_BOND_DEV_NAME,
	.probe = yusur_ib_mp_probe,
	.remove = yusur_ib_mp_remove,
	.id_table = yusur_ib_mp_id_table,
};

static struct yrdma_driver yusur_ib_driver = {
	.name = YRDMA_DEV_NAME,
	.probe = yusur_ib_probe,
	.remove = yusur_ib_remove,
	.shutdown = yusur_ib_shutdown,
	.id_table = yusur_ib_id_table,
};

static int __init yusur_rdma_init(void)
{
	int ret = 0;
	yib_pr_info(YUSUR_IB_DBG_INIT, "yusur rdma driver init version: %d.%d.%d\n", DRV_VER_MAJOR,
		DRV_VER_MINOR, DRV_VER_BUILD);

	yib_init_debugfs();
	yusur_hw_host_register();
	ret = yrdma_driver_register(&yusur_ib_mp_driver);
	if (ret) {
		yib_dbg_err("init mp driver failed");
		return -1;
	}
	ret = yrdma_driver_register(&yusur_ib_driver);
	if (ret) {
		yib_dbg_err("init test driver failed");
		yrdma_driver_unregister(&yusur_ib_mp_driver);
		return -2;
	}

	return 0;
}

static void __exit yusur_rdma_exit(void)
{
	yib_pr_info(YUSUR_IB_DBG_INIT, "yusur rdma driver exit version: %d.%d.%d\n", DRV_VER_MAJOR,
		DRV_VER_MINOR, DRV_VER_BUILD);
	yrdma_driver_unregister(&yusur_ib_mp_driver);
	yrdma_driver_unregister(&yusur_ib_driver);
	yib_uinit_debugfs();
}

MODULE_ALIAS("yusur_rdma_driver");
MODULE_AUTHOR("GuoXing <guox@yusur.tech>");
MODULE_DESCRIPTION("Yusur Infiniband RDMA driver");
MODULE_LICENSE("Dual BSD/GPL");
MODULE_VERSION(DRV_VER);

module_init(yusur_rdma_init);
module_exit(yusur_rdma_exit);
