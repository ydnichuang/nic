#include "../include/basic.h"
#include <linux/yusur/yrdma_model.h>
#include "../include/os_api.h"
#include "../include/os_ds.h"
#include "../include/mem.h"
#include "../include/queue.h"
#include "../include/host.h"
#include "../include/verbs.h"
#include "../include/yusur_ib.h"
#include "../include/core.h"
#include "priv.h"
#include "ib.h"


int yib_ib_get_hw_stats(struct ib_device *ibdev,
			struct rdma_hw_stats *stats,
			tPortInt port, int index)
{
	struct yusur_ib_dev *yib = to_yib(ibdev);

	if (!port || !stats)
		return -EINVAL;

	if (yib->host.hw_ops.get_hw_counter)
		yib->host.hw_ops.get_hw_counter(&yib->host, stats->value,(u32)port);
	else
		return -EOPNOTSUPP;    

	return yib->host.hw_counter_cnt;
}

struct rdma_hw_stats *yib_ib_alloc_hw_stats(struct ib_device *ibdev,
					    tPortInt port_num)
{
	struct yusur_ib_dev *yib = to_yib(ibdev);
	u32 count = 0;
	struct rdma_hw_stats *ret = NULL;
#if (COUNTER_STAT_DESC)	
	const struct rdma_stat_desc  *descs = yib->host.hw_ops.get_counter_info(&yib->host, &count);
	ret = rdma_alloc_hw_stats_struct(descs, count, RDMA_HW_STATS_DEFAULT_LIFESPAN);
#else
	const char * const * descs = yib->host.hw_ops.get_counter_info(&yib->host, &count);
	ret =  rdma_alloc_hw_stats_struct(descs, count, RDMA_HW_STATS_DEFAULT_LIFESPAN);
#endif
	yib->host.hw_counter_cnt = count;
	return ret;
}
