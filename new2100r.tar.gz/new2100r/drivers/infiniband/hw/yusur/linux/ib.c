#include <rdma/ib_mad.h>
#include <rdma/ib_addr.h>
#include <rdma/ib_user_verbs.h>
#include <rdma/ib_cache.h>
#include <rdma/ib_umem.h>
#include <rdma/ib_verbs.h>
#include <rdma/uverbs_ioctl.h>
#include <linux/yusur/yusur_peer.h>
#include "../include/basic.h"
#include <linux/yusur/yrdma_model.h>
#include "../include/os_api.h"
#include "../include/os_ds.h"
#include "../include/mem.h"
#include "../include/queue.h"
#include "../include/host.h"
#include "../include/verbs.h"
#include "../include/yusur_ib.h"
#include "../include/core.h"
#include "../include/user.h"
#include "../host/hwcomn.h"
#include "priv.h"
#include "ib.h"

static enum rdma_link_layer yib_get_link_layer(struct ib_device *device, tPortInt port_num)
{
	return IB_LINK_LAYER_ETHERNET;
}

#if IB_LAYER_ALLOC_PD
static int yib_alloc_pd(struct ib_pd *ibpd, struct ib_udata *udata)
{
	struct ib_device *ibdev = ibpd->device;
	struct yusur_ib_dev *yib = to_yib(ibdev);
	struct yib_pd *pd = to_yib_pd(ibpd);
	int ret;
	struct yib_ucontext *context = rdma_udata_to_drv_context(udata, struct yib_ucontext, ib_uc);

	ret  = yib_add_to_pool(&yib->host.verbs.pd_pool, &pd->entry);
	if (ret < 0)
		return ret;

	if (udata && context) {
		struct yib_ib_alloc_pd_resp uresp;

		uresp.pdn = pd->entry.index;
		ret = ib_copy_to_udata(udata, &uresp, sizeof(uresp));
		if (ret) {
			os_printw(&ibpd->device->dev, "user data for pd is two small\n");
			yib_elem_drop_ref(&pd->entry);
			return ret;
		}
	}

	yib_dbg_info(YUSUR_IB_M_CORE_VERBS,YUSUR_IB_DBG_CREATE, "pd:%d alloc\n", pd->entry.index);
	return ret;
}
#endif 

#if IB_DESTROY_NO_UDATA == 0
#if IB_DESTROY_NO_RETURN == 0
static int yib_dealloc_pd(struct ib_pd *ibpd, struct ib_udata *udata)
#else
static void yib_dealloc_pd(struct ib_pd *ibpd, struct ib_udata *udata)
#endif
{
	struct yib_pd *pd = to_yib_pd(ibpd);
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS,YUSUR_IB_DBG_DESTROY, "pd:%d dealloc\n", pd->entry.index);
	yib_elem_drop_ref(&pd->entry);

	#if IB_DESTROY_NO_RETURN ==   0	
	return 0;
	#endif
}
#endif

#if IB_LAYER_ALLOC_AH
#if HAS_RDMA_AH_INIT_ATTR
static int yib_create_ah(struct ib_ah *ibah,
			 struct rdma_ah_init_attr *init_attr,
			 struct ib_udata *udata)
#else
static int yib_create_ah(struct ib_ah *ibah,
			 struct rdma_ah_attr *ah_attr,
			 u32 flags,
			 struct ib_udata *udata)
#endif
{
	int err;
	struct ib_device *ibdev = ibah->device;
	struct yib_ib_create_ah_resp *uresp = NULL;
	struct yib_ib_create_ah_resp ah_resp;
	struct yusur_ib_dev *yib = to_yib(ibdev);
	struct yib_ah *ah = to_yib_ah(ibah);

	if (udata) {
		if (udata->outlen >= sizeof(*uresp))
			uresp = udata->outbuf;
		ah->is_user = true;
	} else {
		ah->is_user = false;
	}	

#if HAS_RDMA_AH_INIT_ATTR
	err = yib_av_chk_attr(yib, init_attr->ah_attr);
#else
	err = yib_av_chk_attr(yib, ah_attr);
#endif
	if (err)
		return err;

	err = yib_add_to_pool(&yib->host.verbs.ah_pool, &ah->entry);
	if (err) {
		os_printw(yib->dev, "ah add to pool failed\n");
		return err;
	}

	ah->ah_num = ah->entry.index;

	yib_dbg_info(YUSUR_IB_M_AH, YUSUR_IB_DBG_CREATE, "AH:%d u:%d\n", ah->ah_num, ah->is_user);
#if HAS_RDMA_AH_INIT_ATTR
	yib_init_av(yib, init_attr->ah_attr, &ah->av);
#else
	yib_init_av(yib, ah_attr, &ah->av);
#endif
	yib->host.sf.sf_ops->init_av(&yib->host.sf, &ah->av, ah->entry.index, false);

	if (uresp) {
		/* only if new user provider */
		ah_resp.ah_num = ah->ah_num;
		ah_resp.vlan_id = ah->av.vlan_id;
		ah_resp.vlan_pcp = ah->av.vlan_pcp;
		ah_resp.smac_idx = ah->av.smac_idx;
		memcpy(ah_resp.smac, ah->av.smac, ETH_ALEN);

		err = copy_to_user(uresp, &ah_resp, sizeof(struct yib_ib_create_ah_resp));
		if (err) {
			yib_elem_drop_ref(&ah->entry);
			os_printw(yib->dev, "ah copy to user failed\n");
			return -EFAULT;
		}
	} else if (ah->is_user) {
		/* only if old user provider */
		ah->ah_num = 0;
	}
	return 0;
}

#endif 

#if IB_DESTROY_NO_UDATA == 0
#if IB_DESTROY_NO_RETURN == 0
static int yib_destroy_ah(struct ib_ah *ibah, u32 flags)
#else
static void yib_destroy_ah(struct ib_ah *ibah, u32 flags)
#endif
{
	struct yib_ah *ah = to_yib_ah(ibah);
	struct yusur_ib_dev *yib = to_yib(ibah->device);

	yib->host.sf.sf_ops->init_av(&yib->host.sf, &ah->av, ah->entry.index, true);
	yib_elem_drop_ref(&ah->entry);
	#if IB_DESTROY_NO_RETURN == 0
	return 0;
	#endif
}
#endif

static int yib_modify_ah(struct ib_ah *ibah, struct rdma_ah_attr *attr)
{
	int err;
	struct ib_device *ibdev = ibah->device;
	struct yusur_ib_dev *yib = to_yib(ibdev);
	struct yib_ah *ah = to_yib_ah(ibah);

	err = yib_av_chk_attr(yib, attr);
	if (err) {
		os_printw(yib->dev, "ah chk failed\n");
		return err;
	}
	yib_dbg_info(YUSUR_IB_M_AH, YUSUR_IB_DBG_MODIFY, "modify AH:%d u:%d\n", ah->ah_num, ah->is_user);
	yib_init_av(yib, attr, &ah->av);
	return 0;
}

static int yib_query_ah(struct ib_ah *ibah, struct rdma_ah_attr *attr)
{
	struct yib_ah *ah = to_yib_ah(ibah);

	memset(attr, 0, sizeof(*attr));
	attr->type = ibah->type;
	yib_av_to_attr(&ah->av, attr);
	return 0;
}


#if IB_LAYER_ALLOC_UD
static int yib_alloc_ucontext(struct ib_ucontext *uctx, struct ib_udata *udata)
{
	struct ib_device *ib_dev = uctx->device;
	struct yusur_ib_dev *yib = to_yib(ib_dev);
	int uresp_len = 0;
	char uresp[128];

	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_CREATE, "ucontext alloc\n");
	if (udata) {
		yib->host.hw_ops.get_queue_user_info(&yib->host, YIB_TYPE_PD, NULL, 0, uresp, &uresp_len);
		return ib_copy_to_udata(udata, uresp, (uresp_len > sizeof(uresp))? sizeof(uresp): uresp_len);

	}
	return 0;
}

static void yib_dealloc_ucontext(struct ib_ucontext *ibucontext)
{
	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_DESTROY, "ucontext dealloc\n");
}
#endif

void yib_pool_mr_cleanup(struct yib_pool_entry *arg)
{	
	struct yib_mr *mr= container_of(arg, struct yib_mr, entry);
	struct yusur_ib_dev *yib = to_yib(mr->ib_mr.device);

	yib_mr_info_disable(yib, mr);
	mr->state = YIB_MR_INVALID;
	yib_dbg_info(YUSUR_IB_M_MR, YUSUR_IB_DBG_DESTROY, "mr final clean:%d\n", yib_get_mr_sw_idx(mr));
}

#if IB_ALLOC_MR_NEED_UDATA
static struct ib_mr *yib_alloc_mr(struct ib_pd *ibpd, enum ib_mr_type mr_type,
				  u32 max_num_sg, struct ib_udata *udata)
#else
static struct ib_mr *yib_alloc_mr(struct ib_pd *ibpd, enum ib_mr_type mr_type,
				  u32 max_num_sg)
#endif
{
	struct ib_device *ib_dev = ibpd->device;
	struct yusur_ib_dev *yib = to_yib(ib_dev);
	struct yib_pd *ypd = to_yib_pd(ibpd);
	struct yib_mr *mr;
	int ret = 0;

	if (mr_type != IB_MR_TYPE_MEM_REG) {
		os_printw(&ibpd->device->dev, "we only support mem reg user mr\n");
		return ERR_PTR(-EINVAL);
	}
	
	if (max_num_sg > yib->host.caps.max_mr_sgs) {
		os_printw(&ibpd->device->dev, "alloc_mr max_num_sg=%d is too big\n", max_num_sg);
		return ERR_PTR(-EINVAL);
	}
	
	mr = yib_mr_alloc_new(yib, ypd, false, false, true);
	if (IS_ERR(mr)) {
		os_printw(&ibpd->device->dev, "alloc mr failed\n");
		return (struct ib_mr *)mr;
	}

	mr->ib_mr.device = ibpd->device;
	ret = yib_fmr_init(yib, mr);
	if (ret) {
		yib_mr_dealloc(mr, ypd);
		return ERR_PTR(-EFAULT);
	}

	mr->state = YIB_MR_FREE;
	yib->host.sf.sf_ops->mr_mpt_update(&yib->host.sf, mr);
	yib_dbg_info(YUSUR_IB_M_MR, YUSUR_IB_DBG_CREATE, "mr:%d alloc\n", yib_get_mr_sw_idx(mr));
	return &mr->ib_mr;
}

static struct ib_mr *yib_get_dma_mr(struct ib_pd *ibpd, int access)
{
	struct yusur_ib_dev *yib = to_yib(ibpd->device);
	struct yib_pd *ypd = to_yib_pd(ibpd);
	struct yib_mr *mr;

	mr = yib_mr_alloc_new(yib, ypd, false, true, false);
	if (IS_ERR(mr)) {
		os_printw(&ibpd->device->dev, "alloc mr failed\n");
		return (struct ib_mr *)mr;
	}

	mr->ib_mr.device = ibpd->device;
	mr->state = YIB_MR_VALID;
	mr->access = access;
	yib->host.sf.sf_ops->mr_mpt_update(&yib->host.sf, mr);
	yib_dbg_info(YUSUR_IB_M_MR, YUSUR_IB_DBG_CREATE, "dma mr:%d alloc\n", yib_get_mr_sw_idx(mr));
	return &mr->ib_mr;	
}

#if IB_DESTROY_NO_UDATA == 0
static int yib_dereg_mr(struct ib_mr *ibmr, struct ib_udata *udata)
{
	struct yib_mr *mr = to_yib_mr(ibmr);
	struct yib_pd *ypd = mr_ypd(mr);

	yib_dbg_info(YUSUR_IB_M_MR, YUSUR_IB_DBG_DESTROY, "mr dereg:%d\n", yib_get_mr_sw_idx(mr));
	yib_mr_dealloc(mr, ypd);
	return 0;
}
#endif

void yib_pool_cq_cleanup(struct yib_pool_entry *arg)
{	
	struct yib_cq *ycq= container_of(arg, struct yib_cq, entry);
	struct yusur_ib_dev *yib = to_yib(ycq->ib_cq.device);
	yib_dbg_info(YUSUR_IB_M_CQ, YUSUR_IB_DBG_DESTROY, "cq cleanup:%d\n", yib_get_cq_sw_idx(ycq));

	yib_cq_free(yib, ycq);
}

#if IB_DESTROY_NO_UDATA == 0
#if IB_DESTROY_NO_RETURN == 0
static int yib_destroy_cq(struct ib_cq *ibcq, struct ib_udata *udata)
#else
static void yib_destroy_cq(struct ib_cq *ibcq, struct ib_udata *udata)
#endif
{
	struct yib_cq *ycq = to_yib_cq(ibcq);
	yib_dbg_info(YUSUR_IB_M_CQ, YUSUR_IB_DBG_DESTROY, "cq destroy:%d\n", yib_get_cq_sw_idx(ycq));
	yib_elem_drop_ref(&ycq->entry);
	#if IB_DESTROY_NO_RETURN == 0	
	return 0;
	#endif
}
#endif

#if IB_LAYER_ALLOC_CQ
static int yib_create_cq(struct ib_cq *ibcq, const struct ib_cq_init_attr *attr,
			 struct ib_udata *udata)
{
	struct yusur_ib_dev *yib = to_yib(ibcq->device);
	struct yib_cq *ycq = to_yib_cq(ibcq);
	struct yib_ib_create_cq ureq;
	struct ib_umem *umem = NULL;
	u32 cqe_size, cqe;
	u8 ures[128];

	int ures_len = 0;
	int ret;
	if (udata) {
		if (udata->outlen < sizeof(struct yib_ib_create_cq_resp)) {
			os_printw(&ibcq->device->dev, "cq udata is not enough\n");
			return -EINVAL;
		}
	}	

	cqe = attr->cqe;
	cqe_size = yib_cq_align_size(yib, &cqe);
	if(!ycq) {
		pr_err("%s %d %s is_user \n",__FILE__,__LINE__,__func__);
		return -EINVAL;
	}

	if (cqe > yib->host.caps.max_cqes) {
		os_printw(&ibcq->device->dev, "Failed to create CQ - cqe:%d max_cqes:%d\n", 
				cqe, yib->host.caps.max_cqes);
		return -EINVAL;
	}
	ycq->nvme_off = false;
	if (attr->comp_vector > (yib->host.caps.num_comp_vector - 1)) {
		os_printw(&ibcq->device->dev, "Failed to create CQ - comp vector execeeded\n");
		return -EINVAL;
	}
	if (udata) {
		if (ib_copy_from_udata((void *)&ureq, udata, sizeof(ureq))) {
			os_printw(&ibcq->device->dev, "cq create failed for copy from udata\n");
			return -ENOMEM;
		}
		ycq->nvme_off = ureq.nvme_off?true:false;
		umem = yib_umem_get_mem(&yib->ib_dev, ibcq->cq_context, udata, ureq.cq_va, cqe_size, IB_ACCESS_REMOTE_READ | IB_ACCESS_LOCAL_WRITE);
		if (IS_ERR(umem)) {
			os_printw(&ibcq->device->dev,
				  "failed to get ib umem for cq dma mem, error: %ld, bytes:%d\n",
				   PTR_ERR(umem), cqe_size);
			return -ENOMEM;
		}
	}

	ret = yib_cq_alloc_new(yib, ycq, cqe, umem, attr->comp_vector);
	if (ret) {
		os_printw(&ibcq->device->dev, "Failed to alloc new CQ\n");
		return ret;
	}

	if (udata)
		ycq->u_cq_handler = ureq.u_cq_handler;

	ret = yib->host.sf.sf_ops->cq_info_init(&yib->host.sf, ycq, true);
	if (ret) {
		os_printw(&ibcq->device->dev, "Failed to init CQ info\n");
		goto end;
	}

	if (ycq->is_user) {
		yib->host.hw_ops.get_queue_user_info(&yib->host, YIB_TYPE_CQ, ycq, yib_get_cq_sw_idx(ycq), ures, &ures_len);
		ret = ib_copy_to_udata(udata, ures, ures_len > sizeof(ures)? sizeof(ures): ures_len);
		if (ret != 0) {
			os_printw(&ibcq->device->dev, "cq create failed for copy to udata\n");
			goto end;
		}
	}
	yib_dbg_info(YUSUR_IB_M_CQ, YUSUR_IB_DBG_CREATE, "cqid:%d create u:%d nvme=%d inputcqe=%d cqe=%d\n",
					 yib_get_cq_sw_idx(ycq), 
					 ycq->is_user, ycq->nvme_off?1:0, attr->cqe, cqe);
	return 0;

end:	
	yib_elem_drop_ref(&ycq->entry);
	return -ENOMEM;
}
#endif

static int yib_notify_cq(struct ib_cq *ibcq, enum ib_cq_notify_flags flags)
{
	struct yusur_ib_dev *yib = to_yib(ibcq->device);
	struct yib_cq *ycq = to_yib_cq(ibcq);

	return yib_cq_notify(yib, ycq, flags);	
}

static int yib_poll_cq(struct ib_cq *ibcq, int num_entries, struct ib_wc *wc)
{
	struct yusur_ib_dev *yib = to_yib(ibcq->device);
	struct yib_cq *ycq = to_yib_cq(ibcq);
	if (ycq->is_user)
		return yib_user_poll_cq(yib, ycq, num_entries, wc);

	return yib_cq_poll(yib, ycq, num_entries, wc);
}

//when call resize cq the upper need to stop poll_cq
static int  yib_resize_cq(struct ib_cq *ibcq, int entries, struct ib_udata *udata)
{
	return -EINVAL;
}

void yib_pool_qp_cleanup(struct yib_pool_entry *arg)
{	
	struct yib_qp *yqp= container_of(arg, struct yib_qp, entry);
	struct yusur_ib_dev *yib = to_yib(yqp->ib_qp.device);

	yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_DESTROY, "qp cleanup:%d u:%d\n", yib_get_qp_sw_idx(yqp), yqp->is_user);
	yib_qp_free(yib, yqp, yqp->ypd);
}

static int yib_create_qp_chk(struct ib_device *ib_dev,
				   struct ib_qp_init_attr *init,
				   struct ib_udata *udata, int *u_sq_len, int *u_rq_len)
{
	struct yusur_ib_dev *yib = to_yib(ib_dev);
	int sq_isize = 0, rq_isize = 0;
	bool has_sq = true;
	bool has_rq = init->srq?false:true;
	bool is_ud = false;

	switch (init->qp_type) {
		case IB_QPT_GSI:
			if (!rdma_is_port_valid(ib_dev, init->port_num)) {
				os_printw(&ib_dev->dev, "invalid port = %d\n", init->port_num);
				return -EINVAL;
			}
			is_ud = true;
			if (!init->recv_cq || !init->send_cq) {
				os_printw(&ib_dev->dev,"missing cq\n");
				return -EINVAL;
			}
			break;
		case IB_QPT_RC:
			if (!init->recv_cq || !init->send_cq) {
				os_printw(&ib_dev->dev,"missing cq\n");
				return -EINVAL;
			}
			break;
		case IB_QPT_UD:
			if (!init->recv_cq || !init->send_cq) {
				os_printw(&ib_dev->dev,"missing cq\n");
				return -EINVAL;
			}
			if (yib->host.funcs.ud_supp == 0) {
				os_printw(&ib_dev->dev, "UD QP not support\n");
				return -EINVAL;
			}
			is_ud = true;
			break;
		case IB_QPT_UC:
			if (!init->recv_cq || !init->send_cq) {
				os_printw(&ib_dev->dev,"missing cq\n");
				return -EINVAL;
			}
			if (yib->host.funcs.uc_supp == 0) {
				os_printw(&ib_dev->dev, "UC QP not support\n");
				return -EINVAL;
			}
			break;
		case IB_QPT_XRC_INI:
			if (!init->send_cq) {
				os_printw(&ib_dev->dev,"missing scq\n");
				return -EINVAL;
			}
			if (yib->host.funcs.xrc_supp == 0) {
				os_printw(&ib_dev->dev, "XRC QP not support\n");
				return -EINVAL;
			}
			has_rq = false;
			break;
		case IB_QPT_XRC_TGT:
			if (yib->host.funcs.xrc_supp == 0) {
				os_printw(&ib_dev->dev, "XRC QP not support\n");
				return -EINVAL;
			}
			if (init->xrcd == NULL) {
				os_printw(&ib_dev->dev, "XRCD NULL\n");
				return -EINVAL;
			}
			if (init->srq != NULL) {
				os_printw(&ib_dev->dev, "srq should be null\n");
				return -EINVAL;
			}
			has_sq = false;
			has_rq = false;
			break;
		default:
			os_printw(&ib_dev->dev, "QP type:%d not support\n", init->qp_type);
			return -EINVAL;
	}

	if (udata) {
		if (udata->outlen < 16) {
			os_printw(&ib_dev->dev, "QP user data is short\n");
			return -EINVAL;
		}
	}

	if (yib_qp_chk_cap(&yib->host, &init->cap, has_rq, has_sq)) {
		os_printw(&ib_dev->dev, "QP check failed\n");
		return -EINVAL;
	}

	if (has_sq) {
		sq_isize = yib->host.sf.queue_ops->get_sq_item_size(&init->cap.max_inline_data, &init->cap.max_send_sge, is_ud);
		yib_queue_calc_depth(sq_isize, &init->cap.max_send_wr);
	} else {
		init->cap.max_send_wr = 0;
	}

	if (has_rq) {
		rq_isize = yib->host.sf.queue_ops->get_rq_item_size(&init->cap.max_recv_sge);
		yib_queue_calc_depth(rq_isize, &init->cap.max_recv_wr);
	} else {
		init->cap.max_recv_wr = 0;
	}

	*u_sq_len = init->cap.max_send_wr * sq_isize;
	*u_rq_len = init->cap.max_recv_wr * rq_isize;
	return 0;
}

#if IB_LAYER_ALLOC_QP	== 0
static struct ib_qp *yib_create_qp(struct ib_pd *ibpd,
				   struct ib_qp_init_attr *init,
				   struct ib_udata *udata)			   
{
	struct ib_device *ib_dev = NULL;
	struct yusur_ib_dev *yib = NULL;
	struct yib_pd *ypd = NULL;
	struct yib_qp *yqp  = NULL;
	struct yib_xrcd *yxrcd = NULL;
	struct yib_ib_create_qp ureq;
	struct ib_umem *umem_sq = NULL;
	struct ib_umem *umem_rq = NULL;
	int u_sq_len = 0, u_rq_len = 0;
	int uresp_len;
	u8 uresp[128];
	int ret;

	if (ibpd) {
		ib_dev = ibpd->device;
		ypd = to_yib_pd(ibpd);
	} else {
		if (init->qp_type != IB_QPT_XRC_TGT) {
			yib_dbg_err("no PD for transport\n");
			return ERR_PTR(-EINVAL);
		}
		ib_dev = to_yib_xrcd(init->xrcd)->ib_xrcd.device;
	}
	yib = to_yib(ib_dev);

	yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_CREATE, "create qp begin type=%d swr=%d rwr=%d",
			init->qp_type, init->cap.max_send_wr, init->cap.max_recv_wr);

	ret = yib_create_qp_chk(ib_dev, init, udata, &u_sq_len, &u_rq_len); //这个函数会计算好sq,rq队列深度,放到init->cap中
	if (ret) {
		return ERR_PTR(ret);
	}

	yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_CREATE, "create qp afterchk type=%d swr=%d rwr=%d",
			init->qp_type, init->cap.max_send_wr, init->cap.max_recv_wr);

	if (udata) {
		if (ib_copy_from_udata((void *)&ureq, udata, sizeof(ureq))) {
			os_printw(&ibpd->device->dev, "create qp failed for copy from udata\n");
			return ERR_PTR(-ENOMEM);
		}

		umem_sq = yib_umem_get_mem(&yib->ib_dev, ibpd->uobject->context, udata, ureq.sq_va, u_sq_len, IB_ACCESS_REMOTE_READ | IB_ACCESS_LOCAL_WRITE);
		if (IS_ERR(umem_sq)) {
			os_printw(&ibpd->device->dev,
				  "failed to get ib umem for sq dma mem, error: %ld, bytes:%d\n",
				   PTR_ERR(umem_sq), u_sq_len);
			return ERR_PTR(-ENOMEM);
		}

		if (init->srq == NULL) {
			umem_rq = yib_umem_get_mem(&yib->ib_dev, ibpd->uobject->context, udata, ureq.rq_va, u_rq_len, IB_ACCESS_REMOTE_READ | IB_ACCESS_LOCAL_WRITE);
			if (IS_ERR(umem_rq)) {
				os_printw(&ibpd->device->dev,
					"failed to get ib umem for rq dma mem, error: %ld, bytes:%d\n",
					PTR_ERR(umem_rq), u_rq_len);
				os_umem_release(umem_sq);
				return ERR_PTR(-ENOMEM);
			}
		}
	}

	yxrcd = (init->qp_type == IB_QPT_XRC_TGT)? (to_yib_xrcd(init->xrcd)) : NULL;
	yqp = yib_qp_alloc(yib, ypd, init->qp_type, &init->cap, yxrcd);
	if (yqp == NULL) {
		os_umem_release(umem_rq);
		os_umem_release(umem_sq);
		return ERR_PTR(-ENOMEM);
	}

	ret = yib_qp_attach(yib, yqp, umem_sq, umem_rq);
	if (ret != 0) {
		os_printw(&yib->ib_dev.dev, "qp: %d attach user:%d failed\n", yib_get_qp_sw_idx(yqp), yqp->is_user);
		goto fail;
	}

	if (udata) {
		yqp->nvme_off = ureq.nvme_off?true:false;
		yqp->u_qp_handler = ureq.u_qp_handler;
		if (init->srq == NULL && ureq.u_rq_handler != 0)
			yqp->type.yrq->u_rq_handler = ureq.u_rq_handler;
	} else
		yqp->nvme_off = false;

	yqp->sq_sig_type   = init->sq_sig_type;
	if (!rdma_is_port_valid(ib_dev, init->port_num))
		yqp->attr.port_num  = 1;
	else
		yqp->attr.port_num  = init->port_num;

	yqp->attr.path_mtu = yib->host.ndev_info[yqp->attr.port_num - 1].cur_max_mtu;
	ret = yib_qp_attach_cq(yib, yqp, init->srq?to_yib_srq(init->srq):NULL, 
		init->send_cq? to_yib_cq(init->send_cq):NULL, init->recv_cq? to_yib_cq(init->recv_cq):NULL);
	if (ret != 0) {
		os_printw(&yib->ib_dev.dev, "qp: %d attach cq failed\n", yib_get_qp_sw_idx(yqp));
		goto fail;
	}

	if (yqp->is_user) {
		yib->host.hw_ops.get_queue_user_info(&yib->host, YIB_TYPE_QP, yqp, yib_get_qp_sw_idx(yqp), uresp, &uresp_len);
		ret = ib_copy_to_udata(udata, uresp, (uresp_len > sizeof(uresp))? sizeof(uresp): uresp_len);
		if (ret != 0) {
			os_printw(&ibpd->device->dev, "create qp failed for copy to udata\n");
			goto fail;
		}
	}
	yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_CREATE, "create ok qp id:%d sqe=%d rqe=%d nvme=%d\n",
			yib_get_qp_sw_idx(yqp), yqp->cap.max_send_wr, yqp->use_srq? 0:yqp->cap.max_recv_wr, yqp->nvme_off?1:0);
	return &yqp->ib_qp;
fail:
	yib_dbg_err("create failed qp: %d\n",  yib_get_qp_sw_idx(yqp));
	yib_elem_drop_ref(&yqp->entry);
	return ERR_PTR(ret);
}
#else
extern int yib_create_qp(struct ib_qp *ibqp, struct ib_qp_init_attr *init,
		                         struct ib_udata *udata);
#endif

#if IB_DESTROY_NO_UDATA == 0
static int yib_destroy_qp(struct ib_qp *ibqp, struct ib_udata *udata)
{
	struct yib_qp *yqp = to_yib_qp(ibqp);
	yib_dbg_info(YUSUR_IB_M_QP, YUSUR_IB_DBG_DESTROY, "qp destroy:%d u:%d\n", yib_get_qp_sw_idx(yqp), yqp->is_user);
	yqp->valid = false;
	yib_elem_drop_ref(&yqp->entry);
	return 0;
}
#endif

static int yib_modify_qp(struct ib_qp *ibqp, struct ib_qp_attr *attr,
			 int mask, struct ib_udata *udata)
{
	int err;
	struct yusur_ib_dev *yib = to_yib(ibqp->device);
	struct yib_qp *qp = to_yib_qp(ibqp);
	struct yib_ib_modify_qp ureq;

	err = yib_qp_chk_attr(yib, qp, attr, mask);
	if (err) {
		os_printw(&ibqp->device->dev, "modify qp failed for check attr\n");
		goto err1;
	}

	if (mask & IB_QP_RATE_LIMIT) {
		if (udata) {
			if (ib_copy_from_udata((void *)&ureq, udata, sizeof(ureq))) {
				os_printw(&ibqp->device->dev, "modify qp failed for copy from udata");
				return -ENOMEM;
			}
		}
	}
	yib_qp_from_attr(yib, qp, attr, mask, ureq.cir, ureq.cbs);
err1:
	return err;		
}

static int yib_query_qp(struct ib_qp *ibqp, struct ib_qp_attr *attr,
			int mask, struct ib_qp_init_attr *init)
{
	struct yusur_ib_dev *yib = to_yib(ibqp->device);
	struct yib_qp *qp = to_yib_qp(ibqp);

	yib_qp_to_init(yib, qp, init);
	return yib_qp_to_attr(yib, qp, attr, mask);	
}

static int yib_post_send(struct ib_qp *ibqp, const_ struct ib_send_wr *wr,
			 const_ struct ib_send_wr **bad_wr)
{
	struct yusur_ib_dev *yib = to_yib(ibqp->device);
	struct yib_qp *qp = to_yib_qp(ibqp);
	if (qp->is_user) {
		return yib_user_post_send(yib, qp, wr, bad_wr);
	}
	return yib_sq_send_wr(yib, qp, wr, bad_wr);
}

static int yib_post_recv(struct ib_qp *ibqp, const_ struct ib_recv_wr *wr,
			 const_ struct ib_recv_wr **bad_wr)
{
	struct yusur_ib_dev *yib = to_yib(ibqp->device);
	struct yib_qp *qp = to_yib_qp(ibqp);
	if (qp->is_user) {
		return yib_user_post_recv(yib, qp, wr, bad_wr);
	}
	return yib_rq_recv_wr(yib, qp, wr, bad_wr);
}

void yib_pool_rq_cleanup(struct yib_pool_entry *arg)
{	
	struct yib_rq *yrq= container_of(arg, struct yib_rq, entry);
	
	if (yrq->bsrq) {
		struct yib_srq *ysrq = (struct yib_srq *)yrq->parent;
		struct yib_pd *ypd = to_yib_pd(ysrq->ib_srq.pd);
		if (ypd)
			yib_elem_drop_ref(&ypd->entry);	
	}
	
	yib_rq_free(yrq->yib, yrq);
}

#if IB_DESTROY_NO_UDATA == 0
#if IB_DESTROY_NO_RETURN == 0
static int yib_destroy_srq(struct ib_srq *ibsrq, struct ib_udata *udata)
#else
static void yib_destroy_srq(struct ib_srq *ibsrq, struct ib_udata *udata)
#endif
{
	struct yib_srq *ysrq = to_yib_srq(ibsrq);
	yib_elem_drop_ref(&ysrq->yrq->entry);
	#if IB_DESTROY_NO_RETURN == 0
	return 0;
	#endif
}
#endif

#if IB_LAYER_ALLOC_SRQ 
static int yib_create_srq(struct ib_srq *ibsrq, struct ib_srq_init_attr *init,
			  struct ib_udata *udata)
{
	struct yusur_ib_dev *yib = to_yib(ibsrq->device);
	struct yib_srq *ysrq = to_yib_srq(ibsrq);
	struct yib_pd *ypd = to_yib_pd(ibsrq->pd);
	struct yib_xrcd *yxrcd = NULL;
	struct ib_umem *umem_srq = NULL;
	int u_srq_len = 0;
	u8 ures[128];
	int ures_len = 0;
	int ret = 0;

	if (udata) {
		if (udata->outlen < 16) {
			os_printw(&ibsrq->device->dev, "create srq udata is not enough\n");
			return -EINVAL;
		}
	}

	yib_dbg_info(YUSUR_IB_M_RQ, YUSUR_IB_DBG_CREATE, "create srq begin  wr=%d sge=%d",
			 init->attr.max_wr, init->attr.max_sge);
	ret = yib_srq_chk_attr(yib, ysrq, init, IB_SRQ_INIT_MASK, &u_srq_len);
	if (ret != 0) {
		return -EINVAL;
	}
	yib_dbg_info(YUSUR_IB_M_RQ, YUSUR_IB_DBG_CREATE, "create srq afterchk  wr=%d sge=%d",
			 init->attr.max_wr, init->attr.max_sge);

	yxrcd = (init->srq_type == IB_SRQT_XRC)? (to_yib_xrcd(init->ext.xrc.xrcd)) : NULL;
	ibsrq->event_handler = init->event_handler;
	if (udata) {
		struct yib_ib_create_srq ureq;
		if (ib_copy_from_udata((void *)&ureq, udata, sizeof(ureq))) {
			os_printw(&ibsrq->device->dev, "srq create failed for copy from udata");
			return -ENOMEM;	
		}
	
		umem_srq = yib_umem_get_mem(&yib->ib_dev, ibsrq->pd->uobject->context, udata, ureq.srq_va, u_srq_len, IB_ACCESS_REMOTE_READ | IB_ACCESS_LOCAL_WRITE);
		if (IS_ERR(umem_srq)) {
			os_printw(&ibsrq->device->dev,
				  "failed to get ib umem for srq dma mem, error: %ld, bytes:%d\n",
				   PTR_ERR(umem_srq), u_srq_len);
			return -ENOMEM;
		}

		ret  = yib_srq_init_buf(yib, ysrq, &init->attr, yxrcd, umem_srq,
				 init->ext.cq? to_yib_cq(init->ext.cq):NULL);
		if (ret) {
			os_printw(&ibsrq->device->dev, "srq create failed init user buf\n");
			os_umem_release(umem_srq);
			return -ENOMEM;
		}
		ysrq->u_srq_handler = ureq.u_srq_handler;
		yib->host.hw_ops.get_queue_user_info(&yib->host, YIB_TYPE_RQ, ysrq, yib_get_rq_sw_idx(ysrq->yrq), ures, &ures_len);
		ret = ib_copy_to_udata(udata, ures, ures_len > sizeof(ures)? sizeof(ures): ures_len);	
		if (ret != 0) {
			os_printw(&ibsrq->device->dev, "sirq create failed for copy to udata\n");
			goto end;
		}
	} else {
		ret = yib_srq_init_buf(yib, ysrq, &init->attr, yxrcd, NULL,
		 		init->ext.cq? to_yib_cq(init->ext.cq):NULL);
		if (ret) {
			os_printw(&ibsrq->device->dev, "sirq create failed init kernel buf\n");
			return -ENOMEM;
		}
	}
	os_list_init(&ysrq->evt_limit_node);
	os_list_init(&ysrq->evt_err_node);
	os_list_init(&ysrq->evt_lastwqe_node);
	yib_elem_add_ref(&ypd->entry);
	return 0;
end:
	yib_elem_drop_ref(&ysrq->yrq->entry);
	return -ENOMEM;
}
#endif

int yib_modify_srq(struct ib_srq *ibsrq, struct ib_srq_attr *attr,
		       enum ib_srq_attr_mask attr_mask, struct ib_udata *udata)
{
	struct yusur_ib_dev *yib = to_yib(ibsrq->device);
	struct yib_srq *ysrq = to_yib_srq(ibsrq);
	struct yib_ib_modify_srq ureq;

	/* don't support resizing SRQs */
	if (attr_mask & IB_SRQ_MAX_WR)
		return -EINVAL;

	ureq.generate = 0;

	if (udata) {
		if (ib_copy_from_udata((void *)&ureq, udata, sizeof(ureq))) {
			os_printw(&ibsrq->device->dev, "cq resize failed for copy from udata\n");
			return -ENOMEM;
		}
	}

	if (ureq.generate == 0) {
		if (attr_mask & IB_SRQ_LIMIT) {
			ysrq->limit = attr->srq_limit;
		}
	} else {
		yib_run_srq_limit_evts(yib, ysrq);
	}
	return 0;
}

static int yib_query_srq(struct ib_srq *ibsrq, struct ib_srq_attr *attr)
{
	struct yib_srq *ysrq = to_yib_srq(ibsrq);
	attr->max_wr = ysrq->attr.max_wr;
	attr->max_sge = ysrq->attr.max_sge;
	attr->srq_limit = ysrq->limit;
	return 0;
}

static int yib_post_srq_recv(struct ib_srq *ibsrq, const_ struct ib_recv_wr *wr,
			     const_ struct ib_recv_wr **bad_wr)
{
	struct yusur_ib_dev *yib = to_yib(ibsrq->device);
	struct yib_srq *ysrq = to_yib_srq(ibsrq);
	return yib_srq_recv_wr(yib, ysrq, wr, bad_wr);
}

static void yib_get_dev_fw_str(struct ib_device *dev, char *str)
{
	struct yusur_ib_dev *yib = to_yib(dev);
	u32 date = u64_msb((yib->host.caps.fw_ver & 0xFFFFFFFF00000000));
	u32 ver = u64_lsb((yib->host.caps.fw_ver & 0xFFFFFFFF));

	snprintf(str, IB_FW_VERSION_NAME_MAX, "%04X.%02X.%02X.%04X%02X%02X",
		(int)(ver&0xF000>>12),(int)(ver&0xF00>>8), (int)(ver&0xFF),
		(u16)((date & 0xFFFF0000)>>16), (u8)((date&0x0000FF00)>> 8), (u8)(date & 0xFF));
}
#if IB_LAYER_ALLOC_XRCD == 1
static int yib_alloc_xrcd(struct ib_xrcd *ibxrcd, struct ib_udata *udata)
{
#if 0 //new_new todo
	struct yusur_ib_dev *yib = to_yib(ibxrcd->device);
	struct yib_xrcd *yxrcd = to_yib_xrcd(ibxrcd);
	yib_bmap_alloc_id(&yib->verbs.xrcd_map, &yxrcd->xrcd_val);
#else
	return 0;
#endif
}

static int yib_dealloc_xrcd(struct ib_xrcd *ibxrcd, struct ib_udata *udata)
{
#if 0 //new_new todo
	struct yusur_ib_dev *yib = to_yib(ibxrcd->device);
	struct yib_xrcd *yxrcd = to_yib_xrcd(ibxrcd);
	yib_bmap_release_id(&yib->verbs.xrcd_map, yxrcd->xrcd_val);
#else
	return 0;
#endif
}
#endif

#if IB_LAYER_ALLOC_MW == 1
static int yib_alloc_mw(struct ib_mw *ibmw, struct ib_udata *udata)
{
	struct yusur_ib_dev *yib = to_yib(ibmw->device);
	struct yib_pd *ypd = to_yib_pd(ibmw->pd);
	struct yib_mw *ymw = to_yib_mw(ibmw);
	struct yib_mr *ymr = NULL;
	bool buser = (udata)? true : false;

	if (ibmw->type != IB_MW_TYPE_1) {
		os_printw(&ibmw->device->dev, "mw type is not support\n");
		return -EINVAL;
	}

	ymr = yib_mw_alloc_new(yib, ymw, ypd, buser);
	if (ymr == NULL) {
		os_printw(&ibmw->device->dev, "yib_mw_alloc_new failed\n");
		return -ENOMEM;
	}

	ymr->state = YIB_MR_FREE;
	yib->host.sf.sf_ops->mr_mpt_update(&yib->host.sf, ymr);
	return 0;
}
#endif
int yib_dealloc_mw(struct ib_mw *ibmw)
{
	struct yib_mw *ymw = to_yib_mw(ibmw);
	struct yib_pd *ypd = to_yib_pd(ibmw->pd);
	struct yib_mr *ymr = ymw->pmr;
	yib_elem_drop_ref(&ypd->entry);
	yib_elem_drop_ref(&ymr->entry);
	return 0;
}

void os_ipaddr_to_array(os_ipaddr_t *ipaddr, u8 *ip_array, bool is_ipv6)
{
	u8 *dat = NULL;
	int i = 0;
	u32 val;

	if (is_ipv6) {
		dat = (u8*)&ipaddr->_sockaddr_in6.sin6_addr.s6_addr;
		for (i = 0; i < 4; i++) {
			val = net_addr2_le32(dat + 4 * (3 - i));
			writel(val, ip_array + i*4);
		}
	} else {
		dat = (u8*)&ipaddr->_sockaddr_in.sin_addr.s_addr;
		writel(net_addr2_le32(dat), ip_array);
	}
}

#if IBDEV_NO_OPS == 0
const struct ib_device_ops yib_dev_ops = {
	.owner	= THIS_MODULE,
	.driver_id = RDMA_DRIVER_ID_YUSUR, //rdma-core can use VERBS_DRIVER_ID to match instead of pci id
	.uverbs_abi_ver	= 1,
#if (HW_STAT_FOR_PORT)
	.alloc_hw_port_stats = yib_ib_alloc_hw_stats,
#else
	.alloc_hw_stats = yib_ib_alloc_hw_stats,
#endif
	.get_hw_stats = yib_ib_get_hw_stats,

	.query_device	= yib_query_device, 
	.query_port	= yib_query_port,
	.query_pkey	= yib_query_pkey,
	.get_dev_fw_str = yib_get_dev_fw_str,
	.add_gid	= yib_add_gid,
	.del_gid	= yib_del_gid,
	.get_link_layer	= yib_get_link_layer,
	.get_port_immutable	= yib_port_immutable,
	.get_netdev	= yib_get_netdev,

	.alloc_pd	= yib_alloc_pd,	
	.dealloc_pd	= yib_dealloc_pd,

	.create_ah	= yib_create_ah,
	.destroy_ah	= yib_destroy_ah,
	.query_ah       = yib_query_ah,
	.modify_ah      = yib_modify_ah,
#if HAS_USER_AH_CREATE
	.create_user_ah = yib_create_ah,	
#endif

	.dealloc_ucontext = yib_dealloc_ucontext,
	.alloc_ucontext	= yib_alloc_ucontext,	
	.mmap	        = yib_mmap,

	.alloc_mr	= yib_alloc_mr, //this api is used by kernel only
	.get_dma_mr	= yib_get_dma_mr, //called yb alloc_pd in core
	.map_mr_sg	= yib_map_mr_sg, //called in kernel usage
	.reg_user_mr	= yib_reg_user_mr, //user mode only
	.dereg_mr	= yib_dereg_mr, //both kernel or user

	.create_cq	= yib_create_cq,
	.destroy_cq	= yib_destroy_cq,
	.req_notify_cq  = yib_notify_cq,
	.poll_cq        = yib_poll_cq,
	.resize_cq      = yib_resize_cq,

	.create_qp	= yib_create_qp,
	.destroy_qp	= yib_destroy_qp,
	.modify_qp	= yib_modify_qp,
	.query_qp	= yib_query_qp,

	.post_send	= yib_post_send,
	.post_recv	= yib_post_recv,

	.create_srq = yib_create_srq,
	.modify_srq = yib_modify_srq,
	.destroy_srq = yib_destroy_srq,
	.post_srq_recv = yib_post_srq_recv,
	.query_srq = yib_query_srq,

	.alloc_xrcd = yib_alloc_xrcd,
	.dealloc_xrcd = yib_dealloc_xrcd,
	.alloc_mw = yib_alloc_mw,
	.dealloc_mw = yib_dealloc_mw,

#if IB_DEV_HAS_SYS
#if IB_HAS_SYS_GROUP
	.device_group = &yib_sys_attr_group,
#endif	
#endif

#if IB_LAYER_ALLOC_QP   
        INIT_RDMA_OBJ_SIZE(ib_qp, yib_qp, ib_qp),
#endif
	INIT_RDMA_OBJ_SIZE(ib_ah, yib_ah, ib_ah),
	INIT_RDMA_OBJ_SIZE(ib_cq, yib_cq, ib_cq),
	INIT_RDMA_OBJ_SIZE(ib_pd, yib_pd, ib_pd),
	INIT_RDMA_OBJ_SIZE(ib_srq, yib_srq, ib_srq),
	INIT_RDMA_OBJ_SIZE(ib_ucontext, yib_ucontext, ib_uc),
	INIT_RDMA_OBJ_SIZE(ib_xrcd, yib_xrcd, ib_xrcd),
	INIT_RDMA_OBJ_SIZE(ib_mw, yib_mw, ib_mw),
};
#endif

#include "ib_old.c"
