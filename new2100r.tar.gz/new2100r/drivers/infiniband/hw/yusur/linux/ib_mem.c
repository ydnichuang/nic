#include <rdma/ib_mad.h>
#include <rdma/ib_addr.h>
#include <rdma/ib_user_verbs.h>
#include <rdma/ib_cache.h>
#include <rdma/ib_umem.h>
#include <rdma/ib_verbs.h>
#include <linux/log2.h>
#include <rdma/uverbs_ioctl.h>
#include <linux/yusur/yusur_peer.h>
#include "../include/basic.h"
#include <linux/yusur/yrdma_model.h>
#include "../include/os_api.h"
#include "../include/os_ds.h"
#include "../include/mem.h"
#include "../include/queue.h"
#include "../include/host.h"
#include "../include/verbs.h"
#include "../include/yusur_ib.h"
#include "../include/core.h"
#include "../include/user.h"
#include "priv.h"
#include "ib.h"

#define PAGE_SIZE_4K		BIT(12)
#define PAGE_SIZE_8K		BIT(13)
#define PAGE_SIZE_64K		BIT(16)
#define PAGE_SIZE_2M		BIT(21)
#define PAGE_SIZE_8M		BIT(23)
#define PAGE_SIZE_1G		BIT(30)
#define PAGE_SIZE_MASK_ALL PAGE_SIZE_4K | PAGE_SIZE_8K | PAGE_SIZE_64K | PAGE_SIZE_2M | PAGE_SIZE_8M | PAGE_SIZE_1G

static inline __attribute__((const))
int __yib_bits_per(unsigned long n)
{
	if (n < 2)
		return 1;
	if (is_power_of_2(n))
		return order_base_2(n) + 1;
	return order_base_2(n);
}

/**
 * bits_per - calculate the number of bits required for the argument
 * @n: parameter
 *
 * This is constant-capable and can be used for compile time
 * initializations, e.g bitfields.
 *
 * The first few values calculated by this routine:
 * bf(0) = 1
 * bf(1) = 1
 * bf(2) = 2
 * bf(3) = 2
 * bf(4) = 3
 * ... and so on.
 */
#define yib_bits_per(n)				\
(						\
	__builtin_constant_p(n) ? (		\
		((n) == 0 || (n) == 1)		\
			? 1 : ilog2(n) + 1	\
	) :					\
	__yib_bits_per(n)				\
)

static inline int yib_count_trailing_zeros(unsigned long x)
{
#define COUNT_TRAILING_ZEROS_0 (-1)

	if (sizeof(x) == 4)
		return ffs(x);
	else
		return (x != 0) ? __ffs(x) : COUNT_TRAILING_ZEROS_0;
}

//bar的就直接映射，不是bar的按物理地址空间映射
static int yib_reg_phy_mmap(struct yib_hw_host *host, struct vm_area_struct *vma, ssize_t length, u64 qid_or_addr)
{
	int ret = 0;
	ret = host->hw_ops.host_reg_mmap(host, vma, length, qid_or_addr);
	if (ret) {
		os_printe(host->dev, "Failed to map device memory");
		return ret;
	}

	yib_pr_info(YUSUR_IB_DBG_INIT, "%s : length: %d \n",
		__func__, (int)length);
	return 0;
}

static int yib_ram_mmap(struct yib_hw_host *host, struct vm_area_struct *vma, ssize_t length, yib_mmap_t type)
{
	struct yib_db_frag *db_frag = &host->db_frag;
	struct yib_frag_buf *frag_buf = NULL;
	unsigned long remap_size;
	uint32_t frag_sz;
	int nfrags_need;
	int i;

	switch (type)
	{
		case YIB_MMAP_TYPE_CQ:
			frag_buf = db_frag->cq_info;
			break;
		case YIB_MMAP_TYPE_SQ:
			frag_buf = db_frag->sq_info;
			break;
		case YIB_MMAP_TYPE_RQ:
			frag_buf = db_frag->rq_info;
			break;
		default:
			break;
	}

	if (frag_buf == NULL)
		return -ENOMEM;

	frag_sz = yib_frag_get_pagesz(frag_buf);
	nfrags_need = DIV_ROUND_UP(length, frag_sz);
	for (i = 0; i < nfrags_need; i++) {
		if (frag_sz * (i+1) > length)
			remap_size = length - frag_sz * i;
		else
			remap_size = frag_sz;

		if (remap_pfn_range(vma, vma->vm_start + i*frag_sz, frag_buf->frags[i].dma_addr >> PAGE_SHIFT,
							remap_size, vma->vm_page_prot)) {
			os_printe(host->dev, "Failed to map ram memory");
			return -EAGAIN;
		}
	}

	yib_pr_info(YUSUR_IB_DBG_INIT, "%s : RAM phy_addr: %llx length: %d \n",
		__func__, frag_buf->frags->dma_addr, (int)length);

	return 0;
}

static int yib_priority_mmap(struct yib_hw_host *host, struct vm_area_struct *vma, ssize_t length, u64 qid_or_addr)
{
	u64 array_addr = host->prio_array.dma_addr;

	if (array_addr == 0) {
		os_printe(host->dev, "array_addr invalid");
		return -EINVAL;
	} else {
		if (remap_pfn_range(vma, vma->vm_start, array_addr >> PAGE_SHIFT, length, vma->vm_page_prot)) {
			os_printe(host->dev, "Failed to map prio array mem memory");
			return -EAGAIN;
		}
	}
	return 0;
}

//off低28Bit为qid_or_addr, 29-32bit为type
//用户态传入时会左移PAGE_SHIFT, 内核会右移PAGE_SHIFT，此处不用移位
static void yib_get_command(off_t off, yib_mmap_t *type, u64 *qid_or_addr)
{
	*qid_or_addr = off & 0x0FFFFFFF; //28bit
	*type = (off >> 28) & 0xf;	//4bit
}

int yib_mmap(struct ib_ucontext *ibucontext, struct vm_area_struct *vma)
{
	struct ib_device *ib_dev = ibucontext->device;
	struct yusur_ib_dev *yib = to_yib(ib_dev);
	ssize_t length;
	yib_mmap_t type;
	u64 qid_or_addr;
	int ret = 0;

	yib_get_command(vma->vm_pgoff, &type, &qid_or_addr);

	if (((vma->vm_end - vma->vm_start) % PAGE_SIZE) != 0)
		return -EINVAL;
	length = vma->vm_end - vma->vm_start;
	vma->vm_page_prot = pgprot_noncached(vma->vm_page_prot);

	yib_dbg_info(YUSUR_IB_M_CORE_VERBS, YUSUR_IB_DBG_INIT, "yib mmap type=%d, qid_or_addr=0x%08llx, length=%d",
				type, qid_or_addr, (int)length);

	switch (type)
	{
		case YIB_MMAP_TYPE_REG:
			ret = yib_reg_phy_mmap(&yib->host, vma, length, qid_or_addr);
			break;
		case YIB_MMAP_TYPE_CQ:
		case YIB_MMAP_TYPE_SQ:
		case YIB_MMAP_TYPE_RQ:
			ret = yib_ram_mmap(&yib->host, vma, length, type);
			break;
		case YIB_MMAP_TYPE_PRIO:
			ret = yib_priority_mmap(&yib->host, vma, length, qid_or_addr);
			break;
			break;
		case YIB_MMAP_TYPE_HW1:
		case YIB_MMAP_TYPE_HW2:
		case YIB_MMAP_TYPE_HW3:
		case YIB_MMAP_TYPE_HW4:
		case YIB_MMAP_TYPE_HW5:
		case YIB_MMAP_TYPE_HW6:
		case YIB_MMAP_TYPE_HW7:
		case YIB_MMAP_TYPE_HW8:
			ret = yib->host.hw_ops.host_def_mmap(&yib->host, vma, length, qid_or_addr, type);
			break;
		default:
			break;
	}
	return ret;
}

void yib_sglist_dump(struct ib_umem *umem, int npages, u32 page_size)
{
	struct scatterlist *sg;
	u64 sg_page_pa;
	int len = 0;
	int i;

	yib_dbg_info(YUSUR_IB_M_MR_MTT, YUSUR_IB_DBG_SGLIST, "######### sglist dump BEGIN#####\n");
	yib_dbg_info(YUSUR_IB_M_MR_MTT, YUSUR_IB_DBG_SGLIST, "sgl best page_size: %d, npages: %d\n", page_size, npages);
#if (IB_UMEM_SGITER == 1)
	for_each_sgtable_dma_sg(&umem->sgt_append.sgt, sg, i) {
		sg_page_pa = sg_dma_address(sg);
		len = sg_dma_len(sg);
		yib_dbg_info(YUSUR_IB_M_MR_MTT, YUSUR_IB_DBG_SGLIST, "sgl_page%d len %d: %llX\n", i, len, sg_page_pa);
	}
#else
	for_each_sg(umem->sg_head.sgl, sg, umem->nmap, i) {
		sg_page_pa = sg_dma_address(sg);
		len = sg_dma_len(sg);
		yib_dbg_info(YUSUR_IB_M_MR_MTT, YUSUR_IB_DBG_SGLIST, "sgl_page%d len %d: %llX\n", i, len, sg_page_pa);
	}
#endif
	yib_dbg_info(YUSUR_IB_M_MR_MTT, YUSUR_IB_DBG_SGLIST, "######### sglist dump END#######\n");
}

unsigned long yib_umem_find_best_pgsz(struct ib_umem *umem,
					unsigned long pgsz_bitmap,
					u64 virt, u32 *nsg, u64 *pa)
{
	struct scatterlist *sg;
	u64 va, pgoff;
	dma_addr_t mask;
	int i;

	va = virt;
	mask = pgsz_bitmap &
			GENMASK(BITS_PER_LONG - 1, yib_bits_per((umem->length - 1 + virt) ^ virt));
	/* offset into first SGL */
	pgoff = umem->address & ~PAGE_MASK;

#if (IB_UMEM_SGITER == 1)
	for_each_sgtable_dma_sg(&umem->sgt_append.sgt, sg, i) {
		if (i == 0)
			*pa = sg_dma_address(sg);
		mask |= (sg_dma_address(sg) + pgoff) ^ va;
		va += sg_dma_len(sg) - pgoff;

		if (i != (umem->sgt_append.sgt.nents - 1))
			mask |= va;
		pgoff = 0;
	}
#else
	for_each_sg(umem->sg_head.sgl, sg, umem->nmap, i) {
		if (i == 0)
			*pa = sg_dma_address(sg);
		mask |= (sg_dma_address(sg) + pgoff) ^ va;
		va += sg_dma_len(sg) - pgoff;

		if (i != (umem->nmap - 1))
			mask |= va;
		pgoff = 0;
	}
#endif
	*nsg = i;
	if (mask)
		pgsz_bitmap &= GENMASK(yib_count_trailing_zeros(mask), 0);
	return rounddown_pow_of_two(pgsz_bitmap);
}

static int yib_set_page(struct ib_mr *ibmr, u64 addr)
{
	struct yib_mr *ymr = to_yib_mr(ibmr);
	struct yusur_ib_dev *yib = to_yib(ibmr->device);
	__le64 *descs;

	if (unlikely(ymr->priv.fmr->ndescs == ymr->priv.fmr->max_descs)) {
		os_printe(&yib->ib_dev.dev, "fmr page nums is wrong\n");
		return -ENOMEM;
	}

	descs = ymr->priv.fmr->descs;
	descs[ymr->priv.fmr->ndescs++] = cpu_to_le64(addr);

	return 0;
}

int yib_map_mr_sg(struct ib_mr *ibmr, struct scatterlist *sglist,
			 int sg_nents, unsigned int *sg_offset)
{
	struct yib_mr *ymr = to_yib_mr(ibmr);
	struct yusur_ib_dev *yib = to_yib(ibmr->device);
	unsigned int offset = sg_offset ? *sg_offset : 0;
	int ret = 0;

	if (ymr->type.is_dma || ymr->type.is_user || ymr->priv.fmr == NULL) {
		os_printw(&yib->ib_dev.dev, "Failed to map mr sg for state is wrong\n");
		return -EINVAL;
	}

	ymr->priv.fmr->ndescs = 0;
	ymr->priv.fmr->pa = sg_dma_address(&sglist[0]) + offset;

	ib_dma_sync_single_for_cpu(ibmr->device, ymr->priv.fmr->desc_map,
				   ymr->priv.fmr->desc_size * ymr->priv.fmr->max_descs,
				   DMA_TO_DEVICE);


	ret = ib_sg_to_pages(ibmr, sglist, sg_nents, sg_offset,
			yib_set_page);

	ib_dma_sync_single_for_device(ibmr->device, ymr->priv.fmr->desc_map,
				      ymr->priv.fmr->desc_size * ymr->priv.fmr->max_descs,
				      DMA_TO_DEVICE);

	ymr->state = YIB_MR_VALID;
	return ret;
}

struct ib_umem *yib_umem_get_mem(struct ib_device *device, struct ib_ucontext *context, struct ib_udata *udata,
								unsigned long addr, size_t size, int access)
{
	struct ib_umem *umem = NULL;
#if IB_UMEM_GET_VERSION == 2
	umem = ib_umem_get(device, addr, size, access);
#elif IB_UMEM_GET_VERSION == 1
	umem = ib_umem_get(context, addr, size, access, 1);
#elif IB_UMEM_GET_VERSION == 0
	umem = ib_umem_get(udata, addr, size, access);
#else 
	umem = ib_umem_get(udata, addr, size, access, 0);
#endif
	return umem;
}

//only for mr
static struct ib_umem *yib_umem_get_mem_peer(struct ib_device *device, struct ib_pd *ibpd, struct ib_udata *udata,
								unsigned long addr, size_t size, int access, int dmasync,
								unsigned long peer_mem_flags, bool *is_peer)
{
	struct ib_umem *umem = NULL;
#ifdef GDR_PEER_MEMORY
	bool ispeer = false;
	#if IB_UMEM_GET_VERSION == 2
		/* umem = ib_umem_get_peer(ibpd->uobject->context, start, length, access, &ispeer); */
		umem = ib_umem_get_peer(device, addr, size, access, 0, &ispeer);
		*is_peer = ispeer;
	#elif IB_UMEM_GET_VERSION == 1
		umem = ib_umem_get_peer(ibpd->uobject->context, addr, size, access, &ispeer);
		*is_peer = ispeer;
	#elif IB_UMEM_GET_VERSION == 0
		umem = ib_umem_get_peer(udata, addr, size, access, peer_mem_flags, &ispeer);
		*is_peer = ispeer;
	#else 
		umem = ib_umem_get(udata, addr, size, access, 0);
	#endif
#else
	umem = yib_umem_get_mem(device, ibpd->uobject->context, udata, addr, size, access);
#endif
	return umem;
}

static inline size_t yib_umem_num_dma_blocks(struct ib_umem *umem, unsigned long pgsz)
{
#if HAS_IB_UMEM_NUM_DMA_BLOCKS
	return ib_umem_num_dma_blocks(umem, pgsz);
#else
	return (ib_umem_end(umem) - ib_umem_start(umem)) / pgsz;
#endif
}

struct ib_mr *yib_reg_user_mr(struct ib_pd *ibpd, u64 start, u64 length,
							u64 iova, int access, struct ib_udata *udata)
{
	struct yib_mr *ymr = NULL;
	struct yib_pd *ypd = to_yib_pd(ibpd);
	struct yusur_ib_dev *yib = to_yib(ibpd->device);
	struct yib_ib_reg_mr ureq;
	struct ib_umem *umem;
	bool ispeer = false;
	struct scatterlist *sglist;
	int nsg, npages;
	u32 page_size;
	u32 sg_offset;
	u64 sg_pa;
	int ret = 0;

	if (udata) {
		if (ib_copy_from_udata((void *)&ureq, udata, sizeof(ureq))) {
			os_printw(&ibpd->device->dev, "mr reg failed for copy from udata\n");
			return ERR_PTR(-ENOMEM);
		}
	}

	ymr = yib_mr_alloc_new(yib, ypd, true, false, false);
	if (IS_ERR(ymr)) {
		os_printe(&ibpd->device->dev, "alloc user mr failed\n");
		return (struct ib_mr *)ymr;
	}

	if (udata)
		ymr->u_mr_handler = ureq.u_mr_handler;

	ymr->access = access;
	ymr->ib_mr.device = ibpd->device;//上层在调用完成之后才赋值， 这里提前复制， 错误clean时会用到
	yib_dbg_info(YUSUR_IB_M_MR, YUSUR_IB_DBG_CREATE, "user mr alloc:%d\n", yib_get_mr_sw_idx(ymr));

	umem = yib_umem_get_mem_peer(&yib->ib_dev, ibpd, udata, start, length, access, 1, 1, &ispeer);
	if (IS_ERR(umem) || umem == NULL) {
		os_printe(&yib->ib_dev.dev, "Failed to map mr memory\n");
		goto end;
	}
	ymr->type.is_peer = ispeer;
	ymr->umem = umem;

#if (IB_UMEM_SGITER)
	sglist = umem->sgt_append.sgt.sgl;
#else
	//os兼容性问题
	sglist = umem->sg_head.sgl;
#endif

	sg_offset = ib_umem_offset(umem);
	page_size = yib_umem_find_best_pgsz(umem, PAGE_SIZE_MASK_ALL, iova, &nsg, &sg_pa);
	sg_pa += sg_offset;

	ymr->state = YIB_MR_VALID;
	yib_os_mr_iova(ymr) = iova;
	yib_os_mr_length(ymr) = length;
	npages = yib_umem_num_dma_blocks(umem, page_size);

	yib_sglist_dump(umem, npages, page_size);
	ret = yib->host.sf.sf_ops->mr_mtt_init(&yib->host.sf, ymr, sglist, npages, page_size, sg_pa);
	if (ret) {
		os_printe(&yib->ib_dev.dev, "Failed to update mtt\n");
		ymr->state = YIB_MR_INVALID;
		goto end;
	}

	ret = yib->host.sf.sf_ops->mr_mpt_update(&yib->host.sf, ymr);
	if (ret) {
		os_printe(&yib->ib_dev.dev, "Failed to update mpt\n");
		ymr->state = YIB_MR_INVALID;
		goto end;
	}

	yib_dbg_info(YUSUR_IB_M_MR, YUSUR_IB_DBG_CREATE, "user mr mtt done:%d key=0x%08X\n",
		yib_get_mr_sw_idx(ymr), ymr->ib_mr.rkey);
	return &ymr->ib_mr;
end:
	yib_mr_dealloc(ymr, ypd);
	return ERR_PTR(-EFAULT);
}
