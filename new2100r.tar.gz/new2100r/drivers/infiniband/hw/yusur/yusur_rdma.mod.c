#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x602c1205, "module_layout" },
	{ 0x5b3275d8, "ib_set_device_ops" },
	{ 0x41964dfe, "kmalloc_caches" },
	{ 0xeb233a45, "__kmalloc" },
	{ 0xf9a482f9, "msleep" },
	{ 0xb964f2b9, "yrdma_driver_unregister" },
	{ 0xcfd22645, "debugfs_create_dir" },
	{ 0xd6ee688f, "vmalloc" },
	{ 0x350f6ce5, "tasklet_unlock_wait" },
	{ 0x9bf7e9ba, "ib_device_put" },
	{ 0x54b1fac6, "__ubsan_handle_load_invalid_value" },
	{ 0x46cf10eb, "cachemode2protval" },
	{ 0x5021bd81, "_raw_write_lock_irqsave" },
	{ 0xa07d1b3c, "tasklet_setup" },
	{ 0x8593befc, "ib_get_eth_speed" },
	{ 0x48d490a8, "dma_set_mask" },
	{ 0xcb2f2b52, "boot_cpu_data" },
	{ 0xd36dc10c, "get_random_u32" },
	{ 0xe0112fc4, "__x86_indirect_thunk_r9" },
	{ 0xd2da1048, "register_netdevice_notifier" },
	{ 0x56470118, "__warn_printk" },
	{ 0x66cca4f9, "__x86_indirect_thunk_rcx" },
	{ 0x87b8798d, "sg_next" },
	{ 0x2d5f69b3, "rcu_read_unlock_strict" },
	{ 0x3213f038, "mutex_unlock" },
	{ 0x999e8297, "vfree" },
	{ 0x97892f52, "dma_free_attrs" },
	{ 0x716589cc, "debugfs_create_file" },
	{ 0xa648e561, "__ubsan_handle_shift_out_of_bounds" },
	{ 0x97651e6c, "vmemmap_base" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0x683eadc2, "kthread_create_on_node" },
	{ 0xcce0d0b6, "dma_set_coherent_mask" },
	{ 0x15ba50a6, "jiffies" },
	{ 0x9d0d6206, "unregister_netdevice_notifier" },
	{ 0xeb078aee, "_raw_write_unlock_irqrestore" },
	{ 0x76f64ddd, "ib_dealloc_device" },
	{ 0xda2b8f7f, "__yrdma_driver_register" },
	{ 0x6b10bee1, "_copy_to_user" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0x25974000, "wait_for_completion" },
	{ 0x31549b2a, "__x86_indirect_thunk_r10" },
	{ 0x24ec18f, "_dev_warn" },
	{ 0xfb578fc5, "memset" },
	{ 0xe1997c69, "dma_sync_single_for_cpu" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0xcefb0c9f, "__mutex_init" },
	{ 0xbcab6ee6, "sscanf" },
	{ 0xa50a3da7, "_find_next_bit" },
	{ 0x4c9d28b0, "phys_base" },
	{ 0x1a79c8e9, "__x86_indirect_thunk_r13" },
	{ 0x9d2ab8ac, "__tasklet_schedule" },
	{ 0x3698aaf8, "ib_query_port" },
	{ 0x323c3952, "debugfs_remove" },
	{ 0x3cef829f, "dma_alloc_attrs" },
	{ 0x4dfa8d4b, "mutex_lock" },
	{ 0x1680f69d, "ib_umem_get" },
	{ 0x9be996d9, "ib_device_set_netdev" },
	{ 0x55385e2e, "__x86_indirect_thunk_r14" },
	{ 0x8c8569cb, "kstrtoint" },
	{ 0x6e8b2ed5, "hados_doe_array_read_clear" },
	{ 0x6b958320, "ib_ud_ip4_csum" },
	{ 0x84069228, "simple_open" },
	{ 0xd922ffe7, "pci_request_irq" },
	{ 0x3e3d3caa, "_dev_err" },
	{ 0xb7852a05, "ib_ud_header_init" },
	{ 0x5f895fb0, "ib_dispatch_event" },
	{ 0xea3c74e, "tasklet_kill" },
	{ 0x800473f, "__cond_resched" },
	{ 0x7cd8d75e, "page_offset_base" },
	{ 0x87a21cb3, "__ubsan_handle_out_of_bounds" },
	{ 0xe4e3912f, "hados_doe_delete_arraytbl" },
	{ 0xb1342cdb, "_raw_read_lock_irqsave" },
	{ 0x6383b27c, "__x86_indirect_thunk_rdx" },
	{ 0x618911fc, "numa_node" },
	{ 0xa916b694, "strnlen" },
	{ 0x330632b2, "pci_free_irq" },
	{ 0x296695f, "refcount_warn_saturate" },
	{ 0xd0da656b, "__stack_chk_fail" },
	{ 0x258dd5cd, "ib_register_device" },
	{ 0x1000e51, "schedule" },
	{ 0x92997ed8, "_printk" },
	{ 0x643ead61, "dma_map_page_attrs" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0xe356ebdb, "ib_unregister_device" },
	{ 0xdf2ebb87, "_raw_read_unlock_irqrestore" },
	{ 0xb83420a9, "dev_driver_string" },
	{ 0x481ead8c, "wake_up_process" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0xcbd4898c, "fortify_panic" },
	{ 0x5bb7b46f, "kmem_cache_alloc_trace" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0x21c86242, "_ib_alloc_device" },
	{ 0x148653, "vsnprintf" },
	{ 0xbb4f4766, "simple_write_to_buffer" },
	{ 0x37a0cba, "kfree" },
	{ 0xff1a2262, "remap_pfn_range" },
	{ 0xf521f28b, "ib_sg_to_pages" },
	{ 0x69acdf38, "memcpy" },
	{ 0xf6f8f718, "hados_doe_array_load" },
	{ 0x7b37d4a7, "_find_first_zero_bit" },
	{ 0xe7bbdda1, "dma_sync_single_for_device" },
	{ 0x5634a098, "hados_doe_create_arraytbl" },
	{ 0x73baf9a2, "ib_modify_qp_is_ok" },
	{ 0xa1496fdf, "dma_unmap_page_attrs" },
	{ 0x608741b5, "__init_swait_queue_head" },
	{ 0xc3ff9d0e, "hados_doe_array_store" },
	{ 0xe9e799fc, "ib_ud_header_pack" },
	{ 0x9f3a9f4c, "rdma_read_gid_l2_fields" },
	{ 0xa6257a2f, "complete" },
	{ 0x656e4a6e, "snprintf" },
	{ 0x3781ab4c, "yusur_intf_get_netdev_from_bonding" },
	{ 0x7f02188f, "__msecs_to_jiffies" },
	{ 0x13c49cc2, "_copy_from_user" },
	{ 0x4e0722a5, "ib_umem_release" },
	{ 0x88db9f48, "__check_object_size" },
	{ 0xc31db0ce, "is_vmalloc_addr" },
	{ 0xab65ed80, "set_memory_uc" },
	{ 0x8a35b432, "sme_me_mask" },
};

MODULE_INFO(depends, "ib_core,yusur_model,ib_uverbs,ys_doe");


MODULE_INFO(srcversion, "CD720C1AE1EA5AB4B60EE0C");
