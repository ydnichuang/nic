#include <linux/device.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/string.h>
#include <linux/pm_domain.h>
#include <linux/pm_runtime.h>
#include <linux/mod_devicetable.h>
#include <linux/netdevice.h>
#include <linux/pci.h>
#include <linux/yusur/compiler.h>
#include <linux/yusur/yrdma_model.h>
#include "rdma_model.h"

#ifdef pr_fmt
#undef pr_fmt
#endif
#define pr_fmt(fmt) "%s:%s: " fmt, KBUILD_MODNAME, __func__

#define DRV_VER	__stringify(DRV_VER_MAJOR) "."		\
	__stringify(DRV_VER_MINOR) "." __stringify(DRV_VER_BUILD)
 
static int __yrdma_device_add(struct yrdma_device *ydev, const char *modname);
#define yrdma_device_add(ydev) __yrdma_device_add(ydev, KBUILD_MODNAME)

static inline void yrdma_device_uninit(struct yrdma_device *ydev)
{
	put_device(&ydev->dev);
}

static inline void yrdma_device_delete(struct yrdma_device *ydev)
{
	device_del(&ydev->dev);
}

static const struct yrdma_device_id *yrdma_match_id(const struct yrdma_device_id *id,
							    const struct yrdma_device *ydev)
{
	for (; id->name[0]; id++) {
		const char *p = strrchr(dev_name(&ydev->dev), '.');
		int match_size;

		if (!p)
			continue;
		match_size = p - dev_name(&ydev->dev);

		if (strlen(id->name) == match_size &&
		    !strncmp(dev_name(&ydev->dev), id->name, match_size))
			return id;
	}
	return NULL;
}

static int yrdma_match(struct device *dev, struct device_driver *drv)
{
	struct yrdma_device *ydev = to_yrdma_dev(dev);
	struct yrdma_driver *ydrv = to_yrdma_drv(drv);

	return !!yrdma_match_id(ydrv->id_table, ydev);
}

#if BUS_TYPE_UEVENT_NEED_CONST
static int yrdma_uevent(const struct device *dev, struct kobj_uevent_env *env)
#else
static int yrdma_uevent(struct device *dev, struct kobj_uevent_env *env)
#endif
{
	const char *name, *p;

	name = dev_name(dev);
	p = strrchr(name, '.');

	return add_uevent_var(env, "MODALIAS=%s%.*s", YRDMA_MODULE_PREFIX,
			      (int)(p - name), name);
}

static const struct dev_pm_ops yrdma_dev_pm_ops = {
	SET_RUNTIME_PM_OPS(pm_generic_runtime_suspend, pm_generic_runtime_resume, NULL)
	SET_SYSTEM_SLEEP_PM_OPS(pm_generic_suspend, pm_generic_resume)
};

static int yrdma_bus_probe(struct device *dev)
{
	struct yrdma_driver *ydrv = to_yrdma_drv(dev->driver);
	struct yrdma_device *ydev = to_yrdma_dev(dev);
	int ret;

#if DEV_HAS_PMD_ATTACH
	ret = dev_pm_domain_attach(dev, true);
	if (ret) {
		dev_warn(dev, "Failed to attach to PM Domain : %d\n", ret);
		return ret;
	}

	ret = ydrv->probe(ydev, yrdma_match_id(ydrv->id_table, ydev));
	if (ret)
		dev_pm_domain_detach(dev, true);
#else
	ret = ydrv->probe(ydev, yrdma_match_id(ydrv->id_table, ydev));
#endif
	return ret;
}

#if YRDMA_BUS_REMOVE_VOID
static void yrdma_bus_remove(struct device *dev)
#else
static int yrdma_bus_remove(struct device *dev)
#endif
{
	struct yrdma_driver *ydrv = to_yrdma_drv(dev->driver);
	struct yrdma_device *ydev = to_yrdma_dev(dev);

	if (ydrv->remove)
		ydrv->remove(ydev);
#if DEV_HAS_PMD_ATTACH
	dev_pm_domain_detach(dev, true);
#endif
#if YRDMA_BUS_REMOVE_VOID
#else
	return 0;
#endif
}

static void yrdma_bus_shutdown(struct device *dev)
{
	struct yrdma_driver *ydrv = NULL;
	struct yrdma_device *ydev;

	if (dev->driver) {
		ydrv = to_yrdma_drv(dev->driver);
		ydev = to_yrdma_dev(dev);
	}

	if (ydrv && ydrv->shutdown)
		ydrv->shutdown(ydev);
}

static struct bus_type yrdma_bus_type = {
	.name = "yrdma",
	.probe = yrdma_bus_probe,
	.remove = yrdma_bus_remove,
	.shutdown = yrdma_bus_shutdown,
	.match = yrdma_match,
	.uevent = yrdma_uevent,
	.pm = &yrdma_dev_pm_ops,
};

static int yrdma_device_init(struct yrdma_device *ydev)
{
	struct device *dev = &ydev->dev;

	if (!dev->parent) {
		pr_err("yrdma_device has a NULL dev->parent\n");
		return -EINVAL;
	}

	if (strlen(ydev->name) == 0) {
		pr_err("yrdma_device has a NULL name\n");
		return -EINVAL;
	}

	dev->bus = &yrdma_bus_type;
	device_initialize(&ydev->dev);
	return 0;
}


static int __yrdma_device_add(struct yrdma_device *ydev, const char *modname)
{
	struct device *dev = &ydev->dev;
	struct yusur_rdma_dev *yrdev = container_of(ydev, struct yusur_rdma_dev, ydev);
	int ret;

	if (!modname) {
		dev_err(dev, "yrdma device modname is NULL\n");
		return -EINVAL;
	}

	ret = dev_set_name(dev, "%s.%d-%s", ydev->name, ydev->id, yrdev->ndev[0]->name);
	if (ret) {
		dev_err(dev, "yrdma device dev_set_name failed: %d\n", ret);
		return ret;
	}

	ret = device_add(dev);
	if (ret)
		dev_err(dev, "adding yrdma device failed!: %d\n", ret);

	return ret;
}

struct yrdma_device *yrdma_find_device(struct device *start,
					       const void *data,
					       int (*match)(struct device *dev, const void *data))
{
	struct device *dev;
#if PCI_BUS_FIND_CONST  ==    1
	dev = bus_find_device(&yrdma_bus_type, start, data, match);
#else
	dev = bus_find_device(&yrdma_bus_type, start, (void*)data, (void*)match);
#endif
	if (!dev)
		return NULL;

	return to_yrdma_dev(dev);
}

int __yrdma_driver_register(struct yrdma_driver *ydrv,
				struct module *owner, const char *modname)
{
	if (WARN_ON(!ydrv->probe) || WARN_ON(!ydrv->id_table))
		return -EINVAL;

	if (ydrv->name)
		ydrv->driver.name = kasprintf(GFP_KERNEL, "%s.%s", modname,
						ydrv->name);
	else
		ydrv->driver.name = kasprintf(GFP_KERNEL, "%s", modname);
	if (!ydrv->driver.name)
		return -ENOMEM;

	ydrv->driver.owner = owner;
	ydrv->driver.bus = &yrdma_bus_type;
	ydrv->driver.mod_name = modname;

	return driver_register(&ydrv->driver);
}
EXPORT_SYMBOL_GPL(__yrdma_driver_register);

void yrdma_driver_unregister(struct yrdma_driver *ydrv)
{
	driver_unregister(&ydrv->driver);
	kfree(ydrv->driver.name);
}
EXPORT_SYMBOL_GPL(yrdma_driver_unregister);


static void yusur_rdma_dev_release(struct device *dev)
{
	struct yusur_rdma_dev *yrdev = container_of(dev, struct yusur_rdma_dev, ydev.dev);
	kfree(yrdev);
}

/*
	This function is called by eth pci driver probe to add yusur rdma device
	(called after pci_set_drvdata)
	Input:
	info : caller need to init info,before call this
	bonding_mode: pci device set to false; and

    return the pointer for yusur_rdma_dev, NULL means failed
*/
struct yusur_rdma_dev *yusur_rdma_add_dev(struct yusur_rdma_dev *yrdev)
{
	struct yrdma_device *ydev;
	int ret;

	if (yrdev->bonding_mode) {
		if (yrdev->get_from_bonding == NULL) {
			pr_err("bonding mode must impl get_from_bonding\n");
			return NULL;
		}
	}

	if (yrdev->ndev[0] == NULL || yrdev->pdev == NULL) {
		pr_err("must provide pcidev and netdev\n");
		return NULL;
	}

	if (yrdev->irq_cnt < 1) {
		pr_warn("must provide correct irq info:%d\n", yrdev->irq_cnt);		
	}

	if (yrdev->bonding_mode) {
		//newtodo get yrdev->get_from_bonding;
	}

	ydev = &yrdev->ydev;
	if (yrdev->bonding_mode) {
		strcpy(ydev->name, YRDMA_BOND_DEV_NAME);
	} else {
		strcpy(ydev->name, YRDMA_DEV_NAME);
	}

	ydev->dev.parent = &yrdev->ndev[0]->dev;
	ydev->dev.release = yusur_rdma_dev_release;

	ret = yrdma_device_init(ydev);
	if (ret) {
		pr_err("yrdma_device_init failed\n");
		kfree(yrdev);
		return NULL;
	}

	ydev->id = yrdev->pdev->bus->number << 16 |  yrdev->pdev->devfn;//TODO NEED MORE INFO
	ret = yrdma_device_add(ydev);
	if (ret) {
		dev_err(&ydev->dev, "yrdma add dev failed:%d\n",ret);
		goto uninit;
	}

	return yrdev;
uninit:
	yrdma_device_uninit(ydev);
	return NULL;
}
EXPORT_SYMBOL_GPL(yusur_rdma_add_dev);

void yusur_rdma_remove_dev(struct yusur_rdma_dev *yrdma_dev)
{
	if (yrdma_dev == NULL)
		return;

	yrdma_device_delete(&yrdma_dev->ydev);
	yrdma_device_uninit(&yrdma_dev->ydev);
	//yrdma_dev free in dev.release
	yrdma_dev = NULL;
}
EXPORT_SYMBOL_GPL(yusur_rdma_remove_dev);

struct net_device *yusur_intf_get_netdev_from_bonding(struct yusur_rdma_dev *yrdev)
{	
	if (yrdev->get_from_bonding == NULL)
		return NULL;
	return yrdev->get_from_bonding(yrdev);
}
EXPORT_SYMBOL_GPL(yusur_intf_get_netdev_from_bonding);

int  yrdma_intf_init(void)//called by pci module init
{
	pr_info("yrdma intf driver version: %d.%d.%d\n", DRV_VER_MAJOR,
		DRV_VER_MINOR, DRV_VER_BUILD);
	
	return bus_register(&yrdma_bus_type);
}
EXPORT_SYMBOL_GPL(yrdma_intf_init);

void  yrdma_intf_exit(void)//called by pci module uninit
{
	bus_unregister(&yrdma_bus_type);
}
EXPORT_SYMBOL_GPL(yrdma_intf_exit);

#ifdef INDEPENDENT_MODEL_DRV
MODULE_ALIAS("yrdma_intf");
MODULE_AUTHOR("GuoXing <guox@yusur.tech>");
MODULE_DESCRIPTION("Yusur RDMA interface for ETH driver");
MODULE_LICENSE("Dual BSD/GPL");
MODULE_VERSION(DRV_VER);

module_init(yrdma_intf_init);
module_exit(yrdma_intf_exit);
#endif
