#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x602c1205, "module_layout" },
	{ 0x225088ae, "bus_register" },
	{ 0x68284a4, "driver_register" },
	{ 0x54b1fac6, "__ubsan_handle_load_invalid_value" },
	{ 0xfb384d37, "kasprintf" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0x24ec18f, "_dev_warn" },
	{ 0xecb40a45, "device_del" },
	{ 0x4f40f56c, "driver_unregister" },
	{ 0x1a79c8e9, "__x86_indirect_thunk_r13" },
	{ 0x5a921311, "strncmp" },
	{ 0xb820898a, "device_add" },
	{ 0xb8f708f6, "bus_find_device" },
	{ 0x3e3d3caa, "_dev_err" },
	{ 0xc91bba3e, "bus_unregister" },
	{ 0x2675fc1d, "pm_generic_suspend" },
	{ 0xa13e8974, "pm_generic_runtime_suspend" },
	{ 0x2d835759, "dev_pm_domain_detach" },
	{ 0x9f984513, "strrchr" },
	{ 0xa916b694, "strnlen" },
	{ 0xc1905b44, "put_device" },
	{ 0x92997ed8, "_printk" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0x23a97cec, "pm_generic_resume" },
	{ 0x607fc77d, "pm_generic_runtime_resume" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0xcbd4898c, "fortify_panic" },
	{ 0x516475f8, "dev_pm_domain_attach" },
	{ 0x37a0cba, "kfree" },
	{ 0xb8c44ddb, "device_initialize" },
	{ 0x8be776fb, "dev_set_name" },
	{ 0x9c6febfc, "add_uevent_var" },
};

MODULE_INFO(depends, "");


MODULE_INFO(srcversion, "8B61EDB88AC29605BCFEDB0");
