#ifndef _RDMA_MODEL_H_
#define _RDMA_MODEL_H_

#define YRDMA_MODULE_PREFIX "yusur_rdma:"
#define MAX_YIB_SF_NUM 128

#define module_yrdma_driver(__yrdma_driver) \
	module_driver(__yrdma_driver, yrdma_driver_register, yrdma_driver_unregister)

struct yrdma_sf_lock
{
	u64 key;
	spinlock_t sf_ddr_lock;
	struct mutex  sf_res_lock;
	struct kref	ref_cnt;
};

struct yusur_rdma_dev *yusur_rdma_add_dev(struct yusur_rdma_dev *yrdev);
void yusur_rdma_remove_dev(struct yusur_rdma_dev *yrdma_dev);
int yrdma_intf_init(void);
void yrdma_intf_exit(void);
#endif /* _RDMA_MODEL_H_ */