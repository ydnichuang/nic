#include <linux/netdevice.h>
#include <linux/virtio.h>
#include <linux/module.h>
#include <linux/delay.h>
#include <linux/pci.h>
#include <linux/of.h>
#include <linux/yusur/yrdma_model.h>
#include <linux/yusur/compiler.h>

#define GET_NET_DEV_BY_NAME 1

#define NETDEV_PCI_VID 0x1f47
#define NETDEV_PCI_DID 0x1001

static bool match_netdev(struct pci_dev *ib_pdev, struct pci_dev *net_pdev)
{
	bool domain_match = false;
	bool bus_match = false;
	bool slot_match = false;
	bool func_id_match = false;

	if (ib_pdev == NULL || net_pdev == NULL) {
		dev_err(&ib_pdev->dev, "match err:one of the pci_dev is null\n");
		return false;
	}

	domain_match = (pci_domain_nr(ib_pdev->bus) == pci_domain_nr(net_pdev->bus))? true : false;
	bus_match = (ib_pdev->bus->number == net_pdev->bus->number)? true : false;
	slot_match = (PCI_SLOT(ib_pdev->devfn) == PCI_SLOT(net_pdev->devfn))? true : false;
	func_id_match = (PCI_FUNC(net_pdev->devfn) == 0)? true : false;

	return domain_match & bus_match & slot_match & func_id_match;
}

static int match_any(struct device *dev, void *unused)
{
	return 1;
}

static struct device *pcie_device_find_any_child(struct device *parent)
{
	return device_find_child(parent, NULL, match_any);
}

static struct net_device* get_net_dev_by_pdev(struct device *rdma_dev, struct pci_dev *net_pdev)
{
	struct device *dev = NULL;
	struct net_device *net_dev = NULL;
	dev = pcie_device_find_any_child(&net_pdev->dev);
	if (dev) {
		net_dev = to_net_dev(dev);
		dev_info(rdma_dev, "net_dev name is %s \n", dev_name(dev));
	}
	return net_dev;
}

#if GET_NET_DEV_BY_NAME == 0
struct net_device* get_net_dev(struct pci_dev *ib_pdev, struct device *dev)
{
	struct pci_dev *net_pdev = NULL;
	struct net_device *net_dev = NULL;
	unsigned int net_pdev_vendor_id = NETDEV_PCI_VID;
	unsigned int net_pdev_device_id = NETDEV_PCI_DID;
	bool net_dev_match = false;

	//get net_dev by net pci_dev
	for (net_pdev = pci_get_device(net_pdev_vendor_id, net_pdev_device_id, net_pdev);
			net_pdev;
			net_pdev = pci_get_device(net_pdev_vendor_id, net_pdev_device_id, net_pdev))
	{
		net_dev_match = match_netdev(ib_pdev, net_pdev);
		if (net_dev_match)
			break;
	}
	if (net_dev_match) {
		net_dev = get_net_dev_by_pdev(dev, net_pdev);
	}

	//when pci_get_device rec++
	if (net_pdev)
		put_device(&net_pdev->dev);
	return net_dev;
}
#else
static char *net_dev_name = "enp4s0";
struct net_device* get_net_dev(struct pci_dev *ib_pdev, struct device *dev)
{
	struct net_device *net_dev = NULL;

	net_dev = dev_get_by_name(&init_net, net_dev_name);
	if (net_dev)
		dev_info(dev, "net_dev name is %s \n", dev_name(&net_dev->dev));
	return net_dev;
}
#endif
