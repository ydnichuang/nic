#include <linux/netdevice.h>
#include <linux/module.h>
#include <linux/delay.h>
#include <linux/pci.h>
#include <linux/of.h>
#include <linux/yusur/yrdma_model.h>
#include <linux/yusur/compiler.h>
#include "../lib/rdma_model.h"

static char *net_dev_name = "eth0";
module_param(net_dev_name, charp,0644);
MODULE_PARM_DESC(net_dev_name, "onic dev name,default 'enp1s0f0'");

#define DRV_VER	__stringify(DRV_VER_MAJOR) "."		\
	__stringify(DRV_VER_MINOR) "." __stringify(DRV_VER_BUILD)

struct bar {
	unsigned long bar0_size;
	unsigned long bar2_size;
	void *bar0_addr;
	void *bar2_addr;
};

struct yusur_roce_priv {
	unsigned long bar0_size;
	unsigned long bar2_size;
	void *bar0_addr;
	void *bar2_addr;
	struct yusur_rdma_dev *yrdev;
	struct net_device *net_dev[YIB_MAX_DEV_PORTS];
	int msixcnt;
	struct bar *iomem;
	u32 irq_vector[8];
	int num_vfs;
	struct mutex *glb_mutex;
};

struct yusur_roce_priv *privdata = NULL;

static struct yusur_rdma_dev *yusur_rdma_dev_init(struct pci_dev *pdev, struct yusur_roce_priv *privdata)
{
	struct yusur_rdma_dev *yrdev;
	int i;

	yrdev = kzalloc(sizeof(*yrdev), GFP_KERNEL);
	if (yrdev == NULL)
		return NULL;

	for (i = 0; i < YIB_MAX_DEV_PORTS; i++) {
		yrdev->ndev[i] = privdata->net_dev[i];
	}
	yrdev->pdev = pdev;
	yrdev->max_ports = 2;
	yrdev->global_bar_virtual_addr[0] = (void *)0x1000;
	yrdev->bar_size[0] = 4096;
	yrdev->host_type = YRDMA_TYPE_SWTEST;
	yrdev->chip_subtype = 0;
	yrdev->bonding_mode = false;
	yrdev->irq_vector = privdata->irq_vector[0];
	yrdev->irq_cnt = privdata->msixcnt;
	yrdev->glb_mutex = privdata->glb_mutex;
	mutex_init(yrdev->glb_mutex);

	return yrdev;
}

static int yusur_roce_pci_probe(struct pci_dev *pdev) {
	int ret;
	struct device *dev = &pdev->dev;
	struct net_device *net_dev = NULL;
	struct yusur_rdma_dev *yrdev = NULL;
  
	privdata = devm_kzalloc(dev, sizeof(struct yusur_roce_priv), GFP_KERNEL);
	if(!privdata) {
		dev_err(dev, "Failed to alloc memory!\n");
		return -ENOMEM;
	}

	net_dev = dev_get_by_name(&init_net, net_dev_name);
	if(!net_dev) {
		dev_err(dev, "Failed to get net dev!\n");
		ret = -ENXIO;
		goto netdev_error;
	}

	privdata->net_dev[0] = net_dev;
	privdata->msixcnt = 0;

	privdata->irq_vector[0] = 0;

	//PF do rdma reset
	pci_set_drvdata(pdev, privdata);
	dma_set_max_seg_size(&pdev->dev, UINT_MAX);

	privdata->glb_mutex = kzalloc(sizeof(struct mutex), GFP_KERNEL);
	if (privdata->glb_mutex == NULL) {
		dev_err(dev, "Failed alloc glb_mutex\n");
		ret = -ENOMEM;
		goto mutex_err;
	}

	yrdev =	yusur_rdma_dev_init(pdev, privdata);
	privdata->yrdev = yusur_rdma_add_dev(yrdev);
	if (privdata->yrdev == NULL) {
		dev_err(dev, "init yrdev failed\n");
	}

	return 0;
mutex_err:
netdev_error:
	if (privdata->net_dev[0]) {
		dev_put(privdata->net_dev[0]);
		privdata->net_dev[0] = NULL;
	}
	devm_kfree(&pdev->dev, privdata);
	privdata = NULL;
	return ret;
}

static void yusur_roce_pci_remove(struct pci_dev *pdev)
{
	if (privdata == NULL)
		return;

	if(privdata->yrdev) {
		yusur_rdma_remove_dev(privdata->yrdev);
		privdata->yrdev = NULL;
		pr_info("yusur_roce_rdma_remove\n");
	}

	if (privdata->glb_mutex)
		kfree(privdata->glb_mutex);

	dev_dbg(&pdev->dev, "QDMA-msix Removed\n");
	if (privdata->net_dev[0])
		dev_put(privdata->net_dev[0]);
	devm_kfree(&pdev->dev, privdata);
}

struct pci_dev *pci_device_d = NULL;
static int __init pci_init(void)
{	
	int ret;
	{
		pr_info("gpci_id pci_dev  \n");
		pci_device_d = pci_get_device(0x8086, 0x7020,NULL);// VGA 126f:0750
		if (!pci_device_d) {
			pr_err("pci device get failed \n");
			return -1;
		}
		pr_info("pci_device device name %s \n",pci_device_d->dev.init_name);
	}

	pr_info("beFore probe");
	ret = yusur_roce_pci_probe(pci_device_d);
	return 0;
}

static void __exit pci_exit(void){
	if (pci_device_d) {
		pr_info("exit [pci_id :%p] \n",pci_device_d);
		yusur_roce_pci_remove(pci_device_d);
	}
}

module_init(pci_init);
module_exit(pci_exit);


MODULE_ALIAS("yusur_swtest_rdma_pci");
MODULE_AUTHOR("guoxing <guox@yusur.tech>");
MODULE_DESCRIPTION("Yusur SWtest RDMA PCIe driver");
MODULE_LICENSE("GPL");
MODULE_VERSION(DRV_VER);

