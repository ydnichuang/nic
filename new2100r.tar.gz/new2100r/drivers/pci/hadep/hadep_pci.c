#include "hadep_pci.h"
#include "match_net_dev.c"

#define DRV_VER	__stringify(DRV_VER_MAJOR) "."		\
	__stringify(DRV_VER_MINOR) "." __stringify(DRV_VER_BUILD)

static const struct pci_device_id yusur_rdma_dev_ids[] = {
	{ PCI_DEVICE(YRDMA_HADEP_PCI_VID, YRDMA_HADEP_PCI_DID), },
	{0, },
};

static struct yusur_rdma_priv *yrdma_pci_yrdma_priv_alloc(struct pci_dev *pdev)
{
	struct device *dev = &pdev->dev;
	struct yusur_rdma_priv *yrdma_priv = NULL;

	yrdma_priv = devm_kzalloc(dev, sizeof(struct yusur_rdma_priv), GFP_KERNEL);
	if(yrdma_priv == NULL) {
		dev_err(dev, "Failed to alloc yrdma_priv memory!\n");
		return NULL;
	}

	yrdma_priv->pdev = pdev;
	return yrdma_priv;
}

static int yrdma_pci_iomem_init(struct yusur_rdma_priv *yrdma_priv)
{
	struct pci_dev *pdev = yrdma_priv->pdev;
	struct device *dev = &pdev->dev;
	struct bar *iomem = NULL;
	unsigned long base = 0;

	iomem = (struct bar *)kmalloc(sizeof(struct bar), GFP_KERNEL);
	if(iomem == NULL) {
		dev_err(dev, "Failed to alloc iomem!\n");
		goto iomem_alloc_error;
	}

#if HAS_PCI_SET_DMA_MASK
	if (!pci_set_dma_mask(pdev, DMA_BIT_MASK(64))) {
		pci_set_consistent_dma_mask(pdev, DMA_BIT_MASK(64));
		dev_info(dev, "Using a 64-bit DMA mask.\n");
	} else if (!pci_set_dma_mask(pdev, DMA_BIT_MASK(32))) {
		pci_set_consistent_dma_mask(pdev, DMA_BIT_MASK(32));
		dev_info(dev, "Using a 32-bit DMA mask.\n");
	} else {
		dev_info(dev, "No suitable DMA possible.\n");
	}
#else
	if (!dma_set_mask(&pdev->dev, DMA_BIT_MASK(64))) {
		dma_set_coherent_mask(&pdev->dev, DMA_BIT_MASK(64));
		dev_info(dev, "Using a 64-bit DMA mask.\n");
	} else if (!dma_set_mask(&pdev->dev, DMA_BIT_MASK(32))) {
		dma_set_coherent_mask(&pdev->dev, DMA_BIT_MASK(32));
		dev_info(dev, "Using a 32-bit DMA mask.\n");
	} else {
		dev_info(dev, "No suitable DMA possible.\n");
	}
#endif
	dma_set_max_seg_size(&pdev->dev, UINT_MAX);

	iomem->bar0_size = pci_resource_len(pdev, 0);
	base = pci_resource_start(pdev, 0);
	iomem->bar0_addr = ioremap(base, iomem->bar0_size);
	if (iomem->bar0_addr == NULL) {
		dev_err(dev, "pci bar0 iomem err\n");
		goto ioremap_err;
	}

	yrdma_priv->iomem = iomem;
	return 0;

ioremap_err:
	kfree(iomem);
iomem_alloc_error:
	return -ENOMEM;
}

static int yrdma_pci_irq_init(struct yusur_rdma_priv *yrdma_priv)
{
	struct pci_dev *pdev = yrdma_priv->pdev;
	struct device *dev = &pdev->dev;
	int msixcnt, i;

	msixcnt = pci_alloc_irq_vectors(pdev, YIB_HW_LEAST_INT_VECTOR, YIB_HW_LEAST_INT_VECTOR, PCI_IRQ_MSIX);
	if (msixcnt < YIB_HW_LEAST_INT_VECTOR) {
		dev_err(dev, "Failed to alloc irq vectors: %d\n", msixcnt);
		return -ENOSPC;
	}

	yrdma_priv->msixcnt = msixcnt;

	for(i = 0; i < msixcnt; i++) {
		yrdma_priv->irq_vector[i] = i;//pci_irq_vector(pdev, i);
	}
	return 0;
}

static int yrdma_ndev_init(struct yusur_rdma_priv *yrdma_priv)
{
	struct pci_dev *pdev = yrdma_priv->pdev;
	struct device *dev = &pdev->dev;
	struct net_device *net_dev;

	net_dev = get_net_dev(pdev, dev);
	if(net_dev == NULL) {
		dev_err(dev, "Failed to get net dev!\n");
		return -ENODEV;
	}
	yrdma_priv->net_dev[0] = net_dev;
	return 0;
}

static int yrdma_rdma_dev_add(struct yusur_rdma_priv *yrdma_priv)
{
	struct pci_dev *pdev = yrdma_priv->pdev;
	struct device *dev = &pdev->dev;
	struct yusur_rdma_dev *yrdev;
	int i;

	yrdev = kzalloc(sizeof(*yrdev), GFP_KERNEL);
	if (yrdev == NULL)
		return -ENOMEM;

	yrdma_priv->glb_mutex = kzalloc(sizeof(struct mutex), GFP_KERNEL);
	if (yrdma_priv->glb_mutex == NULL) {
		dev_err(dev, "Failed alloc glb_mutex\n");
		kfree(yrdev);
		return -ENOMEM;
	}

	for (i = 0; i < YIB_MAX_DEV_PORTS; i++) {
		yrdev->ndev[i] = yrdma_priv->net_dev[i];
	}
	yrdev->pdev = pdev;
	yrdev->max_ports = YIB_MAX_DEV_PORTS;
	yrdev->global_bar_virtual_addr[0] = yrdma_priv->iomem->bar0_addr;
	yrdev->bar_size[0] = yrdma_priv->iomem->bar0_size;
	yrdev->host_type = YRDMA_TYPE_R2100;
	yrdev->chip_subtype = YRDMA_SUB_R2100_HADEP_1;
	yrdev->bonding_mode = false;
	yrdev->irq_vector = yrdma_priv->irq_vector[0];
	yrdev->irq_cnt = yrdma_priv->msixcnt;
	yrdev->glb_mutex = yrdma_priv->glb_mutex;
	mutex_init(yrdev->glb_mutex);

	yrdma_priv->yrdev = yusur_rdma_add_dev(yrdev);
	if (yrdma_priv->yrdev == NULL) {
		dev_err(dev, "init yrdev failed\n");
		kfree(yrdma_priv->glb_mutex);
		kfree(yrdev);
		return -ENODEV;
	}

	return 0;
}

static int yusur_roce_pci_probe(struct pci_dev *pdev, const struct pci_device_id *id)
{
	struct device *dev = &pdev->dev;
	struct yusur_rdma_priv *yrdma_priv = NULL;
	int ret = 0;

	yrdma_priv = yrdma_pci_yrdma_priv_alloc(pdev);
	if (yrdma_priv == NULL) {
		dev_err(dev, "Failed to alloc pci yrdma_priv!\n");
		ret = -ENOMEM;
		goto priv_alloc_error;
	}

	ret = pci_enable_device(pdev);
	if (ret) {
		dev_err(dev, "Failed to enable device mem!\n");
		goto enable_error;
	}

	pci_set_master(pdev);
	pci_set_drvdata(pdev, yrdma_priv);
	dev_info(dev, "yrdma pci enable\n");

	ret = yrdma_pci_iomem_init(yrdma_priv);
	if (ret) {
		dev_err(dev, "Failed to init iomem: %d!\n", ret);
		goto iomem_error;
	}

	ret = yrdma_pci_irq_init(yrdma_priv);
	if (ret) {
		dev_err(dev, "Failed to init pci irq: %d!\n", ret);
		goto irq_error;
	}

	ret = yrdma_ndev_init(yrdma_priv);
	if (ret) {
		dev_err(dev, "Failed to init net_dev: %d!\n", ret);
		goto netdev_error;
	}

	ret = yrdma_rdma_dev_add(yrdma_priv);
	if (ret) {
		dev_err(dev, "Failed to add yrdma dev: %d!\n", ret);
		goto dev_add_error;
	}
	return 0;

dev_add_error:
#if GET_NET_DEV_BY_NAME == 0
	put_device(&yrdma_priv->net_dev[0]->dev);
#else
	dev_put(yrdma_priv->net_dev[0]);
#endif
netdev_error:
	pci_free_irq_vectors(pdev);
irq_error:
	if (yrdma_priv->iomem->bar0_addr != 0)
		iounmap(yrdma_priv->iomem->bar0_addr);
	kfree(yrdma_priv->iomem);
iomem_error:
	pci_clear_master(pdev);
	pci_disable_device(pdev);
enable_error:
	devm_kfree(&pdev->dev, yrdma_priv);
priv_alloc_error:
	return ret;
}

static void yusur_roce_pci_remove(struct pci_dev *pdev)
{
	struct device *dev = &pdev->dev;
	struct yusur_rdma_priv *yrdma_priv = pci_get_drvdata(pdev);

	if (yrdma_priv == NULL)
		return;

	if(yrdma_priv->yrdev) {
		yusur_rdma_remove_dev(yrdma_priv->yrdev);
		mutex_destroy(yrdma_priv->yrdev->glb_mutex);
		yrdma_priv->yrdev = NULL;
		dev_info(dev, "yusur_roce_rdma_remove\n");
	}

	if (yrdma_priv->glb_mutex)
		kfree(yrdma_priv->glb_mutex);

#if GET_NET_DEV_BY_NAME == 0
	put_device(&yrdma_priv->net_dev[0]->dev);
#else
	dev_put(yrdma_priv->net_dev[0]);
#endif
	pci_free_irq_vectors(pdev);
	if (yrdma_priv->iomem->bar0_addr != 0)
		iounmap(yrdma_priv->iomem->bar0_addr);
	kfree(yrdma_priv->iomem);
	pci_clear_master(pdev);
	pci_disable_device(pdev);
	devm_kfree(&pdev->dev, yrdma_priv);
}

static struct pci_driver yrdma_hadep_pci_driver = {
	.name = "yrdma_hadep_pci",
	.id_table = yusur_rdma_dev_ids,
	.probe = yusur_roce_pci_probe,
	.remove = yusur_roce_pci_remove,
};

module_pci_driver(yrdma_hadep_pci_driver);

MODULE_ALIAS("yrdma_hadep_pci");
MODULE_AUTHOR("Zhoumoucheng <zhoumc@yusur.tech>");
MODULE_DESCRIPTION("Yusur RDMA PCIe driver");
MODULE_LICENSE("GPL");
MODULE_VERSION(DRV_VER);