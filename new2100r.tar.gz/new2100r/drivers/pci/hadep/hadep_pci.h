#ifndef _HADEP_PCI_H_
#define _HADEP_PCI_H_

#include <linux/netdevice.h>
#include <linux/module.h>
#include <linux/delay.h>
#include <linux/pci.h>
#include <linux/of.h>
#include <linux/yusur/yrdma_model.h>
#include <linux/yusur/compiler.h>
#include "../lib/rdma_model.h"

#define YRDMA_HADEP_PCI_VID  0x007f
#define YRDMA_HADEP_PCI_DID  0x0043

#define YIB_HW_LEAST_INT_VECTOR 3

struct bar {
    unsigned long bar0_size;
    void *bar0_addr;
};

struct yusur_rdma_priv {
    struct pci_dev *pdev;
	struct yusur_rdma_dev *yrdev;
	struct net_device *net_dev[YIB_MAX_DEV_PORTS];
	int msixcnt;
	struct bar *iomem;
	u32 irq_vector[8];
	struct mutex *glb_mutex;
};
#endif