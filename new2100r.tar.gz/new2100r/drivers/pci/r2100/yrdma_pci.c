#include <linux/netdevice.h>
#include <linux/module.h>
#include <linux/delay.h>
#include <linux/pci.h>
#include <linux/of.h>
#include <linux/yusur/yrdma_model.h>
#include <linux/yusur/compiler.h>
#include "match_net_dev.c"
#include "../lib/rdma_model.h"

#define YUSUR_PCI_VID  0x1f47
#define PLDA_PCI_DID   0x1004
#define YUSUR_PCI_VF_VID  0x1f47
#define PLDA_PCI_VF_DID   0x1101

#define YIB_SWTEST

#ifdef YIB_SWTEST
#define YIB_HW_LEAST_INT_VECTOR 0
#else
#define YIB_HW_LEAST_INT_VECTOR 4
#endif

#define DRV_VER	__stringify(DRV_VER_MAJOR) "."		\
	__stringify(DRV_VER_MINOR) "." __stringify(DRV_VER_BUILD)

static const struct pci_device_id yusur_rdma_dev_ids[] = {
	{ PCI_DEVICE(YUSUR_PCI_VID, PLDA_PCI_DID), },
	{ PCI_DEVICE(YUSUR_PCI_VF_VID, PLDA_PCI_VF_DID), },
	{ PCI_DEVICE(0x10ee, 0xa238), },
	{ PCI_DEVICE(0x10ee, 0x9238), },
	{0, },
};

struct yusur_roce_priv {
	unsigned long bar0_size;
	unsigned long bar2_size;
	void *bar0_addr;
	void *bar2_addr;
	struct yusur_rdma_dev *yrdev;
	struct net_device *net_dev[YIB_MAX_DEV_PORTS];
	int msixcnt;
	struct bar *iomem;
	u32 irq_vector[8];
	int num_vfs;
	struct mutex *glb_mutex;
};

static struct yusur_rdma_dev *yusur_rdma_dev_init(struct pci_dev *pdev, struct yusur_roce_priv *privdata)
{
	struct yusur_rdma_dev *yrdev;
	int i;

	yrdev = kzalloc(sizeof(*yrdev), GFP_KERNEL);
	if (yrdev == NULL)
		return NULL;

	for (i = 0; i < YIB_MAX_DEV_PORTS; i++) {
		yrdev->ndev[i] = privdata->net_dev[i];
	}
	yrdev->pdev = pdev;
	yrdev->max_ports = 2;
	yrdev->global_bar_virtual_addr[0] = privdata->iomem->bar0_addr;
	yrdev->bar_size[0] = privdata->iomem->bar0_size;
	yrdev->host_type = YRDMA_TYPE_R2100;
	yrdev->chip_subtype = YRDMA_SUB_R2100_1;
	yrdev->bonding_mode = false;
	yrdev->irq_vector = privdata->irq_vector[0];
	yrdev->irq_cnt = privdata->msixcnt;
	yrdev->glb_mutex = privdata->glb_mutex;
	mutex_init(yrdev->glb_mutex);

	return yrdev;
}

static int yusur_roce_pci_probe(struct pci_dev *pdev, const struct pci_device_id *id) {
	int i,ret, msixcnt;
	struct device *dev = &pdev->dev;
	struct bar *iomem;
	struct yusur_roce_priv *privdata;
	unsigned long base = 0;
	struct net_device *net_dev;
	enum pci_plat_mode plat_mode = QDMA;
	int ddr_bar = YRDMA_DDR_BAR;

	struct yusur_rdma_dev *yrdev = NULL;

	if (pdev->vendor == YUSUR_PCI_VID) {
		ddr_bar = 4;
		plat_mode = PLDA;
	}
#if USE_INDIRECT_DDR_ACCESS == 0
	pr_info("plda=%s ddr_bar=%d\n", (plat_mode == PLDA)? "true":"false", ddr_bar);
#else
	pr_info("plda=%s USE_INDIRECT_DDR_ACCESS\n", (plat_mode == PLDA)? "true":"false");
#endif

	privdata = devm_kzalloc(dev, sizeof(struct yusur_roce_priv), GFP_KERNEL);
	if(!privdata) {
		dev_err(dev, "Failed to alloc memory!\n");
		return -ENOMEM;
	}
	iomem = (struct bar *)kmalloc(sizeof(struct bar), GFP_KERNEL);
	if(!iomem) {
		dev_err(dev, "Failed to alloc memory!\n");
		ret = -ENOMEM;
		goto memory_error;
	}
	pr_info("yusur_roce_hw_enable\n");
	ret = pci_enable_device(pdev);

	if (ret) {
		dev_err(dev, "Failed to enable device mem!\n");
		ret = -ENOMEM;
		goto enable_error;
	}
#if HAS_PCI_SET_DMA_MASK
	if (!pci_set_dma_mask(pdev, DMA_BIT_MASK(64))) {
		pci_set_consistent_dma_mask(pdev, DMA_BIT_MASK(64));
		pr_info("Using a 64-bit DMA mask.\n");
	} else if (!pci_set_dma_mask(pdev, DMA_BIT_MASK(32))) {
		pci_set_consistent_dma_mask(pdev, DMA_BIT_MASK(32));
		pr_info("Using a 32-bit DMA mask.\n");
	} else {
		pr_err("No suitable DMA possible.\n");
	}
#else
	if (!dma_set_mask(&pdev->dev, DMA_BIT_MASK(64))) {
		dma_set_coherent_mask(&pdev->dev, DMA_BIT_MASK(64));
		pr_info("Using a 64-bit DMA mask.\n");
	} else if (!dma_set_mask(&pdev->dev, DMA_BIT_MASK(32))) {
		dma_set_coherent_mask(&pdev->dev, DMA_BIT_MASK(32));
		pr_info("Using a 32-bit DMA mask.\n");
	} else {
		pr_err("No suitable DMA possible.\n");
	}
#endif
	dma_set_max_seg_size(&pdev->dev, UINT_MAX);

	iomem->bar0_size = pci_resource_len(pdev, YRDMA_REG_BAR);
	base = pci_resource_start(pdev, YRDMA_REG_BAR);
	iomem->bar0_addr = ioremap(base, iomem->bar0_size);
	if (iomem->bar0_addr == NULL) {
		dev_err(dev, "pci bar0 iomem err\n");
		ret = -ENOMEM;
		goto bar0_error;
	}
#if USE_INDIRECT_DDR_ACCESS == 0
	iomem->bar2_size = pci_resource_len(pdev, ddr_bar);
	dev_info(dev, "bar:%d size=%ld\n", ddr_bar, iomem->bar2_size);
	base = pci_resource_start(pdev, ddr_bar);
	iomem->bar2_addr = ioremap(base, iomem->bar2_size);
	if (iomem->bar2_addr == NULL) {
		dev_err(dev, "pci bar2 iomem err\n");
		ret = -ENOMEM;
		goto bar2_error;
	}
#else
	iomem->bar2_size = 0;
	iomem->bar2_addr = 0;
#endif

	pci_set_master(pdev);
	pci_set_drvdata(pdev, privdata);

	net_dev = get_net_dev(pdev, dev, iomem, 0, PF_IN_ALL, plat_mode);
	if(!net_dev) {
		dev_err(dev, "Failed to get net dev!\n");
		ret = -ENXIO;
		goto netdev_error;
	}

	privdata->net_dev[0] = net_dev;
	//msixcnt = pci_msix_vec_count(pdev);
	msixcnt = YIB_HW_LEAST_INT_VECTOR;
	msixcnt = pci_alloc_irq_vectors(pdev, YIB_HW_LEAST_INT_VECTOR, YIB_HW_LEAST_INT_VECTOR, PCI_IRQ_MSIX);
	if (msixcnt < YIB_HW_LEAST_INT_VECTOR) {
		dev_err(dev, "Failed enabling %d MSIX entries: %d\n", msixcnt, ret);
		ret = -ENOSPC;
		goto vectors_error;
	}

	privdata->iomem = iomem;
	privdata->msixcnt = msixcnt;
	privdata->bar2_addr = iomem->bar2_addr;
	privdata->bar0_addr = iomem->bar0_addr;

	for(i = 0; i < msixcnt; i++) {
		privdata->irq_vector[i] = i;//pci_irq_vector(pdev, i);
	}

#ifndef INDEPENDENT_MODEL_DRV
	ret = yrdma_intf_init();
	if (ret) {
		dev_err(dev, "Failed init yrdma intf\n");
		ret = -ENOSPC;
		goto intf_error;
	}
#endif

	privdata->glb_mutex = kzalloc(sizeof(struct mutex), GFP_KERNEL);
	if (privdata->glb_mutex == NULL) {
		dev_err(dev, "Failed alloc glb_mutex\n");
		ret = -ENOMEM;
		goto mutex_err;
	}

	yrdev =	yusur_rdma_dev_init(pdev, privdata);
	privdata->yrdev = yusur_rdma_add_dev(yrdev);
	if (privdata->yrdev == NULL)
		dev_err(dev, "init yrdev failed\n");

	return 0;
mutex_err:
#ifndef INDEPENDENT_MODEL_DRV
	yrdma_intf_exit();
intf_error:
#endif
	pci_free_irq_vectors(pdev);
vectors_error:
	pci_clear_master(pdev);
netdev_error:
	if (iomem->bar2_addr != 0)
		iounmap(iomem->bar2_addr);
#if USE_INDIRECT_DDR_ACCESS == 0
bar2_error:
#endif
	if (iomem->bar0_addr != 0)
		iounmap(iomem->bar0_addr);
bar0_error:
	pci_disable_device(pdev);
enable_error:
	kfree(iomem);
memory_error:
	devm_kfree(&pdev->dev, privdata);
	return ret;
}

static void yusur_roce_pci_remove(struct pci_dev *pdev)
{
	struct yusur_roce_priv *privdata = pci_get_drvdata(pdev);

	if (privdata == NULL)
		return;

	if(privdata->yrdev) {
		yusur_rdma_remove_dev(privdata->yrdev);
		mutex_destroy(privdata->yrdev->glb_mutex);
		privdata->yrdev = NULL;
		pr_info("yusur_roce_rdma_remove\n");
	}

	if (privdata->glb_mutex)
		kfree(privdata->glb_mutex);

#ifndef INDEPENDENT_MODEL_DRV
	yrdma_intf_exit();
#endif

	dev_dbg(&pdev->dev, "QDMA-msix Removed\n");
	iounmap(privdata->bar0_addr);
	if(privdata->bar2_addr != 0)
		iounmap(privdata->bar2_addr);
#if GET_NET_DEV_BY_NAME == 0
	put_device(&privdata->net_dev[0]->dev);
#else
	dev_put(privdata->net_dev[0]);
#endif
	kfree(privdata->iomem);
	pci_clear_master(pdev);
	pci_free_irq_vectors(pdev);
	pci_disable_sriov(pdev);
	//pci_release_regions(pdev);
	pci_disable_device(pdev);
	devm_kfree(&pdev->dev, privdata);
}

static int yusur_roce_pci_sriov_configure(struct pci_dev *pdev, int num_vfs)
{
	struct yusur_roce_priv *privdata = pci_get_drvdata(pdev);
	int ret = 0;

	if (pci_vfs_assigned(pdev))
		return -EPERM;

	if (num_vfs == 0) {
		pci_disable_sriov(pdev);
		return 0;
	}

	privdata->num_vfs = num_vfs;

	ret = pci_enable_sriov(pdev, num_vfs);
	if (ret < 0)
		return ret;

	return num_vfs;
}

static struct pci_driver yusur_rdma_pci_driver = {
	.name = "yusur_rdma_pci",
	.id_table = yusur_rdma_dev_ids,
	.probe = yusur_roce_pci_probe,
	.remove = yusur_roce_pci_remove,
	.sriov_configure = yusur_roce_pci_sriov_configure,
};

module_pci_driver(yusur_rdma_pci_driver);

MODULE_ALIAS("yusur_rdma_pci");
MODULE_AUTHOR("Zhoumoucheng <zhoumc@yusur.tech>");
MODULE_DESCRIPTION("Yusur RDMA PCIe driver");
MODULE_LICENSE("GPL");
MODULE_VERSION(DRV_VER);