#include <linux/netdevice.h>
#include <linux/module.h>
#include <linux/delay.h>
#include <linux/pci.h>
#include <linux/of.h>
#include <linux/yusur/yrdma_model.h>
#include <linux/yusur/compiler.h>

#define GET_NET_DEV_BY_NAME 0

#define YRDMA_REG_BAR 0
#define YRDMA_DDR_BAR 2

#define NIC_VID        0x10ee
#define NIC_DID        0x9038
#define NIC_VF_VID     0x10ee
#define NIC_VF_DID     0xa038

#define PLDA_NIC_VID   0x1f47
#define PLDA_NIC_DID   0x1001
#define PLDA_NIC_VF_VID   0x1f47
#define PLDA_NIC_VF_DID   0xffff

#define MSIX_INTR_VEC_BASE_ADDR_RDMA 0x07D10000
#define MSIX_INTR_VEC_BASE_ADDR_ALL  0x07D30000

#define NIC_PFVFID_ADDR  0x07820014
#define RDMA_PFVFID_ADDR 0x00000008
#define PFID_MASK        0x00007e00
#define VFID_MASK        0x000001ff

enum pci_plat_mode{
    PLDA,
    QDMA,
};

enum pci_func_mode{
    PF_IN_ALL,
    VF_IN_VM,
    VF_IN_HOST,
};

struct bar {
    unsigned long bar0_size;
    unsigned long bar2_size;
    void *bar0_addr;
    void *bar2_addr;
};

unsigned int get_nic_func_id(unsigned int ib_func_id, enum pci_plat_mode plat_mode)
{
    unsigned int nic_func_id = 0;
    //if case increase，use table
    if (plat_mode == PLDA) {
        if (ib_func_id == 1)
            nic_func_id = 0;
    } else if (plat_mode == QDMA) {
        if (ib_func_id == 2)
            nic_func_id = 0;
    }
    //todo: multi PF or multi card 
    return nic_func_id;
}

bool rdma_net_pdev_match(struct pci_dev *ib_pdev, struct pci_dev *nic_pdev,
                                enum pci_plat_mode plat_mode, bool bus_only)
{
    bool domain_match = false;
    bool bus_match = false;
    bool slot_match = false;
    bool func_id_match = false;
    unsigned int ib_func_id = 0;
    unsigned int nic_func_id = 0;

    domain_match = (pci_domain_nr(ib_pdev->bus) == pci_domain_nr(nic_pdev->bus))? true : false;
    bus_match = (ib_pdev->bus->number == nic_pdev->bus->number)? true : false;
    slot_match = (PCI_SLOT(ib_pdev->devfn) == PCI_SLOT(nic_pdev->devfn))? true : false;

    if (bus_only) {
        func_id_match = true;
    } else {
        ib_func_id = PCI_FUNC(ib_pdev->devfn);
        nic_func_id = get_nic_func_id(ib_func_id, plat_mode);
        func_id_match = (nic_func_id == PCI_FUNC(nic_pdev->devfn))? true : false;
    }
    return domain_match & bus_match & slot_match & func_id_match;
}

bool match_netdev(struct pci_dev *ib_pdev, struct pci_dev *nic_pdev,
                       enum pci_plat_mode plat_mode, enum pci_func_mode func_mode)
{
    bool match = false;

    if (ib_pdev == NULL || nic_pdev == NULL) {
        dev_err(&ib_pdev->dev, "match err:one of the pci_dev is null\n");
        return false;
    }

    switch(func_mode) {
    case PF_IN_ALL:
        match = rdma_net_pdev_match(ib_pdev, nic_pdev, plat_mode, false);
        break;
    case VF_IN_VM:
        match = rdma_net_pdev_match(ib_pdev, nic_pdev, plat_mode, true);
        break;
    default:
        break;
    }

    return match;
}

int match_any(struct device *dev, void *unused)
{
    return 1;
}

static struct device *pcie_device_find_any_child(struct device *parent)
{
    return device_find_child(parent, NULL, match_any);
}

void get_nic_vid_and_did(enum pci_func_mode func_mode, enum pci_plat_mode plat_mode,
                                       unsigned int *vid, unsigned int *did)
{
    switch(func_mode) {
    case PF_IN_ALL:
    case VF_IN_HOST:
        *vid = (plat_mode == PLDA)? PLDA_NIC_VID : NIC_VID;
        *did = (plat_mode == PLDA)? PLDA_NIC_DID : NIC_DID;
        break;
    case VF_IN_VM:
        *vid = (plat_mode == PLDA)? PLDA_NIC_VF_VID : NIC_VF_VID;
        *did = (plat_mode == PLDA)? PLDA_NIC_VF_DID : NIC_VF_DID;
        break;
    default:
        break;
    }
}

struct net_device* get_net_dev_by_pdev(struct device *dev, struct pci_dev *nic_pdev)
{
    struct device *nic_dev = NULL;
    struct net_device *net_dev = NULL;
    nic_dev = pcie_device_find_any_child(&nic_pdev->dev);
    if (nic_dev) {
        dev_info(dev, "nic_dev name is %s \n", dev_name(nic_dev));
        net_dev = to_net_dev(nic_dev);
    }
    return net_dev;
}

#if GET_NET_DEV_BY_NAME == 0
struct net_device* get_net_dev(struct pci_dev *ib_pdev, struct device *dev, struct bar *ib_iomem,
                                   u32 ib_vf_id, enum pci_func_mode func_mode, enum pci_plat_mode plat_mode)
{
    struct pci_dev *nic_pdev = NULL;
    struct net_device *net_dev = NULL;
    struct pci_dev *nic_vfdev = NULL;
    unsigned int nic_pdev_vendor_id = 0;
    unsigned int nic_pdev_device_id = 0;
    bool net_dev_match = false;
    bool pf_match = false;	
    int pos;
    u16 vf_device_id;
    int count;

    //get nic_pci_dev  VID&DID
    get_nic_vid_and_did(func_mode, plat_mode, &nic_pdev_vendor_id, &nic_pdev_device_id);

    //get net_dev by onic pci_dev
    switch(func_mode) {
    case PF_IN_ALL:
    {
        for (nic_pdev = pci_get_device(nic_pdev_vendor_id, nic_pdev_device_id, nic_pdev);
             nic_pdev; 
             nic_pdev = pci_get_device(nic_pdev_vendor_id, nic_pdev_device_id, nic_pdev))
        {
            net_dev_match = match_netdev(ib_pdev, nic_pdev, plat_mode, func_mode);
            if (net_dev_match)
                break;
        }
        if (net_dev_match) {
            net_dev = get_net_dev_by_pdev(dev, nic_pdev);
        }
        break;
    }
    case VF_IN_VM:
    {
        for (nic_pdev = pci_get_device(nic_pdev_vendor_id, nic_pdev_device_id, nic_pdev);
             nic_pdev; 
             nic_pdev = pci_get_device(nic_pdev_vendor_id, nic_pdev_device_id, nic_pdev))
        {
            //todo: match vf_id
            net_dev_match = match_netdev(ib_pdev, nic_pdev, plat_mode, func_mode);
            if (net_dev_match)
                break;
        }
        if (net_dev_match) {
            net_dev = get_net_dev_by_pdev(dev, nic_pdev);
        }
        break;
    }
    case VF_IN_HOST:
    {
        for (nic_pdev = pci_get_device(nic_pdev_vendor_id, nic_pdev_device_id, nic_pdev);
             nic_pdev;
             nic_pdev = pci_get_device(nic_pdev_vendor_id, nic_pdev_device_id, nic_pdev))
        {
            pf_match = rdma_net_pdev_match(ib_pdev->physfn, nic_pdev, plat_mode, false);
            if (pf_match)
                break;
        }
        if (pf_match) {
            pos = pci_find_ext_capability(nic_pdev, PCI_EXT_CAP_ID_SRIOV);
            if (!pos) {
                return NULL;
            }
            pci_read_config_word(nic_pdev, pos + PCI_SRIOV_VF_DID, &vf_device_id);
            nic_vfdev = pci_get_device(nic_pdev->vendor, vf_device_id, nic_pdev);
            //todo: match vf_id
            count = 1;
            for ( ; nic_vfdev; nic_vfdev = pci_get_device(nic_pdev_vendor_id, vf_device_id, nic_vfdev))
            {
                if (count >= ib_vf_id)
                    break;

                count++;
            }
            if (nic_vfdev)
                net_dev_match = true;
        }
        if (net_dev_match) {
            net_dev = get_net_dev_by_pdev(dev, nic_vfdev);
        }	
        break;
    }
    default:
        break;
    }

    //when pci_get_device rec++
    if (nic_pdev)
        put_device(&nic_pdev->dev);
    return net_dev;
}
#else
static char *net_dev_name = "enp1s0f0";
struct net_device* get_net_dev(struct pci_dev *ib_pdev, struct device *dev, struct bar *ib_iomem,
                                   u32 ib_vf_id, enum pci_func_mode func_mode, enum pci_plat_mode plat_mode)
{
    struct net_device *net_dev = NULL;
    char vf_net_dev_name[64];
    if (ib_vf_id == 0) {
        net_dev = dev_get_by_name(&init_net, net_dev_name);
    } else {
        snprintf(vf_net_dev_name, sizeof(vf_net_dev_name), "tap%d", ib_vf_id);
        net_dev = dev_get_by_name(&init_net, vf_net_dev_name);
    }
    if (net_dev) {
        dev_info(dev, "net_dev name is %s \n", dev_name(&net_dev->dev));
    }
    return net_dev;
}
#endif

