#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x602c1205, "module_layout" },
	{ 0x41964dfe, "kmalloc_caches" },
	{ 0xcaa88eb5, "pci_free_irq_vectors" },
	{ 0x48d490a8, "dma_set_mask" },
	{ 0x1aab7c0b, "pci_disable_device" },
	{ 0xcce0d0b6, "dma_set_coherent_mask" },
	{ 0x4b9d387d, "yusur_rdma_remove_dev" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0xb28c58df, "pci_set_master" },
	{ 0x3924710f, "pci_alloc_irq_vectors_affinity" },
	{ 0x4708c4ff, "yusur_rdma_add_dev" },
	{ 0xcefb0c9f, "__mutex_init" },
	{ 0x44cde28f, "device_find_child" },
	{ 0xde80cd09, "ioremap" },
	{ 0x3e3d3caa, "_dev_err" },
	{ 0xfc68477c, "devm_kfree" },
	{ 0xc50be1cc, "pci_clear_master" },
	{ 0x87a21cb3, "__ubsan_handle_out_of_bounds" },
	{ 0x50f4a523, "_dev_info" },
	{ 0xc1905b44, "put_device" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x235ed0d8, "pci_unregister_driver" },
	{ 0x5bb7b46f, "kmem_cache_alloc_trace" },
	{ 0x37a0cba, "kfree" },
	{ 0xedc03953, "iounmap" },
	{ 0x3eff7cb3, "__pci_register_driver" },
	{ 0x1eb373df, "pci_get_device" },
	{ 0x9cdd4d33, "pci_enable_device" },
	{ 0x6f0e2f03, "devm_kmalloc" },
};

MODULE_INFO(depends, "yusur_model");


MODULE_INFO(srcversion, "10D131D91AD96B61CD885F9");
