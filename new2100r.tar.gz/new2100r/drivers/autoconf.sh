#!/bin/sh

if [ ! -e "autocfg/compiler.h" ]; then
        cd autocfg
        sh autogen.sh
        ./configure
        cd -
fi
