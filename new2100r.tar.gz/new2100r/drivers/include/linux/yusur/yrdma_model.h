#ifndef _YRDMA_INTF_H_
#define _YRDMA_INTF_H_

#define YIB_MAX_DEV_PORTS 1
#define YIB_PER_MAX_SF	2
#define BAR_SPACES_MAX  6
#define YRDMA_NAME_SIZE_MAX 32
#define YRDMA_BOND_DEV_NAME "yrdma_bond"
#define YRDMA_DEV_NAME "yrdma_single"

#define USE_INDIRECT_DDR_ACCESS 1

#define DRV_VER_MAJOR 0
#define DRV_VER_MINOR 8
#define DRV_VER_BUILD 0

enum yrdma_host_type {
	YRDMA_TYPE_R2100		= 0,
	YRDMA_TYPE_NP			= 1,
	YRDMA_TYPE_SWTEST       = 0xFE,
	YRDMA_TYPE_UNKNOW       = 0xFF,
};

enum yrdma_chip_subtype {
	YRDMA_SUB_R2100_HADEP_1 = 0,
	YRDMA_SUB_R2100_1       = 1,
};

typedef enum {
	YIB_GBL_BMP_LCK_QP = 0,
	YIB_GBL_BMP_LCK_CQ,
	YIB_GBL_BMP_LCK_RQ, 
	YIB_GBL_BMP_LCK_MR,
	YIB_GBL_BMP_LCK_EQ,
	YIB_GBL_LOCK_RESOURCE, //FOR QP,CQ
	YIB_GLB_LOCK_UDMCAST,
} yib_gbl_lock_t;

#define YIB_BMP_LCK_LEN (YIB_GBL_BMP_LCK_EQ - YIB_GBL_BMP_LCK_QP + 1)

struct yusur_rdma_dev;
typedef struct net_device * (*func_get_netdev_t)(void *); //void *  real type is struct yusur_rdma_dev *
typedef int (*func_get_left_sfs)(struct yusur_rdma_dev*);

struct yrdma_device {
	struct device dev;
	char name[YRDMA_NAME_SIZE_MAX];
	u32 id;
};

struct yrdma_device_id {
	char name[YRDMA_NAME_SIZE_MAX];
	kernel_ulong_t driver_data;
};

struct yrdma_driver {
	int (*probe)(struct yrdma_device *ydev, const struct yrdma_device_id *id);
	void (*remove)(struct yrdma_device *ydev);
	void (*shutdown)(struct yrdma_device *ydev);
	int (*suspend)(struct yrdma_device *ydev, pm_message_t state);
	int (*resume)(struct yrdma_device *ydev);
	const char *name;
	struct device_driver driver;
	const struct yrdma_device_id *id_table;
};

struct yusur_rdma_dev {
	struct yrdma_device		ydev;
	struct pci_dev			*pdev;
	struct net_device		*ndev[YIB_MAX_DEV_PORTS];
	int						max_ports;
	void					*global_bar_virtual_addr[BAR_SPACES_MAX]; //rdma全局bar虚拟地址
	u32						bar_size[BAR_SPACES_MAX];
	enum yrdma_host_type	host_type;
	u32						chip_subtype;//扩展使用目前填0
	bool					bonding_mode;
	u32						irq_vector; //给rdma设备的起始中断向量,要求连续分配
	int						irq_cnt;    //中断向量的个数
	void					*priv_data;
	func_get_netdev_t		get_from_bonding;
	func_get_left_sfs		get_left_sfs;
	struct mutex			*glb_mutex;
};

/*****************************************
 Below APIs is for rdma driver only	
 ************************************/
struct net_device *yusur_intf_get_netdev_from_bonding(struct yusur_rdma_dev * yrdev);

static inline struct yrdma_device *to_yrdma_dev(struct device *dev)
{
	return container_of(dev, struct yrdma_device, dev);
}

static inline struct yrdma_driver *to_yrdma_drv(struct device_driver *drv)
{
	return container_of(drv, struct yrdma_driver, driver);
}

int __yrdma_driver_register(struct yrdma_driver *ydrv, struct module *owner,
				const char *modname);
                
#define yrdma_driver_register(ydrv) \
	__yrdma_driver_register(ydrv, THIS_MODULE, KBUILD_MODNAME)

void yrdma_driver_unregister(struct yrdma_driver *ydrv);


#endif /* _YRDMA_INTF_H_ */
