#ifndef _YUSUR_PEER_H_
#define _YUSUR_PEER_H_
#include "compiler.h"

#ifndef IB_UMEM_GET_PEER_DEFINED
#if IB_UMEM_GET_VERSION == 2
struct ib_umem *ib_umem_get_peer(struct ib_device *device, unsigned long addr,
                            size_t size, int access, int dmasync, bool *is_peer);
#elif IB_UMEM_GET_VERSION == 1
struct ib_umem *ib_umem_get_peer(struct ib_ucontext *context, unsigned long addr,
                                 size_t size, int access,
                                 bool *is_peer);
#else
struct ib_umem *ib_umem_get_peer(struct ib_udata *udata, unsigned long addr,
                                 size_t size, int access,
                                 unsigned long peer_mem_flags, bool *is_peer);
#endif
void ib_umem_release_peer(struct ib_umem *umem);

#endif
#endif
