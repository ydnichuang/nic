#!/bin/sh

path="/sys/class/infiniband/yusur_0/ports/1/hw_counters/"
files=`ls $path`
for f in $files
do
	val=`cat $path/$f`
	echo $f $val
done
