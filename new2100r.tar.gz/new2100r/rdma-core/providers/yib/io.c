#include "yib_utils.h"
#include "swcmd.h"
#include "io.h"
#define YIB_MAX_BATCH_SQ (16)



static int yib_u_srq_post_one_recv(struct yib_context *ctx , struct yib_srq *srq, struct ibv_recv_wr *wr);

static const struct yib_wr_opcode_info yib_wr_opcode_info[] = { //IBV_WR_REG_MR + 1
	[IBV_WR_RDMA_WRITE]				= {
		.name	= "IBV_WR_RDMA_WRITE",
		.mask	= {
			[IBV_QPT_RC]	= WR_INLINE_MASK | WR_WRITE_MASK,
		},
	},
	[IBV_WR_RDMA_WRITE_WITH_IMM]			= {
		.name	= "IBV_WR_RDMA_WRITE_WITH_IMM",
		.mask	= {
			[IBV_QPT_RC]	= WR_INLINE_MASK | WR_WRITE_MASK,
		},
	},
	[IBV_WR_SEND]					= {
		.name	= "IBV_WR_SEND",
		.mask	= {
			[IBV_QPT_RC]	= WR_INLINE_MASK | WR_SEND_MASK,
			[IBV_QPT_UD]	= WR_INLINE_MASK | WR_SEND_MASK,
		},
	},
	[IBV_WR_SEND_WITH_IMM]				= {
		.name	= "IBV_WR_SEND_WITH_IMM",
		.mask	= {
			[IBV_QPT_RC]	= WR_INLINE_MASK | WR_SEND_MASK,
			[IBV_QPT_UD]	= WR_INLINE_MASK | WR_SEND_MASK,
		},
	},
	[IBV_WR_RDMA_READ]				= {
		.name	= "IBV_WR_RDMA_READ",
		.mask	= {
			[IBV_QPT_RC]	= WR_READ_MASK,
		},
	},
	[IBV_WR_ATOMIC_CMP_AND_SWP]			= {
		.name	= "IBV_WR_ATOMIC_CMP_AND_SWP",
		.mask	= {
			[IBV_QPT_RC]	= WR_ATOMIC_MASK,
		},
	},
	[IBV_WR_ATOMIC_FETCH_AND_ADD]			= {
		.name	= "IBV_WR_ATOMIC_FETCH_AND_ADD",
		.mask	= {
			[IBV_QPT_RC]	= WR_ATOMIC_MASK,
		},
	},
	[IBV_WR_SEND_WITH_INV]				= {
		.name	= "IBV_WR_SEND_WITH_INV",
		.mask	= {
			[IBV_QPT_RC]	= WR_INLINE_MASK | WR_SEND_MASK,
			[IBV_QPT_UD]	= WR_INLINE_MASK | WR_SEND_MASK,
		},
	},
	[IBV_WR_LOCAL_INV]				= {
		.name	= "IBV_WR_LOCAL_INV",
		.mask	= {
			[IBV_QPT_RC]	= WR_REG_MASK ,
		},
	},
};


static inline u32  yib_get_rq_sw_idx(struct yib_rq *rq)
{
	return rq->qid;
}

static inline u32  yib_get_cq_sw_idx(struct yib_cq *cq)
{
	return cq->cq_id;
}

//qpc_index is the index in ddr qpc table, entry_index is index of qp sw table
static inline u32  yib_get_qp_sw_idx(struct yib_qp *qp)
{
	return qp->qpn;
}



//返回true表示可以db, 否则不能db
bool yib_srq_db_helper(struct yib_srq *srq, int pos)
{
	int temp = 0;
	u32 pi = 0;

	if (pos == srq->next_db) {
		while (test_bit(pos, srq->post_bitmap) && (test_bit(pos, srq->db_bitmap) == 0))
		{
			__set_bit(pos, srq->db_bitmap);
			temp = pos + 1;
			pos = queue_index_inc(pos, srq->rq.buf_v.q_depth);
			srq->next_db = pos;
			if (temp != pos)
				srq->toggle = srq->toggle? false: true;
		}

		pi = queue_index_dec(srq->next_db, srq->rq.buf_v.q_depth);
		atomic_set(&srq->rq.rq_info.info->pi, pi);
		return true;
	}

	return false;
}

//在check cq empty中调用
int yib_urq_check_hwcqe(struct yib_context *ctx, struct yib_rq *rq, int index)
{
	if (index >= rq->buf_v.q_depth) {
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_QP ,"rqn:%d, index:%d err\n", yib_get_rq_sw_idx(rq), index);
		return -EINVAL;
	}

	if (rq->sw_cmds[index].posted == 0) {
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_QP ,"rqn:%d, get an rq cqe err at %d\n", yib_get_rq_sw_idx(rq), index);
		return -EINVAL;
	}
	return 0;
}

//在check_cq_empty(bsw = false)和sw_fill_cqe(bsw = true)中调用
int yib_usq_check_cqe(struct yib_context *ctx, struct yib_qp *qp, int index, bool bsw)
{
	struct yib_sq *sq = &qp->sq;
	u32 ci = 0;
	u32 pi = 0;

	if (index >= sq->buf_v.q_depth) {
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_QP ,"qpn:%d, index:%d err, out of range\n", yib_get_qp_sw_idx(qp), index);
		return -EINVAL;
	}

	//如果为纯软件提交，仅在软件填写cqe时返回成功
	if (sq->sw_posted[index] > 0)
		return bsw? 0 : -EINVAL;

	ci = atomic_get(&sq->sq_info.info->ci);
	pi = atomic_get(&sq->sq_info.info->pi);
	if (sq->sq_info.info->ci_toggle == sq->sq_info.info->pi_toggle) {//未翻转
		if (index < ci || index >= pi) {
			YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_QP ,"qpn:%d, index:%d err, not between ci and pi\n",  qp->qpn, index);
			return -EINVAL;
		}
	} else {//翻转
		if (index < ci && index >= pi) {
			YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_QP ,"qpn:%d, index:%d err, not between ci and pi\n", qp->qpn, index);
			return -EINVAL;
		}
	}

	if (sq->sw_cmds[index].posted == 0 ) {
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_QP ,"qpn:%d, get an err sq cqe at %d, no posted\n", qp->qpn, index);
		return -EINVAL;
	}

	return 0;
}




static int validate_send_wr(struct yib_qp *qp, struct ibv_send_wr *ibwr,
			    u32 mask, u32 length)
{
	int num_sge = ibwr->num_sge;
	struct yib_context *ctx = to_yib_ctx(qp->vqp.qp.context);

	if (unlikely(num_sge > qp->sq.sq_info.max_sge)) {
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_IO ,"sge:%d is bigger than max_sge:%d\n", num_sge, qp->sq.sq_info.max_sge);
		goto err1;
	}

	if (unlikely(mask & WR_ATOMIC_MASK)) {
		if (length < 8) {
			YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_IO ,"%s","atomic length need to be 8 byte\n");
			goto err1;
		}

		if (ibwr->wr.rdma.remote_addr & 0x7) {
			YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_IO ,"atomic addr need 8byte aligned\n");
			goto err1;
		}
	}

	if (unlikely((ibwr->send_flags & IBV_SEND_INLINE) &&
		     (length > qp->sq.sq_info.max_inline))) {
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_IO ,"inline send:%d bigger than:%d\n", length, qp->sq.sq_info.max_inline);
		goto err1;
	}

	if (unlikely((ibwr->send_flags & IBV_SEND_INLINE) &&
				!(mask & WR_INLINE_MASK))) {
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_IO , "qpid:%d op:%d not support inline\n",
				yib_get_qp_sw_idx(qp), ibwr->opcode);
		goto err1;
	}

	return 0;

err1:
	return -EINVAL;
}

void* yib_u_queue_get_vaddr_by_index(char *Q_buffer, size_t item_size, int index)
{
	return Q_buffer + index * item_size;
}

void* yib_u_queue_get_pi_vaddr(struct yib_queue_info *info , char *Q_buffer ,size_t item_size)
{
	int pi = atomic_get(&info->pi);
//	return yib_queue_get_vaddr_by_index(queue, pi);
	return Q_buffer + pi * item_size;
}

void* yib_u_queue_get_ci_vaddr(struct yib_queue_info *info , char *Q_buffer ,size_t item_size)
{
	int ci = atomic_get(&info->ci);
//	return yib_queue_get_vaddr_by_index(queue, ci);
	return Q_buffer + ci * item_size;
}

int yib_u_queue_advance_pi(struct yib_queue_info *info, int diff , int depth )
{
	int pi = atomic_get(&info->pi);
	if ((pi + diff) >= depth) {
		atomic_set(&info->pi, (pi + diff - depth));
		info->pi_toggle = (info->pi_toggle)? 0 : 1;
		return (pi + diff - depth);
	} else {
		atomic_add(&info->pi, diff);
		return (pi + diff);
	}
}

int yib_u_queue_advance_ci(struct yib_queue_info *info, int diff , int depth )
{
	int ci = atomic_get(&info->ci);
	if ((ci + diff) >= depth) {
		atomic_set(&info->ci, (ci + diff - depth));
		info->ci_toggle = (info->ci_toggle)? 0 : 1;
		return (ci + diff - depth);
	} else {
		atomic_add(&info->ci, diff);
		return (ci + diff);
	}
}


int yib_u_poll_cq(struct ibv_cq *ibcq, int num_entries, struct ibv_wc *wc)
{


	int i;
	u8 *cqe = NULL;
	int poll_cnt = 0;
	struct yib_context *ctx = to_yib_ctx(ibcq->context);
	struct yib_cq *cq = to_yib_cq(ibcq); 

	pthread_spin_lock(&cq->lock);
	//sw_cqe
	for (i = 0; i < num_entries; i++) {
		if (cq->cur_sw_cqe != NULL) {
			if (yib_cur_usw_cqe_process(ctx, cq, wc) != 0)
				goto next;
			cq->cqinfo.info->direct_cnt++;
			wc++;
			continue;
	}

next:
		cqe = yib_u_queue_get_ci_vaddr( cq->cqinfo.info , cq->buf_v.buf , ctx->hw_caps.cqe_isize );
		if (ctx->hw_ops->check_cq_empty(ctx, cq, cqe) == true) {
			if (yib_usw_poll_cq(ctx, cq, wc)) {
				cq->cqinfo.info->direct_cnt++;
				wc++;
				continue;
			}
			break;
		}

		ctx->hw_ops->fill_cqe(cq, wc, cqe);
		if (wc->status != 0)
			cq->cqinfo.info->err_count++;
		else
			cq->cqinfo.info->io_count++;

		yib_u_queue_advance_ci(cq->cqinfo.info , 1 , cq->buf_v.q_depth);
		wc++;
		poll_cnt++;
	}

	if (poll_cnt > 0) {
		udma_from_device_barrier();
		ctx->hw_ops->cq_ci_db_update(ctx , cq, poll_cnt);
	}
	pthread_spin_unlock(&cq->lock);
	return i;


		
}



static int post_one_send(struct yib_qp *qp, struct ibv_send_wr *wr,
			    u32 mask, u32 length) 
{
	struct yib_sq *sq = &qp->sq;
	struct yib_context *ctx = qp->ctx;
	int err = 0;
	u8 *wqe = NULL;
	int pos = atomic_read(&sq->sq_info.info->pi);

	err = validate_send_wr(qp, wr, mask, length);
	if (err) {
		sq->sq_info.info->direct_cnt++;
		goto exit;
	}

	if (ctx->hw_ops->check_sq_full(ctx , sq)) {
		sq->sq_info.info->err_count++;
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_IO ,"sq queue is full\n");
		err = -ENOMEM;
		goto exit;
	}

	wqe = yib_u_queue_get_pi_vaddr(sq->sq_info.info , sq->buf_v.buf , qp->sq.sq_info.item_size);
	err = ctx->hw_ops->fill_wqe(ctx, qp, (const void*)wr, wqe, length, mask);
	if (unlikely(err)) {
		sq->sq_info.info->direct_cnt++;
		goto exit;
	}

	sq->sw_cmds[pos].wrid = wr->wr_id;
	sq->sw_cmds[pos].opcode = yib_wr_to_wc_opcode(wr->opcode);
	sq->sw_cmds[pos].at_err = 0;
	if ((wr->send_flags & IBV_SEND_SIGNALED))
		sq->sw_cmds[pos].bsignal = 1;
	sq->sw_cmds[pos].posted = 1;
	pos = yib_u_queue_advance_pi(sq->sq_info.info , 1 , sq->buf_v.q_depth);
	sq->sq_info.info->io_count++;

exit:
	return err;              
}

int yib_u_post_send(struct ibv_qp *ibvqp, struct ibv_send_wr *wr, struct ibv_send_wr **bad_wr)
{
	u32 mask = 0;
	int err = 0;
	u32 length = 0;
	int i;
	int io_cnt = 0;
	struct yib_qp *qp = to_yib_qp(ibvqp);
	struct yib_cq *send_cq = to_yib_cq(ibvqp->send_cq);
	struct yib_context *ctx = to_yib_ctx(ibvqp->context);


	if(qp->vqp.qp.qp_type >= IBV_QPT_DRIVER) {
		*bad_wr = wr;
		return -EINVAL;
	}

	pthread_spin_lock(&qp->sq.lock);

	if (unlikely(qp->qp_state < IBV_QPS_RTS)) {
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_IO , "qpid:%d state:%d send before rts\n",qp->qpn , qp->qp_state);
		err = -EINVAL;
		goto exit;
	}

	//如果硬件有能力，在err时将提交的wr错误完成，则不需要err的判断，可以直接提交到队列中
	if (unlikely(qp->qp_state == IBV_QPS_ERR) && (ctx->sw_err_flush == 1)) {
		struct yib_sw_cqe input_sw_cqe;
		err = yib_usq_send_wr_when_err( ctx , qp , wr, &input_sw_cqe);
		pthread_spin_unlock(&qp->sq.lock);
		if (input_sw_cqe.end_pos > input_sw_cqe.start_pos)
			yib_usw_cqe_generate(ctx, send_cq, &input_sw_cqe);
		goto end;
	}

	while (wr) {
		/* TODO 		if (wr->opcode > IBV_WR_REG_MR) {
			err = -EINVAL;
			goto exit;
		} 
		*/

		mask = yib_wr_opcode_info[wr->opcode].mask[qp->vqp.qp.qp_type];
		if (unlikely(!mask)) {
			YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_IO , "qpid:%d op:%d invalid\n",qp->qpn , wr->opcode);
			err = -EINVAL;
			goto exit;
		}

		if (unlikely((wr->send_flags & IBV_SEND_INLINE) &&
			     !(mask & WR_INLINE_MASK))) {
			YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_IO , "qpid:%d op:%d not support inline\n",qp->qpn , wr->opcode);
			err = -EINVAL;
			goto exit;
		}

		length = 0;
		for (i = 0; i < wr->num_sge; i++)
			length += wr->sg_list[i].length;

		err = post_one_send(qp, wr, mask, length);
		if (err) {
			goto exit;
		}

		io_cnt++;
		wr = wr->next;
	}

exit:
	if (io_cnt > 0) {
		udma_to_device_barrier();
		ctx->hw_ops->sq_pi_db_update(ctx, qp , io_cnt);
	}
	pthread_spin_unlock(&qp->sq.lock);

end:
	if (err) {
		*bad_wr = wr;
	}
	return err;
}

				   

static int post_one_recv(struct yib_context * ctx, struct yib_rq *rq, struct ibv_recv_wr *wr)
{
		int err;
	int i;
	u32 length;
	u8 *rqe = NULL;
	int num_sge = wr->num_sge;
	int pos = atomic_read(&rq->rq_info.info->pi);

	if (unlikely(num_sge > rq->rq_info.max_sge)) {
		rq->rq_info.info->direct_cnt++;
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_IO ,"recv failed for sge:%d > max_recv_sge:%d\n", \
						num_sge, rq->rq_info.max_sge);
		err = -EINVAL;
		goto exit;
	}

	length = 0;
	for (i = 0; i < num_sge; i++)
		length += wr->sg_list[i].length;

	if (ctx->hw_ops->check_rq_full(ctx, rq)) {
		rq->rq_info.info->err_count++;
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_IO , "rq queue is full\n");
		err = -ENOMEM;
		goto exit;
	}

	rqe = yib_u_queue_get_pi_vaddr( rq->rq_info.info , rq->buf_v.buf , rq->rq_info.item_size );
	err = ctx->hw_ops->fill_rqe(ctx , rq, (const void*)wr, rqe, length);
	if (unlikely(err)) {
		rq->rq_info.info->direct_cnt++;
		goto exit;
	}

	rq->sw_cmds[pos].wrid = wr->wr_id;
	rq->sw_cmds[pos].opcode = IBV_WC_RECV;
	rq->sw_cmds[pos].at_err = 0;
	rq->sw_cmds[pos].bsignal = 1;
	rq->sw_cmds[pos].posted = 1;
	pos = yib_u_queue_advance_pi(rq->rq_info.info, 1 ,rq->buf_v.q_depth);
	rq->rq_info.info->io_count++;

exit:
	return err;
}



int yib_u_post_recv(struct ibv_qp *ibvqp,struct ibv_recv_wr *wr,
				   struct ibv_recv_wr **bad_wr)
{

	struct yib_qp *qp = to_yib_qp(ibvqp);
	struct yib_context *ctx = to_yib_ctx(ibvqp->context);
	struct yib_cq *recv_cq = to_yib_cq(ibvqp->recv_cq);
	struct yib_rq *rq = &qp->rq;
	int err = 0;
	int io_cnt = 0;

 	if (unlikely(!rq)) {
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_IO , "qp: %d rq is null\n", qp->qpn );
		*bad_wr = wr;
		return -EINVAL;
	}

	pthread_spin_lock(&rq->lock);

	if ((qp->qp_state < IBV_QPS_INIT))  {
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_IO , "qp: %d recv in wrong state:%d \n",qp->qpn , qp->qp_state);
		err = -EINVAL;
		goto exit;
	}

	//如果硬件有能力，在err时将提交的wr错误完成，则不需要err的判断
	if (unlikely(qp->qp_state == IBV_QPS_ERR) && (ctx->sw_err_flush == 1)) {
		struct yib_sw_cqe input_sw_cqe;
		err = yib_urq_recv_wr_when_err(ctx, qp, wr, &input_sw_cqe);
		pthread_spin_unlock(&rq->lock);
		if (input_sw_cqe.end_pos > input_sw_cqe.start_pos)
			yib_usw_cqe_generate(ctx, recv_cq , &input_sw_cqe);
		goto end;
	}

	while (wr) {
		//再次检查，状态不对退出
		if (unlikely(qp->qp_state < IBV_QPS_INIT)) {
			YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_IO , "qp: %d recv in wrong state:%d \n",qp->qpn, qp->qp_state);
			err = -EINVAL;
			goto exit;
		}

		err = post_one_recv(ctx, rq, wr); //gsi硬件接收产生cq
		if (unlikely(err)) {
			*bad_wr = wr;
			break;
		}

		io_cnt++;
		wr = wr->next;
	}

exit:
	if (io_cnt > 0) {		
		udma_to_device_barrier();
		ctx->hw_ops->rq_pi_db_update(ctx , rq, io_cnt);
	}
	pthread_spin_unlock(&rq->lock);

end:
	if (err)
		*bad_wr = wr;
	return err;
}


static int yib_u_srq_post_one_recv(struct yib_context *ctx , struct yib_srq *srq, struct ibv_recv_wr *wr)
{
	int err;
	int i;
	u32 length;
	u8 *rqe = NULL;
	int num_sge = wr->num_sge;
	struct yib_rq *rq = &srq->rq;
	int pos = 0;

	if (unlikely(num_sge > ctx->hw_caps.max_srq_sge)) {
		rq->rq_info.info->direct_cnt++;
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_IO , "recv failed for sge:%d > max_recv_sge:%d\n", 
			num_sge, ctx->hw_caps.max_srq_sge);
		err = -EINVAL;
		goto exit;
	}

	length = 0;
	for (i = 0; i < num_sge; i++)
		length += wr->sg_list[i].length;

	if (ctx->hw_ops->check_srq_full(ctx, srq, &pos)) {
		rq->rq_info.info->err_count++;
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_IO , "srq queue is full\n");
		err = -ENOMEM;
		goto exit;
	}

#if (0) //当前版本不支持srq limit,后面再扩展
	if (yrq->bsrq) {
		struct yib_srq *ysrq = yrq->parent;
		if (yib_queue_get_count(&yrq->queue, YIB_RQ_QUEUE_MASK) >= ysrq->limit && ysrq->limit > 0) {
			yib_run_srq_limit_evts(yib, ysrq);
		}
	}
#endif
	rqe = yib_u_queue_get_vaddr_by_index(rq->buf_v.buf, rq->rq_info.item_size, pos);
	err = ctx->hw_ops->fill_srqe(ctx, rq, (const void*)wr, rqe, length, pos);
	if (unlikely(err)) {
		rq->rq_info.info->direct_cnt++;
		goto exit;
	}

	rq->sw_cmds[pos].wrid = wr->wr_id;
	rq->sw_cmds[pos].opcode = IBV_WC_RECV;
	rq->sw_cmds[pos].at_err = 0;
	rq->sw_cmds[pos].bsignal = 1;
	rq->sw_cmds[pos].posted = 1;
	rq->rq_info.info->io_count++;

	__set_bit(pos, srq->post_bitmap);
	udma_to_device_barrier();
	ctx->hw_ops->srq_pi_db_update(ctx, srq, pos);

exit:
	return err;
}


int yib_u_srq_recv_wr(struct yib_context *ctx, struct yib_srq *srq, struct ibv_recv_wr *wr,
			struct ibv_recv_wr **bad_wr)
{

	struct yib_rq *rq = &srq->rq;
	int err = -EINVAL;

	if( pthread_spin_lock(&rq->lock) ){
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_IO , "rq lock failed \n" );
		return -1;
	}

	while (wr) {
		err = yib_u_srq_post_one_recv(ctx, srq, wr); 
		if (unlikely(err)) {
			*bad_wr = wr;
			break;
		}
		wr = wr->next;
	}

	if(pthread_spin_unlock(&rq->lock)){
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_IO , "rq  unlock failed \n" );
		return -2;
	}

	if (err)
		*bad_wr = wr;
	return err; 
}


int yib_u_post_srq_recv(struct ibv_srq *ibvsrq,struct ibv_recv_wr *wr,
				   struct ibv_recv_wr **bad_wr)
{

	struct yib_srq *srq = to_yib_srq(ibvsrq);
	struct yib_rq *rq = &srq->rq;
	struct yib_context *ctx = rq->ctx;
	int io_cnt = 0;
	int ret = 0 ;
 	if (unlikely(!rq)) {
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_IO , "srq: %d srq is null\n", srq->rq.qid );
		*bad_wr = wr;
		return -EINVAL;
	}
	
	ret = yib_u_srq_recv_wr(ctx , srq , wr , bad_wr);

	if (ret) {		
		udma_to_device_barrier();
		ctx->hw_ops->rq_pi_db_update(ctx , rq, io_cnt);
	}

//exit:
	if (ret)
		*bad_wr = wr;
	return ret;
}


