#ifndef _SW_CQ_H_
#define _SW_CQ_H_

#include <sys/types.h>
#include <infiniband/verbs.h>

#include "yib.h"
#include "io.h"

void yib_clear_sw_cqe_list(struct yib_context *ctx , struct yib_cq *cq, u64 handle, bool b_all);

int yib_cur_usw_cqe_process(struct yib_context *ctx, struct yib_cq *cq, struct ibv_wc *wc);
bool yib_usw_poll_cq(struct yib_context *ctx, struct yib_cq *cq, struct ibv_wc *wc_out);
int yib_usq_send_wr_when_err(struct yib_context *ctx, 
							struct yib_qp *qp, 
							const  struct ibv_send_wr *wr,
		   					struct yib_sw_cqe *input_sw_cqe);

int yib_urq_recv_wr_when_err(struct yib_context *ctx, 
			struct yib_qp *qp, 
			const  struct ibv_recv_wr *wr,
		    struct yib_sw_cqe *input_sw_cqe);

int yib_usw_cqe_generate(struct yib_context *ctx, struct yib_cq *cq, struct yib_sw_cqe *input_sw_cqe);
enum ibv_wc_opcode yib_wr_to_wc_opcode(enum ibv_wr_opcode opcode);
#endif