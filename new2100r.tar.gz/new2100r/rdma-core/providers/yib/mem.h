#ifndef _YIB_MEM_H
#define _YIB_MEM_H

#include <stdlib.h>
#include <stdio.h>


#define YIBfree(ptr) 							\
do{ 										\
	if(ptr) { 								\
		free(ptr) ; 						\
		ptr = NULL ; 						\
	} 										\
}while(0)


static inline void *YIBmalloc(size_t size)
{
	void *ptr = NULL;

	ptr = malloc(size);
	if (!ptr) {
		fprintf(stderr, "malloc failed\n");
		return NULL;
	}

	return ptr;
}


struct yib_roce_buf {
	void			*buf;
	unsigned int	length;
	int 			q_depth;	// 队列深度,单位wqe个数
};


int  yib_roce_alloc_buf(struct yib_roce_buf *buf, unsigned int size,int page_size);
void yib_roce_free_buf(struct yib_roce_buf *buf);




#endif


