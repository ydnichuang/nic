#include <sys/types.h>
#include <errno.h>
#include <sys/mman.h>
#include <stdlib.h>
#include <stdint.h>

#include "yib_utils.h"
#include "yib_log.h"
#include "ib.h"

#define PAGE_SIZE  4096ul
//适用于2的整数次放
#define align(x,s) ((x) & ~((s) - 1))
#define align_up(x,s) (((x) + (s) -1) & ~((s) -1))
#define align_any(x, a)  ((x)  / (a) * (a))
#define align_any_up(x, a)   (((x) + (a) - 1) / (a) * (a))


#define YIB_MAP_ALIGN (4096ul)



u32 numTo2n2(uint32_t    x)
{
	int i = 1;
	uint32_t tmp = x;
	while (x >>= 1) {
		i <<= 1;
	}
	return (i < tmp)? i << 1: i;
}

int log2n(uint32_t x)
{
	int n = 0;
	while (1 < x) {
		n++;
		x >>= 1;
	}	
	return n;
}



static inline off_t yib_mmap_cmd_code(yib_mmap_t type, uint32_t qid) {
    off_t ret = (type & 0x0F) << 28; // type: 4bit, 
    ret += (qid & 0x0FFFFFFF); //qid: 28bit
    return ret << 12; //4096 align
}

void* yib_mmap_addr(int fd, uint64_t pa, int size) {
    void* p = NULL;
    uint64_t pa_align = pa - (pa & (4096ul - 1));
    uint32_t add = pa - pa_align;
    if (pa == 0)
        return NULL;

    p = mmap(NULL, size + add, PROT_READ | PROT_WRITE, MAP_SHARED, fd,
             pa_align);
    if (p == MAP_FAILED || p == NULL) {
//        YIB_ERR(SYS, "map pa=%lx size=%d failed:%d", pa, size, errno);
        return NULL;
    }
    return p + add;
}

void yib_ummap_vaddr(void* va, int size) {
    uint64_t iva = (uint64_t)va;
    if (va == NULL)
        return;
    uint32_t sub = iva - (iva & ~(4096 - 1));

    munmap(va - sub, size + sub);
}


void yib_queue_calc_depth(int item_size, uint32_t *cnt)
{
	//前提:一个4k能放整数个cqe,sqe, rqe
	uint32_t basic = 0;
	uint32_t page_size = PAGE_SIZE;

	basic = page_size / item_size;
	*cnt = align_any_up(*cnt, basic); //按basic对齐
	*cnt = numTo2n2(*cnt);//按2整数次幂对齐
}


void *yib_private_mmap(yib_mmap_t type, uint32_t qid, size_t len, int fd)
{
	len = (len + YIB_MAP_ALIGN - 1) / YIB_MAP_ALIGN * YIB_MAP_ALIGN;
	void *addr;
	addr = mmap(NULL, len, PROT_READ | PROT_WRITE, MAP_SHARED, fd, yib_mmap_cmd_code(type, qid));

	if (MAP_FAILED == addr)
	{
		YIB_USER_ERR("map type:%d len:%ld qid:%d failed, errno:%d", type, len, qid, errno);
		addr = NULL;
	}
	return addr;
}

void yib_private_munmap(void *addr, size_t len)
{
	len = (len + YIB_MAP_ALIGN - 1) / YIB_MAP_ALIGN * YIB_MAP_ALIGN;
	munmap(addr, len);
}

int yib_resource_mmap(struct yib_context *ctx)
{
#if defined(YIB_CFG_MAP_GLOABL_QINFO)
	ctx->resource.cq_base = yib_private_mmap(YIB_MMAP_TYPE_CQ, 0, ctx->hw_caps.max_cq * sizeof(struct yib_queue_info), ctx->cmd_fd);
	if (ctx->resource.cq_base == NULL)
		return -ENOMEM;

	ctx->resource.sq_base = yib_private_mmap(YIB_MMAP_TYPE_SQ, 0, ctx->hw_caps.max_qp * sizeof(struct yib_queue_info), ctx->cmd_fd);
	if (ctx->resource.sq_base == NULL) {
		yib_private_munmap(ctx->resource.cq_base, ctx->hw_caps.max_cq * sizeof(struct yib_queue_info));
		return -ENOMEM;
	}

	ctx->resource.rq_base = yib_private_mmap(YIB_MMAP_TYPE_RQ, 0, ctx->hw_caps.max_qp * sizeof(struct yib_queue_info), ctx->cmd_fd);
	if (ctx->resource.rq_base == NULL) {
		yib_private_munmap(ctx->resource.cq_base, ctx->hw_caps.max_cq * sizeof(struct yib_queue_info));
		yib_private_munmap(ctx->resource.sq_base, ctx->hw_caps.max_qp * sizeof(struct yib_queue_info));
		return -ENOMEM;
	}
#endif
	return 0;
}

void yib_resource_unmmap(struct yib_context *ctx)
{
#if defined(YIB_CFG_MAP_GLOABL_QINFO)
	if (ctx->resource.cq_base)
		yib_private_munmap(ctx->resource.cq_base, ctx->hw_caps.max_cq * sizeof(struct yib_queue_info));
	if (ctx->resource.sq_base)
		yib_private_munmap(ctx->resource.sq_base, ctx->hw_caps.max_qp * sizeof(struct yib_queue_info));
	if (ctx->resource.rq_base)
		yib_private_munmap(ctx->resource.rq_base, ctx->hw_caps.max_qp * sizeof(struct yib_queue_info));

	memset(&ctx->resource , 0 , sizeof(struct resource));
#endif
	return;
}