#include "basic.h"
#include "yib.h"
#include "ib.h"
#include <pthread.h>
#include "yib_utils.h"
#include "yib_log.h"

#include "swcmd.h"
#include "hw/hw_comm.h"


#define YCQ_TASKLET_MAX_TIME_JIFFIES msecs_to_jiffies(2)


enum ibv_wc_opcode yib_wr_to_wc_opcode(enum ibv_wr_opcode opcode)
{
	switch (opcode) {
	case IBV_WR_RDMA_WRITE:			return IBV_WC_RDMA_WRITE;
	case IBV_WR_RDMA_WRITE_WITH_IMM:		return IBV_WC_RDMA_WRITE;
	case IBV_WR_SEND:			return IBV_WC_SEND;
	case IBV_WR_SEND_WITH_IMM:		return IBV_WC_SEND;
	case IBV_WR_RDMA_READ:			return IBV_WC_RDMA_READ;
	case IBV_WR_ATOMIC_CMP_AND_SWP:		return IBV_WC_COMP_SWAP;
	case IBV_WR_ATOMIC_FETCH_AND_ADD:	return IBV_WC_FETCH_ADD;
//	case IBV_WR_LSO:				return IBV_WC_LSO;
	case IBV_WR_SEND_WITH_INV:		return IBV_WC_SEND;
//	case IBV_WR_RDMA_READ_WITH_INV:		return IBV_WC_RDMA_READ;
	case IBV_WR_LOCAL_INV:			return IBV_WC_LOCAL_INV;
//	case IBV_WR_REG_MR:			return IBV_WC_REG_MR;
	case IBV_WR_BIND_MW:			return IBV_WC_BIND_MW;

	default:
		return 0xff;
	}
}



static inline u32  yib_get_rq_sw_idx(struct yib_rq *rq)
{
	return rq->qid;
}

static inline u32  yib_get_cq_sw_idx(struct yib_cq *cq)
{
	return cq->cq_id;
}

//qpc_index is the index in ddr qpc table, entry_index is index of qp sw table
static inline u32  yib_get_qp_sw_idx(struct yib_qp *qp)
{
	return qp->qpn;
}

void yib_clear_sw_cqe_list(struct yib_context *ctx , struct yib_cq *cq, u64 handle, bool b_all)
{

	struct yib_sw_cqe *sw_cqe, *temp;

	pthread_spin_lock(&cq->lock);
	if (b_all) {
//		list_for_each_entry_safe(sw_cqe, temp, &cq->sw_done_list, node) {
		list_for_each_safe(&cq->sw_done_list, sw_cqe, temp, node){
			list_del(&sw_cqe->node);
			YIBfree(sw_cqe);
		}
		if (cq->cur_sw_cqe) {
			YIBfree(cq->cur_sw_cqe);
			cq->cur_sw_cqe = NULL;
		}
	} else {
//		list_for_each_entry_safe(sw_cqe, temp, &cq->sw_done_list, node) {
		list_for_each_safe(&cq->sw_done_list, sw_cqe, temp, node){
			if (sw_cqe->handler == handle) {
				list_del(&sw_cqe->node);
				YIBfree(sw_cqe);
			}

			if (cq->cur_sw_cqe) {
				if (cq->cur_sw_cqe->handler == handle) {
					YIBfree(cq->cur_sw_cqe);
					cq->cur_sw_cqe = NULL;
				}
			}
		}
	}
	pthread_spin_unlock(&cq->lock);
}

int yib_usw_cqe_generate(struct yib_context *ctx, struct yib_cq *cq, struct yib_sw_cqe *input_sw_cqe)
{
	struct yib_sw_cqe *sw_cqe = NULL;

	if (cq == NULL)
		return -EINVAL;

	sw_cqe = YIBmalloc(sizeof(struct yib_sw_cqe));
	if (sw_cqe == NULL) {
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_IO , "sw_cqe alloc failed\n");
		return -ENOMEM;
	}

	sw_cqe->type      = input_sw_cqe->type;
	sw_cqe->status    = input_sw_cqe->status;
	sw_cqe->start_pos = input_sw_cqe->start_pos;
	sw_cqe->end_pos   = input_sw_cqe->end_pos;
	sw_cqe->depth     = input_sw_cqe->depth;
	sw_cqe->handler   = input_sw_cqe->handler;

	pthread_spin_lock(&cq->lock);
//	list_add_tail(&sw_cqe->node, &cq->sw_done_list);
	list_add_tail(&cq->sw_done_list , &sw_cqe->node );
	pthread_spin_unlock(&cq->lock);
	return 0;
}

int yib_cur_usw_cqe_process(struct yib_context *ctx, struct yib_cq *cq, struct ibv_wc *wc)
{
	if (ctx->hw_ops->sw_fill_cqe(ctx, cq, wc) != 0)
		return -1;
	cq->cur_sw_cqe->start_pos = (cq->cur_sw_cqe->start_pos + 1) % cq->cur_sw_cqe->depth;
	if (cq->cur_sw_cqe->start_pos == cq->cur_sw_cqe->end_pos) {
		YIBfree(cq->cur_sw_cqe);
	}
	return 0;
}

// return true if have sw cqe
bool yib_usw_poll_cq(struct yib_context *ctx, struct yib_cq *cq, struct ibv_wc *wc_out)
{
	struct yib_sw_cqe *sw_cqe, *temp;

	if (cq->cur_sw_cqe != NULL) {
		if (yib_cur_usw_cqe_process(ctx, cq, wc_out) != 0)
			return false;
		return true;
	}
//	list_for_each_entry_safe(sw_cqe, temp, &cq->sw_done_list, node) {
	list_for_each_safe(&cq->sw_done_list, sw_cqe, temp, node){		
		list_del(&sw_cqe->node);
		cq->cur_sw_cqe = sw_cqe;
		if (yib_cur_usw_cqe_process(ctx, cq, wc_out) != 0)
			return false;
		return true;
	}

	return false;
}



int yib_usq_send_wr_when_err(struct yib_context *ctx, 
							struct yib_qp *qp, 
							const  struct ibv_send_wr *wr,
		   					struct yib_sw_cqe *input_sw_cqe)
{
	int io_cnt = 0;
	struct yib_sq *sq = &qp->sq;
	int pos = atomic_read(&sq->sq_info.info->pi);

	input_sw_cqe->start_pos = pos;
	while (wr) {
		if (ctx->hw_ops->check_sq_full(ctx, sq)) {
			YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_IO , "sq queue is full at err state\n");
			return -ENOMEM;
		}

		sq->sw_cmds[pos].wrid = wr->wr_id;
		sq->sw_cmds[pos].opcode = yib_wr_to_wc_opcode(wr->opcode);
		sq->sw_cmds[pos].at_err = 1;
		sq->sw_cmds[pos].bsignal = 1;
		sq->sw_cmds[pos].posted = 1;

		pos = yib_u_queue_advance_pi(sq->sq_info.info , 1 , sq->buf_v.q_depth);
		io_cnt++;
		wr = wr->next;
	}

	input_sw_cqe->type = YIB_CQE_SQ;
	input_sw_cqe->status = IBV_WC_WR_FLUSH_ERR;
	input_sw_cqe->depth = sq->buf_v.q_depth;
	input_sw_cqe->end_pos = (input_sw_cqe->start_pos + io_cnt) % input_sw_cqe->depth;
	input_sw_cqe->handler = (u64)qp;
	return 0;
}



int yib_urq_recv_wr_when_err(struct yib_context *ctx, 
			struct yib_qp *qp, 
			const  struct ibv_recv_wr *wr,
		    struct yib_sw_cqe *input_sw_cqe)
{
	int io_cnt = 0;
	struct yib_rq *rq = &qp->rq;
	int pos = atomic_read(&rq->rq_info.info->pi);

	input_sw_cqe->start_pos = pos;
	while (wr) {
		if (ctx->hw_ops->check_rq_full(ctx, rq)) {
			YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_IO , "rq queue is full at err state\n");
			return -ENOMEM;
		}

		rq->sw_cmds[pos].wrid = wr->wr_id;
		rq->sw_cmds[pos].at_err = 1;
		rq->sw_cmds[pos].opcode = IBV_WC_RECV;
		rq->sw_cmds[pos].bsignal = 1;
		rq->sw_cmds[pos].posted = 1;

		pos = yib_u_queue_advance_pi(rq->rq_info.info , 1 , rq->buf_v.q_depth);
		io_cnt++;
		wr = wr->next;
	}

	input_sw_cqe->type = YIB_CQE_RQ;
	input_sw_cqe->status = IBV_WC_WR_FLUSH_ERR;
	input_sw_cqe->depth =  rq->buf_v.q_depth;
	input_sw_cqe->end_pos = (input_sw_cqe->start_pos + io_cnt) % input_sw_cqe->depth;
	input_sw_cqe->handler = (u64)rq;
	return 0;
}
							

#define SW_CMD



//在fill cqe中调用
void yib_usq_swcmd_done(struct yib_context *ctx, struct yib_qp *qp, int index, bool bsw)
{
	struct yib_sq *sq = &qp->sq;
	int cmpl_cnt = 1;

#if (YIB_DEBUG_IO_DONE == 1)
	int i = queue_index_dec(index, sq->buf_v.q_depth);

	if (bsw) {
		if (sq->sw_posted[index] > 0)
			sq->sw_posted[index]--;
		else
			YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_IO ,\
			"qpn:%d, comp an err sq at %d, no sw posted\n",  qp->qpn, index);
		return;
	}

	if (sq->sw_cmds[index].posted == 0 ) {
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_IO ,\
			"qpn:%d, comp an err sq at %d, no posted\n",  qp->qpn, index);
		goto end;
	}
	//fill cqe时根据wc填写at_err状态
	if (sq->sw_cmds[index].bsignal== 0 && sq->sw_cmds[index].at_err == 0) {
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_IO ,\
			"qpn:%d, comp an err sq at %d, no signal, no err\n",  qp->qpn, index);
		goto end;
	}

	while (true) {
		if (sq->sw_cmds[i].posted == 0)
			break;
		if (sq->sw_cmds[i].bsignal == 1 || sq->sw_cmds[i].at_err == 1) {
			YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_IO ,\
				"qpn:%d, sq comp seq err at %d\n", qp->qpn, index);
			break;
		}
		memset(&sq->sw_cmds[i], 0, sizeof(struct yib_sw_cmd));
		i = queue_index_dec(i, sq->buf_v.q_depth);
		cmpl_cnt++;
	}

end:
	memset(&sq->sw_cmds[index], 0, sizeof(struct yib_sw_cmd));
	yib_u_queue_advance_ci(sq->sq_info.info, cmpl_cnt , sq->buf_v.q_depth);
	
#else
	//默认index合法，即在ci与pi之间，此处不做校验
	u32 ci = atomic_get(&qp->sq.sq_info.info->ci);
	if (index >= ci) {
		cmpl_cnt = index - ci + 1;
		memset(&sq->sw_cmds[ci], 0, cmpl_cnt * sizeof(struct yib_sw_cmd));
		yib_u_queue_advance_ci(sq->sq_info.info, cmpl_cnt , sq->buf_v.q_depth);
	} else {
		cmpl_cnt = index + sq->buf_v.q_depth - ci + 1;
		memset(&sq->sw_cmds[ci], 0, (sq->buf_v.q_depth - ci) * sizeof(struct yib_sw_cmd));
		memset(&sq->sw_cmds[0], 0, index * sizeof(struct yib_sw_cmd));
		yib_u_queue_advance_ci(sq->sq_info.info, cmpl_cnt , sq->buf_v.q_depth);
	}
#endif

}

//在fill cqe中调用
void yib_usrq_swcmd_done(struct yib_context *ctx, struct yib_srq *srq, int index)
{
	if (srq->rq.sw_cmds[index].posted == 0) {
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_IO ,"srqn:%d, comp srq err at %d\n", yib_get_rq_sw_idx(&srq->rq), index);
	}

	memset(&srq->rq.sw_cmds[index], 0, sizeof(struct yib_sw_cmd));
	clear_bit(index, srq->post_bitmap);
	clear_bit(index, srq->db_bitmap);
}

//在fill cqe中调用
void yib_urq_swcmd_done(struct yib_context *ctx, struct yib_rq *rq, int index)
{
	int depth = rq->buf_v.q_depth;
	if (rq->sw_cmds[index].posted == 0) {
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_IO ,"rqn:%d, comp rq err at %d\n", yib_get_rq_sw_idx(rq), index);
	}
	memset(&rq->sw_cmds[index], 0, sizeof(struct yib_sw_cmd));
	yib_u_queue_advance_ci(rq->rq_info.info, 1 , depth);
}

#define CHECK

int yib_srq_find_useable_pos(struct yib_srq *srq)
{
	int pos = 0;
	pos = find_next_zero_bit(srq->post_bitmap, srq->rq.buf_v.q_depth, srq->next_db);
	if (pos >= srq->rq.buf_v.q_depth) {
		pos = find_first_zero_bit(srq->post_bitmap, srq->rq.buf_v.q_depth);
		if (pos >= srq->rq.buf_v.q_depth) {
			return -ENOMEM;
		}
	}

	return pos;
}



void yib_aeq_generate_sq_sw_cqe(struct yib_context *context, struct yib_qp *qp)
{

	struct yib_sq *sq = &qp->sq;
	struct yib_cq *cq = to_yib_cq(qp->vqp.qp.send_cq);
	struct yib_sw_cqe input_sw_cqe;

	if (context->quick_excep == 0)
		return;

	input_sw_cqe.type = YIB_CQE_SQ;
	input_sw_cqe.status = IBV_WC_WR_FLUSH_ERR;
	input_sw_cqe.depth = sq->buf_v.q_depth;
	input_sw_cqe.handler = (u64)qp;

	pthread_spin_lock(&sq->lock);
	input_sw_cqe.start_pos = atomic_read(&sq->sq_info.info->ci);
	input_sw_cqe.end_pos = atomic_read(&sq->sq_info.info->pi);
	while ((input_sw_cqe.end_pos != input_sw_cqe.start_pos) && sq->sw_cmds[input_sw_cqe.end_pos - 1].at_err) {
		input_sw_cqe.end_pos = queue_index_dec(input_sw_cqe.end_pos, input_sw_cqe.depth);
	}
	pthread_spin_unlock(&sq->lock);

	if (input_sw_cqe.end_pos != input_sw_cqe.start_pos)
		yib_usw_cqe_generate(qp->ctx , cq , &input_sw_cqe);
}

void yib_aeq_generate_rq_sw_cqe(struct yib_context *context, struct yib_qp *qp)
{
	struct yib_rq *rq = &qp->rq;
	struct yib_cq *cq = to_yib_cq(qp->vqp.qp.recv_cq);
	struct yib_sw_cqe input_sw_cqe;

	if (context->quick_excep == 0)
		return;

	input_sw_cqe.type = YIB_CQE_RQ;
	input_sw_cqe.status = IBV_WC_WR_FLUSH_ERR;
	input_sw_cqe.depth = rq->buf_v.q_depth;
	input_sw_cqe.handler = (u64)qp;

	pthread_spin_lock(&rq->lock);
	input_sw_cqe.start_pos = atomic_read(&rq->rq_info.info->ci);
	input_sw_cqe.end_pos = atomic_read(&rq->rq_info.info->pi);
	while ((input_sw_cqe.end_pos != input_sw_cqe.start_pos) && rq->sw_cmds[input_sw_cqe.end_pos - 1].at_err) {
		input_sw_cqe.end_pos = queue_index_dec(input_sw_cqe.end_pos, input_sw_cqe.depth);
	}
	pthread_spin_unlock(&rq->lock);

	if (input_sw_cqe.end_pos != input_sw_cqe.start_pos)
		yib_usw_cqe_generate(qp->ctx , cq , &input_sw_cqe);
}