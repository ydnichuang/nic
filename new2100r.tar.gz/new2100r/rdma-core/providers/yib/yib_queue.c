#include "yib_queue.h"
#include <errno.h>

int yib_queue_mmap(struct yib_queue* queue,
                   int depth,
                   int isize,
                   int fd,
                   u64 q_id,
                   u32 mask,
                   enum yib_mmap_type type) {
    queue->depth = depth;
    queue->item_size = isize;
    queue->mask = mask;
    queue->buf =
        yib_private_mmap(type, q_id, ((size_t)queue->depth) * queue->item_size, fd);
    if (queue->buf == NULL) {
        YIB_ERR(SYS, "map queue:%lld depth:%d item_size:%d failed, errno:%d",
                q_id, queue->depth, queue->item_size, errno);
        return -errno;
    }
    return 0;
}

int yib_queue_unmmap(struct yib_queue* queue) {
    int ret = 0;
    if (queue->buf) {
        ret = munmap(queue->buf, queue->depth * queue->item_size);
        if(ret == 0)
            queue->buf = NULL;
    }
    return ret;
}

static inline int yib_queue_cnt(u32 pi_val, u32 ci_val, u32 mask) //mask不包含反转位
{
	int diff = pi_val - ci_val;

	if (diff == 0) {
		return 0;
	} else if (diff < 0) {
		return diff + ((mask + 1) << 1);
	} else {
		return diff;
	}
}

int yib_queue_get_count(struct yib_queue *queue)
{
	u32 pi_val = atomic_load(queue->sw_pi) & queue->mask;
	u32 ci_val = atomic_load(queue->sw_ci) & queue->mask;
	return yib_queue_cnt(pi_val, ci_val, queue->mask >> 1);
}

bool yib_queue_is_full(struct yib_queue *queue)
{
	u32 pi_val = atomic_load(queue->sw_pi) & queue->mask;
	u32 ci_val = atomic_load(queue->sw_ci) & queue->mask;
	return yib_queue_cnt(pi_val, ci_val, queue->mask >> 1) == queue->depth;
}

bool yib_queue_is_empty(struct yib_queue *queue)
{
	u32 pi_val = atomic_load(queue->sw_pi) & queue->mask;
	u32 ci_val = atomic_load(queue->sw_ci) & queue->mask;
	if (pi_val == ci_val) 
		return 0;
	return 1;
}


void* yib_queue_get_addr_by_index(struct yib_queue *queue, u32 index)
{
    u64 off;
    index %= queue->depth;
    off = (u64)queue->item_size * index;
    return (char *)queue->buf + off; 
}

bool yib_queue_check_full_by_pi(struct yib_queue* queue, u32 pi) {
    pi &= queue->mask;
    return yib_queue_cnt(pi, atomic_load(queue->sw_ci) & queue->mask, queue->mask >> 1) == queue->depth;
}

void* yib_queue_prod_addr(struct yib_queue* queue) {
    if (yib_queue_is_full(queue))
        return NULL;
    return yib_queue_get_addr_by_index(queue, atomic_load(queue->sw_pi) & queue->mask);
}

void* yib_queue_cons_addr(struct yib_queue* queue) {
    if (yib_queue_is_empty(queue))
        return NULL;
    return yib_queue_get_addr_by_index(queue, atomic_load(queue->sw_ci));
}