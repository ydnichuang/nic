#ifndef YIB_BASIC_H
#define YIB_BASIC_H

#include <stdint.h>
#include <stdarg.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/mman.h>
#include <pthread.h>
#include <string.h>
#include <sched.h>
#include <sys/param.h>
#include <util/util.h>
#include <util/mmio.h>
#include <util/udma_barrier.h>

/* UserSpace  typedefs  */
#include <sys/types.h>
/* Kernel typedefs 		*/
#include <linux/types.h>

typedef uint8_t  u8;
typedef uint16_t u16; 
typedef uint32_t u32;
typedef uint64_t u64;



#include "config.h"
#include "mem.h"
#include "yib.h"
#include "yib_utils.h"




#define u64_lsb(a) ((u32)((a) & 0xFFFFFFFF))
#define u64_msb(a) ((u32)((a) >> 32))
#define yib_ilog32(n)		ilog32((n) - 1)





enum yrdma_host_type {
	YRDMA_TYPE_SWIFT2100R	= 0,
	YRDMA_TYPE_NP			= 1,
	YRDMA_TYPE_SWTEST       = 0xFE,
	YRDMA_TYPE_UNKNOW       = 0xFF,
};








#endif
