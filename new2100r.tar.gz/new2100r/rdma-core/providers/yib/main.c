
#include <infiniband/driver.h>
#include <infiniband/verbs.h>
#include <util/symver.h>
#include <rdma/ib_user_ioctl_cmds.h>


#include "basic.h"
#include "swtest.h"
#include "yib_log.h"
#include "yib-drv-cmd-abi.h"
#include "yib.h"
#include "ib.h"
#include "hw/2100r/sw2100r.h"
#include "hw/np/np.h"
#include "ioctl.h"


static u64 g_uctx_id = 0;

//This function is used to enable qp capture: todo
LATEST_SYMVER_FUNC(yib_enable_capture, 1_0, "YIB_1.0",
		   int,
		   struct ibv_qp *ibqp,
		   bool enable)
{
	struct yib_context *context = to_yib_ctx(ibqp->context);
	struct yib_qp *qp = to_yib_qp(ibqp);
	return context->hw_ops->set_capture(qp, enable);
}

LATEST_SYMVER_FUNC(yib_nvme_mode_set, 1_0, "YIB_1.0",
		   int,
		   struct ibv_context *context,
		   bool enable)
{
	struct yib_context *yctx = to_yib_ctx(context);
	yctx->nvme_off = enable;
	return 0;
}

//#define PCI_VENDOR_ID_YUSUR 0x15ad
#define PCI_VENDOR_ID_YUSUR 0x10EE //0x100f
#define HCA(v, d) VERBS_PCI_MATCH(PCI_VENDOR_ID_##v, d, NULL)

static const struct verbs_match_ent hca_table[] = {
    VERBS_DRIVER_ID(RDMA_DRIVER_ID_YUSUR),
	HCA(YUSUR,0x9038),
	HCA(YUSUR,0x9238),
	VERBS_PCI_MATCH(0x007f, 0x0043, NULL),
    {},
};

int yib_roce_alloc_buf(struct yib_roce_buf *buf, unsigned int size,
		       int page_size)
{
	int ret;
	buf->length = align(size, page_size);
	buf->buf = mmap(NULL, buf->length, PROT_READ | PROT_WRITE,
			MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
	if (buf->buf == MAP_FAILED) {
		return errno;
	}

	ret = ibv_dontfork_range(buf->buf, buf->length);
	if (ret) {
		munmap(buf->buf, buf->length);
	}

	return ret;
}

void yib_roce_free_buf(struct yib_roce_buf *buf)
{
    if(buf->buf) {
        ibv_dofork_range(buf->buf, buf->length);
        munmap(buf->buf, buf->length);
	buf->buf = NULL;
    }
}

//the *cnt*isize should be 4*(2^n)KB
int yib_roce_alloc_dma_buf(struct yib_roce_buf *buf, int *cnt, int isize)
{
	int bytes = 0;
	int ret = 0;
	int n = 0;

	bytes = align(*cnt * isize, 4096ul);
        *cnt = bytes / isize;

	n = numTo2n2(bytes/4096);
	*cnt = (n * 4096) / isize;
	bytes = *cnt * isize;
	ret = yib_roce_alloc_buf(buf, bytes, 4096ul);
	if (ret) {
		buf->buf = NULL;
		ret = -ENOMEM;
		return ret;
	}

	return ret;
}

static inline void print_fw_ver(uint64_t fw_ver, char *str, size_t len)
{
	u32 date, ver;

	date = u64_msb((fw_ver & 0xFFFFFFFF00000000));
	ver = u64_lsb((fw_ver & 0xFFFFFFFF));

	snprintf(str, len, "%04X.%02X.%02X.%04X%02X%02X",
		(int)(ver&0xF000>>12),(int)(ver&0xF00>>8), (int)(ver&0xFF),
		(uint16_t)((date & 0xFFFF0000)>>16), (u8)((date&0x0000FF00)>> 8), (u8)(date & 0xFF));
}


int yib_u_query_device(struct ibv_context *context,
			   const struct ibv_query_device_ex_input *input,
			   struct ibv_device_attr_ex *attr, size_t attr_size)
{
	struct ib_uverbs_ex_query_device_resp resp = {};
	size_t resp_size = sizeof(resp);
	int ret;

	ret = ibv_cmd_query_device_any(context, input, attr, attr_size,
				       &resp, &resp_size);
	if (ret)
		return ret;

	print_fw_ver(resp.base.fw_ver, attr->orig_attr.fw_ver, sizeof(attr->orig_attr.fw_ver));
	return 0;
}



static int yib_map_global_reg(struct yib_context *context,  int cmd_fd)
{
    return context->hw_ops->hw_global_map_reg(context) ;
}


static int yib_init_hw_func(struct yib_context *ctx) 
{
	
		int ret = 0;
		printf("hca %d %d \n",hca_table->vendor,hca_table->device);
		switch (ctx->chip_type) {
		case YRDMA_TYPE_NP:
			ctx->hw_ops = &np_hw_ctx_ops;
			verbs_set_ops(&ctx->ibv_ctx, &yib_np_uops);
			break;
		case YRDMA_TYPE_SWTEST:
			ctx->hw_ops = &swtest_hw_ctx_ops;
			verbs_set_ops(&ctx->ibv_ctx, &yib_uops);
//			ctx->hw_priv = ctx->hw_ops->hw_context_alloc(ctx);
			break;
		case YRDMA_TYPE_SWIFT2100R:
			ctx->hw_ops = &r2100u_hw_ctx_ops;
            verbs_set_ops(&ctx->ibv_ctx, &yib_uops);
			break;
		default:
			YIB_LOGm_ERR(ctx->dbg_fp,YIB_MSG_INIT ,"unknown yusur chip type:%u \n", ctx->chip_type);
			return -1;
	}

	ret = ctx->hw_ops->hw_context_alloc(ctx);
	ctx->nvme_off = false;
	return ret;
}




static void yib_ucontext_free(struct yib_context *context)
{

	yib_close_debug_file(context);


	context->hw_ops->hw_global_unmap_reg(context);
	context->hw_ops->hw_context_dealloc(context);

	verbs_uninit_context(&context->ibv_ctx);
	YIBfree(context);
}

void yib_dealloc_context(struct ibv_context *ibctx)
{
	struct yib_context *context = to_yib_ctx(ibctx);
	yib_ucontext_free(context);
}


//
static struct verbs_context *yib_alloc_context(struct ibv_device *ibdev,
						int cmd_fd,
						void *private_data)
{
	struct yib_device *dev = to_yib_dev(ibdev);
	struct yib_alloc_ucontext_resp resp={};
	struct ibv_device_attr dev_attrs;
	struct yib_context *context; // yib_context大改
	struct ibv_get_context cmd;

	context = verbs_init_and_alloc_context(ibdev, cmd_fd, context, ibv_ctx,
					       RDMA_DRIVER_ID_YUSUR);
	if (!context) {
		return NULL;
	}


	context->ctx_id = g_uctx_id++;

	yib_open_debug_file(context);
	yib_set_debug_mask();

	YIB_LOGm_DBG(context->dbg_fp, YIB_MSG_INIT, "alloc context\n");
	if (ibv_cmd_get_context(&context->ibv_ctx, &cmd, sizeof(cmd),
				&resp.ibv_resp, sizeof(resp))) {
		YIB_LOGm_ERR(context->dbg_fp,YIB_MSG_INIT ,"get ctx cmd failed\n");
		goto error_free;
	}

	YIB_LOGm_DBG(context->dbg_fp, YIB_MSG_INIT, \
									"alloc context OK chip:%d cq_isize:%d bar:%d map_len:%d cqe_isize:%d \n",\
									resp.chip_type ,resp.cq_isize ,resp.bar_offset \
									,resp.bar_map_len,resp.cq_isize);
				
	context->chip_type = resp.chip_type;				
	context->hw_caps.cqe_isize = resp.cq_isize;
	context->bar_offset = resp.bar_offset;
	context->bar_len = resp.bar_map_len;
	context->quick_excep = resp.quick_excep;
	context->sw_err_flush = resp.sw_err_flush;
	context->cmd_fd  = cmd_fd;
//	memcpy(context->mac, resp.smac, 6);

	
	if (yib_u_query_device(&context->ibv_ctx.context, NULL,
			       container_of(&dev_attrs,
					    struct ibv_device_attr_ex,
					    orig_attr), sizeof(dev_attrs)))
		goto error_free;

	dev->hw_version = dev_attrs.hw_ver;

	context->hw_caps.max_qp_wr = dev_attrs.max_qp_wr;
	context->hw_caps.max_sge = dev_attrs.max_sge;
	context->hw_caps.max_cqe = dev_attrs.max_cqe;
	context->hw_caps.max_qp = dev_attrs.max_qp;
	context->hw_caps.max_cq = dev_attrs.max_cq;
	context->hw_caps.max_mr = dev_attrs.max_mr;
	context->hw_caps.max_mr_size =  dev_attrs.max_mr_size;

	context->hw_caps.max_ah = dev_attrs.max_ah;
	context->hw_caps.max_pd = dev_attrs.max_pd;
	context->hw_caps.max_srq = dev_attrs.max_srq;
	context->hw_caps.max_srq_sge  = dev_attrs.max_srq_sge;



	if (yib_init_hw_func(context)) {
		YIB_LOGm_ERR(context->dbg_fp,YIB_MSG_INIT ,"yib_init_hw_func ctx cmd failed\n");
		goto error_free;
	}
	if (yib_map_global_reg(context, context->cmd_fd)) {
		YIB_LOGm_ERR(context->dbg_fp,YIB_MSG_INIT ,"yib_map_global_reg ctx cmd failed\n");
		goto error_free;
	}

	YIB_LOGm_DBG(context->dbg_fp, YIB_MSG_INIT, "alloc context OK\n");
	return &context->ibv_ctx;

error_free:
	yib_ucontext_free(context);
	return NULL;
}


static void yib_uninit_device(struct verbs_device *verbs_device)
{
	struct yib_device *dev = to_yib_dev(&verbs_device->device);
	YIBfree(dev);
}

static struct verbs_device *yib_device_alloc(struct verbs_sysfs_dev *sysfs_dev)
//不需要修改
{
	struct yib_device *dev;

	dev = calloc(1, sizeof(struct yib_device));
	if (!dev)
		return NULL;

	dev->page_size = sysconf(_SC_PAGESIZE);

	return &dev->ibv_dev;
}

int yib_ib_ext_cmd(struct ibv_context *context, struct yib_ext_in_cmd_hdr *in,
				   struct yib_ext_out_cmd_hdr *out)
{
	DECLARE_COMMAND_BUFFER(cmd,
			       YIB_IB_OBJECT_EXT_OBJ,
			       YIB_IB_METHOD_EXT_CMD,
			       2);

	fill_attr_in(cmd, YIB_IB_ATTR_EXT_CMD_IN, in, sizeof(*in));
	fill_attr_out(cmd, YIB_IB_ATTR_EXT_CMD_OUT, out, sizeof(*out));

	return execute_ioctl(context, cmd);
}

static const struct verbs_device_ops yib_dev_ops = {
	.name = "yusur",
	.match_min_abi_version = 0,
	.match_max_abi_version = 6,
	.match_table = hca_table, //暂定,不确定id
	.alloc_device = yib_device_alloc,
	.uninit_device = yib_uninit_device,
	.alloc_context = yib_alloc_context,
};
PROVIDER_DRIVER(yib, yib_dev_ops);

u32 yib_get_qpc_index(struct yib_context *ctx, u32 entry_index)
{
	return entry_index;
}

u32 yib_get_qp_entry_idx(struct yib_context *ctx, u32 qpc_index)
{
//	int each = 0;
	return qpc_index;
}

u32 yib_get_cqc_index(struct yib_context *ctx, u32 entry_index)
{
//	int each = 0;
	return entry_index;
}

u32 yib_get_cq_entry_idx(struct yib_context *ctx, u32 cqc_index)
{
//	int each = 0;
	return (cqc_index);	
}
