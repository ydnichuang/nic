#ifndef YIB_U_ABI_H
#define YIB_U_ABI_H

#include <infiniband/kern-abi.h>
#include <rdma/ib_user_verbs.h>
#include <rdma/yib-abi.h>
#include <kernel-abi/yib-abi.h>



DECLARE_DRV_CMD(yib_alloc_ucontext,
                IB_USER_VERBS_CMD_GET_CONTEXT,
                empty,
                yib_ib_alloc_uctx_resp);
DECLARE_DRV_CMD(yib_alloc_pd,
                IB_USER_VERBS_CMD_ALLOC_PD,
                empty,
                yib_ib_alloc_pd_resp);
DECLARE_DRV_CMD(yib_reg_mr,
                IB_USER_VERBS_CMD_REG_MR,
                yib_ib_reg_mr,
                empty);                
DECLARE_DRV_CMD(yib_create_ah,
                IB_USER_VERBS_CMD_CREATE_AH,
                empty,
                yib_ib_create_ah_resp);
DECLARE_DRV_CMD(yib_create_cq,
                IB_USER_VERBS_CMD_CREATE_CQ,
                yib_ib_create_cq,
                yib_ib_create_cq_resp);
DECLARE_DRV_CMD(yib_create_qp,
                IB_USER_VERBS_CMD_CREATE_QP,
                yib_ib_create_qp,
                yib_ib_create_qp_resp);
/* DECLARE_DRV_CMD(yib_resize_cq,
                IB_USER_VERBS_CMD_RESIZE_CQ,
                yib_ib_resize_cq,
                empty); */
DECLARE_DRV_CMD(yib_create_qp_ex,
                IB_USER_VERBS_EX_CMD_CREATE_QP,
                yib_ib_create_qp,
                yib_ib_create_qp_resp);
DECLARE_DRV_CMD(yib_create_srq,
                IB_USER_VERBS_CMD_CREATE_SRQ,
                yib_ib_create_srq,
                yib_ib_create_srq_resp);

DECLARE_DRV_CMD(yib_modify_srq,
                IB_USER_VERBS_CMD_MODIFY_SRQ,
                yib_ib_modify_srq,
                empty);

#endif /* XIB_U_ABI_H */