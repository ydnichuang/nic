#ifndef YIB_IB_H
#define YIB_IB_H

#include "basic.h"
#include "rdma/yib-abi.h"
#include "stdatomic.h"

extern const struct verbs_context_ops yib_uops;
extern const struct verbs_context_ops yib_np_uops;

enum yib_cqe_type {
    YIB_CQE_SQ,
    YIB_CQE_RQ,
    YIB_CQE_SRQ,
};

enum yib_wr_mask {
	WR_INLINE_MASK			= BIT(0),
	WR_ATOMIC_MASK			= BIT(1),
	WR_SEND_MASK			= BIT(2),
	WR_READ_MASK			= BIT(3),
	WR_WRITE_MASK			= BIT(4),
	WR_LOCAL_MASK			= BIT(5),
	WR_REG_MASK			= BIT(6),

	WR_READ_OR_WRITE_MASK		= WR_READ_MASK | WR_WRITE_MASK,
	WR_READ_WRITE_OR_SEND_MASK	= WR_READ_OR_WRITE_MASK | WR_SEND_MASK,
	WR_WRITE_OR_SEND_MASK		= WR_WRITE_MASK | WR_SEND_MASK,
	WR_ATOMIC_OR_READ_MASK		= WR_ATOMIC_MASK | WR_READ_MASK,
};



struct yib_wr_opcode_info {
	const char			*name;
	enum yib_wr_mask	mask[IBV_QPT_DRIVER+1];
};


typedef int os_atomic ;

struct yib_queue_info	//sq rc,cq
{
	atomic_int        pi;
	atomic_int        ci;
	u64        io_count; 	//完成或提交次数
	u64        err_count; 	//完成错误个数, 【rq,sq 为队列满的次数】 cq为wc->err的个数
	u32        direct_cnt; 	//[sq,rq]为直接返回失败的次数， cq为软件完成次数
	u16        pi_toggle; 	//翻转位
	u16        ci_toggle;
};

struct yib_sw_cmd
{	
	enum ibv_wc_opcode opcode;    
	u8                 bsignal:1; 
	u8                 at_err:1;  
	u8                 posted;    
	u64                wrid;
};

// sw_cqe
struct yib_sw_cqe {
	u8 	type;						//sq:0 rq:1 srq:2
	u8 	status;
	u32 start_pos;
	u32 end_pos;  					// [start_pos, end_pos)
	u32 depth;
	u64 handler; 					//sq:填写yqp地址，rq、srq:填写yrq地址	
	u64 sw_wr_id;					//仅软件注入时使用
	enum ibv_wc_opcode sw_opcode; 	
	//仅软件注入时使用,纯软件注入时sq只赋值sw_opcode及sw_wr_id, 然后对sw_posted递增
	struct list_node node;
};


struct qp_info {
	struct yib_queue_info *info;
};

struct cq_info {	
	struct yib_queue_info *info;
};
struct rq_info {
	int item_size;
	int max_sge;
	struct yib_queue_info *info;
};

struct sq_info {	
	int item_size;
	int max_sge;
	uint32_t 		 max_inline;
	struct yib_queue_info *info;
};



struct yib_pd {
	struct ibv_pd		ibv_pd;
	unsigned int		pdn;
};

struct yib_ah {
	struct ibv_ah		ibv_ah;
	struct yib_av		av;
	int			ah_num;

};

struct yib_mr {
	struct verbs_mr vmr;
	void *hw_mr_priv;
};


struct yib_cq {
		struct ibv_cq			ibv_cq;
		struct yib_context      *ctx;
		struct yib_roce_buf		buf_v;
	
		u32                     cqe; 		// cqe 数目
		u32                     cq_id;

		//属于设备层相关层实现
		struct cq_info 			cqinfo;		//rq ,sq 目前		
		void 					*hw_cq_priv;	

		struct list_head		sw_done_list;
		struct yib_sw_cqe		*cur_sw_cqe;
		
		//数据同步
		pthread_spinlock_t		lock;
};



struct y2100r_hw_cq {
	int q;
};

struct swtest_hw_cq {
	int q;

};
struct swtest_hw_qp {
	int q;

};
struct swtest_hw_rq {
	int q;

};
struct swtest_hw_sq {
	int q;

};

struct yib_sq   
{
	pthread_spinlock_t	lock;	
    struct yib_roce_buf buf_v;
    int cnt;
	struct yib_context  *ctx;
	struct yib_sw_cmd 	*sw_cmds; // malloc 根据队列深度	
	u32					*sw_posted;
	u32 				qid;
	u64  				stat_sq_cnt;
	struct sq_info 		sq_info; 	
	void  				*hw_priv;
	void*				cur_send_wqe;
};

struct yib_rq   
{
	pthread_spinlock_t	lock;
    bool   is_srq;
	struct rq_info     	rq_info; //
	struct yib_sw_cmd  *sw_cmds; // malloc 根据队列深度
	struct yib_context *ctx;
	u32 qid;
    int cnt;
    struct yib_roce_buf buf_v;   
	u64    				stat_rq_cnt;
    void  				*parent; //is_srq parent yib_srq, other qp;
	bool  		 		nvme_off;
	void  				*hw_priv;
	void*				cur_recv_wqe;
};

enum srq_ops_mask {
		INIT_SRQ = 0, MODIFY_SRQ = 1
};

struct init_srq_args {
	struct ibv_srq_init_attr *init_attr;
	int *len;
};

struct modify_srq_args {
	struct ibv_srq_attr *attr;
	enum ibv_srq_attr_mask mask;
	int *len;
};

struct yib_srq_check_args {
		enum srq_ops_mask mask;
		union {
			struct modify_srq_args mod_args;
			struct init_srq_args   init_args;
		};
};

struct yib_srq
{
	 struct ibv_srq		ibv_srq;
	 u32 srq_limit;
	 bool            toggle;
	 u32				next_db;
	 unsigned long	*post_bitmap;
	 unsigned long	*db_bitmap;
	 struct yib_rq 		rq;
};


struct yib_qp {
	struct 	verbs_qp		vqp;
	enum 	ibv_qp_state	qp_state;	
	bool 	is_srq;	
	union {
	   struct yib_rq  	rq;
	   struct yib_srq 	*srq;
	};
 	struct yib_context  *ctx;
 	struct yib_sq		sq;
	unsigned int		qpn;
    int	                sqsig;
	int					port_num;
	void                *capture;//for capture ctrl, if non, not support this func
	void  *hw_priv;
	//new API support
	u32	curr_index;
	u32 pending_wqe_num;
	u8* wqe; 
	int err;
};




static inline struct yib_pd *to_yib_pd(struct ibv_pd *ibv_pd)
{
	return container_of(ibv_pd, struct yib_pd, ibv_pd);
}

static inline struct yib_ah *to_yib_ah(struct ibv_ah *ibv_ah)
{
	return container_of(ibv_ah, struct yib_ah, ibv_ah);
}

static inline struct yib_mr *to_yib_mr(struct ibv_mr *ibv_mr)
{
	struct verbs_mr *vmr = container_of(ibv_mr, struct verbs_mr, ibv_mr);
	return container_of(vmr, struct yib_mr, vmr);
}

static inline struct yib_cq *to_yib_cq(struct ibv_cq *ibv_cq)
{
	return container_of(ibv_cq, struct yib_cq, ibv_cq);
}

static inline struct yib_qp *to_yib_qp(struct ibv_qp *ibv_qp)
{
	return container_of(ibv_qp, struct yib_qp, vqp.qp);
}

static inline struct yib_srq *to_yib_srq(struct ibv_srq *ibv_srq)
{
	return container_of(ibv_srq, struct yib_srq, ibv_srq);
}


static inline struct yib_device *to_yib_dev(struct ibv_device *ibv_dev)
{
	return container_of(ibv_dev, struct yib_device, ibv_dev.device);
}

static inline struct yib_context *to_yib_ctx(struct ibv_context *ibv_ctx)
{
	return container_of(ibv_ctx, struct yib_context, ibv_ctx.context);
}


int  yib_u_query_device(struct ibv_context *context,
			   const struct ibv_query_device_ex_input *input,
			   struct ibv_device_attr_ex *attr, size_t attr_size);
void yib_dealloc_context(struct ibv_context *ibctx);
int  yib_roce_alloc_dma_buf(struct yib_roce_buf *buf, int *cnt, int isize);



int yib_u_query_srq(struct ibv_srq *srq,struct ibv_srq_attr *attr);
int yib_u_modify_srq(struct ibv_srq *srq,struct ibv_srq_attr *attr,int attr_mask);


struct ibv_mw *yib_u_alloc_mw(struct ibv_pd *pd, enum ibv_mw_type type);
int yib_u_dealloc_mw(struct ibv_mw *mw);
int yib_u_bind_mw(struct ibv_qp *qp, struct ibv_mw *mw,struct ibv_mw_bind *mw_bind);


#define os_align_any_up(x, a)   (((x) + (a) - 1) / (a) * (a))

u32 yib_get_qp_entry_idx(struct yib_context *ctx, u32 qpc_index);
u32 yib_get_cq_entry_idx(struct yib_context *ctx, u32 cqc_index);
u32 yib_get_cqc_index(struct yib_context *ctx, u32 entry_index);
u32 yib_get_qpc_index(struct yib_context *ctx, u32 entry_index);
int yib_u_srq_chk_attr(struct yib_context  *ctx, struct yib_srq *srq,struct yib_srq_check_args *args);
int yib_u_notify_cq(struct ibv_cq *ibvcq, int solicited);
void yib_u_async_event(struct ibv_context *ibv_ctx,
		      struct ibv_async_event *event);

#endif

