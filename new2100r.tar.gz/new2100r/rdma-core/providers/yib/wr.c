#include "infiniband/verbs.h"


#if defined(__WR_ENABLE__)


#define YQP_WR_API_GET_WQE(qp) \
	if(qp->err)  {\
		return; \
	} \
	if((qp->pending_wqe_num >= YIB_MAX_BATCH_SQ)|| \
		(sq_full_pi(&qp->sq, qp->curr_index)) ) \
	{ \
		qp->err = ENOSPC;\
		return; \
	} \
	qp->wqe = sq_get_item(&qp->sq, qp->ctx->wqe_isize, q_get_val(qp->curr_index))\

#define YQP_WR_API_GET_WQE(qp)                                       \
    if (qp->err) {                                                   \
        return;                                                       \
    }                                                                 \
    if ((qp->pending_wqe_num >= YIB_MAX_BATCH_SQ) ||                 \
        (yib_queue_check_full_by_pi(&qp->sq.queue, qp->curr_index))) { \
        qp->err = ENOSPC;                                            \
        return;                                                       \
    }                                                                 \
    qp->wqe = yib_queue_get_addr_by_index(&qp->sq.queue, qp->curr_index)

static inline void yib_wr_start(struct ibv_qp_ex* qpx) {
    struct yib_qp* qp = qpx_to_yib_qp(qpx);

    pthread_spin_lock(&qp->sq.lock);
    qp->curr_index = yib_queue_pi(&qp->sq.queue);
    qp->pending_wqe_num = 0;
    qp->err = 0;
}

static inline void yib_wr_send(struct ibv_qp_ex* qpx) {
    struct yib_qp* qp = qpx_to_yib_qp(qpx);

    YQP_WR_API_GET_WQE(qp);

    if (!qp->ctx->hw_ops->wr_send) {
        qp->err = EOPNOTSUPP;
        return;
    }

    qp->ctx->hw_ops->wr_send(qp);
    qp->curr_index++;
    qp->pending_wqe_num++;
}

static inline void yib_wr_send_imm(struct ibv_qp_ex* qpx, __be32 imm_data) {
    struct yib_qp* qp = qpx_to_yib_qp(qpx);

    YQP_WR_API_GET_WQE(qp);

    if (!qp->ctx->hw_ops->wr_send_imm) {
        qp->err = EOPNOTSUPP;
        return;
    }

    qp->ctx->hw_ops->wr_send_imm(qp, imm_data);
    qp->curr_index++;
    qp->pending_wqe_num++;
}

static inline void yib_wr_send_inv(struct ibv_qp_ex* qpx,
                                   uint32_t invalidate_rkey) {
    struct yib_qp* qp = qpx_to_yib_qp(qpx);

    YQP_WR_API_GET_WQE(qp);

    if (!qp->ctx->hw_ops->wr_send_inv) {
        qp->err = EOPNOTSUPP;
        return;
    }

    qp->ctx->hw_ops->wr_send_inv(qp, invalidate_rkey);
    qp->curr_index++;
    qp->pending_wqe_num++;
}

static inline void yib_wr_rdma_read(struct ibv_qp_ex* qpx,
                                    uint32_t rkey,
                                    uint64_t remote_addr) {
    struct yib_qp* qp = qpx_to_yib_qp(qpx);

    YQP_WR_API_GET_WQE(qp);

    if (!qp->ctx->hw_ops->wr_rdma_read) {
        qp->err = EOPNOTSUPP;
        return;
    }

    qp->ctx->hw_ops->wr_rdma_read(qp, rkey, remote_addr);
    qp->curr_index++;
    qp->pending_wqe_num++;
}

static inline void yib_wr_rdma_write(struct ibv_qp_ex* qpx,
                                     uint32_t rkey,
                                     uint64_t remote_addr) {
    struct yib_qp* qp = qpx_to_yib_qp(qpx);

    YQP_WR_API_GET_WQE(qp);

    if (!qp->ctx->hw_ops->wr_rdma_write) {
        qp->err = EOPNOTSUPP;
        return;
    }

    qp->ctx->hw_ops->wr_rdma_write(qp, rkey, remote_addr);
    qp->curr_index++;
    qp->pending_wqe_num++;
}

static inline void yib_wr_rdma_write_imm(struct ibv_qp_ex* qpx,
                                         uint32_t rkey,
                                         uint64_t remote_addr,
                                         __be32 imm_data) {
    struct yib_qp* qp = qpx_to_yib_qp(qpx);

    YQP_WR_API_GET_WQE(qp);

    if (!qp->ctx->hw_ops->wr_rdma_write_imm) {
        qp->err = EOPNOTSUPP;
        return;
    }

    qp->ctx->hw_ops->wr_rdma_write_imm(qp, rkey, remote_addr, imm_data);
    qp->curr_index++;
    qp->pending_wqe_num++;
}

static inline void yib_wr_set_inline_data(struct ibv_qp_ex* qpx,
                                          void* addr,
                                          size_t length) {
    struct yib_qp* qp = qpx_to_yib_qp(qpx);
    if (qp->err) {
        return;
    }

    if (!qp->ctx->hw_ops->wr_set_inline_data) {
        qp->err = EOPNOTSUPP;
        return;
    }

    return qp->ctx->hw_ops->wr_set_inline_data(qp, addr, length);
}

static inline void yib_wr_set_inline_data_list(
    struct ibv_qp_ex* qpx,
    size_t num_buf,
    const struct ibv_data_buf* buf_list) {
    struct yib_qp* qp = qpx_to_yib_qp(qpx);
    if (qp->err) {
        return;
    }

    if (!qp->ctx->hw_ops->wr_set_inline_data_list) {
        qp->err = EOPNOTSUPP;
        return;
    }

    return qp->ctx->hw_ops->wr_set_inline_data_list(qp, num_buf, buf_list);
}

static inline void yib_wr_set_sge(struct ibv_qp_ex* qpx,
                                  uint32_t lkey,
                                  uint64_t addr,
                                  uint32_t length) {
    struct yib_qp* qp = qpx_to_yib_qp(qpx);
    if (qp->err) {
        return;
    }

    if (!qp->ctx->hw_ops->wr_set_sge) {
        qp->err = EOPNOTSUPP;
        return;
    }

    return qp->ctx->hw_ops->wr_set_sge(qp, lkey, addr, length);
}

static inline void yib_wr_set_sge_list(struct ibv_qp_ex* qpx,
                                       size_t num_sge,
                                       const struct ibv_sge* sg_list) {
    struct yib_qp* qp = container_of(qpx, struct yib_qp, vqp.qp_ex);
    if (qp->err) {
        return;
    }

    if (!qp->ctx->hw_ops->wr_set_sge_list) {
        qp->err = EOPNOTSUPP;
        return;
    }

    return qp->ctx->hw_ops->wr_set_sge_list(qp, num_sge, sg_list);
}

static inline int yib_wr_complete(struct ibv_qp_ex* qpx) {
    struct yib_qp* qp = qpx_to_yib_qp(qpx);

    if (qp->err) {
        pthread_spin_unlock(&qp->sq.lock);
        return qp->err;
    }

    yib_queue_prod_advance(&qp->sq.queue, qp->pending_wqe_num);
    udma_to_device_barrier();
    mmio_wc_start();
    qp->sq.stat->io_count += qp->pending_wqe_num;
    qp->ctx->hw_ops->sq_pi_db_update(&qp->sq);
    mmio_flush_writes();
    pthread_spin_unlock(&qp->sq.lock);

    return 0;
}

static inline void yib_wr_abort(struct ibv_qp_ex* qpx) {
    struct yib_qp* qp = qpx_to_yib_qp(qpx);

    pthread_spin_unlock(&qp->sq.lock);
}


#endif

