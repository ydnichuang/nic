#include "basic.h"
#include <netinet/in.h>
#include <infiniband/driver.h>
#include <infiniband/verbs.h>
#include <stdint.h>
#include <util/symver.h>
#include "yib-drv-cmd-abi.h"
#include "yib.h"
#include "ib.h"
#include "queue.h"


#include "swtest.h"
#include "yib_log.h"
#include "io.h"

int get_qp_info(struct yib_context *ctx , struct yib_qp *qp , struct ibv_qp_init_attr_ex * attr);
int yib_qp_type_check(enum ibv_qp_type type);
static int yib_u_destroy_srq(struct ibv_srq *ibvsrq);
static inline int ipv6_addr_v4mapped(const struct in6_addr *a)
{
        return IN6_IS_ADDR_V4MAPPED(a);
}

typedef typeof(((struct yib_av *)0)->sgid_addr) sockaddr_union_t;

static inline int rdma_gid2ip(sockaddr_union_t *out, union ibv_gid *gid)
{
        if (ipv6_addr_v4mapped((struct in6_addr *)gid)) {
                memset(&out->_sockaddr_in, 0, sizeof(out->_sockaddr_in));
                memcpy(&out->_sockaddr_in.sin_addr.s_addr, gid->raw + 12, 4);
        } else {
                memset(&out->_sockaddr_in6, 0, sizeof(out->_sockaddr_in6));
                out->_sockaddr_in6.sin6_family = AF_INET6;
                memcpy(&out->_sockaddr_in6.sin6_addr.s6_addr, gid->raw, 16);
        }
        return 0;
}



int yib_u_srq_chk_attr(struct yib_context  *ctx, struct yib_srq *srq,
		     struct yib_srq_check_args *args)
{
	int rq_isize;
	switch(args->mask) {
		case MODIFY_SRQ: {
			struct ibv_srq_attr *attr = args->mod_args.attr;
			if (args->mod_args.mask & IBV_SRQ_MAX_WR) {
				if (attr->max_wr > ctx->hw_caps.max_srq_wr) {
					YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_QP ,"max_wr(%d) > max_srq_wr(%d)\n",
						attr->max_wr, ctx->hw_caps.max_srq_wr);
					goto err1;
				}

				if (srq && srq->srq_limit && (attr->max_wr < srq->srq_limit)) {
					YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_QP ,"max_wr (%d) < srq->srq_limit (%d)\n",
						attr->max_wr, srq->srq_limit);
					goto err1;
				}

				if (attr->max_wr < 1)
					attr->max_wr = 1;
			}

			if (args->mod_args.mask  & IBV_SRQ_LIMIT) {
				if (attr->srq_limit > ctx->hw_caps.max_srq_wr) {
					YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_QP ,"srq_limit(%d) > max_srq_wr(%d)\n",
						attr->srq_limit, ctx->hw_caps.max_srq_wr);
					goto err1;
				}
			}
			rq_isize = ctx->hw_ops->get_rq_item_size(&attr->max_sge);
			yib_queue_calc_depth(rq_isize, &attr->max_wr);
			*args->mod_args.len = attr->max_wr * rq_isize;
			break;
		}	
		case INIT_SRQ: {
			struct ibv_srq_init_attr *init_attr = args->init_args.init_attr;
			struct ibv_srq_attr *attr = &init_attr->attr;
			
//			struct ibv_srq_init_attr *init = &args->init_args.init_attr;
//			if (init->srq_type == IBV_SRQT_XRC) {
//				if (init->ext.xrc.xrcd == NULL) {
//					YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_QP ,"xsrq xrcd is NULL\n");
//					goto err1;
//				}
//				if (init->ext.cq == NULL) {
//					YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_QP ,"xsrq cq is NULL\n");
//					goto err1;
//				}
//			}
			if (attr->max_sge > ctx->hw_caps.max_srq_sge) {
				YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_QP ,"max_sge(%d) > max_srq_sge(%d)\n",
					attr->max_sge, ctx->hw_caps.max_srq_sge);
				goto err1;
			}
			if (attr->max_sge < ctx->hw_caps.max_srq_sge)
				attr->max_sge = ctx->hw_caps.max_srq_sge;
			
			rq_isize = ctx->hw_ops->get_rq_item_size(&attr->max_sge);
			yib_queue_calc_depth(rq_isize, &attr->max_wr);
			*args->init_args.len = attr->max_wr * rq_isize;
			break;
		}		
	}

	return 0;
	
err1:
	return -EINVAL;
}




static int yib_u_query_port(struct ibv_context *context, uint8_t port,
			struct ibv_port_attr *attr)
{
	struct ibv_query_port cmd;

	memset(attr, 0, sizeof(struct ibv_port_attr));
	return ibv_cmd_query_port(context, port, attr, &cmd, sizeof(cmd));
}

static struct ibv_pd *yib_u_alloc_pd(struct ibv_context *context)
{
	struct yib_alloc_pd_resp resp = {};
	struct ibv_alloc_pd cmd = {};
	struct yib_pd *pd;
	struct yib_context *ctx = to_yib_ctx(context);

	pd = (struct yib_pd *)malloc(sizeof(struct yib_pd));
	if(!pd) {
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_PD , "alloc pd mem failed\n");
		return NULL;
	}

	memset(pd, 0, sizeof(*pd));

	if (ibv_cmd_alloc_pd(context, &pd->ibv_pd, &cmd, sizeof(cmd),
				&resp.ibv_resp, sizeof(resp))) {
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_PD , "alloc pd cmd failed\n");
		YIBfree(pd);
		return NULL;
	}

	pd->pdn = resp.pdn;
	return &pd->ibv_pd;
}

static int yib_u_free_pd(struct ibv_pd *ibpd)
{
	int ret;
	struct yib_context *ctx = to_yib_ctx(ibpd->context);
	struct yib_pd *pd = to_yib_pd(ibpd);
	ret = ibv_cmd_dealloc_pd(ibpd);
	if (ret) {
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_PD , "dealloc pd cmd failed\n");
		return ret;
	}

	YIBfree(pd);
	return ret;
}

static struct ibv_mr *yib_u_reg_mr(struct ibv_pd *pd, void *addr, size_t length,
				uint64_t hca_va, int access)
{
	struct yib_context *context = to_yib_ctx(pd->context);
	struct ib_uverbs_reg_mr_resp resp = {};
	FILE *fp = context->dbg_fp;
	struct yib_reg_mr cmd = {};
	struct yib_mr *ymr = NULL;
	int ret;

	if(!addr) {
		YIB_LOGm_ERR(fp, YIB_MSG_MR , "MR addr is NULL!\n");
		return NULL;
	}

	if(!length) {
		YIB_LOGm_ERR(fp, YIB_MSG_MR , "MR length is 0!\n");
		return NULL;
	}

	YIB_LOGm_DBG(fp, YIB_MSG_MR,
		"staring to register memory region, addr:%lx, length:%d\n",
		(uintptr_t)addr, (int)length);

	ymr = (struct yib_mr *)malloc(sizeof(struct yib_mr));
	if (!ymr) {
		YIB_LOGm_ERR(fp, YIB_MSG_MR , "alloc mem for mr failed\n");
		return NULL;
	}

	memset(ymr, 0, sizeof(*ymr));
	cmd.u_mr_handler = (uintptr_t)ymr;
	ret = ibv_cmd_reg_mr(pd, addr, length, hca_va, access, &ymr->vmr,
				&cmd.ibv_cmd, sizeof(cmd), &resp, sizeof(resp));
	if (ret) {
		YIB_LOGm_ERR(fp, YIB_MSG_MR ,"failed to register memory region, ret:%d\n", ret);
		YIBfree(ymr);
		return NULL;
	}

	ret = context->hw_ops->hw_mr_init(context, ymr);
	if(ret) {
		YIB_LOGm_ERR(fp, YIB_MSG_MR ,"hw failed to register memory region, ret:%d\n", ret);	
		ret = ibv_cmd_dereg_mr(&ymr->vmr);
		return NULL;
	}
	
	return &ymr->vmr.ibv_mr;
}


static int yib_u_dereg_mr(struct verbs_mr *vmr)
{
	struct yib_context *context = to_yib_ctx(vmr->ibv_mr.context);
	struct yib_mr *ymr = to_yib_mr(&vmr->ibv_mr);
	FILE *fp = context->dbg_fp;
	int ret;

	YIB_LOGm_DBG(fp, YIB_MSG_MR, "starting to deregister memory region\n");

	ret = ibv_cmd_dereg_mr(vmr);
	if (ret) {
		YIB_LOGm_ERR(fp,YIB_MSG_MR, "failed to deregister memory region, ret:%d\n", ret);
		return ret;
	}
	ret = context->hw_ops->hw_mr_uninit(context, ymr);
	if(ret){
		YIB_LOGm_ERR(fp , YIB_MSG_MR , "hw failed to deregister memory region, ret:%d\n", ret);
		return ret;
	}
	YIBfree(ymr);
	return ret;
}

static struct ibv_ah *yib_u_create_ah(struct ibv_pd *pd,
					struct ibv_ah_attr *attr)
{
        int err;
        struct yib_ah *ah;
        struct yib_av *av;
        union ibv_gid sgid;
        struct yib_create_ah_resp resp = {};
		struct yib_context *ctx = to_yib_ctx(pd->context);

        err = ibv_query_gid(pd->context, attr->port_num, attr->grh.sgid_index,
                            &sgid);
        if (err) {
                YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_AH , "Failed to query sgid.\n");
                return NULL;
        }

        ah = malloc(sizeof(*ah));
        if (ah == NULL) {
				YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_AH , "alloc ah mem failed\n");
                return NULL;
		}

        av = &ah->av;
        av->port_num = attr->port_num;
        memcpy(&av->grh, &attr->grh, sizeof(attr->grh));
        av->network_type =
                ipv6_addr_v4mapped((struct in6_addr *)attr->grh.dgid.raw) ?
                YIB_NETWORK_TYPE_IPV4 : YIB_NETWORK_TYPE_IPV6;

        rdma_gid2ip(&av->sgid_addr, &sgid);
        rdma_gid2ip(&av->dgid_addr, &attr->grh.dgid);
        if (ibv_resolve_eth_l2_from_gid(pd->context, attr, av->dmac, NULL)) {
				YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_AH , "alloc resolve dmac gid failed\n");
                YIBfree(ah);
                return NULL;
        }

        memset(&resp, 0, sizeof(resp));
        if (ibv_cmd_create_ah(pd, &ah->ibv_ah, attr, &resp.ibv_resp, sizeof(resp))) {
				YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_AH , "create ah cmd failed\n");
                YIBfree(ah);
                return NULL;
        }

		ah->ah_num = resp.ah_num;
		ah->av.vlan_id = resp.vlan_id;
		ah->av.vlan_pcp = resp.vlan_pcp;
		ah->av.smac_idx = resp.smac_idx;
		memcpy(ah->av.smac , resp.smac , 6 );// 1
		return &ah->ibv_ah;
}

static int yib_u_destroy_ah(struct ibv_ah *ibah)
{
	struct yib_ah *ah = to_yib_ah(ibah);	
	struct yib_context *ctx = to_yib_ctx(ibah->context);
	int ret;

	ret = ibv_cmd_destroy_ah(&ah->ibv_ah);
	if (!ret)
		YIBfree(ah);
	else {
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_AH , "destroh ah failed ret=%d\n", ret);
	}

	return ret;
}

static struct ibv_cq *yib_u_create_cq(struct ibv_context *context, int cqe,
				    struct ibv_comp_channel *channel,
				    int comp_vector)
{
	struct yib_create_cq		cmd = {};
	struct yib_create_cq_resp	resp = {};
	struct yib_cq 	*cq;
	int	ret;
    struct yib_context *ctx = to_yib_ctx(context);

	cq = calloc(1, sizeof(struct yib_cq));
	if(!cq) {
		goto yib_cq_err;
	}
	memset(cq, 0, sizeof(*cq));
	list_head_init(&cq->sw_done_list);
	
	cq->ctx = ctx;
	
	if (pthread_spin_init(&cq->lock, PTHREAD_PROCESS_PRIVATE))
		goto yib_cq_err;

	ret = yib_roce_alloc_dma_buf(&cq->buf_v, &cqe, ctx->hw_caps.cqe_isize);
	if (ret) {
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_CQ , "create cq dma buf failed\n");
		goto buf_err;
	}
	cq->buf_v.q_depth = cqe;
	cq->cqe = cq->ibv_cq.cqe = cqe;
	cmd.cq_va = (uintptr_t)cq->buf_v.buf;
	cmd.u_cq_handler = (uintptr_t)cq;
	ret = ibv_cmd_create_cq(context, cqe, channel, comp_vector,
				&cq->ibv_cq, &cmd.ibv_cmd, sizeof(cmd),
				&resp.ibv_resp, sizeof(resp));
	if (ret) {
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_CQ ,"create cq cmd failed\n");
		goto buf_err;
	}	
	YIB_LOGm_DBG(ctx->dbg_fp, YIB_MSG_CQ, "create cq success, cq_id:%d  max_cqe:%d \n ", \
									resp.cqid ,  resp.max_cqe );
	
	cq->cq_id = resp.cqid;

#if defined(YIB_CFG_MAP_GLOABL_QINFO)
	cq->cqinfo.info = (struct yib_queue_info *)(ctx->resource.cq_base + (cq->cq_id * sizeof(struct yib_queue_info)));
#else
	cq->cqinfo.info = malloc(sizeof(struct yib_queue_info));
	if(cq->cqinfo.info == NULL)	{
			YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_CQ ,"alloc cqinfo failed \n");
			goto ibv_cq_info_err;
	}
	memset(cq->cqinfo.info, 0, sizeof(struct yib_queue_info));
#endif

	ret = ctx->hw_ops->hw_cq_init(ctx , cq);
	if( ret ){
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_CQ ,"hw create cq  failed , ret %d \n",ret);
		goto ibv_cq_err;
	}

	return &cq->ibv_cq;


ibv_cq_err:
#ifndef YIB_CFG_MAP_GLOABL_QINFO
	if(cq->cqinfo.info)
		YIBfree(cq->cqinfo.info);
ibv_cq_info_err:
#endif
	ibv_cmd_destroy_cq(&cq->ibv_cq);
buf_err:
	yib_roce_free_buf(&cq->buf_v);
yib_cq_err:
	YIBfree(cq);

	return NULL;
}

static int yib_u_destroy_cq(struct ibv_cq *ibcq)
{
	struct yib_context *ctx = to_yib_ctx(ibcq->context);
	struct yib_cq *cq = to_yib_cq(ibcq);
	FILE *fp = ctx->dbg_fp;
	int ret;

#ifndef YIB_CFG_MAP_GLOABL_QINFO
	if(cq->cqinfo.info)
		YIBfree(cq->cqinfo.info);
#endif
	ret = ibv_cmd_destroy_cq(ibcq);
	if (ret) {
 		if (ret < 0) 
			YIB_LOGm_ERR(fp, YIB_MSG_CQ ,"failed to destroy cq ret=%d\n", ret);
        return ret;
	}
	yib_roce_free_buf(&cq->buf_v);
	YIBfree(cq);
	return ret;
}




//设置队列深度,保证偶数和4096对齐
static int yib_roce_update_qp_params(struct ibv_qp_init_attr_ex *attr,
				   struct yib_qp *qp,
				   struct yib_context *ctx,
				   char *err_msg)
{
	u32 rqe_cnt; 
	u32 sqe_cnt;
	u32 page_size = 4096ul;//wqe buf 按照4096和2的n次幂对齐

	qp->vqp.qp.qp_type = attr->qp_type;
	if (attr->cap.max_send_sge > qp->sq.sq_info.max_sge) {
		sprintf(err_msg , "%s", "send sge is two big");
		return -EINVAL;
	}
	
	if (attr->cap.max_send_wr == 0) {
		attr->cap.max_send_wr = 128;
	}
	if (attr->cap.max_send_wr) {
		sqe_cnt = attr->cap.max_send_wr;
		sqe_cnt = os_align_any_up(sqe_cnt * qp->sq.sq_info.item_size , page_size) / qp->sq.sq_info.item_size;
		sqe_cnt = numTo2n2((sqe_cnt * qp->sq.sq_info.item_size) / page_size);   
		sqe_cnt = (sqe_cnt * page_size) / qp->sq.sq_info.item_size;
/* 		if (sqe_cnt > ctx->hw_caps.max_sge) {
			sprintf(err_msg ,"send sqe is two big:%d", sqe_cnt);
			return -EINVAL;	
		} */
		attr->cap.max_send_wr = sqe_cnt;
		qp->sq.cnt = sqe_cnt;
	} else {
		sprintf(err_msg , "%s", "send wr is zero\n");
		return -EINVAL;
	}

	if (attr->recv_cq == NULL || attr->send_cq == NULL) {
		sprintf(err_msg , "%s", "cq is not provide\n");
		return -EINVAL;
	}		

	if (attr->srq) {
		qp->rq.is_srq = true;
		return 0;
	} 

	if (attr->cap.max_recv_sge > qp->rq.rq_info.max_sge) {
		sprintf(err_msg , "%s", "send sge is two big");
		return -EINVAL;
	}
	if (attr->cap.max_recv_wr == 0) {
		attr->cap.max_recv_wr = 128;
	}
	if (attr->cap.max_recv_wr) {
		rqe_cnt = attr->cap.max_recv_wr;
		rqe_cnt = os_align_any_up(rqe_cnt * qp->rq.rq_info.item_size, page_size) / qp->rq.rq_info.item_size ;
		rqe_cnt = numTo2n2((rqe_cnt * qp->rq.rq_info.item_size) / page_size);   
		rqe_cnt = (rqe_cnt * page_size) / qp->rq.rq_info.item_size; 

/* 		if (rqe_cnt > ctx->hw_caps.max_rqe) {
			sprintf(err_msg , "recv rqe is two big:%d", rqe_cnt);
			return -EINVAL;	
		} */
		attr->cap.max_recv_wr = rqe_cnt;
		qp->rq.cnt = rqe_cnt;
	} else {
		sprintf(err_msg , "%s", "recv wr is zero\n");
		return -EINVAL;
	}

	return 0;
}

static void yib_qp_free_bufs(struct yib_context *context, struct yib_qp *qp)
{
	if (qp == NULL)
		return;

	if (!qp->is_srq) {
		if(qp->rq.sw_cmds)
			YIBfree(qp->rq.sw_cmds);
	}
	if (qp->sq.sw_cmds)
		YIBfree(qp->sq.sw_cmds);

	if (qp->sq.sw_posted)
		YIBfree(qp->sq.sw_posted);

#ifndef YIB_CFG_MAP_GLOABL_QINFO
	if (qp->sq.sq_info.info)
		YIBfree(qp->sq.sq_info.info);
	if (!qp->is_srq) {
		if (qp->rq.rq_info.info)
			YIBfree(qp->rq.rq_info.info);
	}
#endif

	if (!qp->is_srq)
		yib_roce_free_buf(&qp->rq.buf_v);
	yib_roce_free_buf(&qp->sq.buf_v);
	

	YIBfree(qp);
}



int yib_qp_type_check(enum ibv_qp_type type){

	switch(type){
		case IBV_QPT_RC:
			return 0;
		case IBV_QPT_UD:
			return 0;
		default:
			return -1;
	}
	return -1;
}


int get_qp_info(struct yib_context *ctx , struct yib_qp *qp , struct ibv_qp_init_attr_ex * attr){
#if defined(YIB_CFG_MAP_GLOABL_QINFO)
	qp->sq.sq_info.info = (struct yib_queue_info *)(ctx->resource.sq_base + (qp->sq.qid * sizeof(struct yib_queue_info)));
	if (!attr->srq)
		qp->rq.rq_info.info = (struct yib_queue_info *)(ctx->resource.rq_base + (qp->rq.qid * sizeof(struct yib_queue_info)));
#else
	qp->sq.sq_info.info = malloc(sizeof(struct yib_queue_info));
	if (!qp->sq.sq_info.info) {
		return -1;
	}
	memset(qp->sq.sq_info.info , 0 , sizeof(struct yib_queue_info));
	if (!attr->srq) {
		qp->rq.rq_info.info = malloc(sizeof(struct yib_queue_info));
		if (!qp->rq.rq_info.info) {
			YIBfree(qp->sq.sq_info.info);
			return -1;
		}
		memset(qp->rq.rq_info.info , 0 , sizeof(struct yib_queue_info));
	}
#endif
	return 0;
}

// 1.wqe size 2.
// qp类型检测 RC , UD
// attr->cap 计算出sq : depth, max_inline, sg
// 判断srq 还是 rq模式
// 如果是rq模式, 根据attr->cap  计算 rq: depth, sg
// 分配sq , rq内存
// 调用内核
// 处理内核resp
// queue_info赋值
// 硬件私有初始化
// sw_cmd 分配内存

static struct ibv_qp *yib_u_create_qp_ex(struct ibv_context *ibv_ctx, struct ibv_qp_init_attr_ex *attr)
{
	struct yib_context *ctx = to_yib_ctx(ibv_ctx);
 	struct yib_create_qp_ex_resp resp = {};
	struct yib_create_qp_ex cmd = {};
	FILE *fp = ctx->dbg_fp;
	struct yib_qp *qp = NULL;
	int ret = 0;
	int page_size = 4096ul;
	int wqe_isize , rqe_isize  = 0;
	uint32_t max_send_sge , max_recv_sge;
	int inline_size = attr->cap.max_inline_data;
	char err_msg[128];

	if (yib_qp_type_check(attr->qp_type)) {
		YIB_LOGm_ERR(fp, YIB_MSG_QP," create qp type err :%u \n",attr->qp_type);
		return NULL;
	}

	qp = calloc(1, sizeof(*qp));
	if (!qp) {
		YIB_LOGm_ERR(fp, YIB_MSG_QP, "alloc mem for qp faield\n");
		errno = -ENOMEM;
		return NULL;
	}
	memset(qp, 0, sizeof(*qp));
	
	if (pthread_spin_init(&qp->sq.lock, PTHREAD_PROCESS_PRIVATE)) {
		ret = -ENOMEM;
		YIB_LOGm_ERR(fp, YIB_MSG_QP,"sq pthread lock init error \n");
		goto pthread_init_err;
	}
	if (pthread_spin_init(&qp->rq.lock, PTHREAD_PROCESS_PRIVATE)) {
		ret = -ENOMEM;
		YIB_LOGm_ERR(fp, YIB_MSG_QP,"sq pthread lock init error \n");
		goto pthread_init_err;
	}

	// init qp with qp_init_attr
	max_send_sge = attr->cap.max_send_sge;
	max_recv_sge = attr->cap.max_recv_sge;
	wqe_isize = ctx->hw_ops->get_sq_item_size(attr->qp_type , &inline_size , &max_send_sge);
	//inline 由内核决定	
	//wqe,rqe 的大小不在是定值,根据用户输入的sge数量和inline动态调整. 硬件定义大小和用户数量,并且会调整inline和max_send_sge数量,有可能和输入值不同
	if (attr->srq == NULL) {
		qp->rq.rq_info.item_size = ctx->hw_ops->get_rq_item_size(&max_recv_sge);
		rqe_isize = qp->rq.rq_info.item_size;
		qp->rq.rq_info.max_sge = max_recv_sge;
	}

	qp->sq.sq_info.item_size = wqe_isize;
	qp->sq.sq_info.max_sge = max_send_sge;
	qp->sq.sq_info.max_inline = inline_size;
	YIB_LOGm_DBG(fp, YIB_MSG_QP,"sqe:%d  rqe:%d  \n",wqe_isize , rqe_isize);

	// init sq buffer
	ret = yib_roce_update_qp_params(attr, qp, ctx ,err_msg);//队列深度2的n次方和4096对齐
	if (ret) {
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_QP ,"SQ Error status ret:%d err_msg:%s  sqe:%d  rqe:%d  \n", ret , err_msg ,wqe_isize , rqe_isize);			
		goto qp_params_err;
	}
	YIB_LOGm_DBG(fp, YIB_MSG_QP,"swr:%d sqcnt:%d  rwr:%d  rqcnt:%d \n", attr->cap.max_send_wr ,qp->sq.cnt , attr->cap.max_recv_wr , qp->rq.cnt);

	ret = yib_roce_alloc_buf(&qp->sq.buf_v, attr->cap.max_send_wr * wqe_isize , page_size);
	if (ret) {
		YIB_LOGm_ERR(fp, YIB_MSG_QP, "alloc buf for qp sq failed ret=%d\n", ret);
		goto sq_buf_err;
	}
	qp->sq.buf_v.q_depth = attr->cap.max_send_wr;
	cmd.sq_va = (uintptr_t)qp->sq.buf_v.buf;
	cmd.nvme_off = ctx->nvme_off;
	cmd.u_qp_handler = (uintptr_t)qp;
	cmd.u_rq_handler = (uintptr_t)&qp->rq;
	// init rq buffer
	if (attr->srq) {
		qp->srq = to_yib_srq(attr->srq);
		qp->is_srq = true;
	} else {
		qp->rq.parent = qp;						// srq/rq指向指向srq rq->parent = srq;
		ret = yib_roce_alloc_buf(&qp->rq.buf_v, attr->cap.max_recv_wr * rqe_isize, page_size);
		if (ret) {
			YIB_LOGm_ERR(fp, YIB_MSG_QP,"alloc buf for qp rq failed ret=%d\n", ret);
			ret = -ENOMEM;
			goto rq_buf_err;
		}
		qp->rq.ctx= ctx;
		cmd.rq_va = (uintptr_t)qp->rq.buf_v.buf;
		qp->rq.buf_v.q_depth = attr->cap.max_recv_wr;
		qp->rq.nvme_off = ctx->nvme_off;
	}

	ret = ibv_cmd_create_qp_ex2(ibv_ctx, &qp->vqp, attr, &cmd.ibv_cmd, sizeof(cmd), &resp.ibv_resp, sizeof(resp));
	if (ret) {
		YIB_LOGm_ERR(fp, YIB_MSG_QP,"ibv_cmd_create_qp_ex2 failed!\n");
		goto qp_resp_err;
	}

	// init sq,rq with IB response 
	qp->sq.ctx		= ctx;
	qp->sq.sq_info.max_inline = resp.max_inline_data;
	qp->qp_state 	= IBV_QPS_RESET;	
	qp->sqsig 		= attr->sq_sig_all;	
	qp->sq.qid 		= qp->qpn = resp.qpid;
	if (!attr->srq)
		qp->rq.qid      = resp.rqid;
	qp->ctx 		= qp->sq.ctx = ctx;
	attr->cap.max_inline_data = resp.max_inline_data;
	YIB_LOGm_DBG(fp, YIB_MSG_QP,"resp qpid:%d inline:%d  max_send_wr:%d  max_recv_wr:%d \n",resp.qpid , resp.max_inline_data , resp.max_send_wr , resp.max_recv_wr );

	// sq , rq info
	ret = get_qp_info(ctx  , qp , attr);// 依赖qpid
	if (ret) {
		goto qp_info_err;
	}

	// sw_posted
	qp->sq.sw_posted = malloc(qp->sq.buf_v.q_depth * sizeof(u32));
	if (qp->sq.sw_posted == NULL) {
		YIB_LOGm_ERR(fp, YIB_MSG_QP,"alloc sw_posted failed!\n");
		goto sw_posted_err;
	}
	memset(qp->sq.sw_posted , 0 , qp->sq.buf_v.q_depth * sizeof(u32));

	// sq malloc
	qp->sq.sw_cmds = malloc(qp->sq.buf_v.q_depth * sizeof(struct yib_sw_cmd));
	if (qp->sq.sw_cmds == NULL) {
		YIB_LOGm_ERR(fp, YIB_MSG_QP,"alloc sw_cmds failed!\n");
		goto sq_cmd_err;
	}
	memset(qp->sq.sw_cmds , 0 , qp->sq.buf_v.q_depth * sizeof(struct yib_sw_cmd));
	if (!attr->srq) {
		qp->rq.sw_cmds = (struct yib_sw_cmd *)malloc( qp->rq.buf_v.q_depth * sizeof(struct yib_sw_cmd) );
		if (!qp->rq.sw_cmds) {
			goto rq_cmd_err;
		}
		memset(qp->rq.sw_cmds , 0 , qp->rq.buf_v.q_depth * sizeof(struct yib_sw_cmd));
	}



	if (!attr->srq) { // normal rq
		ret = ctx->hw_ops->hw_rq_init(ctx , &qp->rq);
		//hw_rq_init 回调需要分配 rq_hw_priv
		if(ret || !qp->rq.sw_cmds ){
			YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_QP ,"RQ Error status hw_init:%d, sw_cmd:0x%p \n", ret , qp->rq.sw_cmds );
			goto rq_hw_init_err;
		}
	}

	ret = ctx->hw_ops->hw_qp_init(ctx , qp);
	if (ret || !qp->sq.sw_cmds) {
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_QP ,"SQ Error status hw_init:%d, sw_cmd:0x%p  \n", ret , qp->sq.sw_cmds );
		goto qp_hw_init_err;
	}

	if (attr->comp_mask & IBV_QP_INIT_ATTR_SEND_OPS_FLAGS) {
		//todo	set_yib_qpx_ops(&qp->vqp.qp_ex);
		qp->vqp.comp_mask |= VERBS_QP_EX;
	}

	return &qp->vqp.qp;

qp_hw_init_err:
	ctx->hw_ops->hw_rq_uninit(ctx, &qp->rq);

rq_hw_init_err:
	if (!attr->srq) {
		if (qp->rq.sw_cmds)
			YIBfree(qp->rq.sw_cmds);
	}
rq_cmd_err:
	if (qp->sq.sw_cmds)
		YIBfree(qp->sq.sw_cmds);

sq_cmd_err:
	if (qp->sq.sw_posted)
		YIBfree(qp->sq.sw_posted);

sw_posted_err:
#ifndef YIB_CFG_MAP_GLOABL_QINFO
	if (qp->sq.sq_info.info)
		YIBfree(qp->sq.sq_info.info);
	if (!attr->srq) {
		if (qp->rq.rq_info.info)
			YIBfree(qp->rq.rq_info.info);
	}
#endif
qp_info_err:
	if (qp->qpn) {
		ibv_cmd_destroy_qp(&qp->vqp.qp);
		qp->qpn = 0;
	}

qp_resp_err:
	if (!attr->srq) {
		if (qp->rq.buf_v.buf)
			yib_roce_free_buf(&qp->rq.buf_v);
	}
rq_buf_err:
	if (qp->sq.buf_v.buf)
		yib_roce_free_buf(&qp->sq.buf_v);
sq_buf_err:
qp_params_err:
pthread_init_err:
	if (qp)
		YIBfree(qp);

	if (ret < 0)
		ret = -ret;
	errno = ret;
	return NULL;
}

static struct ibv_qp *yib_u_create_qp(struct ibv_pd *ibvpd, struct ibv_qp_init_attr *attr)
{
	struct ibv_qp_init_attr_ex attr_ex = {};
	memcpy(&attr_ex, attr, sizeof(*attr));
	attr_ex.comp_mask = IBV_QP_INIT_ATTR_PD;
	attr_ex.pd = ibvpd;

	return yib_u_create_qp_ex(ibvpd->context, &attr_ex);
}

static int yib_u_destroy_qp(struct ibv_qp *ibqp)
{
	struct yib_context *ctx = to_yib_ctx(ibqp->context);
	struct yib_qp *qp = to_yib_qp(ibqp);
	FILE *fp = ctx->dbg_fp;
	int ret;

	YIB_LOGm_DBG(fp , YIB_MSG_QP, "starting to destroy userspace qp\n");

	ret = ibv_cmd_destroy_qp(ibqp);
	if (ret < 0) {
		YIB_LOGm_ERR(fp , YIB_MSG_QP, "failed to destroy\n");
		goto end;
	}

	ret = ctx->hw_ops->hw_qp_uninit(ctx , qp);
	if(ret){
		YIB_LOGm_ERR(fp , YIB_MSG_QP, "hw uninit failed to destroy qp \n");
	}

	ret = ctx->hw_ops->hw_rq_uninit(ctx, &qp->rq);
	if(ret){
		YIB_LOGm_ERR(fp , YIB_MSG_QP, "hw uninit failed to destroy qp->rq \n");
	}
	yib_qp_free_bufs(ctx, qp);
end:
	return ret;
}


static struct ibv_srq *yib_u_create_srq(struct ibv_pd *pd, struct
                                      ibv_srq_init_attr *srq_init_attr)
{

	struct yib_create_srq cmd = {};
	struct yib_create_srq_resp resp = {};
	struct yib_context *ctx = to_yib_ctx(pd->context);
	struct yib_srq *srq = NULL;
	struct ibv_srq *ibvsrq = NULL;
	int ret = 0 , page_size = 4096;
	int rqe_isize = 0;
//	int max_recv_sge = srq_init_attr->attr.max_sge;
	int len = 0;
	struct yib_srq_check_args chk_args = { .mask = INIT_SRQ , .init_args = { srq_init_attr , &len } };	

	//srq alloc
	srq = calloc(1 , sizeof(*srq));
	if (!srq) {
		YIB_LOGm_ERR(ctx->dbg_fp,YIB_MSG_SRQ , "srq calloc failed \n");
		return NULL;
	}
	ibvsrq = &srq->ibv_srq;
	srq->rq.parent = srq;						// srq/rq指向指向srq rq->parent = srq;

	if (pthread_spin_init(&srq->rq.lock, PTHREAD_PROCESS_PRIVATE)) {
		ret = -ENOMEM;
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_SRQ,"srq pthread lock init error \n");
		goto err;
	}

	ret = yib_u_srq_chk_attr(ctx, srq ,	&chk_args);
	if(ret){
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_SRQ,"yib_srq_chk_attr failed ret=%d\n", ret);
		goto err;
	}
	rqe_isize = srq->rq.rq_info.item_size = ctx->hw_ops->get_rq_item_size(&srq_init_attr->attr.max_sge);
	
	ret = yib_roce_alloc_buf(&srq->rq.buf_v, srq_init_attr->attr.max_wr * rqe_isize, page_size);
	if (ret) {
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_SRQ,"alloc buf for qp rq failed ret=%d\n", ret);
		ret = -ENOMEM;
		goto err;
	}
	srq->rq.buf_v.q_depth = srq_init_attr->attr.max_wr;
	srq->rq.ctx= ctx;
	srq->rq.nvme_off = ctx->nvme_off;
	// srq req_cmd 
	cmd.srq_va = (uintptr_t)srq->rq.buf_v.buf;
	cmd.nvme_off = ctx->nvme_off;
	cmd.u_srq_handler = (uintptr_t)srq;

	ret = ibv_cmd_create_srq(pd, ibvsrq, srq_init_attr, &cmd.ibv_cmd, sizeof(cmd),
				 &resp.ibv_resp, sizeof(resp));
	if (ret){
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_SRQ,"ibv_cmd_create_srq failed %d \n", ret);
		ibv_cmd_destroy_srq(&srq->ibv_srq);
		goto err;
	}
	// srq response 
	srq->rq.qid = resp.srqid;
	srq->rq.is_srq = true;
	// return 
	srq_init_attr->attr.max_sge = resp.max_sge;
	srq_init_attr->attr.max_wr  = resp.max_wr;

	// yib srq qeueue info
#if defined YIB_CFG_MAP_GLOABL_QINFO
	srq->rq.rq_info.info = (struct yib_queue_info *)(ctx->resource.rq_base + (srq->rq.qid * sizeof(struct yib_queue_info)));
#else
	srq->rq.rq_info.info = malloc(sizeof(struct yib_queue_info));
	if(srq->rq.rq_info.info == NULL)	{
			YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_SRQ ,"alloc srqinfo failed \n");
			goto err;
	}
	memset(srq->rq.rq_info.info, 0, sizeof(struct yib_queue_info));
#endif
	// yib srq sw_cmd
	srq->rq.sw_cmds = (struct yib_sw_cmd *)malloc( srq->rq.buf_v.q_depth * sizeof(struct yib_sw_cmd) );
	if(!srq->rq.sw_cmds){
		goto err;
	}
	memset(srq->rq.sw_cmds , 0 , srq->rq.buf_v.q_depth * sizeof(struct yib_sw_cmd));

	srq->post_bitmap = malloc(BITS_TO_LONGS(srq_init_attr->attr.max_wr) * sizeof(unsigned long));
	if(!srq->post_bitmap){
		goto err;
	}
	memset(srq->post_bitmap, 0, BITS_TO_LONGS(srq_init_attr->attr.max_wr) * sizeof(unsigned long));

	srq->db_bitmap = malloc(BITS_TO_LONGS(srq_init_attr->attr.max_wr) * sizeof(unsigned long));
	if(!srq->db_bitmap){
		goto err;
	}
	memset(srq->db_bitmap, 0, BITS_TO_LONGS(srq_init_attr->attr.max_wr) * sizeof(unsigned long));

	ret = ctx->hw_ops->hw_rq_init(ctx , &srq->rq );
	if(ret){
		  YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_SRQ,"hw_rq_init failed %d\n", ret);
		  ctx->hw_ops->hw_rq_uninit(ctx , &srq->rq );
		  goto err;
	}

	

	return &srq->ibv_srq;

err:
	if (srq->db_bitmap)
		YIBfree(srq->db_bitmap);

	if (srq->post_bitmap)
	    YIBfree(srq->post_bitmap);

	if(srq->rq.sw_cmds){
		YIBfree(srq->rq.sw_cmds);
	}

#ifndef YIB_CFG_MAP_GLOABL_QINFO
	if (srq->rq.rq_info.info)
	    YIBfree(srq->rq.rq_info.info);
#endif

	yib_roce_free_buf(&srq->rq.buf_v);
	
	if(srq){
		YIBfree(srq);
	}

	return NULL;
}

static int yib_u_destroy_srq(struct ibv_srq *ibvsrq)
{
	struct yib_context *ctx = to_yib_ctx(ibvsrq->context);
	struct yib_srq *srq = to_yib_srq(ibvsrq);
	FILE *fp = ctx->dbg_fp;
	int ret;

	YIB_LOGm_DBG(fp , YIB_MSG_SRQ, "starting to destroy userspace qp\n");

	ret = ibv_cmd_destroy_srq(&srq->ibv_srq);
	if (ret < 0) {
		YIB_LOGm_ERR(fp , YIB_MSG_SRQ, "failed to destroy\n");
	}


 	ret = ctx->hw_ops->hw_rq_uninit(ctx , &srq->rq);
	if(ret){
		YIB_LOGm_ERR(fp , YIB_MSG_SRQ, "hw uninit failed to destroy qp \n");
	}

	if (srq->db_bitmap)
		YIBfree(srq->db_bitmap);

	if (srq->post_bitmap)
	    YIBfree(srq->post_bitmap);

	if(srq->rq.sw_cmds){
		YIBfree(srq->rq.sw_cmds);
	}
#ifndef YIB_CFG_MAP_GLOABL_QINFO
	if (srq->rq.rq_info.info)
	    YIBfree(srq->rq.rq_info.info);
#endif
	yib_private_munmap( srq->rq.rq_info.info , sizeof(struct yib_queue_info) );	
	yib_roce_free_buf(&srq->rq.buf_v);
	YIBfree(srq);

	return ret;
}


int yib_u_query_srq(struct ibv_srq *srq,
		    struct ibv_srq_attr *attr)
{
	struct ibv_query_srq cmd = {};

	return ibv_cmd_query_srq(srq, attr, &cmd, sizeof cmd);
}

int yib_u_modify_srq(struct ibv_srq *srq,
		    struct ibv_srq_attr *attr,
		    int attr_mask)
{
	struct yib_modify_srq cmd = {};

	return ibv_cmd_modify_srq(srq, attr, attr_mask, &cmd.ibv_cmd, sizeof cmd);
}


struct ibv_mw *yib_u_alloc_mw(struct ibv_pd *pd, enum ibv_mw_type type)
{
	struct ibv_mw *mw;
	struct ibv_alloc_mw cmd = {};
	struct ib_uverbs_alloc_mw_resp resp = {};
	int ret;

	mw = YIBmalloc(sizeof(*mw));
	if (!mw)
		return NULL;

	memset(mw, 0, sizeof(*mw));

	ret = ibv_cmd_alloc_mw(pd, type, mw, &cmd, sizeof(cmd), &resp,
			       sizeof(resp));
	if (ret) {
		YIBfree(mw);
		return NULL;
	}

	return mw;
}

int yib_u_dealloc_mw(struct ibv_mw *mw)
{
	int ret;

	ret = ibv_cmd_dealloc_mw(mw);
	if (ret)
		return ret;

	YIBfree(mw);
	return 0;
}



int yib_u_bind_mw(struct ibv_qp *qp, struct ibv_mw *mw,
		 struct ibv_mw_bind *mw_bind)
{
	struct ibv_mw_bind_info	*bind_info = &mw_bind->bind_info;
	struct ibv_send_wr wr = {};
	struct ibv_send_wr *bad_wr = NULL;
	int ret;

	if (!bind_info->mr && (bind_info->addr || bind_info->length)) {
		errno = EINVAL;
		return errno;
	}

	if (bind_info->mw_access_flags & IBV_ACCESS_ZERO_BASED) {
		errno = EINVAL;
		return errno;
	}

	if (bind_info->mr) {
		if (verbs_get_mr(bind_info->mr)->mr_type != IBV_MR_TYPE_MR) {
			errno = ENOTSUP;
			return errno;
		}

		if (mw->pd != bind_info->mr->pd) {
			errno = EPERM;
			return errno;
		}
	}

	wr.opcode = IBV_WR_BIND_MW;
	wr.next = NULL;
	wr.wr_id = mw_bind->wr_id;
	wr.send_flags = mw_bind->send_flags;
	wr.bind_mw.bind_info = mw_bind->bind_info;
	wr.bind_mw.mw = mw;
	wr.bind_mw.rkey = ibv_inc_rkey(mw->rkey);

	ret = yib_u_post_send(qp, &wr, &bad_wr);
	if (ret)
		return ret;

	mw->rkey = wr.bind_mw.rkey;

	return 0;
}


int yib_u_notify_cq(struct ibv_cq *ibvcq, int solicited){
		
    struct yib_context *ctx = to_yib_ctx(ibvcq->context);
	struct yib_cq *cq = to_yib_cq(ibvcq);

   	ctx->hw_ops->hw_notify_cq(cq, solicited);
	return 0;
}


#include "io.c"


static int yib_u_query_qp(struct ibv_qp *ibqp, struct ibv_qp_attr *attr,
			int attr_mask, struct ibv_qp_init_attr *init_attr)
{
	struct ibv_query_qp cmd = {};

	return ibv_cmd_query_qp(ibqp, attr, attr_mask, init_attr,
				&cmd, sizeof(cmd));
}


static int yib_u_modify_qp(struct ibv_qp *ibqp, struct ibv_qp_attr *attr,
				   int attr_mask)
{
	struct yib_context *context = to_yib_ctx(ibqp->context);
	struct ibv_modify_qp cmd = {};
//	FILE *fp = context->dbg_fp;
	struct yib_qp *qp = to_yib_qp(ibqp);
	int ret;

	if (attr_mask & IBV_QP_STATE) {
		pthread_spin_lock(&qp->sq.lock);
	}
	

	ret = ibv_cmd_modify_qp(ibqp, attr, attr_mask, &cmd, sizeof(cmd));
	if (ret) {
		YIB_LOGm_ERR(context->dbg_fp, YIB_MSG_QP , "QP Modify: Failed command. ret=%d\n", ret);
		goto end;
	}

	if (attr_mask & IBV_QP_STATE) {
		qp->qp_state = attr->qp_state;
	}

end:	
	if (attr_mask & IBV_QP_STATE) {
		pthread_spin_unlock(&qp->sq.lock);
	}	
	return ret;
}

void yib_u_async_event(struct ibv_context *ibv_ctx,
		      struct ibv_async_event *event)
{
	struct yib_context *ctx = to_yib_ctx(ibv_ctx);

	ctx->hw_ops->hw_async_event(ctx, event);
	
}

const struct verbs_context_ops yib_uops = {

		.async_event = yib_u_async_event,
		
		.query_device_ex	= yib_u_query_device,
		.query_port		= yib_u_query_port,

		.alloc_pd		= yib_u_alloc_pd,
		.dealloc_pd		= yib_u_free_pd,

		.reg_mr			= yib_u_reg_mr,
		.dereg_mr		= yib_u_dereg_mr,

		.create_ah              = yib_u_create_ah,
		.destroy_ah             = yib_u_destroy_ah,   

		//以上原则上流程不变,只是resp可能调整了

		.create_cq		= yib_u_create_cq,
		.destroy_cq		= yib_u_destroy_cq,    
		.req_notify_cq	        = yib_u_notify_cq, //ibv_cmd_req_notify_cq,
		.poll_cq		= yib_u_poll_cq,
		//.cq_event               = yib_u_cq_event,
		//.resize_cq              = yib_u_resize_cq,

		.create_srq = yib_u_create_srq,
		.destroy_srq = yib_u_destroy_srq,
		.query_srq = yib_u_query_srq,

		.alloc_mw = yib_u_alloc_mw,
		.bind_mw  = yib_u_bind_mw,
		.dealloc_mw = yib_u_dealloc_mw,

		.create_qp		= yib_u_create_qp,
		.destroy_qp		= yib_u_destroy_qp,   
		.query_qp		= yib_u_query_qp,     
		.modify_qp		= yib_u_modify_qp,

		.post_send		= yib_u_post_send,
		.post_recv		= yib_u_post_recv,
		.post_srq_recv  = yib_u_post_srq_recv,
		.free_context		= yib_dealloc_context,
		.create_qp_ex = yib_u_create_qp_ex,
};

const struct verbs_context_ops yib_np_uops = {

		.async_event = yib_u_async_event,

		.query_device_ex	= yib_u_query_device,
		.query_port		= yib_u_query_port,

		.alloc_pd		= yib_u_alloc_pd,
		.dealloc_pd		= yib_u_free_pd,

		.reg_mr			= yib_u_reg_mr,
		.dereg_mr		= yib_u_dereg_mr,

		.create_ah              = yib_u_create_ah,
		.destroy_ah             = yib_u_destroy_ah,

		//以上原则上流程不变,只是resp可能调整了

		.create_cq		= yib_u_create_cq,
		.destroy_cq		= yib_u_destroy_cq,
		//.req_notify_cq	        = yib_u_notify_cq, //ibv_cmd_req_notify_cq,
		.poll_cq		= yib_u_poll_cq,
		//.cq_event               = yib_u_cq_event,
		//.resize_cq              = yib_u_resize_cq,

		.create_qp		= yib_u_create_qp,
		.destroy_qp		= yib_u_destroy_qp,
		.query_qp		= yib_u_query_qp,
		.modify_qp		= yib_u_modify_qp,

		.post_send		= yib_u_post_send,
		.post_recv		= yib_u_post_recv,

		.free_context		= yib_dealloc_context,
		.create_qp_ex = yib_u_create_qp_ex,
};

