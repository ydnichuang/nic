
#include "basic.h"
#include "hw/hw_comm.h"
#include <bits/stdint-uintn.h>

struct swtest_hw_ctx {
	char *reg_base;
};

extern struct yib_hw_ctx_ops swtest_hw_ctx_ops ;


int swtest_get_sq_item_size(enum ibv_qp_type qp_type , int *inline_size , uint32_t *max_sge);//inline_len和max_sg为输入输出参数
int swtest_get_rq_item_size(uint32_t *max_sg);
int swtest_hw_global_map_reg(struct yib_context *ctx);
int swtest_hw_global_unmap_reg(struct yib_context *ctx);
int swtest_hw_context_alloc(void  * context);
int swtest_hw_context_dealloc(void *context);
int swtest_hw_cq_init(struct yib_context * ctx, struct yib_cq *cq );
int swtest_hw_qp_init(struct yib_context * ctx, struct yib_qp* qp);
int swtest_hw_rq_init(struct yib_context * ctx, struct yib_rq*  rq);
int swtest_hw_mr_init(struct yib_context * ctx, struct yib_mr* mr);
int swtest_hw_mr_uninit(struct yib_context * ctx, struct yib_mr* mr);
int swtest_hw_cq_uninit(struct yib_context * ctx, struct yib_cq* cq);
int swtest_hw_qp_uninit(struct yib_context * ctx, struct yib_qp*  qp);
int swtest_hw_rq_uninit(struct yib_context * ctx, struct yib_rq*  rq);
int swtest_fill_rqe(struct yib_context * ctx, struct yib_rq *rq, const void *os_wq, u8 *buf, u32 length);
int swtest_fill_srqe(struct yib_context * ctx, struct yib_rq *rq, const void *os_wq, u8 *buf, u32 length, int pos);
int swtest_fill_wqe(struct yib_context * ctx, struct yib_qp *qp, const void *os_wq, u8 *buf, u32 length,  u32 mask) ;

//qp_cache是否使用，由底层的情况决定，当底层硬件有能力在cq中返回qp地址信息时不使用， 否则底层硬件可返回qpn(这时需要使用qp_cache)
void swtest_fill_cqe(struct yib_cq *cq,  struct ibv_wc *wc, u8 *cqe) ;
int swtest_sw_fill_cqe(struct yib_context * ctx, struct yib_cq *cq, void *os_cq);
bool swtest_check_sq_full(struct yib_context *ctx, struct yib_sq *sq);
bool swtest_check_rq_full(struct yib_context *ctx, struct yib_rq *rq);
bool swtest_check_srq_full(struct yib_context *ctx, struct yib_srq *srq, int *pos);
bool swtest_check_cq_empty(struct yib_context * ctx , struct yib_cq *cq, void *cqe);
void swtest_sq_pi_db_update(struct yib_context * ctx, struct yib_qp *qp, int io_cnt);
void swtest_rq_pi_db_update(struct yib_context * ctx, struct yib_rq *rq, int io_cnt);
void swtest_srq_pi_db_update(struct yib_context * ctx, struct yib_srq *srq, int pos);
void swtest_cq_ci_db_update(struct yib_context *ctx, struct yib_cq *cq, int poll_cnt);
/*new api support*/
void swtest_wr_send(struct yib_qp *qp);
void swtest_wr_rdma_read(struct yib_qp *qp, uint32_t rkey, uint64_t remote_addr);
void swtest_wr_rdma_write(struct yib_qp *qp, uint32_t rkey,uint64_t remote_addr);
void swtest_wr_rdma_write_imm(struct yib_qp *qp, uint32_t rkey,uint64_t remote_addr, __be32 imm_data);
void swtest_wr_send_imm(struct yib_qp *qp, __be32 imm_data);
void swtest_wr_send_inv(struct yib_qp *qp, uint32_t invalidate_rkey);
void swtest_wr_set_inline_data(struct yib_qp *qp, void *addr, size_t length);
void swtest_wr_set_inline_data_list(struct yib_qp *qp, size_t num_buf,const struct ibv_data_buf *buf_list);
void swtest_wr_set_sge(struct yib_qp* qp, uint32_t lkey, uint64_t addr, uint32_t length);
void swtest_wr_set_sge_list(struct yib_qp *qp, uint32_t num_sge, const struct ibv_sge *list);
