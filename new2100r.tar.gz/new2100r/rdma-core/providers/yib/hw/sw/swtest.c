#include "basic.h"
#include "rdma/yib-abi.h"
#include "ib.h"

#include "swtest.h"
#include "yib_log.h"


// 硬件相关实现

int swtest_hw_context_alloc(void *context)
{
	struct yib_context *yib_ctx = context;

	struct swtest_hw_ctx *hw_ctx = malloc(sizeof(struct swtest_hw_ctx));
	yib_ctx->hw_priv = hw_ctx;

	return 0;
}

int swtest_hw_context_dealloc(void *context)
{

	struct yib_context *ctx = context;
	if (ctx->hw_priv)
	{
		free(ctx->hw_priv);
		ctx->hw_priv = NULL;
	}

	return 0;
};

int swtest_hw_global_map_reg(struct yib_context *ctx)
{
	int ret = 0;
	struct swtest_hw_ctx *hw_ctx = (struct swtest_hw_ctx *)ctx->hw_priv;

	hw_ctx->reg_base = yib_private_mmap(YIB_MMAP_TYPE_REG, ctx->bar_offset , ctx->bar_len , ctx->cmd_fd);
	if (hw_ctx->reg_base == NULL)
		return -ENOMEM;

	ret = yib_resource_mmap(ctx);
	if (ret) {
		yib_private_munmap(hw_ctx->reg_base, ctx->bar_len);
		return ret;
	}

	return 0;
} // 映射regi寄存器

int swtest_hw_global_unmap_reg(struct yib_context *ctx)
{
	struct swtest_hw_ctx *hw_ctx = (struct swtest_hw_ctx *)ctx->hw_priv;
	if (hw_ctx->reg_base) {
		yib_private_munmap(hw_ctx->reg_base, ctx->bar_len);
		hw_ctx->reg_base = NULL;
	}

	yib_resource_unmmap(ctx);
	return 0;
}

// 硬件相关的初始化函数
int swtest_hw_cq_init(struct yib_context *ctx, struct yib_cq *cq)
{

	cq->hw_cq_priv = NULL;
	return 0;
}

int swtest_hw_qp_init(struct yib_context *ctx, struct yib_qp *qp) { return 0; }
int swtest_hw_rq_init(struct yib_context *ctx, struct yib_rq *rq) { return 0; }

int swtest_hw_mr_init(struct yib_context *ctx, struct yib_mr *mr)
{

	return 0;
}

int swtest_hw_mr_uninit(struct yib_context *ctx, struct yib_mr *mr)
{

	return 0;
}

int swtest_hw_cq_uninit(struct yib_context *ctx, struct yib_cq *cq) { return 0; }
int swtest_hw_qp_uninit(struct yib_context *ctx, struct yib_qp *qp) { return 0; }
int swtest_hw_rq_uninit(struct yib_context *ctx, struct yib_rq *rq)
{
	return 0; // srq,rq
}

//	int (*get_sq_item_size)(enum qp_type , int is_inline  , int sge_num);
//	int (*get_rq_item_size)(enum qp_type , int is_inline  , int sge_num);//qp_type rc,ud

int swtest_fill_rqe(struct yib_context *ctx, struct yib_rq *rq, const void *os_wq, u8 *buf, u32 length)
{
	return 0;
}
int swtest_fill_srqe(struct yib_context *ctx, struct yib_rq *rq, const void *os_wq, u8 *buf, u32 length, int pos)
{
	return 0;
}
int swtest_fill_wqe(struct yib_context *ctx, struct yib_qp *qp, const void *os_wq, u8 *buf, u32 length, u32 mask)
{
	return 0;
}
// qp_cache是否使用，由底层的情况决定，当底层硬件有能力在cq中返回qp地址信息时不使用， 否则底层硬件可返回qpn(这时需要使用qp_cache)
void swtest_fill_cqe(struct yib_cq *cq, struct ibv_wc *wc, u8 *cqe)
{
	return ;
}

int swtest_sw_fill_cqe(struct yib_context *ctx, struct yib_cq *cq, void *os_cq)
{
	return 0;
} // 返回0表示处理成功，小于0表示不保序

bool swtest_check_sq_full(struct yib_context *ctx, struct yib_sq *sq)
{
	return false;
	bool q_state;
	if (sq->sq_info.info->pi_toggle && !sq->sq_info.info->ci_toggle && sq->sq_info.info->ci == sq->sq_info.info->pi)
		q_state = 1;
	else
		q_state = 0;
	return q_state;
}
bool swtest_check_rq_full(struct yib_context *ctx, struct yib_rq *rq)
{
	return false;
	bool q_state;
	if (rq->rq_info.info->pi_toggle && !rq->rq_info.info->ci_toggle && rq->rq_info.info->ci == rq->rq_info.info->pi)
		q_state = 1;
	else
		q_state = 0;
	return q_state;
}
bool swtest_check_srq_full(struct yib_context *ctx, struct yib_srq *srq, int *pos) { return 0; }

bool swtest_check_cq_empty(struct yib_context *ctx, struct yib_cq *cq, void *cqe)
{
	return true;
	bool q_state;
	if (cq->cqinfo.info->pi_toggle == cq->cqinfo.info->ci_toggle && cq->cqinfo.info->ci == cq->cqinfo.info->pi)
		q_state = 1;
	else
		q_state = 0;
	return q_state;
}

int swtest_get_sq_item_size(enum ibv_qp_type qp_type, int *inline_len, uint32_t *max_sg)
{
	// inline: 16 80 208
	// sg: 1 5 13
	// ud inline: 48 176
	int isize = 0;
	int input = max(*inline_len, *max_sg * 16);
	int len = 0, sg_num = 0;
	if (qp_type == IBV_QPT_UD)
	{
		if (input <= 48)
		{
			isize = 128;
			len = 48;
		}
		else
		{
			isize = 256;
			len = 176;
		}
		sg_num = len / 16;
	}
	else
	{
		if (input <= 16)
		{
			isize = 64;
			len = 16;
		}
		else if (input > 16 && input <= 80)
		{
			isize = 128;
			len = 80;
		}
		else if (input > 80)
		{
			isize = 256;
			len = 208;
		}
		sg_num = len / 16;
	}

	*inline_len = len;
	*max_sg = sg_num;
	return isize;
}

int swtest_get_rq_item_size(uint32_t *max_sg)
{
	// sg: 2 6 14
	int isize = 0;
	int sg_num = 0;
	if (*max_sg <= 2)
	{
		isize = 64;
		sg_num = 2;
	}
	else if (*max_sg > 2 && *max_sg <= 6)
	{
		isize = 128;
		sg_num = 6;
	}
	else if (*max_sg > 6)
	{
		isize = 256;
		sg_num = 14;
	}
	*max_sg = sg_num;
	return isize;
}

// db update
void swtest_sq_pi_db_update(struct yib_context *ctx, struct yib_qp *qp, int io_cnt) { return; }
void swtest_rq_pi_db_update(struct yib_context *ctx, struct yib_rq *rq, int io_cnt) { return; }
void swtest_srq_pi_db_update(struct yib_context *ctx, struct yib_srq *srq, int pos) { return; }

void swtest_cq_ci_db_update(struct yib_context *ctx, struct yib_cq *cq, int poll_cnt)
{
	//		u32 idx = q_get_val(cq->cqinfo.info->ci);
	//		u32 c = q_get_carrier(cq->cqinfo.info->ci);
	//				mmio_write32(cq->ci_db, (idx << 16) | yib_get_cqc_index(cq->ctx, cq->cqid) | (c<<15));
}

/*new api support*/
void swtest_wr_send(struct yib_qp *qp) { return; }
void swtest_wr_rdma_read(struct yib_qp *qp, uint32_t rkey, uint64_t remote_addr) { return; }
void swtest_wr_rdma_write(struct yib_qp *qp, uint32_t rkey, uint64_t remote_addr) { return; }
void swtest_wr_rdma_write_imm(struct yib_qp *qp, uint32_t rkey, uint64_t remote_addr, __be32 imm_data) { return; }
void swtest_wr_send_imm(struct yib_qp *qp, __be32 imm_data) { return; }
void swtest_wr_send_inv(struct yib_qp *qp, uint32_t invalidate_rkey) { return; }
void swtest_wr_set_inline_data(struct yib_qp *qp, void *addr, size_t length) { return; }
void swtest_wr_set_inline_data_list(struct yib_qp *qp, size_t num_buf,
									const struct ibv_data_buf *buf_list) { return; }

void swtest_wr_set_sge(struct yib_qp *qp, uint32_t lkey, uint64_t addr, uint32_t length) { return; }
void swtest_wr_set_sge_list(struct yib_qp *qp, uint32_t num_sge, const struct ibv_sge *list) { return; }

struct swtest_hw_ctx swt_hw_ctx;

struct yib_hw_ctx_ops swtest_hw_ctx_ops = {
	.hw_context_alloc = swtest_hw_context_alloc,
	.hw_context_dealloc = swtest_hw_context_dealloc,

	.hw_global_map_reg = swtest_hw_global_map_reg, // 映射regi寄存器
	.hw_global_unmap_reg = swtest_hw_global_unmap_reg,

	// 硬件相关的初始化函数
	.hw_cq_init = swtest_hw_cq_init,
	.hw_qp_init = swtest_hw_qp_init,
	.hw_rq_init = swtest_hw_rq_init,
	.hw_mr_init = swtest_hw_mr_init,

	.hw_cq_uninit = swtest_hw_cq_uninit,
	.hw_qp_uninit = swtest_hw_qp_uninit,
	.hw_rq_uninit = swtest_hw_rq_uninit, // srq,rq
	.hw_mr_uninit = swtest_hw_mr_uninit,

	//	int cqe_isize,
	.fill_rqe = swtest_fill_rqe,
	.fill_srqe = swtest_fill_srqe,
	.fill_wqe = swtest_fill_wqe,
	// qp_cache是否使用，由底层的情况决定，当底层硬件有能力在cq中返回qp地址信息时不使用， 否则底层硬件可返回qpn(这时需要使用qp_cache)
	.fill_cqe = swtest_fill_cqe,
	.sw_fill_cqe = swtest_sw_fill_cqe, // 返回0表示处理成功，小于0表示不保序

	.check_sq_full = swtest_check_sq_full,
	.check_rq_full = swtest_check_rq_full,
	.check_srq_full = swtest_check_srq_full,
	.check_cq_empty = swtest_check_cq_empty,
	// bool (*is_resize_cq)(u8 *buf);

	.get_sq_item_size = swtest_get_sq_item_size, // inline_len和max_sg为输入输出参数
	.get_rq_item_size = swtest_get_rq_item_size,

	// db update
	.sq_pi_db_update = swtest_sq_pi_db_update,
	.rq_pi_db_update = swtest_rq_pi_db_update,
	.srq_pi_db_update = swtest_srq_pi_db_update,
	.cq_ci_db_update = swtest_cq_ci_db_update,

	// #endif

	/*new api support*/
	.wr_send = swtest_wr_send,
	.wr_rdma_read = swtest_wr_rdma_read,
	.wr_rdma_write = swtest_wr_rdma_write,
	.wr_rdma_write_imm = swtest_wr_rdma_write_imm,
	.wr_send_imm = swtest_wr_send_imm,
	.wr_send_inv = swtest_wr_send_inv,
	.wr_set_inline_data = swtest_wr_set_inline_data,
	.wr_set_inline_data_list = swtest_wr_set_inline_data_list,

	.wr_set_sge = swtest_wr_set_sge,
	.wr_set_sge_list = swtest_wr_set_sge_list,
};
