#ifndef YIB_R2100_H
#define YIB_R2100_H


#include "hw/hw_comm.h"
#include "hw/linux.h"
#include "io.h"
#include "swcmd.h"

#include "rdma-header/include/yib_inc_fw.h"
#include "rdma-header/include/yib_inc_io.h"
#include "rdma-header/include/yib_inc_base.h"

#include <bits/stdint-uintn.h>


#define R2100_DB64_REG    0x80
#define R2100_FW_CMD_REG(x)   (0x00 + (x))


#define R2100_CPLQ_SIZE  4096
#define R2100_DMA_BUF_SIZE  4096
#define R2100_MAX_SMACS  256
#define R2100_MAX_SGIDS  256
#define R2100_ENABLE_INT 0
#define R2100_SF_START_OFFSET	0 //todo
#define R2100_CQ_CI_DB	0x1000
#define LOCAL_RQ_CREDITS_EN  0
#define REMOTE_RQ_CREDITS_EN  0
#define YIB_ROCE_UDP_ENCAP_VALID_PORT_MIN (0xC000)
#define YIB_ROCE_UDP_ENCAP_VALID_PORT_MAX (0xFFFF)
#define R2100_CHIPSUBTYPE  1
#define R2100_ACCESS_RIGHT 0x1F
#define R2100_MAX_EQ_NUM 8


extern struct yib_hw_ctx_ops r2100u_hw_ctx_ops;

struct r2100_hw_ctx   {
	char *reg_base;
};


void r2100u_fill_cqe(struct yib_cq *cq,  struct ibv_wc *wc, u8 *buf);
int r2100u_fill_wqe(struct yib_context *ctx, struct yib_qp *qp, const void *os_wq, u8 *buf, u32 length, u32 mask);
int r2100u_fill_rqe(struct yib_context *ctx, struct yib_rq *rq, const void *os_wq, u8 *buf, u32 length);
int r2100u_fill_srqe(struct yib_context *ctx, struct yib_rq *rq, const void *os_wq, u8 *buf, u32 length, int pos);
void r2100_ucq_ci_db_update(struct yib_cq *cq);
void r2100_usq_pi_db_update(struct yib_sq *sq);
void r2100_urq_pi_db_update(struct yib_rq *rq);
bool r2100_is_resize_cqe(u8 *buf);
int r2100u_set_capture(struct yib_qp *qp, bool enable);

//static enum yib_wqe_type ibv_wr_to_hw_wr_opcode(enum ibv_wr_opcode opcode);


void r2100u_fill_av(struct yib_hw_av *hw_av, struct yib_av *av);

int r2100u_sw_fill_cqe(struct yib_context *ctx, struct yib_cq *cq, void *os_cq);
int r2100u_hw_global_map_reg(struct yib_context *ctx);
int r2100u_hw_global_unmap_reg(struct yib_context *ctx);
void r2100u_cq_notify(struct yib_cq *cq, u32 solicited);



bool r2100u_check_cq_empty(struct yib_context *ctx, struct yib_cq *cq, void *cqe);
int r2100u_get_sq_item_size(enum ibv_qp_type qp_type, int *inline_len, uint32_t *max_sg);
int r2100u_get_rq_item_size(uint32_t *max_sg);



void r2100u_cq_ci_db_update(struct yib_context *ctx, struct yib_cq *cq, int poll_cnt);
void r2100u_rq_pi_db_update(struct yib_context *ctx, struct yib_rq *rq, int io_cnt);
void r2100u_srq_pi_db_update(struct yib_context *ctx, struct yib_srq *srq, int pos);
void r2100u_sq_pi_db_update(struct yib_context *ctx, struct yib_qp *qp, int io_cnt);
bool r2100u_check_sq_full(struct yib_context *ctx, struct yib_sq *sq);
bool r2100u_check_srq_full(struct yib_context *ctx, struct yib_srq *srq, int *pos);
bool r2100u_check_rq_full(struct yib_context *ctx, struct yib_rq *rq);



int r2100u_hw_context_alloc(void  * context);
int r2100u_hw_context_dealloc(void *context);




//硬件相关的初始化函数
int r2100u_hw_cq_init(struct yib_context * ctx, struct yib_cq *cq );
int r2100u_hw_qp_init(struct yib_context * ctx, struct yib_qp* qp);
int r2100u_hw_rq_init(struct yib_context * ctx, struct yib_rq* rq);
int r2100u_hw_mr_init(struct yib_context * ctx, struct yib_mr* mr);
int r2100u_hw_mr_uninit(struct yib_context * ctx, struct yib_mr* mr);
int r2100u_hw_cq_uninit(struct yib_context * ctx, struct yib_cq* cq);
int r2100u_hw_qp_uninit(struct yib_context * ctx, struct yib_qp* qp);
int r2100u_hw_rq_uninit(struct yib_context * ctx, struct yib_rq* rq);


void r2100u_async_event(struct yib_context *context,
		      struct ibv_async_event *event);

void r2100_wr_send(struct yib_qp *qp);
void r2100_wr_send_imm(struct yib_qp *qp, __be32 imm_data);
void r2100_wr_send_inv(struct yib_qp *qp, uint32_t invalidate_rkey);
void r2100_wr_rdma_read(struct yib_qp *qp, uint32_t rkey, uint64_t remote_addr);
void r2100_wr_rdma_write(struct yib_qp *qp, uint32_t rkey,uint64_t remote_addr);
void r2100_wr_rdma_write_imm(struct yib_qp *qp, uint32_t rkey, uint64_t remote_addr, __be32 imm_data);
void r2100_wr_set_inline_data(struct yib_qp *qp, void *addr,size_t length);
void r2100_wr_set_inline_data_list(struct yib_qp *qp, size_t num_buf, const struct ibv_data_buf *buf_list);
void r2100_wr_set_sge(struct yib_qp* qp,uint32_t lkey,uint64_t addr, uint32_t length);
void r2100_wr_set_sge_list(struct yib_qp *qp, uint32_t num_sge, const struct ibv_sge *list);



#endif 
