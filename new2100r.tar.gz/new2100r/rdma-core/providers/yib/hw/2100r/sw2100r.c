#include "basic.h"
#include <netinet/in.h>
#include <infiniband/driver.h>
#include <infiniband/verbs.h>
#include <util/symver.h>
#include "yib-abi.h"
#include "yib.h"
#include "ib.h"
#include "queue.h"
#include "sw2100r.h"
#include "yib_log.h"

#include "hw/hw_comm.h"




//from kernel
enum rdma_network_type {
	RDMA_NETWORK_IB,
	RDMA_NETWORK_ROCE_V1 = RDMA_NETWORK_IB,
	RDMA_NETWORK_IPV4,
	RDMA_NETWORK_IPV6
};


static enum yib_wqe_type ibv_wr_to_hw_wr_opcode(enum ibv_wr_opcode opcode)
{
	switch (opcode) {
		case IBV_WR_SEND:			
			return YIB_WQE_SEND;
		case IBV_WR_SEND_WITH_IMM:		
			return YIB_WQE_SEND_WITH_IMM;
		case IBV_WR_SEND_WITH_INV:
			return YIB_WQE_SEND_WITH_INV;
		case IBV_WR_RDMA_WRITE:		
			return YIB_WQE_RDMA_WRITE;
		case IBV_WR_RDMA_WRITE_WITH_IMM:			
			return YIB_WQE_RDMA_WRITE_WITH_IMM;
		case IBV_WR_RDMA_READ:			
			return YIB_WQE_READ;
		case IBV_WR_ATOMIC_CMP_AND_SWP:			
			return YIB_WQE_ATOMIC_CAS;
		case IBV_WR_ATOMIC_FETCH_AND_ADD:			
			return YIB_WQE_ATOMIC_FETCH_ADD;
		case IBV_WR_LOCAL_INV:			
			return YIB_WQE_LOCAL_INV;
/* 		case IBV_WR_REG_MR:			
			return YIB_WQE_FR_PMR; */
		case IBV_WR_BIND_MW:			
			return YIB_WQE_MEM_BIND;

		default:
			return 0xff;
	}
}

static enum r2100_network_type to_hw_network_type(int type)
{
	switch (type) {
		case YIB_NETWORK_TYPE_IPV4:
			return R2100_NETWORK_TYPE_IPV4;
		case YIB_NETWORK_TYPE_IPV6:
			return R2100_NETWORK_TYPE_IPV6;
		default:
			return 0xff;
	}
}

void r2100u_fill_av(struct yib_hw_av *hw_av, struct yib_av *av)
{
	bool 	bipv6;
	bool 	vlan_enable;
	u16 	vlan_id;
	u32 	val;
	u32 	dmac_lsb, dmac_msb;
	int network_type = to_hw_network_type(av->network_type);

	bipv6 = (network_type == R2100_NETWORK_TYPE_IPV6)? true: false;
	vlan_id = av->vlan_id;
	vlan_enable = (vlan_id == 0xFFFF)? false: true;
	//mac info
	dmac_lsb = av->dmac[5] | (av->dmac[4] << 8) | (av->dmac[3] << 16) | (av->dmac[2] << 24);
	dmac_msb = av->dmac[1] | (av->dmac[0] << 8);

	yib_hwres_write(hw_av, YIB_AV_DST_MAC_ADDR_LSB, dmac_lsb);
	yib_hwres_write(hw_av, YIB_AV_DST_MAC_ADDR_MSB, dmac_msb);
	yib_hwres_write(hw_av, YIB_AV_TC, av->grh.traffic_class);
	yib_hwres_write(hw_av, YIB_AV_SRC_MAC_IDX, av->smac_idx);
	yib_hwres_write(hw_av, YIB_AV_FLOW_LABEL, av->grh.flow_label);
	yib_hwres_write(hw_av, YIB_AV_NETWORK_TYPE, network_type);
	yib_hwres_write(hw_av, YIB_AV_SRC_GID_IDX, av->grh.sgid_index);
	yib_hwres_write(hw_av, YIB_AV_VLAN_VID, vlan_id & 0xFFF);
	yib_hwres_write(hw_av, YIB_AV_VLAN_PRI, av->vlan_pcp);
	yib_hwres_write(hw_av, YIB_AV_VLAN_CFI, 0);
	yib_hwres_write(hw_av, YIB_AV_VLAN_ENABLE, vlan_enable);
	yib_hwres_write(hw_av, YIB_AV_TTL, av->grh.hop_limit);

	if (!bipv6) {
		u8 *addrv4;
		addrv4 = (u8 *)(&av->dgid_addr._sockaddr_in.sin_addr.s_addr);
		val = net_addr2_le32(addrv4);
		yib_hwres_write(hw_av, YIB_AV_DST_GID_OR_IP_0, val);

	} else {
		u8 *addrv6;
		addrv6 = (u8 *)(&av->dgid_addr._sockaddr_in6.sin6_addr.s6_addr);
		val = net_addr2_le32(addrv6 + 12);
		yib_hwres_write(hw_av, YIB_AV_DST_GID_OR_IP_0, val);
		val = net_addr2_le32(addrv6 + 8);
		yib_hwres_write(hw_av, YIB_AV_DST_GID_OR_IP_1, val);
		val = net_addr2_le32(addrv6 + 4);
		yib_hwres_write(hw_av, YIB_AV_DST_GID_OR_IP_2, val);
		val = net_addr2_le32(addrv6);
		yib_hwres_write(hw_av, YIB_AV_DST_GID_OR_IP_3, val);
	}
}


int r2100u_sw_fill_cqe(struct yib_context *ctx, struct yib_cq *cq, void *os_cq)
{
	struct yib_sw_cqe *cqe = cq->cur_sw_cqe;
	struct ibv_wc *wc = os_cq;
	u32 cqe_type;
	u64 handle;
	u32 index;
	bool bsw = false;
	int ret;

	cqe_type = cqe->type;
	handle = cqe->handler;
	index = cqe->start_pos;
	wc->status = cqe->status;
	
	if (cqe_type == YIB_CQE_SQ) {
		struct yib_qp *qp = (struct yib_qp *)handle;
		ret = yib_usq_check_cqe(ctx, qp, index, true);
		if (ret)
			return ret;
		if(qp->sq.sw_posted[index] == 0) {
			wc->opcode = qp->sq.sw_cmds[index].opcode;
			wc->wr_id = qp->sq.sw_cmds[index].wrid;
		} else {
			wc->opcode = cqe->sw_opcode;
			wc->wr_id = cqe->sw_wr_id;
			bsw = true;
		}
		yib_usq_swcmd_done(ctx, qp, index, bsw);
	} else if (cqe_type == YIB_CQE_RQ) {
		struct yib_rq *rq = (struct yib_rq *)handle;
		wc->opcode = rq->sw_cmds[index].opcode;
		wc->wr_id = rq->sw_cmds[index].wrid;
		yib_urq_swcmd_done(ctx, rq, index);
	} else if (cqe_type == YIB_CQE_SRQ) {
		struct yib_srq *srq = (struct yib_srq *)handle;
		wc->opcode = srq->rq.sw_cmds[index].opcode;
		wc->wr_id = srq->rq.sw_cmds[index].wrid;
		yib_usrq_swcmd_done(ctx, srq, index);
	}
	
	return 0;
}



/* ###################################################################################################### */


int r2100u_set_capture(struct yib_qp *qp, bool enable)
{
	return -1;
}



int r2100u_hw_global_map_reg(struct yib_context *ctx)
{
	int ret = 0 ;
	struct r2100_hw_ctx *hw_ctx = (struct r2100_hw_ctx *)ctx->hw_priv;

	hw_ctx->reg_base = yib_private_mmap(YIB_MMAP_TYPE_REG, ctx->bar_offset , ctx->bar_len , ctx->cmd_fd);
	if (hw_ctx->reg_base == NULL)
		return -ENOMEM;

	ret = yib_resource_mmap(ctx);
	if (ret) {
		yib_private_munmap(hw_ctx->reg_base, ctx->bar_len);
		return ret;
	}

	return 0;
}//映射regi寄存器

int r2100u_hw_global_unmap_reg(struct yib_context *ctx)
{
	struct r2100_hw_ctx *hw_ctx = (struct r2100_hw_ctx *)ctx->hw_priv;
	if (hw_ctx->reg_base) {
		yib_private_munmap(hw_ctx->reg_base, ctx->bar_len);
		hw_ctx->reg_base = NULL;
	}

	yib_resource_unmmap(ctx);
	return 0;
}




int r2100u_get_sq_item_size(enum ibv_qp_type qp_type, int *inline_len, uint32_t *max_sg)
{
	int isize = 0;
	int input = max(*inline_len, *max_sg * 16);
	int len = 0, sg_num = 0;
	if (qp_type == IBV_QPT_UD) {
		if (input <= 16) {
			isize = 64;
			len = 16;
		} else if (input > 16 && input <= 80) {
			isize = 128;
			len = 80;
		} else if (input > 80) {
			isize = 256;
			len = 208;
		}
		sg_num = len / 16;
	} else {
		if (input <= 32) {
			isize = 64;
			len = 32;
		} else if (input > 32 && input <= 96) {
			isize = 128;
			len = 96;
		} else if (input > 96) {
			isize = 256;
			len = 224;
		}
		sg_num = len / 16;
	}

	*inline_len = len;
	*max_sg = sg_num;
	return isize;
}

int r2100u_get_rq_item_size(uint32_t *max_sg)
{	
	*max_sg = 3;	
	return 64;
}


#define QUEUE_STATE_CHECK

bool r2100u_check_cq_empty(struct yib_context *ctx, struct yib_cq *cq, void *cqe)
{
	struct yib_hw_cqe *hw_cqe = NULL;
	u32 toggle;
	u32 ci_toggle;
	u32 cqe_type;
	u64 handle;
	u32 handle_lsb;
	u64 handle_msb;
	u32 index;
	int ret = 0;
	struct yib_qp *qp = NULL;

	hw_cqe = (struct yib_hw_cqe *)cqe;
	
	ci_toggle = cq->cqinfo.info->ci_toggle;
	toggle = yib_hwres_read(hw_cqe, YIB_CQE_TOGGLE);
	if (toggle == ci_toggle)
		return true;

	cqe_type = yib_hwres_read(hw_cqe, YIB_CQE_CQE_TYPE);
	handle_lsb = yib_hwres_read(hw_cqe, YIB_CQE_QP_HANDLE_LSB);
	handle_msb = yib_hwres_read(hw_cqe, YIB_CQE_QP_HANDLE_MSB);
	handle = handle_lsb | (handle_msb << 32);
	index = yib_hwres_read(hw_cqe, YIB_CQE_WQE_IDX);
	qp = (struct yib_qp *)handle;
	YIB_LOGm_INFO(ctx->dbg_fp, YIB_MSG_IO, "buf=%p cqe=%p pos=%ld ci=%d info=%p toggle=%d handle=0x%lx\n",
	    cq->buf_v.buf, cqe, (cqe - cq->buf_v.buf) / ctx->hw_caps.cqe_isize, 
		atomic_get(&cq->cqinfo.info->ci), cq->cqinfo.info, toggle, handle);

	if (cqe_type == YIB_CQE_SQ) {
		ret = yib_usq_check_cqe(ctx, qp, index, false);
	} else if (cqe_type == YIB_CQE_RQ) {
// TODO	commit_id 42fb1a4b2f304e017bfa39f7c2d60d87d418b539
// YIB_CQE_SRQ表示来自srq,这里不需要区分
		ret = yib_urq_check_hwcqe(ctx, &qp->rq , index);
	}
	
	if(ret)
		return true;

	return false;
}

bool r2100u_check_rq_full(struct yib_context *ctx, struct yib_rq *rq)
{
	struct yib_queue_info *info = rq->rq_info.info;
	u32 pi, ci, pi_toggle, ci_toggle;

	pi = atomic_get(&info->pi);
	ci = atomic_get(&info->ci);
	pi_toggle = info->pi_toggle;
	ci_toggle = info->ci_toggle;

	return (pi == ci) && (pi_toggle != ci_toggle);
}

bool r2100u_check_srq_full(struct yib_context *ctx, struct yib_srq *srq, int *pos)
{
	int ret = 0;
	ret = yib_srq_find_useable_pos(srq);
	if (ret == -ENOMEM)
		return true;
//TODO commit_id f0e56b9b872ae185b13e7b5ca3043bf988dcda27
	*pos = ret;
	return false;
}

bool r2100u_check_sq_full(struct yib_context *ctx, struct yib_sq *sq)
{
	struct yib_queue_info *info = sq->sq_info.info;
	u32 pi, ci, pi_toggle, ci_toggle;

	pi = atomic_get(&info->pi);
	ci = atomic_get(&info->ci);
	pi_toggle = info->pi_toggle;
	ci_toggle = info->ci_toggle;

	return (pi == ci) && (pi_toggle != ci_toggle);
}



#define FILL_XQE


void r2100u_fill_cqe(struct yib_cq *cq,  struct ibv_wc *wc, u8 *buf)
{
	struct yib_hw_cqe *cqe = (struct yib_hw_cqe *)buf;
	struct yib_context *ctx = cq->ctx;
	struct yib_qp *qp = NULL;
	struct yib_rq *rq = NULL;
	u32 opcode;
	u32 immdata_or_invkey;
	u32 cqe_type;
	u64 handle;
	u32 handle_lsb;
	u64 handle_msb;
	int qid = 0;
	u32 wqe_idx;
	
	opcode = yib_hwres_read(cqe, YIB_CQE_OPCODE);
	immdata_or_invkey = yib_hwres_read(cqe, YIB_CQE_IMMDATA_OR_INVKEY);
	cqe_type = yib_hwres_read(cqe, YIB_CQE_CQE_TYPE);
	handle_lsb = yib_hwres_read(cqe, YIB_CQE_QP_HANDLE_LSB);
	handle_msb = yib_hwres_read(cqe, YIB_CQE_QP_HANDLE_MSB);
	handle = handle_lsb | (handle_msb << 32);
	wqe_idx = yib_hwres_read(cqe, YIB_CQE_WQE_IDX);
	
    wc->wc_flags = 0;
	wc->byte_len = yib_hwres_read(cqe, YIB_CQE_BYTE_LEN);
	wc->status = yib_hwres_read(cqe, YIB_CQE_STATUS);
    switch (opcode) {
            case YIB_WQE_RDMA_WRITE:
                    wc->opcode = IBV_WC_RDMA_WRITE;
                    break;
            case YIB_WQE_RDMA_WRITE_WITH_IMM:
                    wc->opcode = IBV_WC_RDMA_WRITE;
                    wc->imm_data = immdata_or_invkey;
                    wc->wc_flags |= IBV_WC_WITH_IMM;
                    break;
            case YIB_WQE_SEND:
					if (cqe_type == YIB_CQE_SQ) {
                    	wc->opcode = IBV_WC_SEND;
					} else {
						wc->opcode = IBV_WC_RECV;
					}
                    break;
            case YIB_WQE_SEND_WITH_IMM:
					if (cqe_type == YIB_CQE_SQ) {
	                    wc->opcode = IBV_WC_SEND;
	                    wc->imm_data = immdata_or_invkey;
	                    wc->wc_flags |= IBV_WC_WITH_IMM;
					} else {
						wc->opcode = IBV_WC_RECV_RDMA_WITH_IMM;
	                    wc->imm_data = immdata_or_invkey;
	                    wc->wc_flags |= IBV_WC_WITH_IMM;
					}
                    break;
            case YIB_WQE_SEND_WITH_INV:
					if (cqe_type == YIB_CQE_SQ) {
	                    wc->opcode = IBV_WC_SEND;
	                    wc->invalidated_rkey = immdata_or_invkey;
	                    wc->wc_flags |= IBV_WC_WITH_INV;
					} else {
						wc->opcode = IBV_WC_RECV;
	                    wc->invalidated_rkey = immdata_or_invkey;
	                    wc->wc_flags |= IBV_WC_WITH_INV;
					}
                    break;
            case YIB_WQE_READ:
                    wc->opcode = IBV_WC_RDMA_READ;
                    break;
            case YIB_WQE_LOCAL_INV:
                    wc->opcode = IBV_WC_LOCAL_INV;
					break;
			case YIB_WQE_ATOMIC_FETCH_ADD:
                    wc->opcode = IBV_WC_FETCH_ADD;
					break;
			case YIB_WQE_ATOMIC_CAS:
                    wc->opcode = IBV_WC_COMP_SWAP;
					break;
            default:
                    YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_IO ,"unknow opcode");
                    break;
    }

	
	qp = (struct yib_qp *)handle;
	if (qp == NULL || qp->qpn >= ctx->hw_caps.max_qp) {
	    YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_IO ,"can't find qp id=%d\n", qid);
	    wc->status = IBV_WC_BAD_RESP_ERR;
	    goto end;
	}
	wc->qp_num = qp->qpn;
	
	if (qp->vqp.qp.qp_type == IBV_QPT_UD) {
		    wc->pkey_index = 0;
		    wc->src_qp = yib_hwres_read(cqe, YIB_CQE_SRC_QPN);
		    wc->wc_flags |= IBV_WC_GRH; 
    }
	// swcmd part
	switch(cqe_type) {
		case YIB_CQE_SQ:
			wc->wr_id = qp->sq.sw_cmds[wqe_idx].wrid;
	    	yib_usq_swcmd_done(ctx, qp, wqe_idx, 0);
			break;
		case YIB_CQE_RQ:
			rq = &qp->rq;
			wc->wr_id = rq->sw_cmds[wqe_idx].wrid;
	        yib_urq_swcmd_done(ctx, rq, wqe_idx);
			break;
		case YIB_CQE_SRQ:
			rq = &qp->srq->rq;
			wc->wr_id = rq->sw_cmds[wqe_idx].wrid;
			if (qp->srq == NULL) {
						YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_IO ,"srq is NULL");
						wc->status = IBV_WC_BAD_RESP_ERR;
						goto end;
			}
	    	yib_usrq_swcmd_done(ctx, qp->srq, wqe_idx);
			break;
		default:
			YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_IO ,"unknown cqe type ");
			break;
	}
end:        
    return;
}

int r2100u_fill_srqe(struct yib_context *ctx, struct yib_rq *rq, const void *os_wq, u8 *buf, u32 length, int pos)
{
	struct ibv_recv_wr *recv_wr = (struct ibv_recv_wr *)os_wq;
	u8 *dst_buf = buf + sizeof(struct yib_hw_rq_wqe);
	struct yib_hw_rq_wqe * rqe = (struct yib_hw_rq_wqe *)buf;
	int i = 0;
	int size = recv_wr->num_sge * sizeof(struct yib_hw_sge) + sizeof(struct yib_hw_rq_wqe);

	memset(rqe, 0, sizeof(struct yib_hw_rq_wqe));
	yib_hwres_write(rqe, YIB_RQ_WQE_TYPE, YIB_WQE_RECV);
	yib_hwres_write(rqe, YIB_RQ_WQE_RQE_INDEX, pos & 0x7FFFFFFF);
	yib_hwres_write(rqe, YIB_RQ_WQE_LENGTH, length);
	yib_hwres_write(rqe, YIB_RQ_WQE_SIZE, size / 16);

	for (i = 0; i < recv_wr->num_sge; i++) {
		yib_hwres_write32(dst_buf, u64_lsb(recv_wr->sg_list[i].addr));
		dst_buf += 4;
		yib_hwres_write32(dst_buf, u64_msb(recv_wr->sg_list[i].addr));
		dst_buf += 4;
		yib_hwres_write32(dst_buf, recv_wr->sg_list[i].lkey);
		dst_buf += 4;
		yib_hwres_write32(dst_buf, recv_wr->sg_list[i].length);
		dst_buf += 4;
	}

	return 0;
}

int r2100u_fill_rqe(struct yib_context *ctx, struct yib_rq *rq, const void *os_wq, u8 *buf, u32 length)
{
	struct ibv_recv_wr *recv_wr = (struct ibv_recv_wr *)os_wq;
	u8 *dst_buf = buf + sizeof(struct yib_hw_rq_wqe);
	struct yib_hw_rq_wqe * rqe = (struct yib_hw_rq_wqe *)buf;	
	struct yib_queue_info *info = rq->rq_info.info;
	int i = 0;
	int size = recv_wr->num_sge * sizeof(struct yib_hw_sge) + sizeof(struct yib_hw_rq_wqe);

	memset(rqe, 0, sizeof(struct yib_hw_rq_wqe));
	yib_hwres_write(rqe, YIB_RQ_WQE_TYPE, YIB_WQE_RECV);
	yib_hwres_write(rqe, YIB_RQ_WQE_RQE_INDEX, atomic_get(&info->pi) & 0x7FFFFFFF);
	yib_hwres_write(rqe, YIB_RQ_WQE_LENGTH, length);
	yib_hwres_write(rqe, YIB_RQ_WQE_SIZE, size / 16);
	
	for (i = 0; i < recv_wr->num_sge; i++) {
		yib_hwres_write32(dst_buf, u64_lsb(recv_wr->sg_list[i].addr));
		dst_buf += 4;
		yib_hwres_write32(dst_buf, u64_msb(recv_wr->sg_list[i].addr));
		dst_buf += 4;
		yib_hwres_write32(dst_buf, recv_wr->sg_list[i].lkey);
		dst_buf += 4;
		yib_hwres_write32(dst_buf, recv_wr->sg_list[i].length);
		dst_buf += 4;
	}

	return 0;
}



static int r2100u_fill_rc_wqe(struct yib_context *ctx, struct yib_qp *qp, const void *os_wq, u8 *buf, u32 length, u32 mask, enum yib_wqe_type opcode)
{
	u8 *dst_buf = buf + sizeof(struct yib_hw_rc_wqe);
	struct yib_hw_rc_wqe *wqe = (struct yib_hw_rc_wqe *)buf;
	struct ibv_send_wr *send_wr = (struct ibv_send_wr *)os_wq;
	int i = 0;
	u64 compare_add = 0;
	u64	swap = 0;
	u32 remote_key = 0;
	u32 remote_va_lsb = 0;
	u32	remote_va_msb = 0;
	u32 com_data_lsb = 0;
	u32	com_data_msb =0;
	u32 length_data = 0;
	u32	key_data = 0;
	u8 signal_comp = 0;
	u8 rd_or_atomic_fence_flag = 0;
	u8 se_flag = 0;
	u8 inline_flag = 0;

	if ((send_wr->send_flags & IBV_SEND_SIGNALED) || qp->sqsig)
    	signal_comp = 1;
        
    if (send_wr->send_flags & IBV_SEND_SOLICITED)
		se_flag = 1;
    
    if (send_wr->send_flags & IBV_SEND_FENCE)
		rd_or_atomic_fence_flag = 1;

	if (send_wr->send_flags & IBV_SEND_INLINE) {
		inline_flag = 1;
	}

	if (mask & WR_READ_OR_WRITE_MASK) {
		remote_key = send_wr->wr.rdma.rkey;
		remote_va_lsb = u64_lsb(send_wr->wr.rdma.remote_addr);
		remote_va_msb = u64_msb(send_wr->wr.rdma.remote_addr);
	}

	if (mask & WR_ATOMIC_MASK) {
		yib_hwres_write(wqe, YIB_RC_WQE_WQE_SIZE, sizeof(struct yib_hw_rc_wqe) / 16);
		remote_key = send_wr->wr.atomic.rkey;
		remote_va_lsb = u64_lsb(send_wr->wr.atomic.remote_addr);
		remote_va_msb = u64_msb(send_wr->wr.atomic.remote_addr);
		compare_add = send_wr->wr.atomic.compare_add;
		swap = send_wr->wr.atomic.swap;
		if (opcode == YIB_WQE_ATOMIC_CAS) {
			length_data = u64_lsb(swap);
			key_data = u64_msb(swap);
			com_data_lsb = u64_lsb(compare_add);
			com_data_msb = u64_msb(compare_add);
		} else if (opcode == YIB_WQE_ATOMIC_FETCH_ADD) {
			length_data = u64_lsb(compare_add);
			key_data = u64_msb(compare_add);
		}
	} else {
		length_data = length;
		if (opcode == YIB_WQE_SEND_WITH_IMM || opcode == YIB_WQE_RDMA_WRITE_WITH_IMM)
			key_data = send_wr->imm_data;
		else if (opcode == YIB_WQE_SEND_WITH_INV)
			key_data = send_wr->invalidate_rkey;
	}

	memset(wqe, 0, sizeof(struct yib_hw_rc_wqe));
	yib_hwres_write(wqe, YIB_RC_WQE_TYPE, opcode);
	yib_hwres_write(wqe, YIB_RC_WQE_SIGNAL_COMP, signal_comp);
	yib_hwres_write(wqe, YIB_RC_WQE_RD_OR_ATOMIC_FENCE_FLAG, rd_or_atomic_fence_flag);
	yib_hwres_write(wqe, YIB_RC_WQE_SE_FLAG, se_flag);
	yib_hwres_write(wqe, YIB_RC_WQE_INLINE_FLAG, inline_flag);
	yib_hwres_write(wqe, YIB_RC_WQE_LENGTH_OR_SWAP_DATA_OR_ADD_DATA, length_data);
	yib_hwres_write(wqe, YIB_RC_WQE_INVKEY_OR_IMMDATA_OR_SWAP_DATA_OR_ADD_DATA, key_data);
	yib_hwres_write(wqe, YIB_RC_WQE_REMOTE_VA_LSB, remote_va_lsb);
	yib_hwres_write(wqe, YIB_RC_WQE_REMOTE_VA_MSB, remote_va_msb);
	yib_hwres_write(wqe, YIB_RC_WQE_REMOTE_KEY, remote_key);
	yib_hwres_write(wqe, YIB_RC_WQE_COM_DATA_LSB, com_data_lsb);
	yib_hwres_write(wqe, YIB_RC_WQE_COM_DATA_MSB, com_data_msb);

	if (send_wr->send_flags & IBV_SEND_INLINE) {
		yib_hwres_write(wqe, YIB_RC_WQE_WQE_SIZE, (length + 15 + sizeof(struct yib_hw_rc_wqe)) / 16);	
		for (i = 0; i < send_wr->num_sge; i++) {
			memcpy(dst_buf, (u8 *)send_wr->sg_list[i].addr, send_wr->sg_list[i].length);
			dst_buf += send_wr->sg_list[i].length;
		}
	} else {
		yib_hwres_write(wqe, YIB_RC_WQE_WQE_SIZE, 
				(send_wr->num_sge * sizeof(struct yib_hw_sge) + sizeof(struct yib_hw_rc_wqe)) / 16);
		for (i = 0; i < send_wr->num_sge; i++) {
			yib_hwres_write32(dst_buf, u64_lsb(send_wr->sg_list[i].addr));
			dst_buf += 4;
			yib_hwres_write32(dst_buf, u64_msb(send_wr->sg_list[i].addr));
			dst_buf += 4;
			yib_hwres_write32(dst_buf, send_wr->sg_list[i].lkey);
			dst_buf += 4;
			yib_hwres_write32(dst_buf, send_wr->sg_list[i].length);
			dst_buf += 4;
		}
	}
	return 0;
}


//wr2hwqe
static int r2100u_fill_ud_wqe(struct yib_context *ctx, struct yib_qp *qp, 
											const void *os_wq, 
											u8 *buf, u32 length, 
											u32 mask, enum yib_wqe_type opcode)
{
	struct yib_hw_ud_wqe *ud_wqe =(struct yib_hw_ud_wqe *)buf;
	struct ibv_send_wr *send_wr = (struct ibv_send_wr *)os_wq;
	struct yib_hw_av *hw_av = &ud_wqe->av;	
	struct yib_ah *ah = to_yib_ah(send_wr->wr.ud.ah);
	u8 *dst_buf = buf + sizeof(struct yib_hw_ud_wqe);
	u8 signal_comp = 0;
	u8 rd_or_atomic_fence_flag = 0;
	u8 se_flag = 0;
	u8 inline_flag = 0;
	u32 imm_data = 0;
	int i = 0;

	if ((send_wr->send_flags & IBV_SEND_SIGNALED) || qp->sqsig)
		signal_comp = 1;
			
	if (send_wr->send_flags & IBV_SEND_SOLICITED)
		se_flag = 1;
	
	if (send_wr->send_flags & IBV_SEND_INLINE) {
		inline_flag = 1;
	}

	if (opcode == YIB_WQE_SEND_WITH_IMM || opcode == YIB_WQE_RDMA_WRITE_WITH_IMM)
		imm_data = send_wr->imm_data;
	
	memset(ud_wqe, 0, sizeof(struct yib_hw_ud_wqe));
	yib_hwres_write(ud_wqe, YIB_UD_WQE_TYPE, opcode);
	yib_hwres_write(ud_wqe, YIB_UD_WQE_SIGNAL_COMP, signal_comp);
	yib_hwres_write(ud_wqe, YIB_UD_WQE_RD_OR_ATOMIC_FENCE_FLAG, rd_or_atomic_fence_flag);
	yib_hwres_write(ud_wqe, YIB_UD_WQE_SE_FLAG, se_flag);
	yib_hwres_write(ud_wqe, YIB_UD_WQE_INLINE_FLAG, inline_flag);
	yib_hwres_write(ud_wqe, YIB_UD_WQE_DEST_QPN, send_wr->wr.ud.remote_qpn);
	yib_hwres_write(ud_wqe, YIB_UD_WQE_LENGTH, length);
	yib_hwres_write(ud_wqe, YIB_UD_WQE_IMM_DATA, imm_data);
	yib_hwres_write(ud_wqe, YIB_UD_WQE_Q_KEY, send_wr->wr.ud.remote_qkey);

	r2100u_fill_av(hw_av, &ah->av);// yib_av2hw_av

	if (send_wr->send_flags & IBV_SEND_INLINE) {
		yib_hwres_write(ud_wqe, YIB_UD_WQE_SIZE, 
			(length + 15 + sizeof(struct yib_hw_ud_wqe)) / 16);
		for (i = 0; i < send_wr->num_sge; i++) {
			memcpy(dst_buf, (u8 *)send_wr->sg_list[i].addr, send_wr->sg_list[i].length);
			dst_buf += send_wr->sg_list[i].length;
		}
	} else {
		yib_hwres_write(ud_wqe, YIB_UD_WQE_SIZE, 
				(send_wr->num_sge * sizeof(struct yib_hw_sge) + sizeof(struct yib_hw_ud_wqe)) / 16);
		for (i = 0; i < send_wr->num_sge; i++) {
			yib_hwres_write32(dst_buf, u64_lsb(send_wr->sg_list[i].addr));
			dst_buf += 4;
			yib_hwres_write32(dst_buf, u64_msb(send_wr->sg_list[i].addr));
			dst_buf += 4;
			yib_hwres_write32(dst_buf, send_wr->sg_list[i].lkey);
			dst_buf += 4;
			yib_hwres_write32(dst_buf, send_wr->sg_list[i].length);
			dst_buf += 4;
		}
	}
	return 0;
}



int r2100u_fill_wqe(struct yib_context *ctx, struct yib_qp *qp, const void *os_wq, u8 *buf, u32 length, u32 mask)
{
	struct ibv_send_wr *wr = (struct ibv_send_wr *)os_wq;
	u32 opcode = ibv_wr_to_hw_wr_opcode(wr->opcode);
	int ret = 0;

	if (qp->vqp.qp.qp_type == IBV_QPT_UD) {
		ret = r2100u_fill_ud_wqe(ctx, qp, os_wq, buf, length, mask, opcode);
	} else if (opcode == YIB_WQE_MEM_BIND || opcode == YIB_WQE_FR_PMR || opcode == YIB_WQE_LOCAL_INV) {
//		ret = r2100_fill_fmr_bind(ctx, qp, os_wq, buf, length, mask, opcode);
	} else {
		ret = r2100u_fill_rc_wqe(ctx, qp, os_wq, buf, length, mask, opcode);
	}
	
	return ret;
}


#define DB_UPDATE

void r2100u_cq_ci_db_update(struct yib_context *ctx, struct yib_cq *cq, int poll_cnt)
{
	struct yib_queue_info *info = cq->cqinfo.info;
	u64 val = 0;
	u32 val_lsb;
	u64 val_msb;
	u32 cq_idx;
	u16 index, epoch, resize_toggle;
	u16 path, valid, debug_trace, type;

	struct r2100_hw_ctx  *hw_ctx = ctx->hw_priv;
	
	index = atomic_get(&info->ci) & 0xFFFF;
	epoch = info->ci_toggle & 0x01;
	resize_toggle = 0;
	cq_idx = cq->cq_id;
	path = 0;
	valid =0;
	debug_trace = 0;
	type = YIB_DB_CQ;

	val_lsb = index | (epoch << 16) | (resize_toggle << 17);
	val_msb = cq_idx | (path << 23) | (valid << 25) | (debug_trace << 26) | (type << 27);
	val = val_lsb | (val_msb << 32);
	
	yib_write_reg64(hw_ctx->reg_base, R2100_DB64_REG, val);
}

void r2100u_rq_pi_db_update(struct yib_context *ctx, struct yib_rq *rq, int io_cnt)
{
	struct yib_queue_info *info = rq->rq_info.info;
//	struct yib_qp *qp = (struct yib_qp *)rq->parent;
	u64 val = 0;
	u32 val_lsb;
	u64 val_msb;
	u32 index, rq_idx;
	u16 epoch, resize_toggle;
	u16 path, valid, debug_trace, type;
	
	struct r2100_hw_ctx  *hw_ctx = ctx->hw_priv;
	
	index = atomic_get(&info->pi) & 0xFFFF;
	epoch = info->pi_toggle & 0x01;
	resize_toggle = 0;
	rq_idx = rq->qid;
	path = 0;
	valid =0;
	debug_trace = 0;
	type = YIB_DB_RQ;

	val_lsb = index | (epoch << 16) | (resize_toggle << 17);
	val_msb = rq_idx | (path << 23) | (valid << 25) | (debug_trace << 26) | (type << 27);
	val = val_lsb | (val_msb << 32);
	yib_write_reg64(hw_ctx->reg_base, R2100_DB64_REG, val);
}

void r2100u_srq_pi_db_update(struct yib_context *ctx, struct yib_srq *srq, int pos)
{
	bool bdb = false;
	u64 val = 0;
	u32 val_lsb;
	u64 val_msb;
	u32 index , rq_idx;
	u16 epoch, resize_toggle;
	u16 path, valid, debug_trace, type;
	u16 srq_toggle;
	
	struct r2100_hw_ctx  *hw_ctx = ctx->hw_priv;

	bdb = yib_srq_db_helper(srq, pos);
	if (!bdb)
		return;
	
	index = queue_index_inc(pos, srq->rq.buf_v.q_depth);
	srq_toggle = srq->toggle? 1: 0;
	epoch = srq_toggle & 0x01;
	resize_toggle = 0;
	rq_idx = srq->rq.qid; // TODO
	path = 0;
	valid = 0;
	debug_trace = 0;
	type = YIB_DB_SRQ;

	val_lsb = index | (epoch << 16) | (resize_toggle << 17);
	val_msb = rq_idx | (path << 23) | (valid << 25) | (debug_trace << 26) | (type << 27);
	val = val_lsb | (val_msb << 32);
	yib_write_reg64(hw_ctx->reg_base, R2100_DB64_REG, val);
}

void r2100u_sq_pi_db_update(struct yib_context *ctx, struct yib_qp *qp, int io_cnt)
{
	struct yib_queue_info *info = qp->sq.sq_info.info;
	u64 val = 0;
	u32 val_lsb;
	u64 val_msb;
	u32 index,sq_idx;
	u16 epoch, resize_toggle;
	u16 path, valid, debug_trace, type;
	
	struct r2100_hw_ctx  *hw_ctx = ctx->hw_priv;
	
	index = atomic_get(&info->pi) & 0xFFFF;
	epoch = info->pi_toggle & 0x01;
	resize_toggle = 0;
	sq_idx = qp->qpn;
	path = 0;
	valid =0;
	debug_trace = 0;
	type = YIB_DB_SQ;

	val_lsb = index | (epoch << 16) | (resize_toggle << 17);
	val_msb = sq_idx | (path << 23) | (valid << 25) | (debug_trace << 26) | (type << 27);
	val = val_lsb | (val_msb << 32);
	
	yib_write_reg64(hw_ctx->reg_base, R2100_DB64_REG, val);
}


void r2100u_async_event(struct yib_context *context,
		      struct ibv_async_event *event)
{
	struct yib_qp *qp = NULL;
	switch (event->event_type) {
		case IBV_EVENT_QP_FATAL:
			qp = to_yib_qp(event->element.qp);
			yib_aeq_generate_sq_sw_cqe(context, qp);
			if (!qp->is_srq)
				yib_aeq_generate_rq_sw_cqe(context, qp);
			break;
		default:
			break;
	}
}
void r2100u_cq_notify(struct yib_cq *cq, u32 solicited)
{
	struct yib_queue_info *info = cq->cqinfo.info;
	struct yib_context *ctx = cq->ctx;
	struct r2100_hw_ctx  *hw_ctx = ctx->hw_priv;
	u64 val = 0;
	u32 val_lsb;
	u64 val_msb;
	u32 cq_idx;
	u16 index, epoch, resize_toggle;
	u16 path, valid, debug_trace, type;
	
	index = atomic_read(&info->ci) & 0xFFFF;
	epoch = info->ci_toggle & 0x01;
	resize_toggle = 0;
	cq_idx = cq->cq_id;
	path = 0;
	valid = 0;//unknown
	debug_trace = 0;
	if (solicited)
		type = YIB_DB_CQARMSE;
	else
		type = YIB_DB_CQARMALL;

	val_lsb = index | (epoch << 16) | (resize_toggle << 17);
	val_msb = cq_idx | (path << 23) | (valid << 25) | (debug_trace << 26) | (type << 27);
	val = val_lsb | (val_msb << 32);
	
	yib_write_reg64(hw_ctx->reg_base, R2100_DB64_REG, val);
}


int r2100u_hw_context_alloc(void  * context) {
	struct yib_context *ctx = (struct yib_context *)context;

	struct r2100_hw_ctx *hw_ctx = YIBmalloc(sizeof (struct r2100_hw_ctx));
	ctx->hw_priv = hw_ctx;
	
	return 0;
}	

int r2100u_hw_context_dealloc(void *context) {

	struct yib_context *ctx = (struct yib_context *)context;
	if(ctx->hw_priv) {
		YIBfree(ctx->hw_priv);
		ctx->hw_priv = NULL;
	}	

	return 0;	
}



//硬件相关的初始化函数
int r2100u_hw_cq_init(struct yib_context * ctx, struct yib_cq *cq ) {
	cq->hw_cq_priv = NULL;
	return 0;
}		
int r2100u_hw_qp_init(struct yib_context * ctx, struct yib_qp* qp){ return 0;}
int r2100u_hw_rq_init(struct yib_context * ctx, struct yib_rq* rq){ return 0;}
int r2100u_hw_mr_init(struct yib_context * ctx, struct yib_mr* mr){return 0;}
int r2100u_hw_mr_uninit(struct yib_context * ctx, struct yib_mr* mr){return 0;}
int r2100u_hw_cq_uninit(struct yib_context * ctx, struct yib_cq* cq){return 0;}
int r2100u_hw_qp_uninit(struct yib_context * ctx, struct yib_qp* qp){return 0;}	
int r2100u_hw_rq_uninit(struct yib_context * ctx, struct yib_rq* rq){ return 0; }



#if defined(__WR_ENABLE__)

static void r2100u_send_wr_start(struct yib_qp  *qp)
{
	

	pthread_spin_lock(&qp->sq.lock);

/* 	mqp->cur_post_rb = mqp->sq.cur_post;
	mqp->fm_cache_rb = mqp->fm_cache;
	mqp->err = 0;
	mqp->nreq = 0;
	mqp->inl_wqe = 0; */
}


//static inline void _common_wqe_init_op(struct ibv_qp_ex *ibqp, int ib_op,
//				       uint8_t mlx5_op)


//	mqp->cur_data = mlx5_get_send_wqe(mqp, 0);


int common_init_wr(ib_op , struct ibv_send_wr *wr){

		wr->opcode = ib_op;
		wr->send_flags = 0;
		return 0;
}

void _common_wqe_init_op(struct yib_qp *qp, int ib_op, uint8_t mlx5_op) {

	struct yib_sq *sq = &qp->sq;
	struct yib_context *ctx = qp->ctx;
	int err = 0;
	u8 *wqe = NULL;
	int pos = atomic_read(&sq->sq_info.info->pi);
	struct ibv_send_wr send_wr = {};


	common_init_wr(ib_op , &send_wr);

	if (ctx->hw_ops->check_sq_full(ctx , sq)) {
		sq->sq_info.info->err_count++;
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_IO ,"sq queue is full\n");
		err = -ENOMEM;
		goto exit;
	}

	wqe = yib_u_queue_get_pi_vaddr(sq->sq_info.info , sq->buf_v.buf , ctx->hw_caps.wqe_isize);
	//TODO 这里并不需要填写sge等信息,下层的fill_wqe可能会检查造成错误返回
	err = ctx->hw_ops->fill_wqe(ctx, qp, (const void*)send_wr, wqe, length, mask);
	if (unlikely(err)) {
		sq->sq_info.info->direct_cnt++;
		goto exit;
	}
	//TODO 这里cur_send_wqe的指向交由上层还是在这里实现,是当前的wqe还是下一个空闲的wqe的位置
	sq->cur_send_wqe = wqe;

	sq->sw_cmds[pos].wrid = wr->wr_id;
	sq->sw_cmds[pos].opcode = yib_wr_to_wc_opcode(wr->opcode);
	sq->sw_cmds[pos].at_err = 0;
	if ((wr->send_flags & IBV_SEND_SIGNALED))
		sq->sw_cmds[pos].bsignal = 1;
	sq->sw_cmds[pos].posted = 1;

	pos = yib_u_queue_advance_pi(sq->sq_info.info , 1 , sq->buf_v.q_depth);
	sq->sq_info.info->io_count++;

exit:
	return err;              


}

int _common_wqe_init(struct yib_qp* qp,enum ibv_wr_opcode ib_op){

	_common_wqe_init_op(struct yib_qp *qp, int ib_op, uint8_t mlx5_op)
}

static inline void r2100u_send_wr_send(struct yib_qp *qp,
				      enum ibv_wr_opcode ib_op)
{
	size_t transport_seg_sz = 0;

	_common_wqe_init(qp, ib_op);


	/* In UD/DC cur_data may overrun the SQ */
	if (unlikely(mqp->cur_data == mqp->sq.qend))
		qp->cur_send_wqe = yib_get_send_wqe(qp, 0);

	
}

#endif

struct yib_hw_ctx_ops r2100u_hw_ctx_ops = {

	.hw_context_alloc= r2100u_hw_context_alloc,
	// swtest_hw_context_alloc(){ return &yib_2100r_hw_ctx;}
	.hw_context_dealloc=  r2100u_hw_context_dealloc,

	.hw_global_map_reg= r2100u_hw_global_map_reg, //映射regi寄存器
	.hw_global_unmap_reg= r2100u_hw_global_unmap_reg,

	//硬件相关的初始化函数
	.hw_cq_init = r2100u_hw_cq_init,
	.hw_qp_init = r2100u_hw_qp_init,
	.hw_rq_init = r2100u_hw_rq_init,	
	.hw_mr_init = r2100u_hw_mr_init,

	.hw_cq_uninit = r2100u_hw_cq_uninit,
	.hw_qp_uninit = r2100u_hw_qp_uninit,	
	.hw_rq_uninit = r2100u_hw_rq_uninit,//srq,rq
	.hw_mr_uninit = r2100u_hw_mr_uninit,

	.fill_rqe = r2100u_fill_rqe,
	.fill_srqe = r2100u_fill_srqe,
	.fill_wqe = r2100u_fill_wqe,
	//qp_cache是否使用，由底层的情况决定，当底层硬件有能力在cq中返回qp地址信息时不使用， 否则底层硬件可返回qpn(这时需要使用qp_cache)
	.fill_cqe = r2100u_fill_cqe,
	.sw_fill_cqe = r2100u_sw_fill_cqe,//返回0表示处理成功，小于0表示不保序

	.check_sq_full = r2100u_check_sq_full,
	.check_rq_full = r2100u_check_rq_full,
	.check_srq_full = r2100u_check_srq_full,
	.check_cq_empty = r2100u_check_cq_empty,
	//bool (*is_resize_cq)(u8 *buf);

	.get_sq_item_size = r2100u_get_sq_item_size,//inline_len和max_sg为输入输出参数
	.get_rq_item_size = r2100u_get_rq_item_size,

	//db update
	.sq_pi_db_update = r2100u_sq_pi_db_update,
	.rq_pi_db_update = r2100u_rq_pi_db_update,
	.srq_pi_db_update = r2100u_srq_pi_db_update,
	.cq_ci_db_update = r2100u_cq_ci_db_update,
	.hw_notify_cq = r2100u_cq_notify,

	.hw_async_event = r2100u_async_event
};



#if 0



//new api
// static inline void r2100_wr_set_wr_id(struct yib_qp* qp)
// {
//     qp->sq.wr_id_buf[qp->curr_index] = qp->vqp.qp_ex.wr_id;
// }

//NOTE after this call, wqe should be update by "read-update-write"
static void r2100_wr_fill_wqe_comm(struct yib_qp *qp, int ibv_opc, u32 imm_data, u32 invalidate_rkey, 
                                        u32 r_key, u64 r_addr)
{
    u32 tmp = 0;
    u32 send_flags = qp->vqp.qp_ex.wr_flags;
    memset(qp->wqe, 0, qp->ctx->wqe_isize);
    if ((send_flags & IBV_SEND_SIGNALED) || (qp->sqsig))
            tmp |= BIT(18);
    
    if (send_flags & IBV_SEND_SOLICITED) tmp |= BIT(16);
    
    if (send_flags & IBV_SEND_FENCE) tmp |= BIT(19);

    if (send_flags & IBV_SEND_INLINE) tmp |= BIT(23);

    uint32_t index = q_get_val(qp->curr_index);
    qp->ctx->qp_array[qp->qpn]->sq_wr_id_buf[index] = qp->vqp.qp_ex.wr_id;
    tmp |= index & 0x7fff;
    xqe_writel(tmp, qp->wqe, 0);

    switch (ibv_opc) {
        case IBV_WR_RDMA_WRITE: 
            tmp = 0;
            break;
        case IBV_WR_RDMA_WRITE_WITH_IMM: 
            xqe_writel(htobe32(imm_data), qp->wqe, 6);
            tmp = 1;
            break;
        case IBV_WR_SEND:
            tmp = 2;
            break; 
        case IBV_WR_SEND_WITH_IMM: 
            xqe_writel(htobe32(imm_data), qp->wqe, 6);
            tmp = 3;
            break;
        case IBV_WR_SEND_WITH_INV: 
            xqe_writel(invalidate_rkey, qp->wqe, 6);
            tmp = 4;
            break;
        case IBV_WR_RDMA_READ: 
            tmp = 5;
            break;
        case IBV_WR_LOCAL_INV: 
            xqe_writel(invalidate_rkey, qp->wqe, 6);
            tmp = 0xa;
            break;
        default:
            qp->err = EINVAL;
            return;
    
        }

    xqe_writel(tmp, qp->wqe, 1);

    if (ibv_opc == IBV_WR_RDMA_READ ||
            ibv_opc == IBV_WR_RDMA_WRITE) {
        xqe_writel(r_key, qp->wqe, 2);
        xqe_writel(u64_lsb(r_addr), qp->wqe, 4);
        xqe_writel(u64_msb(r_addr), qp->wqe, 5);                
    }
}

void r2100_wr_send(struct yib_qp *qp)
{
    r2100_wr_fill_wqe_comm(qp, IBV_WR_SEND, 0, 0, 0, 0);
}

void r2100_wr_send_imm(struct yib_qp *qp, __be32 imm_data)
{
    r2100_wr_fill_wqe_comm(qp, IBV_WR_SEND_WITH_IMM, imm_data, 0, 0, 0);
}
void r2100_wr_send_inv(struct yib_qp *qp, uint32_t invalidate_rkey)
{
    r2100_wr_fill_wqe_comm(qp, IBV_WR_SEND_WITH_INV, 0, invalidate_rkey, 0, 0);
}
void r2100_wr_rdma_read(struct yib_qp *qp, uint32_t rkey, uint64_t remote_addr)
{
    r2100_wr_fill_wqe_comm(qp, IBV_WR_RDMA_READ, 0, 0, rkey, remote_addr);
}

void r2100_wr_rdma_write(struct yib_qp *qp, uint32_t rkey,uint64_t remote_addr)
{
    r2100_wr_fill_wqe_comm(qp, IBV_WR_RDMA_WRITE, 0, 0, rkey, remote_addr);
}

void r2100_wr_rdma_write_imm(struct yib_qp *qp, uint32_t rkey,
                uint64_t remote_addr, __be32 imm_data)
{
    r2100_wr_fill_wqe_comm(qp, IBV_WR_RDMA_WRITE_WITH_IMM, imm_data, 0, rkey, remote_addr);
}

void r2100_wr_set_inline_data(struct yib_qp *qp, void *addr,size_t length)
{

    u8 *pos = qp->wqe + 8*4;

    if(unlikely(length > qp->sq.max_inline)) {
        qp->err = EINVAL;
        return;
    }
    memcpy(pos, addr, length);

    xqe_writel(length, qp->wqe, 3);
}

void r2100_wr_set_inline_data_list(struct yib_qp *qp, size_t num_buf,
				const struct ibv_data_buf *buf_list)
{
    u32 length = 0;
    u8 *pos = qp->wqe + 8*4;
    for (size_t i = 0; i < num_buf; i++){
        if((length + buf_list->length > qp->sq.max_inline)) {
            qp->err = EINVAL;
            return;
        }
        memcpy(pos, buf_list->addr, buf_list->length);
        length += buf_list->length;
        buf_list++;
        pos += buf_list->length;
    }

    xqe_writel(length, qp->wqe, 3);    
}

void r2100_wr_set_sge(struct yib_qp* qp, uint32_t lkey, uint64_t addr, uint32_t length)
{
    u32 tmp = length;
    xqe_writel(tmp, qp->wqe, 3);
    
    tmp = xqe_readl(qp->wqe, 1);
    tmp |= (u32)0x01 << 8;
    xqe_writel(tmp, qp->wqe, 1);

    xqe_writel(lkey, qp->wqe, 8);
    xqe_writel(length, qp->wqe, 9);
    xqe_writel(u64_lsb(addr), qp->wqe, 10);
    xqe_writel(u64_msb(addr), qp->wqe, 11);
}

void r2100_wr_set_sge_list(struct yib_qp *qp, uint32_t num_sge, const struct ibv_sge *list) 
{
    u32 length = 0;
    u32 tmp;
    if(num_sge > 4) {
        qp->err = EINVAL;
        return;
    }

    for (uint32_t i = 0; i < num_sge; ++i){
        length += list[i].length;
    }

    tmp = length;
    xqe_writel(tmp, qp->wqe, 3);

    tmp = xqe_readl(qp->wqe, 1);
    tmp |= num_sge << 8;
    xqe_writel(tmp, qp->wqe, 1);

    for (uint32_t i = 0; i < num_sge; ++i){
        xqe_writel(list[i].lkey, qp->wqe, (8 + i*4));
        xqe_writel(list[i].length, qp->wqe, (8 + i*4 + 1));
        xqe_writel(u64_lsb(list[i].addr), qp->wqe, (8 + i*4 + 2));
        xqe_writel(u64_msb(list[i].addr), qp->wqe, (8 + i*4 + 3));
    }
    
}

#endif


