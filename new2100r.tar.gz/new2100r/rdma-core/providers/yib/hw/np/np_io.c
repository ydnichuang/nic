enum np_wqe_type {
    NP_WQE_SEND = 0,
    NP_WQE_SEND_WITH_IMM = 1,
    NP_WQE_SEND_WITH_INV = 2,
    NP_WQE_RDMA_WRITE = 4,
    NP_WQE_RDMA_WRITE_WITH_IMM = 5,
    NP_WQE_READ = 6,
};

#define NP_SQ_DB_BASE(cid, qid) (0x101000+(0x40000*cid)+ 4 * (int)(qid /2))
#define NP_RQ_DB_BASE(cid, qid) (0x241000+(0x40000*cid)+ 4 * (int)(qid /2))

static enum np_wqe_type ibv_wr_to_np_wr_opcode(enum ibv_wr_opcode opcode)
{
	switch (opcode) {
		case IBV_WR_SEND:			
			return NP_WQE_SEND;
		case IBV_WR_SEND_WITH_IMM:		
			return NP_WQE_SEND_WITH_IMM;
		case IBV_WR_SEND_WITH_INV:
			return NP_WQE_SEND_WITH_INV;
		case IBV_WR_RDMA_WRITE:		
			return NP_WQE_RDMA_WRITE;
		case IBV_WR_RDMA_WRITE_WITH_IMM:			
			return NP_WQE_RDMA_WRITE_WITH_IMM;
		case IBV_WR_RDMA_READ:			
			return NP_WQE_READ;
		default:
			return 0xff;
	}
}	

static struct yib_qp * np_get_neigh_qp(struct np_hw_ctx* np_ctx, struct qp_priv * priv)
{
	u32 qid = priv->qid;
	u32 cid = priv->clu_id;
	struct np_qpn_map_item * qmap = NULL;

	if (qid & 0x1) {
		qmap = &np_ctx->qid_cid_base[cid*YIB_MAX_QID_PER_CLU + qid - 1];
	} else {
		qmap = &np_ctx->qid_cid_base[cid*YIB_MAX_QID_PER_CLU + qid + 1];
	}
	return (struct yib_qp *)(((uintptr_t *)np_ctx->qp_pool)[qmap->qpn]);
}

static void np_sq_pi_db_update(struct yib_context * ctx, struct yib_qp *yqp, int io_cnt)
{
	struct np_hw_ctx *np_ctx = ctx->hw_priv;
	struct qp_priv * priv = yqp->hw_priv;
	struct yib_qp * yqpn = 	np_get_neigh_qp(np_ctx, priv);
	u32 base = 0;
	u16 pi;
	u16 pi_n = 0;
	u16 pi_toggle;
	u16 pi_togglen = 0;
	u32 val = 0;

	base = NP_SQ_DB_BASE(priv->clu_id, priv->qid);
	pi = atomic_get(&yqp->sq.sq_info.info->pi);
	pi_toggle = yqp->sq.sq_info.info->pi_toggle;
	if(yqpn != NULL){
		pi_n = atomic_get(&yqpn->sq.sq_info.info->pi);
		pi_togglen = yqpn->sq.sq_info.info->pi_toggle;
	}
	
	if (priv->qid & 0x1) {
		val = (pi << 16) | (pi_toggle << 31) | pi_n | (pi_togglen << 15);
	} else {
		val = (pi_n << 16) | (pi_togglen << 31) | pi | (pi_toggle << 15);
	}
	
	yib_write_reg64(np_ctx->reg_base, base, val);
	
	YIB_LOGm_INFO(ctx->dbg_fp, YIB_MSG_IO, "sq doorbell base:0x%08X val:0x%08X cid:%d qid:%d\n", base, val, priv->clu_id + 4, priv->qid);

}

static void np_rq_pi_db_update(struct yib_context * ctx, struct yib_rq *rq, int io_cnt)
{
	struct yib_qp * yqp = rq->parent;
	struct np_hw_ctx *np_ctx = ctx->hw_priv;
	struct qp_priv * priv = yqp->hw_priv;
	struct yib_qp * yqpn = 	np_get_neigh_qp(np_ctx, priv);
	u32 base;
	u16 pi;
	u16 pi_n = 0;
	u16 pi_toggle;
	u16 pi_togglen = 0;
	u32 val;

	base = NP_RQ_DB_BASE(priv->clu_id, priv->qid);
	pi = atomic_get(&yqp->rq.rq_info.info->pi);
	pi_toggle = yqp->rq.rq_info.info->pi_toggle;
	if(yqpn != NULL){
		pi_n = atomic_get(&yqpn->rq.rq_info.info->pi);
		pi_togglen = yqpn->rq.rq_info.info->pi_toggle;
	}
	
	if (priv->qid & 0x1) {
		val = (pi << 16) | (pi_toggle << 31) | pi_n | (pi_togglen << 15);
	} else {
		val = (pi_n << 16) | (pi_togglen << 31) | pi | (pi_toggle << 15);
	}
	
	yib_write_reg64(np_ctx->reg_base, base, val);

	YIB_LOGm_INFO(ctx->dbg_fp, YIB_MSG_IO, "rq doorbell base:0x%08X val:0x%08X cid:%d qid:%d\n", base, val, priv->clu_id + 9, priv->qid);
}

static void np_srq_pi_db_update(struct yib_context * ctx, struct yib_srq *srq, int pos){ return ;}

static void np_cq_ci_db_update(struct yib_context *ctx, struct yib_cq *cq, int poll_cnt) { return; }


static bool np_check_rq_full(struct yib_context *ctx, struct yib_rq *rq)
{ 
	struct yib_queue_info *info = rq->rq_info.info;
	u32 pi, ci, pi_toggle, ci_toggle;

	pi = atomic_get(&info->pi);
	ci = atomic_get(&info->ci);
	pi_toggle = info->pi_toggle;
	ci_toggle = info->ci_toggle;

	return (pi == ci) && (pi_toggle != ci_toggle);
}

static int np_fill_rqe(struct yib_context * ctx, struct yib_rq *rq, const void *os_wq, u8 *buf, u32 length)
{
	struct ibv_recv_wr *recv_wr = (struct ibv_recv_wr *)os_wq;
	u8 *dst_buf = buf + 4;
	int i;
	struct yib_queue_info *info = rq->rq_info.info;

	memset(buf, 0, 20);
	xqe_writel((128 << 8) | (atomic_get(&info->pi) & 0x7FFFFFFF), buf, 0);;
	
	for (i = 0; i < recv_wr->num_sge; i++) {
		xqe_writel(u64_lsb(recv_wr->sg_list[i].addr), buf, i*4+1);
		xqe_writel(u64_msb(recv_wr->sg_list[i].addr), buf, i*4+2);
		xqe_writel(recv_wr->sg_list[i].lkey, buf, i*4+3);
		xqe_writel(recv_wr->sg_list[i].length, buf, i*4+4);
	}

	return 0;
}

static int np_fill_srqe(struct yib_context * ctx, struct yib_rq *rq, const void *os_wq, u8 *buf, u32 length, int pos)
{
	return 0;
}

static int np_fill_rc_wqe(struct yib_context *ctx, struct yib_qp *qp, 
			const void *os_wq, 
			u8 *buf, u32 length, 
			u32 mask, enum np_wqe_type opcode)
{
	struct ibv_send_wr *send_wr = (struct ibv_send_wr *)os_wq;
	u8 wqe_size = 0;
	u8 signal_comp = 0;
	u8 fence = 0;
	u8 se_flag = 0;
	u8 inline_flag = 0;
	u32 imm_data = 0;
	int i = 0;
	u32 tmp0, tmp1, tmp2, tmp3, tmp4,tmp5, tmp6;
	u8* dst_buf = buf + 32;
	struct qp_priv  *hw_priv = qp->hw_priv;
	struct np_hw_ctx * hw_ctx = ctx->hw_priv;
	

	if ((send_wr->send_flags & IBV_SEND_SIGNALED) || qp->sqsig)
		signal_comp = 1;
			
	if (send_wr->send_flags & IBV_SEND_SOLICITED)
		se_flag = 1;
	
	if (send_wr->send_flags & IBV_SEND_INLINE) {
		inline_flag = 1;
	}

	if (send_wr->send_flags & IBV_SEND_FENCE) {
		fence = 1;
	}

	
	memset(buf, 0, 64);
	tmp0 = opcode | (signal_comp << 8) | (se_flag << 10) | (inline_flag << 12) | (fence << 11) |
		   (atomic_get(&qp->sq.sq_info.info->pi) & 0x7FFFFFFF) << 16;
	xqe_writel(tmp0, buf, 0);

	tmp1 = length;
	xqe_writel(tmp1, buf, 1);

	if (mask & WR_READ_OR_WRITE_MASK) {
		tmp5 = send_wr->wr.rdma.rkey;
		xqe_writel(tmp5, buf, 5);
		tmp2 = u64_lsb(send_wr->wr.rdma.remote_addr);
		xqe_writel(tmp2, buf, 2);
		tmp3 = u64_msb(send_wr->wr.rdma.remote_addr);
		xqe_writel(tmp3, buf, 3);
	}	

	if (opcode == NP_WQE_SEND_WITH_IMM || opcode == NP_WQE_RDMA_WRITE_WITH_IMM)
		tmp4 = send_wr->imm_data;
	else if (opcode == NP_WQE_SEND_WITH_INV)
		tmp4 = send_wr->invalidate_rkey;
	xqe_writel(tmp4, buf, 4);


	tmp6 = hw_ctx->qid_cid_base[hw_priv->clu_id*YIB_MAX_QID_PER_CLU + hw_priv->qid].av_index;
	xqe_writel(tmp6, buf, 6);

	if (send_wr->send_flags & IBV_SEND_INLINE) {	
		for (i = 0; i < send_wr->num_sge; i++) {
			memcpy(dst_buf, (u8 *)send_wr->sg_list[i].addr, send_wr->sg_list[i].length);
			dst_buf += send_wr->sg_list[i].length;
		}
	} else {
		for (i = 0; i < send_wr->num_sge; i++) {
			xqe_writel(u64_lsb(send_wr->sg_list[i].addr), buf, i*4+8);
			xqe_writel(u64_msb(send_wr->sg_list[i].addr), buf, i*4+9);
			xqe_writel(send_wr->sg_list[i].lkey, buf, i*4+10);
			xqe_writel(send_wr->sg_list[i].length, buf, i*4+11);
		}
	}
	return 0;
}


static int np_fill_ud_wqe(struct yib_context *ctx, struct yib_qp *qp, 
			const void *os_wq, u8 *buf, u32 length, 
			u32 mask, enum np_wqe_type opcode)
{
	struct ibv_send_wr *send_wr = (struct ibv_send_wr *)os_wq;
	struct yib_ah *ah = to_yib_ah(send_wr->wr.ud.ah);
	u8 signal_comp = 0;
	u8 se_flag = 0;
	u8 inline_flag = 0;
	u32 imm_data = 0;
	int i = 0;
	u32 tmp0, tmp1, tmp2, tmp4,tmp5, tmp6;
	u8* dst_buf = buf + 32;

	if ((send_wr->send_flags & IBV_SEND_SIGNALED) || qp->sqsig)
		signal_comp = 1;
			
	if (send_wr->send_flags & IBV_SEND_SOLICITED)
		se_flag = 1;
	
	if (send_wr->send_flags & IBV_SEND_INLINE) {
		inline_flag = 1;
	}

	if (opcode == NP_WQE_SEND_WITH_IMM || opcode == NP_WQE_RDMA_WRITE_WITH_IMM)
		imm_data = send_wr->imm_data;
	
	memset(buf, 0, 64);
	tmp0 = opcode | (signal_comp << 8) | (se_flag << 10) | (inline_flag << 12) |
		   (atomic_get(&qp->sq.sq_info.info->pi) & 0x7FFFFFFF) << 16;
	xqe_writel(tmp0, buf, 0);

	tmp1 = length;
	xqe_writel(tmp1, buf, 1);

	tmp2 = send_wr->wr.ud.remote_qpn;
	xqe_writel(tmp2, buf, 2);

	tmp4 = imm_data;
	xqe_writel(tmp4, buf, 4);

	tmp5 = send_wr->wr.ud.remote_qkey;
	xqe_writel(tmp5, buf, 5);

	tmp6 = ah->ah_num;
	xqe_writel(tmp6, buf, 6);

	if (send_wr->send_flags & IBV_SEND_INLINE) {	
		for (i = 0; i < send_wr->num_sge; i++) {
			memcpy(dst_buf, (u8 *)send_wr->sg_list[i].addr, send_wr->sg_list[i].length);
			dst_buf += send_wr->sg_list[i].length;
		}
	} else {
		for (i = 0; i < send_wr->num_sge; i++) {
			xqe_writel(u64_lsb(send_wr->sg_list[i].addr), buf, i*4+8);
			xqe_writel(u64_msb(send_wr->sg_list[i].addr), buf, i*4+9);
			xqe_writel(send_wr->sg_list[i].lkey, buf, i*4+10);
			xqe_writel(send_wr->sg_list[i].length, buf, i*4+11);
		}
	}
	return 0;
}


static int np_fill_wqe(struct yib_context * ctx, struct yib_qp *qp,
				const void *os_wq, u8 *buf, u32 length,  u32 mask)
{ 
		struct ibv_send_wr *wr = (struct ibv_send_wr *)os_wq;
		u32 opcode = ibv_wr_to_np_wr_opcode(wr->opcode);
		int ret = 0;
	
		if (qp->vqp.qp.qp_type == IBV_QPT_UD) {
			ret = np_fill_ud_wqe(ctx, qp, os_wq, buf, length, mask, opcode);
		} else if (opcode == 0xff) {
			YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_QP, "qp:%d wqe not support opcdoe:%d\n",
						qp->qpn, opcode);
		} else {
			ret = np_fill_rc_wqe(ctx, qp, os_wq, buf, length, mask, opcode);
		}
		
		return ret;

}

static bool np_check_sq_full(struct yib_context *ctx, struct yib_sq *sq)
{
	struct yib_queue_info *info = sq->sq_info.info;
	u32 pi, ci, pi_toggle, ci_toggle;

	pi = atomic_get(&info->pi);
	ci = atomic_get(&info->ci);
	pi_toggle = info->pi_toggle;
	ci_toggle = info->ci_toggle;

	return (pi == ci) && (pi_toggle != ci_toggle);

}

static void np_fill_cqe(struct yib_cq *cq,  struct ibv_wc *wc, u8 *cqe) 
{ 
	u32 qpn;
	u8 opcode;
	u8 cqe_type;
	u32 wqe_idx;
	struct yib_qp * qp;
	u32 tmp0;
	u32 tmp1;
	u32 tmp2; 
	u32 tmp3; 
	u32 tmp4;

	struct np_hw_ctx *np_ctx;
	struct yib_context      *ctx = cq->ctx;

	np_ctx = cq->ctx->hw_priv;

	tmp0 = xqe_readl(cqe, 0);
	tmp1 = xqe_readl(cqe, 1);
	tmp2 = xqe_readl(cqe, 2);
	tmp3 = xqe_readl(cqe, 3);
	tmp4 = xqe_readl(cqe, 4);

	qpn = tmp1 & 0xFFFF;
	wqe_idx = (tmp1 & 0xFFFF0000) >> 16;
	opcode = (tmp0 & 0x1F0000) >> 16;
	cqe_type = (tmp0 & (BIT(24) | BIT(25) | BIT(26))) >> 24;
		
	wc->wc_flags = 0;
	switch (opcode) {
		case NP_WQE_RDMA_WRITE:
			wc->opcode = IBV_WC_RDMA_WRITE;
			break;
		case NP_WQE_RDMA_WRITE_WITH_IMM:
			if (cqe_type == 0)
				wc->opcode = IBV_WC_RDMA_WRITE;
			else
				wc->opcode = IBV_WC_RECV_RDMA_WITH_IMM;
			wc->imm_data = be32toh(tmp3);
			wc->wc_flags |= IBV_WC_WITH_IMM;
			break;
		case NP_WQE_SEND:
			if (cqe_type == 0)
				wc->opcode = IBV_WC_SEND;
			else
				wc->opcode = IBV_WC_RECV;
			break;
		case NP_WQE_SEND_WITH_IMM:
			if (cqe_type == 0)
				wc->opcode = IBV_WC_SEND;
			else
				wc->opcode = IBV_WC_RECV;

			wc->imm_data = be32toh(tmp3);
			wc->wc_flags |= IBV_WC_WITH_IMM;
			break;
		case NP_WQE_SEND_WITH_INV:
			if (cqe_type == 0)
				wc->opcode = IBV_WC_SEND;
			else
				wc->opcode = IBV_WC_RECV;
			wc->invalidated_rkey = tmp3;
			wc->wc_flags |= IBV_WC_WITH_INV;
			break;
		case NP_WQE_READ:
			wc->opcode = IBV_WC_RDMA_READ;
			break;					  
		default:
			YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_CQ, "cq_id=%d not support opcdoe:%d\n",
						cq->cq_id, opcode);
			break;
		}


	qp = (struct yib_qp *)(((uintptr_t *)np_ctx->qp_pool)[qpn]);
	if (qp == NULL || qp->qpn >= cq->ctx->hw_caps.max_qp) {
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_QP, "cq_id=%d check empty find qp null\n", cq->cq_id);
		goto end;
	}

	wc->qp_num = qp->qpn;
	
	if (qp->vqp.qp.qp_type == IBV_QPT_UD) {
		wc->pkey_index = 0;
		wc->src_qp = tmp4 & 0xFFFF;
		wc->wc_flags |= IBV_WC_GRH; 
    	}

	wc->byte_len = tmp2;
	switch(cqe_type) {
		case YIB_CQE_SQ:
			wc->wr_id = qp->sq.sw_cmds[wqe_idx].wrid;
	    		yib_usq_swcmd_done(ctx, qp, wqe_idx, 0);
			break;
		case YIB_CQE_RQ:
			wc->wr_id = qp->rq.sw_cmds[wqe_idx].wrid;
	        	yib_urq_swcmd_done(ctx, &qp->rq, wqe_idx);
			break;
		case YIB_CQE_SRQ:
			wc->wr_id = qp->srq->rq.sw_cmds[wqe_idx].wrid;
			if (qp->srq == NULL) {
				YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_IO ,"srq is NULL");
				wc->status = IBV_WC_BAD_RESP_ERR;
				goto end;
			}
	    		yib_usrq_swcmd_done(ctx, qp->srq, wqe_idx);
			break;
		default:
			YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_IO ,"unknown cqe type ");
			break;
	}	

end:
	wc->status = tmp0 & 0xFF;
} 


static int np_sw_fill_cqe(struct yib_context * ctx, struct yib_cq *cq, void *os_cq)
{ 
	struct yib_sw_cqe *cqe = cq->cur_sw_cqe;
	struct ibv_wc *wc = os_cq;
	u32 cqe_type;
	u64 handle;
	u32 index;
	bool bsw = false;
	int ret;

	cqe_type = cqe->type;
	handle = cqe->handler;
	index = cqe->start_pos;
	wc->status = cqe->status;
	
	if (cqe_type == YIB_CQE_SQ) {
		struct yib_qp *qp = (struct yib_qp *)handle;
		ret = yib_usq_check_cqe(ctx, qp, index, true);
		if (ret)
			return ret;
		if(qp->sq.sw_posted[index] == 0) {
			wc->opcode = qp->sq.sw_cmds[index].opcode;
			wc->wr_id = qp->sq.sw_cmds[index].wrid;
		} else {
			wc->opcode = cqe->sw_opcode;
			wc->wr_id = cqe->sw_wr_id;
			bsw = true;
		}
		yib_usq_swcmd_done(ctx, qp, index, bsw);
	} else if (cqe_type == YIB_CQE_RQ) {
		struct yib_rq *rq = (struct yib_rq *)handle;
		wc->opcode = rq->sw_cmds[index].opcode;
		wc->wr_id = rq->sw_cmds[index].wrid;
		yib_urq_swcmd_done(ctx, rq, index);
	} else if (cqe_type == YIB_CQE_SRQ) {
		struct yib_srq *srq = (struct yib_srq *)handle;
		wc->opcode = srq->rq.sw_cmds[index].opcode;
		wc->wr_id = srq->rq.sw_cmds[index].wrid;
		yib_usrq_swcmd_done(ctx, srq, index);
	}
	
	return 0;
}


static bool np_check_srq_full(struct yib_context *ctx, struct yib_srq *srq, int *pos)
{
	int ret = 0;
	ret = yib_srq_find_useable_pos(srq);
	if (ret == -ENOMEM)
		return true;

	*pos = ret;
	return false;
}

static bool np_check_cq_empty(struct yib_context * ctx , struct yib_cq *cq, void *cqe)
{ 
	u32 toggle;
	u32 ci_toggle;
	u32 cqe_type;
	u32 index;
	u32 qpn;
	int ret = 0;
	struct yib_qp *qp = NULL;
	struct np_hw_ctx *np_ctx = ctx->hw_priv;
	
		
	ci_toggle = cq->cqinfo.info->ci_toggle;
	toggle = (xqe_readl(cqe, 0) & BIT(8)) ? 1:0;
	if (toggle == ci_toggle)
		return true;
	
	cqe_type = (xqe_readl(cqe, 0) & (BIT(24) | BIT(25) | BIT(26))) >> 24;
	qpn = xqe_readl(cqe, 1) & 0xFFFF;
	index = (xqe_readl(cqe, 1) & 0xFFFF0000) >> 16;
	qp = (struct yib_qp *)(((uintptr_t *)np_ctx->qp_pool)[qpn]);
	if (qp == NULL) {
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_QP, "cq_id=%d check empty find qp null\n", cq->cq_id);
		return true;
	}
		
	YIB_LOGm_INFO(ctx->dbg_fp, YIB_MSG_IO, "buf=%p cqe=%p pos=%ld ci=%d info=%p toggle=%d qpn=%d\n",
			cq->buf_v.buf, cqe, (cqe - cq->buf_v.buf) / ctx->hw_caps.cqe_isize, 
			atomic_get(&cq->cqinfo.info->ci), cq->cqinfo.info, toggle, qpn);
	
	if (cqe_type == YIB_CQE_SQ) {
		ret = yib_usq_check_cqe(ctx, qp, index, false);
	} else if (cqe_type == YIB_CQE_RQ) {
		ret = yib_urq_check_hwcqe(ctx, &qp->rq , index);
	}
		
	if(ret)
		return true;
	
	return false;
}
