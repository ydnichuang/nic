#include "basic.h"
#include "rdma/yib-abi.h"
#include "ib.h"
#include "io.h"
#include "swcmd.h"

#include "np.h"
#include "yib_log.h"
#include "np_io.c"

//typedef int (*init)(void *);
//struct yib_hw_ctx_ops //硬件无关的抽象操作,所i有硬件都对应此结构

//硬件相关实现

int np_hw_context_alloc(void  * context) {
	struct yib_context *yib_ctx = context;
	int i = 0;
	
	struct np_hw_ctx *hw_ctx = malloc(sizeof (struct np_hw_ctx));
	if(hw_ctx == NULL){
		YIB_LOG_ERR(yib_ctx->dbg_fp, "alloc np hw ctx failed\n");
		return -ENOMEM;
	}
	memset(hw_ctx, 0, sizeof(*hw_ctx));
	hw_ctx->qp_pool = malloc(yib_ctx->hw_caps.max_qp * sizeof(struct yib_qp *));
	if(hw_ctx->qp_pool == NULL){
		YIB_LOG_ERR(yib_ctx->dbg_fp, "alloc qp pool failed\n");
		free(hw_ctx);
		return -ENOMEM;
	}
	memset(hw_ctx->qp_pool, 0, (yib_ctx->hw_caps.max_qp * sizeof(struct yib_qp *)));
	yib_ctx->hw_priv = hw_ctx;
	
	return 0;// hw_ctx;
}	

int np_hw_context_dealloc(void *context) {

	struct yib_context *ctx = context;
	struct np_hw_ctx *np_ctx = NULL;
	
	if(ctx->hw_priv) {
		np_ctx = ctx->hw_priv;
		if(np_ctx->qp_pool){
			free(np_ctx->qp_pool);
			np_ctx->qp_pool = NULL;
		}
		np_ctx = NULL;
		free(ctx->hw_priv);
		ctx->hw_priv = NULL;
	}	

	return 0;	
};

int np_hw_global_map_reg(struct yib_context *ctx){
	
	int i, ret = 0 ;
	struct np_hw_ctx *hw_ctx = (struct np_hw_ctx *)ctx->hw_priv; 

	hw_ctx->reg_base = yib_private_mmap(YIB_MMAP_TYPE_REG, ctx->bar_offset , ctx->bar_len , ctx->cmd_fd);
	if (!hw_ctx->reg_base)
		return -ENOMEM;

	ret = yib_resource_mmap(ctx);
	if (ret) {
		yib_private_munmap(hw_ctx->reg_base, ctx->bar_len);
		return ret;
	}
	hw_ctx->qid_cid_base = yib_private_mmap(YIB_MMAP_TYPE_HW1, 0, (YIB_NP_CLU_NUM * YIB_MAX_QID_PER_CLU * sizeof(struct np_qpn_map_item)), ctx->cmd_fd);
	if (!hw_ctx->qid_cid_base) {
		yib_private_munmap(hw_ctx->reg_base, ctx->bar_len);
		yib_resource_unmmap(ctx);
		return -ENOMEM;
	}	

	return 0;
}//映射regi寄存器





int np_hw_global_unmap_reg(struct yib_context *ctx){ 

	struct np_hw_ctx *hw_ctx = (struct np_hw_ctx *)ctx->hw_priv; 
	if (hw_ctx->reg_base) {
		yib_private_munmap(hw_ctx->reg_base, ctx->bar_len);
		hw_ctx->reg_base = NULL;
	}

	yib_resource_unmmap(ctx);

	if(hw_ctx->qid_cid_base){
		yib_private_munmap(hw_ctx->qid_cid_base, (YIB_NP_CLU_NUM * YIB_MAX_QID_PER_CLU * sizeof(struct np_qpn_map_item)));
		hw_ctx->qid_cid_base = NULL;
	}
	return 0;
}	

//硬件相关的初始化函数
int np_hw_cq_init(struct yib_context * ctx, struct yib_cq *cq ) {

	cq->hw_cq_priv = NULL;
	return 0;
}		

static u32 index_to_qid(u32 index)
{
        return index%YIB_MAX_QID_PER_CLU;
}

static int for_each_qid_cid_map(struct np_hw_ctx *hw_ctx, u32 qpn, struct qp_priv *priv)
{
	int i = 0;
	
	for(i = 0; i < (YIB_NP_CLU_NUM * YIB_MAX_QID_PER_CLU); i++){
		if((qpn & 0xFFFF) == (hw_ctx->qid_cid_base + i)->qpn){
			priv->qid = index_to_qid(i);
			priv->clu_id = (hw_ctx->qid_cid_base + i)->cluster_id;
			return 0;
		}
	}
	return -EAGAIN;
}

int np_hw_qp_init(struct yib_context * ctx, struct yib_qp* qp){ 
	struct qp_priv *priv = NULL;
	struct np_hw_ctx *hw_ctx = (struct np_hw_ctx *)ctx->hw_priv;

	priv = malloc(sizeof(struct qp_priv));
	if(priv == NULL){
		YIB_LOG_ERR(ctx->dbg_fp, "alloc qp priv failed\n");
		return -ENOMEM;
	}
	memset(priv, 0, sizeof(struct qp_priv));
	if(for_each_qid_cid_map(hw_ctx, qp->qpn, priv)){
		YIB_LOG_ERR(ctx->dbg_fp, "search qid cid map failed\n");
		free(priv);
		return -EAGAIN;
	}
	qp->hw_priv = (void *)priv;
	((uintptr_t *)hw_ctx->qp_pool)[qp->qpn] = (uintptr_t)qp;
	return 0;
}

int np_hw_rq_init(struct yib_context * ctx, struct yib_rq* rq){ return 0;}

int np_hw_mr_init(struct yib_context * ctx, struct yib_mr* mr){

		return 0;
}

int np_hw_mr_uninit(struct yib_context * ctx, struct yib_mr* mr){

			return 0;
}


int np_hw_cq_uninit(struct yib_context * ctx, struct yib_cq* cq){return 0;}
int np_hw_qp_uninit(struct yib_context * ctx, struct yib_qp*  qp)
{
	struct np_hw_ctx *hw_ctx = (struct np_hw_ctx *)ctx->hw_priv;
	
	if(qp->hw_priv){
		free(qp->hw_priv);
		qp->hw_priv = NULL;
	}
	((uintptr_t *)hw_ctx->qp_pool)[qp->qpn]= (uintptr_t)NULL;
	return 0;
}	
int np_hw_rq_uninit(struct yib_context * ctx, struct yib_rq*  rq){ 
				return 0; //srq,rq 
}

//	int (*get_sq_item_size)(enum qp_type , int is_inline  , int sge_num);	
//	int (*get_rq_item_size)(enum qp_type , int is_inline  , int sge_num);//qp_type rc,ud 


static int np_get_sq_item_size(enum ibv_qp_type qp_type , int *inline_len, u32 *max_sg)
{
	*inline_len = 32;
	*max_sg = 1;
	return 64;
}



static int np_get_rq_item_size(u32 *max_sg)
{
	*max_sg = 1;
	return 32;
}


struct np_hw_ctx  swt_hw_ctx;


struct yib_hw_ctx_ops np_hw_ctx_ops = {
.hw_context_alloc = np_hw_context_alloc,
.hw_context_dealloc =  np_hw_context_dealloc,

.hw_global_map_reg= np_hw_global_map_reg, //映射regi寄存器
.hw_global_unmap_reg= np_hw_global_unmap_reg,

//硬件相关的初始化函数
.hw_cq_init = np_hw_cq_init,
.hw_qp_init = np_hw_qp_init,
.hw_rq_init = np_hw_rq_init,	
.hw_mr_init = np_hw_mr_init,

.hw_cq_uninit = np_hw_cq_uninit,
.hw_qp_uninit = np_hw_qp_uninit,	
.hw_rq_uninit = np_hw_rq_uninit,//srq,rq
.hw_mr_uninit = np_hw_mr_uninit,

//	int cqe_isize,
.fill_rqe = np_fill_rqe,
.fill_srqe = np_fill_srqe,
.fill_wqe = np_fill_wqe,
//qp_cache是否使用，由底层的情况决定，当底层硬件有能力在cq中返回qp地址信息时不使用， 否则底层硬件可返回qpn(这时需要使用qp_cache)
.fill_cqe = np_fill_cqe,
.sw_fill_cqe = np_sw_fill_cqe,//返回0表示处理成功，小于0表示不保序

.check_sq_full = np_check_sq_full,
.check_rq_full = np_check_rq_full,
.check_srq_full = np_check_srq_full,
.check_cq_empty = np_check_cq_empty,
//bool (*is_resize_cq)(u8 *buf);

.get_sq_item_size = np_get_sq_item_size,//inline_len和max_sg为输入输出参数
.get_rq_item_size = np_get_rq_item_size,

//db update
.sq_pi_db_update = np_sq_pi_db_update,
.rq_pi_db_update = np_rq_pi_db_update,
.srq_pi_db_update = np_srq_pi_db_update,
.cq_ci_db_update = np_cq_ci_db_update,

};





