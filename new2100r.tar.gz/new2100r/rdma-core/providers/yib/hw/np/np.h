#ifndef __YIB_NP_H__
#define __YIB_NP_H__

#include "hw/hw_comm.h"

#define YIB_NP_CLU_NUM          5
#define YIB_MAX_QID_PER_CLU     8

struct np_qpn_map_item{
   u32 qpn:16;
   u32 cluster_id:15;
   u32 valid:1;
   u32 av_index;
} ;

struct np_hw_ctx {
	char *reg_base;
	struct np_qpn_map_item *qid_cid_base;
	void  *qp_pool;
};

struct qp_priv{
	u16 qid;
	u16 clu_id;
};

struct yib_hw_ctx_ops np_hw_ctx_ops ;

int np_hw_global_map_reg(struct yib_context *ctx);
int np_hw_global_unmap_reg(struct yib_context *ctx);
int np_hw_context_alloc(void  * context);
int np_hw_context_dealloc(void *context);
int np_hw_cq_init(struct yib_context * ctx, struct yib_cq *cq );
int np_hw_qp_init(struct yib_context * ctx, struct yib_qp* qp);
int np_hw_rq_init(struct yib_context * ctx, struct yib_rq*  rq);
int np_hw_mr_init(struct yib_context * ctx, struct yib_mr* mr);
int np_hw_mr_uninit(struct yib_context * ctx, struct yib_mr* mr);
int np_hw_cq_uninit(struct yib_context * ctx, struct yib_cq* cq);
int np_hw_qp_uninit(struct yib_context * ctx, struct yib_qp*  qp);
int np_hw_rq_uninit(struct yib_context * ctx, struct yib_rq*  rq);

/*new api support*/
	void np_wr_send(struct yib_qp *qp);
	void np_wr_rdma_read(struct yib_qp *qp, uint32_t rkey, uint64_t remote_addr);
	void np_wr_rdma_write(struct yib_qp *qp, uint32_t rkey,uint64_t remote_addr);
	void np_wr_rdma_write_imm(struct yib_qp *qp, uint32_t rkey,uint64_t remote_addr, __be32 imm_data);
	void np_wr_send_imm(struct yib_qp *qp, __be32 imm_data);
	void np_wr_send_inv(struct yib_qp *qp, uint32_t invalidate_rkey);
	void np_wr_set_inline_data(struct yib_qp *qp, void *addr, size_t length);
	void np_wr_set_inline_data_list(struct yib_qp *qp, size_t num_buf,const struct ibv_data_buf *buf_list);
	void np_wr_set_sge(struct yib_qp* qp, uint32_t lkey, uint64_t addr, uint32_t length);
	void np_wr_set_sge_list(struct yib_qp *qp, uint32_t num_sge, const struct ibv_sge *list);

#endif
