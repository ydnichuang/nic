#ifndef __HW_COMM_H_
#define __HW_COMM_H_

#include "basic.h"
#include "hw/linux.h"
#include <util/util.h>

unsigned long find_first_zero_bit(const unsigned long *addr, unsigned long size);
unsigned long find_next_zero_bit(const unsigned long *addr, unsigned long size, unsigned long offset);


#define BITOPS



static inline void set_bit(int nr, unsigned long *addr)
{
	addr[nr / BITS_PER_LONG] |= 1UL << (nr % BITS_PER_LONG);
}

static inline void clear_bit(int nr, unsigned long *addr)
{
	addr[nr / BITS_PER_LONG] &= ~(1UL << (nr % BITS_PER_LONG));
}

static inline int test_bit(unsigned int nr, const unsigned long *addr)
{
	return ((1UL << (nr % BITS_PER_LONG)) &
		(((unsigned long *)addr)[nr / BITS_PER_LONG])) != 0;
}


#define __set_bit(nr, addr)	set_bit(nr, addr)
#define __clear_bit(nr, addr)	clear_bit(nr, addr)


static inline u32 net_addr2_le32(u8 * dat)
{
	return (dat[0] << 24 | dat[1] << 16 | dat[2] << 8 | dat[3]);
}


#endif
