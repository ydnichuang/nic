#ifndef _LINUX_H
#define _LINUX_H

//#include <linux/io.h>

#include <util/util.h>
#include "config.h"

#define RUNNING_ON_RDMA_CORE


#define yib_write64(reg_base, offset, val)  	        mmio_write64(reg_base+offset , val)
#define yib_read64(addr , offset)  			mmio_read64(addr+offset)

//TODO
#define yib_write_reg64(reg_base, offset, val) 	        yib_write64(reg_base, offset, val)
#define yib_read_reg64(reg_base, offset) 		yib_read64(reg_base, offset)


inline static void xqe_writel(u32 val,  void *buf, int index)
{
        mmio_write32(buf + index *4, val);
}

inline static u32 xqe_readl(void *buf, int index)
{
        return mmio_read32(buf + index*4);
}



#endif
