#ifndef __YIB_UTILS_H_
#define __YIB_UTILS_H_
#include <stddef.h>
#include <stdint.h>

#include <infiniband/verbs.h>


//for atomic api
#include <stdatomic.h>
//for List   api
#include <ccan/list.h>

//for yusur
#include "rdma/yib-abi.h"

#include "basic.h"

//#include "ib.h"

#define atomic_get(x)  atomic_load(x)
#define atomic_read(x)  atomic_load(x)
#define atomic_set(x , y)  atomic_store(x , y)

#define atomic_add( x , y )	 	atomic_fetch_add(x , y)
#define atomic_sub( x , y )		atomic_fetch_sub(x , y)


#define BITMAP_BITOPS
#define BITS_TO_LONGS(nr)	DIV_ROUND_UP(nr, BITS_PER_LONG)



// map qid buff, return NULL if map failed
void* yib_private_mmap(yib_mmap_t type,
                       uint32_t qid,
                       size_t len,
                       int fd);
void  yib_private_munmap(void* addr, size_t len);
int yib_resource_mmap(struct yib_context *ctx);
void yib_resource_unmmap(struct yib_context *ctx);
void* yib_mmap_addr(int fd, uint64_t pa, int size);
void  yib_ummap_vaddr(void* va, int size);


void yib_queue_calc_depth(int item_size, uint32_t *cnt);
int log2n(uint32_t x);
u32 numTo2n2(uint32_t  x);

#define min(a, b) ((a) < (b) ? (a) : (b))
#define max(a, b) ((a) > (b) ? (a) : (b))



#endif  // !__YIB_MAP_H_
