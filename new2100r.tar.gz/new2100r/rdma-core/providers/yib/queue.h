#ifndef YIB_QUEUE_H
#define YIB_QUEUE_H

#define BIT30_16 0x7FFF0000ul
#define q_get_val(x) ((x & BIT30_16)>>16)
#define q_get_carrier(x) ((x & BIT(15))>>15)
int yib_queue_count(u32 pt, u32 ct, u32 cnt);
void yib_advance_q_internal(u32 *pt_addr, int add, u32 cnt);


static inline void *yib_get_q_item(struct yib_roce_buf* buf, u32 isize, int idx)
{
        return buf->buf + isize * idx;
}


#if(0)
static u32 cq_count(struct yib_cq* cq)
{
	return yib_queue_count(mmio_read32(cq->pi), cq->ci, cq->cnt);
}
static u32 sq_count(struct yib_sq* sq)
{
	return (yib_queue_count(sq->pi, mmio_read32(sq->ci), sq->cnt));
}
static u32 rq_count(struct yib_rq* rq)
{
	return (yib_queue_count(rq->pi, mmio_read32(rq->ci), rq->cnt));
}
#endif
#endif