#ifndef YIB_QUEUE_H
#define YIB_QUEUE_H
#include <stdint.h>
#include <util/mmio.h>
#include <stdatomic.h>
#include "basic.h"
#include "yib_map.h"

struct yib_queue {
    void* buf;      // virtual, continuous mem buf
    int depth;      // num of element
    int item_size;  // sizeof element
    u32 mask;

    atomic_uint* sw_pi;
    atomic_uint* sw_ci;
};
YIB_COMPILE_ASSERT(sizeof(atomic_uint) == sizeof(u32));

int yib_queue_mmap(struct yib_queue* queue,
                   int depth,
                   int isize,
                   int fd,
                   u64 q_id,
                   u32 mask,
                   enum yib_mmap_type type);
int yib_queue_unmmap(struct yib_queue* queue);

static inline void yib_queue_reset(struct yib_queue* queue) {}

//Additional Thread Synchronization Mechanisms Needed
int yib_queue_get_count(struct yib_queue *queue);
bool yib_queue_is_full(struct yib_queue *queue);
bool yib_queue_is_empty(struct yib_queue *queue);
bool yib_queue_check_full_by_pi(struct yib_queue* queue, u32 pi);
void* yib_queue_prod_addr(struct yib_queue* queue);
void* yib_queue_cons_addr(struct yib_queue* queue);
void* yib_queue_get_addr_by_index(struct yib_queue *queue, u32 index);
static inline void yib_queue_prod_advance(struct yib_queue* queue,
                                      uint32_t advance) {
    atomic_fetch_add(queue->sw_pi, advance);
}

static inline void yib_queue_cons_advance(struct yib_queue* queue,
                                      uint32_t advance) {
    atomic_fetch_add(queue->sw_ci, advance);
}

static inline u32 yib_queue_pi(struct yib_queue* queue) {
    return atomic_load(queue->sw_pi) & queue->mask;
}

static inline u32 yib_queue_ci(struct yib_queue* queue) {
    return atomic_load(queue->sw_ci) & queue->mask;
}

#endif