

//#define YIB_CFG_MAP_GLOABL_QINFO




//对内核相关宏的重定义

#define __iomem
