#ifndef YIB_IOCTL_H
#define YIB_IOCTL_H

typedef struct 
{
        u8 mem_type; //0:mem 1:reg 2:ddr
        u8 dir;  //0:read 1:write
        u64 mem_addr; //mem is absolute value, reg is offset, ddr is offset
        u32 value;
}yib_debug_cmd;

typedef struct 
{
        u32 qpid;
        u8 bio; //io or admin for nvme
}yib_nvme_cmd;

struct yib_ext_in_cmd_hdr {
	u8         opcode; //1:debug  2:nvmne 3:todo
        union {
		yib_debug_cmd dbg_cmd;
		yib_nvme_cmd nvme_cmd;
	};
};

struct yib_ext_out_cmd_hdr {
	u32         status;
};

enum yusur_ib_objects {
	YIB_IB_OBJECT_EXT_OBJ = (1U << UVERBS_ID_NS_SHIFT),
};

enum yusur_ib_ext_methods {
	YIB_IB_METHOD_EXT_CMD = (1U << UVERBS_ID_NS_SHIFT),    
};

enum  yib_ib_ext_cmd_attrs {
	YIB_IB_ATTR_EXT_CMD_IN = (1U << UVERBS_ID_NS_SHIFT),
	YIB_IB_ATTR_EXT_CMD_OUT,
};

int yib_ib_ext_cmd(struct ibv_context *context, struct yib_ext_in_cmd_hdr *in,
				     struct yib_ext_out_cmd_hdr *out);

#endif

