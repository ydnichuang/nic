#ifndef __YIB_LOG_H

#define __YIB_LOG_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdint.h>

#include <fcntl.h>

#include "basic.h"
#include "yib.h"


enum color {
		RED = 1  	,   //write 
		GREEN = 2  		//read
};

struct msg {
	struct list_node node;
	pthread_mutex_t mutex;
	enum color clr;
	union {
		FILE *fp;
		int fd;
	};
	char info[0];
};

void yib_open_debug_file(struct yib_context *ctx);
void yib_close_debug_file(struct yib_context *ctx);
void yib_set_debug_mask(void);

void log_printf( int debug_level , int module ,const char* fmt , ... );

int log_thread_init(void);
void* log_thread_func(void *args);
void log_fprintf(int dbg_level, int module , FILE *fp ,  const char *fmt , ... );
int main_fifo(void);

int yib_thread_mutex_lock(pthread_mutex_t *mutex , void *msg);
int yib_thread_mutex_unlock(pthread_mutex_t *mutex , void *msg);
int yib_thread_mutex_init(pthread_mutex_t *mutex , const pthread_mutexattr_t *mutexattr , void *msg );

int yib_shm_init(void);

extern uint32_t yib_log_level;
extern uint32_t yib_log_module;

struct dbg_context {
	FILE *fp;
};

/* struct yib_context {

	union {
    	FILE *dbg_fp;
		int dbg_fd;
		struct dbg_context dbg_ctx;
	};	
}; */


enum YIB_DBG_MODULE {
	
	YIB_MSG_PD		= 0x04000,
	YIB_MSG_AH		= 0x08000,
	YIB_MSG_CQ		= 0x10000,
	YIB_MSG_RQ		= 0x20000,
	YIB_MSG_SQ		= 0x40000,
	YIB_MSG_QP		= (YIB_MSG_SQ | YIB_MSG_RQ),
	YIB_MSG_MR		= 0x80000,
	YIB_MSG_INIT	= 0x100000,
	YIB_MSG_SRQ		= 0x200000,
	YIB_MSG_IO		= 0x300000,
};

enum YIB_DBG_LEVEL {
	YIB_LEVEL_DBG	= 0x0,
	YIB_LEVEL_INFO		= 0x1,
	YIB_LEVEL_WARNING	= 0x2,
	YIB_LEVEL_ERR		= 0x3,
};
 
#define YIB_USER_DBG( fmt , ... )     \
do {										\
	printf("[%s:%d]" fmt "\n",				\
		__func__, __LINE__,				\
		##__VA_ARGS__);					\
} while(0)


#define YIB_USER_ERR( fmt , ... )     \
do {										\
	fprintf(stderr, "[%s:%d]" fmt "\n",				\
		__func__, __LINE__,				\
		##__VA_ARGS__);					\
} while(0)		



#define YIB_DBG_FILE "/tmp/yib_dbg_file"

#define YIB_USER_DBG_FP( fmt , ... )     		\
do {											\
	static int time = 0;						\
	FILE *dbg_file = NULL;								\
	if(0 == time){									\
		dbg_file = fopen(YIB_DBG_FILE,"aw");	\
		time=1;									\
	}											\
	fprintf(dbg_file,"[%s:%d]" fmt "\n",				\
		__func__, __LINE__,						\
		##__VA_ARGS__);							\
	fflush(dbg_file);							\
} while(0)	


#define YIB_USER_DBG_FP( fmt , ... )     		\
do {											\
	static int time = 0;						\
	FILE *dbg_file = NULL;								\
	if(0 == time){									\
		dbg_file = fopen(YIB_DBG_FILE,"aw");	\
		time=1;									\
	}											\
	fprintf(dbg_file,"[%s:%d]" fmt "\n",				\
		__func__, __LINE__,						\
		##__VA_ARGS__);							\
	fflush(dbg_file);							\
} while(0)	



#define YIB_LOG_ERR(fp, fmt, ...)					\
do {								\
	if(yib_log_level <= YIB_LEVEL_ERR)		\
	fprintf(fp, "[%s:%d]" fmt,				\
		__func__, __LINE__,				\
		##__VA_ARGS__);					\
	fflush(fp); \
} while (0)

#define YIB_LOG_WARNING(fd, fmt, ...)					\
do {								\
	if (yib_log_level <= YIB_LEVEL_WARNING)	{\
		fprintf(fd, "[%s:%d]" fmt,			\
		      __func__, __LINE__,			\
		      ##__VA_ARGS__);				\
		      fflush(fd); }				\
} while (0)

#define YIB_LOG_INFO(fd, fmt, ...)					\
do {								\
	if (yib_log_level <= YIB_LEVEL_INFO)	{		\
		fprintf(fd, "[%s:%d]" fmt,			\
		      __func__, __LINE__,			\
		      ##__VA_ARGS__); fflush(fd);		\
	}							\
} while (0)




#define YIB_LOG_IO(fd, fmt, ...)			\
do {								\
	if ((yib_log_level <= YIB_LEVEL_DBG) &&		\
		     (yib_log_module & (YIB_MSG_IO))) {		\
		fprintf(fd, "[%s:%d]" fmt,			\
		      __func__, __LINE__,			\
		      ##__VA_ARGS__);	fflush(fd); }		\
} while (0)




//LOG with Module info




#define YIB_LOGm_DBG(fp, module, fmt, ...)			\
do {								\
	if ((yib_log_level <= YIB_LEVEL_DBG) &&		\
		     (yib_log_module & (module))) {		\
		fprintf(fp, "[%s:%d]" fmt,			\
		      __func__, __LINE__,			\
		      ##__VA_ARGS__);	fflush(fp); }		\
} while (0)


#define YIB_LOGm_INFO(fd, module, fmt, ...)			\
do {								\
	if ((yib_log_level <= YIB_LEVEL_INFO) &&		\
		     (yib_log_module & (module))) {		\
		fprintf(fd, "[%s:%d]" fmt,			\
		      __func__, __LINE__,			\
		      ##__VA_ARGS__);	fflush(fd); }		\
} while (0)

#define YIB_LOGm_ERR(fd, module, fmt, ...)			\
do {								\
	if ((yib_log_level <= YIB_LEVEL_ERR) &&		\
		     (yib_log_module & (module))) {		\
		fprintf(fd, "[%s:%d]" fmt,			\
		      __func__, __LINE__,			\
		      ##__VA_ARGS__);	fflush(fd); }		\
} while (0)

#define YIB_LOGm_WARNING(fd, module, fmt, ...)			\
do {								\
	if ((yib_log_level <= YIB_LEVEL_WARNING) &&		\
		     (yib_log_module & (module))) {		\
		fprintf(fd, "[%s:%d]" fmt,			\
		      __func__, __LINE__,			\
		      ##__VA_ARGS__);	fflush(fd); }		\
} while (0)

#else 



#endif

