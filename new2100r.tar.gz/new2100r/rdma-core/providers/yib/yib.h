#ifndef YIB_H
#define YIB_H

#include <stdio.h>

//#include "yib_log.h"
#include <sys/types.h>

#include <infiniband/verbs.h>

#include "basic.h"

#include <infiniband/driver.h> // for struct verbs_device



#define RDMA_DRIVER_ID_YUSUR 1000
#define YIB_MAX_QP      4096

struct yib_context;
struct yib_mr;
struct yib_cq;
struct yib_rq;
struct yib_sq;
struct yib_qp;
struct yib_srq;
struct yib_hw_ctx_ops;

struct yib_device {
	struct verbs_device	ibv_dev;
	int			page_size;
	int			hw_version;
	int			hw_type;
};

struct hw_caps {
		u32     	cqe_isize;
		int 		max_qp;
		int 		max_qp_wr;
		int 		max_sge;
		int 		max_rqe;
		int 		max_cq;
		int 		max_cqe;

		int 		max_mr;
		int 		max_pd;
		int 		max_mw;
		int 		max_mcast_grp;
		int 		max_ah;
		int 		max_srq;
		int 		max_srq_wr;
		int 		max_srq_sge;
		uint64_t		max_mr_size;
		uint32_t		device_cap_flags;
		uint32_t		max_send_wr;
		uint32_t		max_recv_wr;
};

struct resource {
	char *cq_base;
	char *sq_base;
	char *rq_base;
};

// 1.添加context 的 DGB 功能
// 2.yib_hw_context 实现硬件相关功能, 如门铃
struct yib_context {
	struct verbs_context		ibv_ctx;
	uint32_t			cmd_fd;

	struct  	hw_caps hw_caps;
	struct 		yib_hw_ctx_ops *hw_ops; // ctx->ops = swtest_hw_ops;
	void   		*hw_priv; 				//hw_context; hw_priv = swtest_hw_ctx;

	uint64_t             ctx_id;
	union {
    	FILE *dbg_fp;
		int dbg_fd;
	};	

	uint32_t  	chip_type;					//根据chip_type选择hw_context_ops
	uint32_t     subchip_type;
	int     bar_offset;
	int     bar_len;
	int     quick_excep;
	int     sw_err_flush;

	bool 	nvme_off;

	struct resource resource;
};

//typedef int (*init)(void *);
struct yib_hw_ctx_ops //硬件无关的抽象操作,所i有硬件都对应此结构
{
	//硬件相关实现

	int (*hw_context_alloc)(void  *ptr) ;	
	// swtest_hw_context_alloc(){ return &yib_2100r_hw_ctx;}
	int (*hw_context_dealloc)(void *ptr);

	int (*hw_global_map_reg)(struct yib_context *ctx); //映射regi寄存器
	int (*hw_global_unmap_reg)(struct yib_context *ctx);

	//硬件相关的初始化函数
	int (*hw_cq_init)(struct yib_context * ctx, struct yib_cq* );
	int (*hw_qp_init)(struct yib_context * ctx, struct yib_qp* );
	int (*hw_rq_init)(struct yib_context * ctx, struct yib_rq* );	
	int (*hw_mr_init)(struct yib_context * ctx ,  struct yib_mr*);
	
	int (*hw_cq_uninit)(struct yib_context * ctx, struct yib_cq* );
	int (*hw_qp_uninit)(struct yib_context * ctx, struct yib_qp* );	
	int (*hw_rq_uninit)(struct yib_context * ctx, struct yib_rq* );//srq,rq	
	int (*hw_mr_uninit)(struct yib_context * ctx ,  struct yib_mr*);


	//同步内核态 queue_ops

	int cqe_isize;
	int (*fill_rqe)(struct yib_context * ctx, struct yib_rq *rq, const void *os_wq, u8 *buf, u32 length);
	int (*fill_srqe)(struct yib_context * ctx, struct yib_rq *rq, const void *os_wq, u8 *buf, u32 length, int pos);
	int (*fill_wqe)(struct yib_context * ctx, struct yib_qp *qp, const void *os_wq, u8 *buf, u32 length,  u32 mask);
	//qp_cache是否使用，由底层的情况决定，当底层硬件有能力在cq中返回qp地址信息时不使用， 否则底层硬件可返回qpn(这时需要使用qp_cache)
	void (*fill_cqe)(struct yib_cq *cq,  struct ibv_wc *wc, u8 *cqe);
	int	(*sw_fill_cqe)(struct yib_context * ctx, struct yib_cq *cq, void *os_cq);
	//返回0表示处理成功，小于0表示不保序

	bool (*check_sq_full)(struct yib_context *, struct yib_sq *sq);
	bool (*check_rq_full)(struct yib_context *, struct yib_rq *rq);
	bool (*check_srq_full)(struct yib_context *, struct yib_srq *srq, int *pos);
	bool (*check_cq_empty)(struct yib_context *, struct yib_cq *cq, void *cqe);
	//bool (*is_resize_cq)(u8 *buf);

	int (*get_sq_item_size)(enum ibv_qp_type qp_type , int *inline_size , uint32_t *max_sge);//inline_len和max_sg为输入输出参数
	int (*get_rq_item_size)(uint32_t *max_sge);
	
	//db update
	void (*sq_pi_db_update)(struct yib_context *, struct yib_qp *qp, int io_cnt);
	void (*rq_pi_db_update)(struct yib_context *, struct yib_rq *rq, int io_cnt);
	void (*srq_pi_db_update)(struct yib_context *, struct yib_srq *srq, int pos);
	void (*cq_ci_db_update)(struct yib_context *, struct yib_cq *cq, int poll_cnt);

	void (*hw_notify_cq)(struct yib_cq *cq, u32 solicited);
	void  (*hw_async_event)(struct yib_context *ctx , struct ibv_async_event *event);
	
	int (*set_capture)(struct yib_qp *qp , int enable);
	 
	/*new api support*/
	void (*wr_send)(struct yib_qp *qp);
	void (*wr_rdma_read)(struct yib_qp *qp, uint32_t rkey, uint64_t remote_addr);
	void (*wr_rdma_write)(struct yib_qp *qp, uint32_t rkey,uint64_t remote_addr);
	void (*wr_rdma_write_imm)(struct yib_qp *qp, uint32_t rkey,
				  uint64_t remote_addr, __be32 imm_data);
	void (*wr_send_imm)(struct yib_qp *qp, __be32 imm_data);
	void (*wr_send_inv)(struct yib_qp *qp, uint32_t invalidate_rkey);
	void (*wr_set_inline_data)(struct yib_qp *qp, void *addr,
				   size_t length);	
	void (*wr_set_inline_data_list)(struct yib_qp *qp, size_t num_buf,
				const struct ibv_data_buf *buf_list);

	void (*wr_set_sge)(struct yib_qp* qp, uint32_t lkey, uint64_t addr, uint32_t length);
	void (*wr_set_sge_list)(struct yib_qp *qp, uint32_t num_sge, const struct ibv_sge *list);
};



#endif /* YIB_h	*/
