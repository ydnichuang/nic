#ifndef __YIB_IO_H__
#define __YIB_IO_H__
#include <infiniband/verbs.h>
#include "ib.h"
#include "yib.h"

#define queue_index_dec(index, depth) ((index + depth - 1) % depth)
#define queue_index_inc(index, depth) ((index + depth + 1) % depth)

#define YIB_MAX_BATCH_SQ (16)

int yib_u_post_recv(struct ibv_qp* ibvqp,
                    struct ibv_recv_wr* wr,
                    struct ibv_recv_wr** bad_wr);

int yib_u_post_srq_recv(struct ibv_srq *ibvsrq,
			     struct ibv_recv_wr *recv_wr,
			     struct ibv_recv_wr **bad_recv_wr);

int yib_u_post_send(struct ibv_qp* ibvqp,
                    struct ibv_send_wr* wr,
                    struct ibv_send_wr** bad_wr);

int yib_u_poll_cq(struct ibv_cq* ibcq, int num_entries, struct ibv_wc* wc);


void* yib_u_queue_get_vaddr_by_index(char *Q_buffer, size_t item_size, int index);
void* yib_u_queue_get_pi_vaddr(struct yib_queue_info *info , char *Q_buffer ,size_t item_size);
void* yib_u_queue_get_ci_vaddr(struct yib_queue_info *info , char *Q_buffer ,size_t item_size);

int yib_u_queue_advance_pi(struct yib_queue_info *info, int diff , int depth );
int yib_u_queue_advance_ci(struct yib_queue_info *info, int diff , int depth );


int yib_u_srq_recv_wr(struct yib_context *ctx, struct yib_srq *srq, struct ibv_recv_wr *wr, struct ibv_recv_wr **bad_wr);





int yib_usq_check_cqe(struct yib_context *ctx, struct yib_qp *qp, int index, bool bsw);
int yib_urq_check_hwcqe(struct yib_context *ctx, struct yib_rq *rq, int index);

bool yib_srq_db_helper(struct yib_srq *srq, int pos);



#endif  // !__YIB_IO_H__
