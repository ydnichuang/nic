#include "basic.h"
#include <infiniband/driver.h>
#include <infiniband/verbs.h>
#include <util/symver.h>
#include <rdma/ib_user_ioctl_cmds.h>
#include "yib-abi.h"
#include "yib.h"
#include "ib.h"
#include "k2pro.h"
#include "hw/sw2100r.h"
#include "ioctl.h"


#include "hw/swtest.h"


static u64 g_uctx_id = 0;

//This function is used to enable qp capture: todo
LATEST_SYMVER_FUNC(yib_enable_capture, 1_0, "YIB_1.0",
		   int,
		   struct ibv_qp *ibqp,
		   bool enable)
{
	struct yib_context *context = to_yib_ctx(ibqp->context);
	struct yib_qp *qp = to_yib_qp(ibqp);
	return context->hw_ops->set_capture(qp, enable);
}

LATEST_SYMVER_FUNC(yib_nvme_mode_set, 1_0, "YIB_1.0",
		   int,
		   struct ibv_context *context,
		   bool enable)
{
	struct yib_context *yctx = to_yib_ctx(context);
	yctx->nvme_off = enable;
	return 0;
}

//#define PCI_VENDOR_ID_YUSUR 0x15ad
#define PCI_VENDOR_ID_YUSUR 0x10EE //0x100f
#define HCA(v, d) VERBS_PCI_MATCH(PCI_VENDOR_ID_##v, d, NULL)

static const struct verbs_match_ent hca_table[] = {
    VERBS_DRIVER_ID(RDMA_DRIVER_ID_YUSUR),
	HCA(YUSUR,0x9038),
	HCA(YUSUR,0x9238),
    {},
};

unsigned int numTo2n2(unsigned int x)
{
	int i = 1;
	int tmp = x;
	while (x >>= 1) {
		i <<= 1;
	}
	return (i < tmp)? i << 1: i;
}

int yib_roce_alloc_buf(struct yib_roce_buf *buf, unsigned int size,
		       int page_size)
{
	int ret;
	buf->length = align(size, page_size);
	buf->buf = mmap(NULL, buf->length, PROT_READ | PROT_WRITE,
			MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
	if (buf->buf == MAP_FAILED) {
		return errno;
	}

	ret = ibv_dontfork_range(buf->buf, buf->length);
	if (ret) {
		munmap(buf->buf, buf->length);
	}

	return ret;
}

void yib_roce_free_buf(struct yib_roce_buf *buf)
{
    if(buf->buf) {
        ibv_dofork_range(buf->buf, buf->length);
        munmap(buf->buf, buf->length);
	buf->buf = NULL;
    }
}

//the *cnt*isize should be 4*(2^n)KB
int yib_roce_alloc_dma_buf(struct yib_roce_buf *buf, int *cnt, int isize)
{
	int bytes = 0;
	int ret = 0;
	int n = 0;

	bytes = align(*cnt * isize, 4096ul);
        *cnt = bytes / isize;

	n = numTo2n2(bytes/4096);
	*cnt = (n * 4096) / isize;
	bytes = *cnt * isize;
	ret = yib_roce_alloc_buf(buf, bytes, 4096ul);
	if (ret) {
		buf->buf = NULL;
		ret = -ENOMEM;
		return ret;
	}

	return ret;
}

static inline void print_fw_ver(uint64_t fw_ver, char *str, size_t len)
{
	u32 date, ver;

	date = u64_msb((fw_ver & 0xFFFFFFFF00000000));
	ver = u64_lsb((fw_ver & 0xFFFFFFFF));

	snprintf(str, len, "%04X.%02X.%02X.%04X%02X%02X",
		(int)(ver&0xF000>>12),(int)(ver&0xF00>>8), (int)(ver&0xFF),
		(uint16_t)((date & 0xFFFF0000)>>16), (u8)((date&0x0000FF00)>> 8), (u8)(date & 0xFF));
}


int yib_u_query_device(struct ibv_context *context,
			   const struct ibv_query_device_ex_input *input,
			   struct ibv_device_attr_ex *attr, size_t attr_size)
{
	struct ib_uverbs_ex_query_device_resp resp = {};
	size_t resp_size = sizeof(resp);
	int ret;

	ret = ibv_cmd_query_device_any(context, input, attr, attr_size,
				       &resp, &resp_size);
	if (ret)
		return ret;

	print_fw_ver(resp.base.fw_ver, attr->orig_attr.fw_ver, sizeof(attr->orig_attr.fw_ver));
	return 0;
}

void *yib_mmap_addr(struct yib_context *context, u64 pa, int size)
{
	void *p = NULL;
	u64 pa_align = pa - (pa & (4096ul -1));
	u32 add = pa - pa_align;
	if (pa == 0) return NULL;

	p = mmap(NULL, size + add , PROT_READ | PROT_WRITE, MAP_SHARED, context->cmd_fd, pa_align);
	if (p == MAP_FAILED || p == NULL) {
		yib_err(context->dbg_fp, "map pa=%llx size=%d failed:%d\n", pa, size, errno);
		return NULL;
	}	
	return p + add;
}

void yib_ummap_vaddr(void *va, int size)
{
	u64 iva = (u64)va;
	if (va == NULL)
		return;
	u32 sub = iva - (iva & ~(4096-1));

	munmap(va - sub, size + sub);
}

static int yib_map_global_reg(struct yib_context *context,  int cmd_fd)
{

    context->hw_ops->hw_global_map_reg ;
#if(0)		
	if (context->rq_pi_db_pa != 0) {
		context->rq_pi_db = yib_mmap_addr(context, context->rq_pi_db_pa, 4);
		if (context->rq_pi_db == NULL) {
			yib_err(context->dbg_fp, "alloc rq pi db failed\n");
			return -ENOMEM;
		}
	}
	if (context->sq_pi_db_pa != 0) {
		context->sq_pi_db = yib_mmap_addr(context, context->sq_pi_db_pa, 4);
		if (context->sq_pi_db == NULL) {
			yib_err(context->dbg_fp, "alloc sq pi db failed\n");
			return -ENOMEM;
		}
	}
	if (context->cq_event_pa != 0) {
		context->cq_event = yib_mmap_addr(context, context->cq_event_pa, 4);
		if (context->cq_event == NULL) {
			yib_err(context->dbg_fp, "alloc cq event db failed\n");
			return -ENOMEM;
		}

	}
	if (context->cq_ci_db_pa != 0) {
		context->cq_ci_db = yib_mmap_addr(context, context->cq_ci_db_pa, 4);
		if (context->cq_ci_db == NULL) {
			yib_err(context->dbg_fp, "alloc cq ci db failed\n");
			return -ENOMEM;
		}
	}	
#endif	

	return 0;
}

static void yib_ucontext_free(struct yib_context *context)
{
	int i = 0;
	yib_close_debug_file(context->dbg_fp);

	/* if (context->cq_event)
		yib_ummap_vaddr(context->cq_event, 4);
	if (context->rq_pi_db)
		yib_ummap_vaddr(context->rq_pi_db, 4);
	if (context->sq_pi_db)
		yib_ummap_vaddr(context->sq_pi_db, 4);
	if (context->cq_ci_db)
		yib_ummap_vaddr(context->cq_ci_db, 4); */
/* 	context->rq_pi_db = NULL;
	context->sq_pi_db = NULL;
	context->cq_event = NULL;
	context->cq_ci_db = NULL; */
	if (context->qp_array != NULL) {
		for(i = 0; i < YIB_MAX_QP ; i++) {
			if (context->qp_array[i] != NULL) {
				yib_free_qp_wr_ids(context->qp_array[i], context);
				context->qp_array[i] = NULL;
			}
		}
		free(context->qp_array);
		context->qp_array = NULL;
	}	

	verbs_uninit_context(&context->ibv_ctx);
	free(context);
}

void yib_free_context(struct ibv_context *ibctx)
{
	struct yib_context *context = to_yib_ctx(ibctx);
	//struct yib_device *dev = to_yib_dev(ibctx->device);
	yib_ucontext_free(context);
}

static int yib_init_hw_func(struct yib_context *ctx) 
{
	
		printf("hca %d %d \n",hca_table->vendor,hca_table->device);
		switch (ctx->chip_type) {
		case YRDMA_TYPE_K2RRO:
			break;
		case YRDMA_TYPE_SWTEST:
			ctx->hw_ops = &swtest_hw_ctx_ops;
			ctx->hw_priv = ctx->hw_ops->hw_context_alloc(ctx);
#if(0)			
			ctx->fill_cqe = k2pro_fill_cqe;
			ctx->notify_cq = k2pro_notify_cq;
			ctx->cq_ci_db_update = k2pro_cq_ci_db_update;
			ctx->sq_pi_db_update = k2pro_sq_pi_db_update;
			ctx->rq_pi_db_update = k2pro_rq_pi_db_update;
			ctx->fill_wqe = k2pro_fill_wqe;
			ctx->fill_rqe = k2pro_fill_rqe;
			ctx->is_resize_cqe = k2pro_is_resize_cqe;
			ctx->set_capture = k2pro_set_capture;
			ctx->sw_wrid = true;
			ctx->wqe_12kb = true;
			//new api
			ctx->wr_send = k2pro_wr_send;
			ctx->wr_send_imm = k2pro_wr_send_imm;
			ctx->wr_send_inv = k2pro_wr_send_inv;
			ctx->wr_rdma_read = k2pro_wr_rdma_read;
			ctx->wr_rdma_write = k2pro_wr_rdma_write;
			ctx->wr_rdma_write_imm = k2pro_wr_rdma_write_imm;
			ctx->wr_set_inline_data = k2pro_wr_set_inline_data;
			ctx->wr_set_inline_data_list = k2pro_wr_set_inline_data_list;
			ctx->wr_set_sge = k2pro_wr_set_sge;
			ctx->wr_set_sge_list = k2pro_wr_set_sge_list;
#endif			
			break;
		case YRDMA_TYPE_SWIFT2100R:
#if(0)			
			ctx->fill_cqe = r2100_fill_cqe;
			ctx->notify_cq = r2100_notify_cq;
			ctx->cq_ci_db_update = r2100_cq_ci_db_update;
			ctx->sq_pi_db_update = r2100_sq_pi_db_update;
			ctx->rq_pi_db_update = r2100_rq_pi_db_update;
			ctx->fill_wqe = r2100_fill_wqe;
			ctx->fill_rqe = r2100_fill_rqe;
			ctx->is_resize_cqe = r2100_is_resize_cqe;
			ctx->set_capture = r2100_set_capture;
			ctx->sw_wrid = true;
			ctx->wqe_12kb = true;
			//new api
			ctx->wr_send = r2100_wr_send;
			ctx->wr_send_imm = r2100_wr_send_imm;
			ctx->wr_send_inv = r2100_wr_send_inv;
			ctx->wr_rdma_read = r2100_wr_rdma_read;
			ctx->wr_rdma_write = r2100_wr_rdma_write;
			ctx->wr_rdma_write_imm = r2100_wr_rdma_write_imm;
			ctx->wr_set_inline_data = r2100_wr_set_inline_data;
			ctx->wr_set_inline_data_list = r2100_wr_set_inline_data_list;
			ctx->wr_set_sge = r2100_wr_set_sge;
			ctx->wr_set_sge_list = r2100_wr_set_sge_list;
#endif			
			break;
		default:
			yib_err(ctx->dbg_fp, "unkonw yusur chip type:%d\n", ctx->chip_type);
			return -1;
	}

	if (ctx->sw_wrid) {
//		ctx->qp_array = malloc(8*最大qp数);
		ctx->qp_array = malloc(8*ctx->hw_caps.num_qps);
		if (ctx->qp_array == NULL)
			return -ENOMEM;
		memset(ctx->qp_array, 0, 8*YIB_MAX_QP);
	}
	ctx->nvme_off = false;
	return 0;
}


//
static struct verbs_context *yib_alloc_context(struct ibv_device *ibdev,
						int cmd_fd,
						void *private_data)
{
	struct yib_device *dev = to_yib_dev(ibdev);
	struct yib_alloc_ucontext_resp resp={};
	struct ibv_device_attr dev_attrs;
	struct yib_context *context; // yib_context大改
	struct ibv_get_context cmd;

	context = verbs_init_and_alloc_context(ibdev, cmd_fd, context, ibv_ctx,
					       RDMA_DRIVER_ID_YUSUR);
	if (!context) {
		return NULL;
	}

/* 	context->rq_pi_db = NULL;
	context->sq_pi_db = NULL;
	context->cq_event = NULL;
	context->cq_ci_db = NULL; */
	context->ctx_id = g_uctx_id++;
	context->qp_array = NULL;

	yib_open_debug_file(&context->dbg_fp, context->ctx_id);

	yib_dbg(context->dbg_fp, YIB_DBG_INIT, "alloc context\n");
	if (ibv_cmd_get_context(&context->ibv_ctx, &cmd, sizeof(cmd),
				&resp.ibv_resp, sizeof(resp))) {
		yib_err(context->dbg_fp,"get ctx cmd failed\n");
		goto error_free;
	}

//	context->rq_pi_db_pa = resp.rq_pi_db_pa;
//	context->sq_pi_db_pa = resp.sq_pi_db_pa;
//	context->cq_event_pa = resp.cq_event_pa;
//	context->cq_ci_db_pa = resp.cq_ci_db_pa;
	context->chip_type = resp.chip_type;
//	context->sf_index = resp.sf_index; 
	context->cmd_fd  = cmd_fd;
	context->hw_caps.max_sqe = resp.max_sqe;
	context->hw_caps.max_rqe = resp.max_rqe;
 	context->hw_caps.cqe_isize = resp.cqe_isize;
	context->hw_caps.rqe_isize = resp.rqe_isize;
	context->hw_caps.wqe_isize = resp.wqe_isize; 
	memcpy(context->mac, resp.mac, 6);

	if (yib_u_query_device(&context->ibv_ctx.context, NULL,
			       container_of(&dev_attrs,
					    struct ibv_device_attr_ex,
					    orig_attr), sizeof(dev_attrs)))
		goto error_free;

	dev->hw_version = dev_attrs.hw_ver;
	context->hw_caps.max_qp_wr = dev_attrs.max_qp_wr;
	context->hw_caps.max_sge = dev_attrs.max_sge;
	context->hw_caps.max_cqe = dev_attrs.max_cqe;
	context->hw_caps.num_qps = dev_attrs.max_qp;
	context->hw_caps.num_cqs = dev_attrs.max_cq;
	context->hw_caps.num_mr = dev_attrs.max_mr;

	if (yib_init_hw_func(context)) //绫诲埆涓嶆敮锟?
		goto error_free;

	if (yib_map_global_reg(context, context->cmd_fd)) {
		goto error_free;
	}

	yib_dbg(context->dbg_fp, YIB_DBG_INIT, "alloc context OK\n");
	verbs_set_ops(&context->ibv_ctx, &yib_uops);
	return &context->ibv_ctx;

error_free:
	yib_ucontext_free(context);
	return NULL;
}


static void yib_uninit_device(struct verbs_device *verbs_device)
{
	struct yib_device *dev = to_yib_dev(&verbs_device->device);

	if (dev)
		free(dev);
}

static struct verbs_device *yib_device_alloc(struct verbs_sysfs_dev *sysfs_dev)
//不需要修改
{
	struct yib_device *dev;

	dev = calloc(1, sizeof(struct yib_device));
	if (!dev)
		return NULL;

	dev->page_size = sysconf(_SC_PAGESIZE);

	return &dev->ibv_dev;
}

int yib_ib_ext_cmd(struct ibv_context *context, struct yib_ext_in_cmd_hdr *in,
				   struct yib_ext_out_cmd_hdr *out)
{
	DECLARE_COMMAND_BUFFER(cmd,
			       YIB_IB_OBJECT_EXT_OBJ,
			       YIB_IB_METHOD_EXT_CMD,
			       2);

	fill_attr_in(cmd, YIB_IB_ATTR_EXT_CMD_IN, in, sizeof(*in));
	fill_attr_out(cmd, YIB_IB_ATTR_EXT_CMD_OUT, out, sizeof(*out));

	return execute_ioctl(context, cmd);
}

static const struct verbs_device_ops yib_dev_ops = {
	.name = "yusur",
	.match_min_abi_version = 0,
	.match_max_abi_version = 6,
	.match_table = hca_table, //暂定,不确定id
	.alloc_device = yib_device_alloc,
	.uninit_device = yib_uninit_device,
	.alloc_context = yib_alloc_context,
};
PROVIDER_DRIVER(yib, yib_dev_ops);

u32 yib_get_qpc_index(struct yib_context *ctx, u32 entry_index)
{
//	int each = 0;

//	each = ctx->num_qps;
//	return entry_index + each * ctx->sf_index;
	return entry_index;
}

u32 yib_get_qp_entry_idx(struct yib_context *ctx, u32 qpc_index)
{
	int each = 0;

//	each = ctx->hw_caps.num_qps;
//	return qpc_index - each *  ctx->sf_index;
	
	return qpc_index;
}

u32 yib_get_cqc_index(struct yib_context *ctx, u32 entry_index)
{
	int each = 0;

//	each = ctx->hw_caps.num_cqs;
//	return entry_index + each * ctx->sf_index;	
	return entry_index;

}

u32 yib_get_cq_entry_idx(struct yib_context *ctx, u32 cqc_index)
{
	int each = 0;

//	each = ctx->hw_caps.num_cqs;
//	return (cqc_index - each * ctx->sf_index);	
	
	return (cqc_index);	
}
