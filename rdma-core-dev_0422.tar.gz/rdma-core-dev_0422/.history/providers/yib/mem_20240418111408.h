#ifndef _YIB_MEM_H
#define _YIB_MEM_H


#define YIBfree(void *ptr) 						\
	do{ 										\
		if(ptr) { free(ptr) ; ptr = NULL ; } 	\
	}while(0)

#define YIBmalloc(size) 						\
do { 											\
		malloc(size);							\
}while(0);



#endif


