#ifndef YIB_IB_H
#define YIB_IB_H

enum yib_wr_mask {
	WR_INLINE_MASK			= BIT(0),
	WR_ATOMIC_MASK			= BIT(1),
	WR_SEND_MASK			= BIT(2),
	WR_READ_MASK			= BIT(3),
	WR_WRITE_MASK			= BIT(4),
	WR_LOCAL_MASK			= BIT(5),
	WR_REG_MASK			= BIT(6),

	WR_READ_OR_WRITE_MASK		= WR_READ_MASK | WR_WRITE_MASK,
	WR_READ_WRITE_OR_SEND_MASK	= WR_READ_OR_WRITE_MASK | WR_SEND_MASK,
	WR_WRITE_OR_SEND_MASK		= WR_WRITE_MASK | WR_SEND_MASK,
	WR_ATOMIC_OR_READ_MASK		= WR_ATOMIC_MASK | WR_READ_MASK,
};

typedef uint8_t  u8;
typedef uint16_t u16;
typedef uint32_t u32;

struct yib_wr_opcode_info {
	const char			*name;
	enum yib_wr_mask	mask[IBV_QPT_DRIVER+1];
};

extern const struct verbs_context_ops yib_uops;
struct yib_pd {
	struct ibv_pd		ibv_pd;
	unsigned int		pdn;
};

struct yib_ah {
	struct ibv_ah		ibv_ah;
	struct yib_av		av;
	int			ah_num;

};

struct yib_mr {
	struct verbs_mr vmr;
	void *hw_mr_priv;
};

typedef int os_atomic ;
struct yib_queue_info//sq rc,cq
{
	os_atomic  pi;
	os_atomic  ci;
	u64        io_count; 	//完成或提交次数
	u64        err_count; 	//完成错误个数, 【rq,sq 为队列满的次数】 cq为wc->err的个数
	u32        direct_cnt; 	//[sq,rq]为直接返回失败的次数， cq为软件完成次数
	u16        pi_toggle; 	//翻转位
	u16        ci_toggle;
};

struct yib_sw_cmd
{
	u8                 bsignal:1; 
	u8                 at_err:1;  
	enum ibv_wc_opcode opcode;    
	u8                 posted;    
	u64                wrid;
};

struct qp_info {
	struct yib_queue_info *info;
};

struct cq_info {
	struct yib_queue_info *info;
};
struct rq_info {
	struct yib_queue_info *info;
};

struct sq_info {
	struct yib_queue_info *info;
};


struct yib_cq {
		struct ibv_cq			ibv_cq;
		struct yib_context      *ctx;
		struct yib_roce_buf		buf_v;
	
		u32                     cqe; 			// cqe 数目
		u32                     cq_id;

		//属于设备层相关层实现
		struct cq_info 			cqinfo;		//rq ,sq 目前		
		void 					*hw_cq_priv;	
		//数据同步
		pthread_spinlock_t		lock;
};



struct y2100r_hw_cq {
	int q;
};

struct swtest_hw_cq {
	int q;

};
struct swtest_hw_qp {
	int q;

};
struct swtest_hw_rq {
	int q;

};
struct swtest_hw_sq {
	int q;

};





struct yib_sq   
{
	pthread_spinlock_t	lock;	
    struct yib_roce_buf buf_v;
    int cnt;
	struct yib_context      *ctx;
	struct yib_sw_cmd 	*sw_cmd; // malloc 根据队列深度
	u32 qid;
//	u32 swpi;
	u32 max_inline;
	u64  stat_sq_cnt;
	struct sq_info *sq_info; 	
	void  *hw_priv;
};

struct yib_rq   
{
	pthread_spinlock_t	lock;
    bool   is_srq;
	struct rq_info     *rq_info; //
	struct yib_sw_cmd  *sw_cmd; // malloc 根据队列深度
	struct yib_context *ctx;
	u32 qid;
    int cnt;
    struct yib_roce_buf buf_v;   
	struct yib_roce_buf buf_nvme;   
	u64    stat_rq_cnt;
    void  *parent; //is_srq parent yib_srq, other qp;
	bool   nvme_off;
	void  *hw_priv;
};

struct yib_srq
{
	 struct ibv_srq		ibv_srq;
	 u32 srq_limit;
	 struct yib_rq rq;
};


struct yib_qp {
	struct verbs_qp		vqp;
	enum ibv_qp_state	qp_state;	
	bool is_srq;
	union {
	   struct yib_rq  rq;
	   struct yib_srq *srq;
	};
 	struct yib_context      *ctx;
 	struct yib_sq		sq;
	unsigned int		qpn;
    int	                sqsig;
	int				port_num;
	void                    *capture;//for capture ctrl, if non, not support this func
	void  *hw_priv;
	//new API support
	u32	curr_index;
	u32 pending_wqe_num;
	u8* wqe; 
	int err;
};

int yib_u_query_device(struct ibv_context *context,
			   const struct ibv_query_device_ex_input *input,
			   struct ibv_device_attr_ex *attr, size_t attr_size);
void yib_dealloc_context(struct ibv_context *ibctx);
int yib_roce_alloc_dma_buf(struct yib_roce_buf *buf, int *cnt, int isize);
void *yib_mmap_addr(struct yib_context *context, u64 pa, int size);
void yib_ummap_vaddr(void *va, int size);
void yib_free_qp_wr_ids(struct yib_wr_id_buf *wr_id_buf, struct yib_context *context);

static inline struct yib_pd *to_yib_pd(struct ibv_pd *ibv_pd)
{
	return container_of(ibv_pd, struct yib_pd, ibv_pd);
}

static inline struct yib_ah *to_yib_ah(struct ibv_ah *ibv_ah)
{
	return container_of(ibv_ah, struct yib_ah, ibv_ah);
}

static inline struct yib_mr *to_yib_mr(struct ibv_mr *ibv_mr)
{
	struct verbs_mr *vmr = container_of(ibv_mr, struct verbs_mr, ibv_mr);
	return container_of(vmr, struct yib_mr, vmr);
}

static inline struct yib_cq *to_yib_cq(struct ibv_cq *ibv_cq)
{
	return container_of(ibv_cq, struct yib_cq, ibv_cq);
}

static inline struct yib_qp *to_yib_qp(struct ibv_qp *ibv_qp)
{
	return container_of(ibv_qp, struct yib_qp, vqp.qp);
}
#define os_align_any_up(x, a)   (((x) + (a) - 1) / (a) * (a))

u32 yib_get_qp_entry_idx(struct yib_context *ctx, u32 qpc_index);
u32 yib_get_cqc_index(struct yib_context *ctx, u32 entry_index);
u32 yib_get_cq_entry_idx(struct yib_context *ctx, u32 cqc_index);
u32 yib_get_qpc_index(struct yib_context *ctx, u32 entry_index);
#endif

