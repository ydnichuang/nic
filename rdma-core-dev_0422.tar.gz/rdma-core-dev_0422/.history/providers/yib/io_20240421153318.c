#define YIB_MAX_BATCH_SQ (16)

static int yib_u_poll_cq(struct ibv_cq *ibcq, int num_entries, struct ibv_wc *wc);
static int yib_u_post_send(struct ibv_qp *ibvqp, struct ibv_send_wr *wr, struct ibv_send_wr **bad_wr);
static int yib_u_post_recv(struct ibv_qp *ibvqp,struct ibv_recv_wr *wr, struct ibv_recv_wr **bad_wr);

static const struct yib_wr_opcode_info yib_wr_opcode_info[] = { //IBV_WR_REG_MR + 1
	[IBV_WR_RDMA_WRITE]				= {
		.name	= "IBV_WR_RDMA_WRITE",
		.mask	= {
			[IBV_QPT_RC]	= WR_INLINE_MASK | WR_WRITE_MASK,
		},
	},
	[IBV_WR_RDMA_WRITE_WITH_IMM]			= {
		.name	= "IBV_WR_RDMA_WRITE_WITH_IMM",
		.mask	= {
			[IBV_QPT_RC]	= WR_INLINE_MASK | WR_WRITE_MASK,
		},
	},
	[IBV_WR_SEND]					= {
		.name	= "IBV_WR_SEND",
		.mask	= {
			[IBV_QPT_RC]	= WR_INLINE_MASK | WR_SEND_MASK,
			[IBV_QPT_UD]	= WR_INLINE_MASK | WR_SEND_MASK,
		},
	},
	[IBV_WR_SEND_WITH_IMM]				= {
		.name	= "IBV_WR_SEND_WITH_IMM",
		.mask	= {
			[IBV_QPT_RC]	= WR_INLINE_MASK | WR_SEND_MASK,
			[IBV_QPT_UD]	= WR_INLINE_MASK | WR_SEND_MASK,
		},
	},
	[IBV_WR_RDMA_READ]				= {
		.name	= "IBV_WR_RDMA_READ",
		.mask	= {
			[IBV_QPT_RC]	= WR_READ_MASK,
		},
	},
	[IBV_WR_ATOMIC_CMP_AND_SWP]			= {
		.name	= "IBV_WR_ATOMIC_CMP_AND_SWP",
		.mask	= {
			[IBV_QPT_RC]	= WR_ATOMIC_MASK,
		},
	},
	[IBV_WR_ATOMIC_FETCH_AND_ADD]			= {
		.name	= "IBV_WR_ATOMIC_FETCH_AND_ADD",
		.mask	= {
			[IBV_QPT_RC]	= WR_ATOMIC_MASK,
		},
	},
	[IBV_WR_SEND_WITH_INV]				= {
		.name	= "IBV_WR_SEND_WITH_INV",
		.mask	= {
			[IBV_QPT_RC]	= WR_INLINE_MASK | WR_SEND_MASK,
			[IBV_QPT_UD]	= WR_INLINE_MASK | WR_SEND_MASK,
		},
	},
	[IBV_WR_LOCAL_INV]				= {
		.name	= "IBV_WR_LOCAL_INV",
		.mask	= {
			[IBV_QPT_RC]	= WR_REG_MASK ,
		},
	},
};

static int yib_u_poll_cq(struct ibv_cq *ibcq, int num_entries, struct ibv_wc *wc)
{

	return 0;
#if  0
        struct yib_context *context = to_yib_ctx(ibcq->context);
	struct yib_cq *cq = to_yib_cq(ibcq); 
        int i;
        unsigned char *cqe;
	u32 isize = context->cqe_isize;

      	pthread_spin_lock(&cq->lock);
	for (i = 0; i < num_entries; i++) {
		cqe = cq_head(cq, isize);
		if (unlikely(!cqe))
			break;

		udma_from_device_barrier();
		context->fill_cqe(cq,  wc, cqe);
		cq_advance_ci(cq);
                if (unlikely(wc->status != 0))
                        cq->stat_cq_err_cnt++;
                else
                	cq->stat_cq_cnt++;
		wc++;
                mmio_wc_start();
		context->cq_ci_db_update(cq);
                mmio_flush_writes();

	}
	pthread_spin_unlock(&cq->lock);  
        return i;          
#endif		
		
}

static int validate_send_wr(struct yib_qp *yqp, struct ibv_send_wr *ibwr,
			    u32 mask, u32 length)
{
	int num_sge = ibwr->num_sge;
	struct yib_context *ctx = to_yib_ctx(yqp->vqp.qp.context);

	if (unlikely(num_sge > yqp->ctx->max_sge)) {
		yib_err(ctx->dbg_fp, "sge:%d is bigger than max_sge:%d\n", num_sge, yqp->ctx->max_sge);
		goto err1;
	}

	if (unlikely(mask & WR_ATOMIC_MASK)) {
		if (length < 8) {
			yib_err(ctx->dbg_fp,"atomic length need to be 8 byte\n");
			goto err1;
		}

		if (ibwr->wr.rdma.remote_addr & 0x7) {
			yib_err(ctx->dbg_fp,"atomic addr need 8byte aligned\n");
			goto err1;
		}
	}

	if (unlikely((ibwr->send_flags & IBV_SEND_INLINE) &&
		     (length > yqp->sq.max_inline))) {
		yib_err(ctx->dbg_fp,"inline send:%d bigger than:%d\n", length, yqp->sq.max_inline);
		goto err1;
	}

	return 0;

err1:
	return -EINVAL;
}

static int post_one_send(struct yib_qp *yqp, struct ibv_send_wr *wr,
			    u32 mask, u32 length) 
{
        int err = 0; 
        u8 *wqe = NULL;
        struct yib_sq *ysq = &yqp->sq;   
        
        err = validate_send_wr(yqp, wr, mask, length);
        if (err)
		goto exit;
#if(0)
	if (unlikely(yqp->qp_state == IBV_QPS_SQD)) {
		wqe = (u8*)swsq_tail(ysq, yqp->ctx->wqe_isize);
		if (unlikely(!wqe)) {
			err = -ENOMEM;
			goto exit;
		}

		err = yqp->ctx->fill_wqe(yqp, wr, wqe, length, mask);
		if (unlikely(err))
			goto exit;

		//os_smp_wmb();
		swsq_advance_pi(ysq);
	} else
#endif	
	{		
		wqe = (u8*)sq_tail(ysq, yqp->ctx->wqe_isize);
		if (unlikely(!wqe)) {
			err = -ENOMEM;
			goto exit;
		}

		err = yqp->ctx->fill_wqe(yqp, wr, wqe, length, mask);
		if (unlikely(err))
			goto exit;

		sq_advance_pi(ysq);
		udma_to_device_barrier();
                mmio_wc_start();
		yqp->sq.stat_sq_cnt++;
        	yqp->ctx->sq_pi_db_update(&yqp->sq); 	
		mmio_flush_writes();
	}
exit:
	return err;                       
}

static int yib_u_post_send(struct ibv_qp *ibvqp, struct ibv_send_wr *wr,
				   struct ibv_send_wr **bad_wr)
{
		return 0;
        u32 mask = 0;
        int err = 0;
        u32 length = 0;
        int i;
        struct yib_qp *yqp = to_yib_qp(ibvqp);
	struct yib_context *ctx = to_yib_ctx(ibvqp->context);

        if(yqp->vqp.qp.qp_type != IBV_QPT_RC && yqp->vqp.qp.qp_type!= IBV_QPT_UD) {
                *bad_wr = wr;
		yib_err(ctx->dbg_fp, "qp shoule be rc or ud only\n");
                return -EINVAL;
        }

	pthread_spin_lock(&yqp->sq.lock);

        if (unlikely(yqp->qp_state < IBV_QPS_RTS)) { 
		yib_err(ctx->dbg_fp,"qp state:%d is wrong for post send\n", yqp->qp_state);
		err = -EINVAL;
		goto exit;
        }   

        //如果硬件有能力，在err时将提交的wr错误完成，则不需要err的判断，可以直接提交到队列中
        /*if (unlikely(yqp->attr.qp_state == IB_QPS_ERR)) { 
		return -EINVAL;
	}*/

        while (wr) {
		if (wr->opcode > IBV_WR_SEND_WITH_INV) {
			yib_err(ctx->dbg_fp,"opcode:%d is not support\n", wr->opcode);
			err = -EINVAL;
			goto exit;
		}		
                mask = yib_wr_opcode_info[wr->opcode].mask[yqp->vqp.qp.qp_type];
		if (unlikely(!mask)) {
			yib_err(ctx->dbg_fp,"opcode:%d is not support\n", wr->opcode);
			err = -EINVAL;
			goto exit;
		}

		if (unlikely((wr->send_flags & IBV_SEND_INLINE) &&
			     !(mask & WR_INLINE_MASK))) {
			yib_err(ctx->dbg_fp,"opcode:%d inline not support\n", wr->opcode);
			err = -EINVAL;
			goto exit;
		}

		length = 0;
		for (i = 0; i < wr->num_sge; i++)
			length += wr->sg_list[i].length;

                /*if (length == 0 && (mask & WR_READ_WRITE_OR_SEND_MASK)) {
                        //我们目前硬件不能处理0长度，需要直接报�?
			yib_err(ctx->dbg_fp,"zero length send not support\n");
		        err = -EINVAL;
		        goto exit;
                }*/

                if (wr->opcode == IBV_WR_LOCAL_INV) {
                        //todo userspace how to invalidate
		}

		err = post_one_send(yqp, wr, mask, length);
		if (err) {
			goto exit;
		}
		wr = wr->next;
        }

exit:
	pthread_spin_unlock(&yqp->sq.lock);
	if (err) {
		*bad_wr = wr;
	}
        return err;
}

static int post_one_recv(struct yib_context * ctx, struct yib_rq *yrq, struct ibv_recv_wr *wr)
{
	int err;
	int i;
	u32 length;
	u8 *rqe;
	int num_sge = wr->num_sge;

	if (unlikely(num_sge > ctx->max_sge)) {
		yib_err(ctx->dbg_fp,"recv sge:%d > max_sge:%d\n", num_sge, ctx->max_sge);
		err = -EINVAL;
		goto exit;
	}

	length = 0;
	for (i = 0; i < num_sge; i++)
		length += wr->sg_list[i].length;
#if(0)
        if (length == 0) {
		err = -EINVAL;//硬件不支�?长度的接�?
		yib_err(ctx->dbg_fp,"zero length recv not support\n");
		goto exit;
	}
#endif
	rqe = (u8*)rq_tail(yrq, ctx->rqe_isize);
	if (unlikely(!rqe)) {
		err = -ENOMEM;
		goto exit;
	}        
	err = ctx->fill_rqe(ctx, yrq, wr, rqe, length);
	if (unlikely(err))
		goto exit;

	udma_to_device_barrier();
	rq_advance_pi(yrq);
        mmio_wc_start();
	yrq->stat_rq_cnt++;
	ctx->rq_pi_db_update(yrq);
	mmio_flush_writes();


exit:
	return err;
}

static int yib_u_post_recv(struct ibv_qp *ibvqp,struct ibv_recv_wr *wr,
				   struct ibv_recv_wr **bad_wr)
{
	return 0;
        int err = 0;
        struct yib_qp *yqp = to_yib_qp(ibvqp);
        struct yib_rq *yrq = &yqp->rq;
	struct yib_context *ctx = to_yib_ctx(ibvqp->context);

 	if (unlikely(yrq->is_srq)) {
		*bad_wr = wr;
		yib_err(ctx->dbg_fp, "post recv qp for srq\n");
		return -EINVAL;
	}

	pthread_spin_lock(&yrq->lock);

	while (wr) {
                //再次检查，状态不对退�?
                if (unlikely(yqp->qp_state < IBV_QPS_INIT)) {
			yib_err(ctx->dbg_fp,"post recv before qp init\n"); 
                        err = -EINVAL;
                        goto exit;
                }

                //如果硬件有能力，在err时将提交的wr错误完成，则不需要err的判�?
                /*if (unlikely(yqp->attr.qp_state == IB_QPS_ERR)) { 
                        err = -EINVAL;
                        goto exit;
	        }*/          
		err = post_one_recv(yqp->ctx, yrq, wr); //gsi硬件接收产生cq
		if (unlikely(err)) {
			*bad_wr = wr;
			break;
		}
		wr = wr->next;
	}

	         
exit:
        pthread_spin_unlock(&yrq->lock); 
        if (err)
                *bad_wr = wr;
	return err;        
}

int yib_queue_count(u32 pt, u32 ct, u32 cnt)
{
	u32 pi = pt;
	u32 ci =ct;
	
	int off = q_get_val(pi)- q_get_val(ci);
	if (off == 0) {
		if (q_get_carrier(pi) == q_get_carrier(ci))
			return 0;
		else
			 return cnt;
	} else if (off < 0)
		return off + cnt;
	else 
		return off;
}

void yib_advance_q_internal(u32 *pt_addr, int add, u32 cnt)
{
	u32 c = 0;
	u32 id1, id2;

	u32 pi = mmio_read32(pt_addr);

	id1 = q_get_val(pi);	
	c = q_get_carrier(pi);
	id2 = (id1+add) % cnt;
	if (id2 <= id1)
		c ^= 1;
	
	mmio_write32(pt_addr, (c << 15) | (id2<<16)); 
}

#define YQP_WR_API_GET_WQE(yqp) \
	if(yqp->err)  {\
		return; \
	} \
	if((yqp->pending_wqe_num >= YIB_MAX_BATCH_SQ)|| \
		(sq_full_pi(&yqp->sq, yqp->curr_index)) ) \
	{ \
		yqp->err = ENOSPC;\
		return; \
	} \
	yqp->wqe = sq_get_item(&yqp->sq, yqp->ctx->wqe_isize, q_get_val(yqp->curr_index))\

static inline void yib_wr_start(struct ibv_qp_ex* qpx)
{
	struct yib_qp *yqp = container_of(qpx, struct yib_qp, vqp.qp_ex);

	pthread_spin_lock(&yqp->sq.lock);
	yqp->curr_index = yqp->sq.pi;
	yqp->pending_wqe_num = 0;
	yqp->err = 0;
}

static inline void yib_wr_send(struct ibv_qp_ex* qpx) 
{
	struct yib_qp *yqp = container_of(qpx, struct yib_qp, vqp.qp_ex);
	
	YQP_WR_API_GET_WQE(yqp);

	if(!yqp->ctx->wr_send){
		yqp->err = EOPNOTSUPP;
		return;
	}

	yqp->ctx->wr_send(yqp);
	yib_advance_q_internal(&yqp->curr_index, 1, yqp->sq.cnt);
	yqp->pending_wqe_num++;
}

static void yib_wr_send_imm(struct ibv_qp_ex *qpx, __be32 imm_data)
{
	struct yib_qp *yqp = container_of(qpx, struct yib_qp, vqp.qp_ex);

	YQP_WR_API_GET_WQE(yqp);

	if(!yqp->ctx->wr_send_imm){
		yqp->err = EOPNOTSUPP;
		return;
	}

	yqp->ctx->wr_send_imm(yqp, imm_data);
	yib_advance_q_internal(&yqp->curr_index, 1, yqp->sq.cnt);
	yqp->pending_wqe_num++;
}

static void yib_wr_send_inv(struct ibv_qp_ex *qpx, uint32_t invalidate_rkey)
{
	struct yib_qp *yqp = container_of(qpx, struct yib_qp, vqp.qp_ex);

	YQP_WR_API_GET_WQE(yqp);

	if(!yqp->ctx->wr_send_inv){
		yqp->err = EOPNOTSUPP;
		return;
	}

	yqp->ctx->wr_send_inv(yqp, invalidate_rkey);
	yib_advance_q_internal(&yqp->curr_index, 1, yqp->sq.cnt);
	yqp->pending_wqe_num++;	
}

static inline void yib_wr_rdma_read(struct ibv_qp_ex *qpx, uint32_t rkey,
			 uint64_t remote_addr)
{
	struct yib_qp *yqp = container_of(qpx, struct yib_qp, vqp.qp_ex);

	YQP_WR_API_GET_WQE(yqp);

	if(!yqp->ctx->wr_rdma_read){
		yqp->err = EOPNOTSUPP;
		return;
	}

	yqp->ctx->wr_rdma_read(yqp, rkey, remote_addr);
	yib_advance_q_internal(&yqp->curr_index, 1, yqp->sq.cnt);
	yqp->pending_wqe_num++;
}

static inline void yib_wr_rdma_write(struct ibv_qp_ex *qpx, uint32_t rkey,
			 uint64_t remote_addr)
{
	struct yib_qp *yqp = container_of(qpx, struct yib_qp, vqp.qp_ex);

	YQP_WR_API_GET_WQE(yqp);

	if(!yqp->ctx->wr_rdma_write){
		yqp->err = EOPNOTSUPP;
		return;
	}

	yqp->ctx->wr_rdma_write(yqp, rkey, remote_addr);
	yib_advance_q_internal(&yqp->curr_index, 1, yqp->sq.cnt);
	yqp->pending_wqe_num++;	
}

static inline void yib_wr_rdma_write_imm(struct ibv_qp_ex *qpx, uint32_t rkey,
			      uint64_t remote_addr, __be32 imm_data)
{
	struct yib_qp *yqp = container_of(qpx, struct yib_qp, vqp.qp_ex);

	YQP_WR_API_GET_WQE(yqp);

	if(!yqp->ctx->wr_rdma_write_imm){
		yqp->err = EOPNOTSUPP;
		return;
	}

	yqp->ctx->wr_rdma_write_imm(yqp, rkey, remote_addr, imm_data);
	yib_advance_q_internal(&yqp->curr_index, 1, yqp->sq.cnt);
	yqp->pending_wqe_num++;	
}

static inline void yib_wr_set_inline_data(struct ibv_qp_ex *qpx, void *addr,
			       size_t length)
{
	struct yib_qp *yqp = container_of(qpx, struct yib_qp, vqp.qp_ex);
	if(yqp->err) {
		return;
	}

	if(!yqp->ctx->wr_set_inline_data) {
		yqp->err = EOPNOTSUPP;
		return;
	}

	return yqp->ctx->wr_set_inline_data(yqp, addr, length);
}

static inline void yib_wr_set_inline_data_list(struct ibv_qp_ex *qpx, size_t num_buf,
				    const struct ibv_data_buf *buf_list)
{
	struct yib_qp *yqp = container_of(qpx, struct yib_qp, vqp.qp_ex);
	if(yqp->err) {
		return;
	}

	if(!yqp->ctx->wr_set_inline_data_list) {
		yqp->err = EOPNOTSUPP;
		return;
	}

	return yqp->ctx->wr_set_inline_data_list(yqp, num_buf, buf_list);
}

static inline void yib_wr_set_sge(struct ibv_qp_ex *qpx, uint32_t lkey,
				  uint64_t addr, uint32_t length)
{
	struct yib_qp *yqp = container_of(qpx, struct yib_qp, vqp.qp_ex);
	if(yqp->err) {
		return;
	}

	if(!yqp->ctx->wr_set_sge) {
		yqp->err = EOPNOTSUPP;
		return;
	}

	return yqp->ctx->wr_set_sge(yqp, lkey, addr, length);
}

static inline void yib_wr_set_sge_list(struct ibv_qp_ex *qpx, size_t num_sge,
				const struct ibv_sge *sg_list)
{
	struct yib_qp *yqp = container_of(qpx, struct yib_qp, vqp.qp_ex);
	if(yqp->err) {
		return;
	}

	if(!yqp->ctx->wr_set_sge_list) {
		yqp->err = EOPNOTSUPP;
		return;
	}

	return yqp->ctx->wr_set_sge_list(yqp, num_sge, sg_list);
}


static int yib_wr_complete(struct ibv_qp_ex *qpx) 
{
	struct yib_qp *yqp = container_of(qpx, struct yib_qp, vqp.qp_ex);
	
	if (yqp->err) {
		pthread_spin_unlock(&yqp->sq.lock);
		return yqp->err;
	}

	yib_advance_q_internal(&yqp->sq.pi, yqp->pending_wqe_num, yqp->sq.cnt);
	udma_to_device_barrier();
    mmio_wc_start();
	yqp->sq.stat_sq_cnt += yqp->pending_wqe_num;
    yqp->ctx->sq_pi_db_update(&yqp->sq); 	
	mmio_flush_writes();
	pthread_spin_unlock(&yqp->sq.lock);

	return 0;
}

static void yib_wr_abort(struct ibv_qp_ex *qpx)
{
	struct yib_qp *qp = container_of(qpx, struct yib_qp, vqp.qp_ex);

	pthread_spin_unlock(&qp->sq.lock);
}