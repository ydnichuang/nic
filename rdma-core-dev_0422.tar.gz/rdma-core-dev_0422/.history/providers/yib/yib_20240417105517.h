#ifndef YIB_H
#define YIB_H

#define RDMA_DRIVER_ID_YUSUR 1000

//typedef uint32_t int;
typedef __be32 uint32_t;
//typedef uint64_t;


struct yib_device {
	struct verbs_device	ibv_dev;
	int			page_size;
	int			hw_version;
	int			hw_type;
};

struct yib_cq;
struct yib_rq;
struct yib_sq;
struct yib_qp;

#define YIB_MAX_QP      4096

struct yib_wr_id_buf {
	u64  *rq_wr_id_buf;
	u64  *sq_wr_id_buf;
};


struct yib_2100r_hw_ctx
{
	u64 db_reg;
};






//typedef int (*init)(void *);
struct yib_hw_ctx_ops //硬件无关的抽象操作,所i有硬件都对应此结构
{
//硬件相关实现

	void*  (*hw_context_alloc)(void  *) ;	// swtest_hw_context_alloc(){ return &yib_2100r_hw_ctx;}
	int    (*hw_context_dealloc)(void *);

	int (*hw_global_map_reg)(struct yib_context *); //映射regi寄存器
	int (*hw_global_unmap_reg)(struct yib_context *);

//硬件相关的初始化函数
	int (*hw_cq_init)(struct yib_context * ctx, struct yib_cq* );
	int (*hw_qp_init)(struct yib_context * ctx, struct yib_qp* );
	int (*hw_rq_init)(struct yib_context * ctx, struct yib_rq* );
	int (*hw_cq_uninit)(struct yib_context * ctx, struct yib_cq* );
	int (*hw_qp_uninit)(struct yib_context * ctx, struct yib_qp* );	
	int (*hw_rq_uninit)(struct yib_context * ctx, struct yib_rq* );//srq,rq

//	int (*get_sq_item_size)(enum qp_type , int is_inline  , int sge_num);	
//	int (*get_rq_item_size)(enum qp_type , int is_inline  , int sge_num);//qp_type rc,ud 
#if 0
	//同步内核态 queue_ops
	void (*fill_cqe)(struct yib_cq *cq,  struct ibv_wc *wc, u8 *buf);
	int (*fill_wqe)(struct yib_qp *qp, struct ibv_send_wr *wr, u8 *buf, u32 length, u32 mask);
	int (*fill_rqe)(struct yib_context * ctx, struct yib_rq *rq, struct ibv_recv_wr *wr, u8 *buf, u32 length);
	bool (*is_resize_cqe)(u8 *buf);
	void (*notify_cq)(struct yib_cq *cq, int solicated);
	void (*cq_ci_db_update)(struct yib_cq *cq);
	void (*sq_pi_db_update)(struct yib_sq *sq);
	void (*rq_pi_db_update)(struct yib_rq *rq);
	int (*set_capture)(struct yib_qp *qp, bool enable);	
#else 
	int cqe_isize;
	int (*fill_rqe)(struct yib_context * ctx, struct yib_rq *rq, const void *os_wq, u8 *buf, u32 length);
	int (*fill_wqe)(struct yib_context * ctx, struct yib_qp *qp, const void *os_wq, u8 *buf, u32 length,  u32 mask);
	//qp_cache是否使用，由底层的情况决定，当底层硬件有能力在cq中返回qp地址信息时不使用， 否则底层硬件可返回qpn(这时需要使用qp_cache)
	void (*fill_cqe)(struct yib_context * ctx, struct yib_cq *cq, struct yib_qp **qp_cache, void *os_cq, u8 *buf);
	int(*sw_fill_cqe)(struct yib_context * ctx, struct yib_cq *cq, void *os_cq);//返回0表示处理成功，小于0表示不保序

	bool (*check_sq_full)(struct yib_context *, struct yib_sq *sq);
	bool (*check_rq_full)(struct yib_context *, struct yib_rq *rq);
	bool (*check_srq_full)(struct yib_context *, struct yib_srq *srq, int *pos);
	bool (*check_cq_empty)(struct yib_context *, struct yib_cq *cq);
	//bool (*is_resize_cq)(u8 *buf);

	int (*get_sq_item_size)(int *inline_len, int *max_sg, bool is_ud);//inline_len和max_sg为输入输出参数
	int (*get_rq_item_size)(int *max_sg);

	//db update
	void (*sq_pi_db_update)(struct yib_context *, struct yib_sq *sq, int io_cnt);
	void (*rq_pi_db_update)(struct yib_context *, struct yib_rq *rq, int io_cnt);
	void (*srq_pi_db_update)(struct yib_context *, struct yib_srq *srq, int pos);
	void (*cq_ci_db_update)(struct yib_context *, struct yib_cq *cq, int poll_cnt);

	void (*rq_post_db_ext)(struct yib_context *, struct yib_rq *rq, int io_cnt);//ext结尾的函数指针可以为空

	int (*set_capture)(struct yib_qp *qp , int enable);
	
#endif 	 

	/*new api support*/
	void (*wr_send)(struct yib_qp *qp);
	void (*wr_rdma_read)(struct yib_qp *qp, uint32_t rkey, uint64_t remote_addr);
	void (*wr_rdma_write)(struct yib_qp *qp, uint32_t rkey,uint64_t remote_addr);
	void (*wr_rdma_write_imm)(struct yib_qp *qp, uint32_t rkey,
				  uint64_t remote_addr, __be32 imm_data);
	void (*wr_send_imm)(struct yib_qp *qp, __be32 imm_data);
	void (*wr_send_inv)(struct yib_qp *qp, uint32_t invalidate_rkey);
	void (*wr_set_inline_data)(struct yib_qp *qp, void *addr,
				   size_t length);	
	void (*wr_set_inline_data_list)(struct yib_qp *qp, size_t num_buf,
				const struct ibv_data_buf *buf_list);

	void (*wr_set_sge)(struct yib_qp* qp, uint32_t lkey, uint64_t addr, uint32_t length);
	void (*wr_set_sge_list)(struct yib_qp *qp, uint32_t num_sge, const struct ibv_sge *list);
};




struct hw_caps {
		u32 	num_qps;		//qp数量的最大值
		u32 	num_cqs;
		u32 	num_mr;
		u32 	max_sge;
		u32 	max_qp_wr;
		u32 	max_cqe;
		u32 	max_sqe;
		u32 	max_rqe;
		u32     cqe_isize;
		u32     rqe_isize;
		u32     wqe_isize;
};

// 1.添加context 的 DGB 功能
// 2.yib_hw_context 实现硬件相关功能, 如门铃
struct yib_context {
	struct verbs_context		ibv_ctx;
	u32	cmd_fd;

	
	struct  hw_caps hw_caps;
	struct yib_hw_ctx_ops *hw_ops; // ctx->ops = swtest_hw_ops;
	void   *hw_priv; 	//hw_context; hw_priv = swtest_hw_ctx;

//	int     sf_index;	//删除
	u64             ctx_id;
	FILE			*dbg_fp;

	u32  	chip_type;	//根据chip_type选择hw_context_ops
	int   	cqe_isize;
	bool 	sw_wrid;
//	bool 	wqe_12kb; wqe队列4096和2的N次幂对齐
	bool 	nvme_off;
	u8      mac[6]; 
	struct yib_wr_id_buf ** qp_array;
};

static inline struct yib_device *to_yib_dev(struct ibv_device *ibv_dev)
{
	return container_of(ibv_dev, struct yib_device, ibv_dev.device);
}

static inline struct yib_context *to_yib_ctx(struct ibv_context *ibv_ctx)
{
	return container_of(ibv_ctx, struct yib_context, ibv_ctx.context);
}

#endif /* YIB_h	*/
