#ifndef _YUSUR_OS_USER_H_
#define _YUSUR_OS_USER_H_

//这个文件是用户接态口的信息
#if 0
struct yib_ib_alloc_pd_resp {
	__u32 pdn;
};

struct yib_create_ah_resp {
	__u32 ah_num;
	__u32 reserved;
};

struct yib_ib_create_cq { 
	__aligned_u64 cq_va;
	__u32 nvme_off;
};

struct yib_ib_create_srq { 
	__aligned_u64 srq_va;
	__u32 nvme_off; //该srq是否使用nvme_off
};

struct yib_ib_create_qp { 
	__aligned_u64 sq_va;
	__aligned_u64 rq_va;
	__u32 nvme_off;
	__u32 reserved;
};

struct yib_ib_modify_qp {
	__u32	max_burst_sz;
	__u16	typical_pkt_sz;
	__u16	reserved;
};

struct yib_ib_create_cq_resp {
	__u32	cqid;
	__u32	isize;
	__u32	max_cqe;
	__u32	reserved;
};

struct yib_ib_create_qp_resp {
	__aligned_u64 capture_pa;
	__aligned_u64 nvme_rq_rqe_pa;
	__u32 qpid;
	__u32 rqid;
	__u32 max_send_wr;
	__u32 max_recv_wr;
	__u32 max_send_sge;
	__u32 max_recv_sge;
	__u32 max_inline_data;
	__u32 send_isize;
	__u32 recv_isize;
}; //rq对srq时无效

struct yib_ib_create_srq_resp {
	__u32 srqid;
	__u32 max_wr;
	__u32 max_sge;
	__u32 isize;
}; //rq对srq时无效

struct yib_ib_alloc_uctx_resp {
	__u32  bar_offset; //rdma寄存器相对于 bar0的偏移
	__u32  bar_map_len;
	__u32  chip_type;
	__u32  chip_subtype;
	__u32  reserved;
};


typedef enum
{
	YIB_MMAP_TYPE_REG = 0,
	YIB_MMAP_TYPE_CQ,
	YIB_MMAP_TYPE_SQ,
	YIB_MMAP_TYPE_RQ,
	YIB_MMAP_TYPE_RSV1 = 4,
	YIB_MMAP_TYPE_RSV2,
	YIB_MMAP_TYPE_RSV3,
	YIB_MMAP_TYPE_RSV4,
	YIB_MMAP_TYPE_HW1 = 8,
	YIB_MMAP_TYPE_HW2,
	YIB_MMAP_TYPE_HW3,
	YIB_MMAP_TYPE_HW4,
	YIB_MMAP_TYPE_HW5,
	YIB_MMAP_TYPE_HW6,
	YIB_MMAP_TYPE_HW7,
	YIB_MMAP_TYPE_HW8,
}yib_mmap_t;

struct yib_ib_modify_srq {
	__u32 generate;
	__u32 reserved;
};

#endif

#endif /* end YUSUR_OS_USER */