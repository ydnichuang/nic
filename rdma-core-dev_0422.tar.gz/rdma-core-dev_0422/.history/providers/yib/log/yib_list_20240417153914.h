#ifndef __YIB_LIST_H

#define __YIB_LIST_H


typedef struct yib_list {
		struct yib_list *prev;
		struct yib_list *next;
} yib_list_t;



#define YIB_LIST_HEAD_INIT(name)  { (&name),(&name)}

#define YIB_LIST_HEAD(name) 	struct yib_list name = YIB_LIST_HEAD_INIT(name)


static inline void yib_list_add( struct yib_list* new , struct yib_list *prev , struct yib_list * next) {
		next->prev = new;
		new->next = next;
		new->prev = prev;
		prev->next = new;
}

static inline void yib_list_del(struct yib_list *prev , struct yib_list *next){
		prev->next = next;
		next->prev = prev;
}

static inline void yib_list_tail(struct yib_list *head , struct yib_list *new ) {

		yib_list_add(new , head->prev , head);

}

static inline int yib_list_empty(struct yib_list *head){

	
				return (head->next == head);
}

static inline int yib_list_is_head(struct yib_list *list , struct yib_list *head){

				return (list == head);
}


#define yib_list_for_each(pos , head ) \
	for(pos=head->next, !(list_is_head(pos , head)) ; pos=pos->next)

#else



#endif

