 
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <sys/types.h>
#include <unistd.h>
#include <stdint.h>

#include <pthread.h>

#include "yib_log.h"

uint32_t yib_log_level = YIB_LEVEL_ERR;
uint32_t yib_log_module = YIB_MSG_CQ | YIB_MSG_QP;




struct yib_context yib_ctx;



static void yib_open_debug_file(struct yib_context *ctx)
{
	char *env;

	env = getenv("YIB_LOG_FILE");
	if (!env) {
		ctx->dbg_fp = stderr;
		YIB_LOG_INFO(ctx->dbg_fp,
			   "Debug file opened: stderr\n");
		return;
	}

	ctx->dbg_fp = fopen(env, "aw+");
	if (!ctx->dbg_fp) {
		fprintf(stderr, "Failed opening debug file %s, using stderr\n",
			env);
		ctx->dbg_fp = stderr;
		YIB_LOG_INFO(ctx->dbg_fp,
			   "Debug file opmened: stderr\n");
		return;
	}

//	YIB_LOGm_INFO(ctx->dbg_fp, YIB_MSG_INIT, "Debug file opened: %s\n", env);
}

static void yib_close_debug_file(struct yib_context *ctx)
{
	if (ctx->dbg_fp && ctx->dbg_fp != stderr)
		fclose(ctx->dbg_fp);
}



static void yib_set_debug_mask(void)
{
	char *env;

	yib_log_level = YIB_LEVEL_WARNING;
	yib_log_module = 0;

	env = getenv("YIB_LOG_LEVEL");
	if (env)
		yib_log_level = atoi(env);

	env = getenv("YIB_LOG_MODULE");
	if (env)
		yib_log_module = atoi(env);
}


int main_list(){

		int cond = 1;
		char msg[55];
		pid_t pid;
        yib_open_debug_file(&yib_ctx);
        YIB_LOG_INFO(yib_ctx.dbg_fp , "yib log info \n" );
		YIB_LOGm_INFO(yib_ctx.dbg_fp , YIB_MSG_CQ, " ----------------- \n " );
        yib_set_debug_mask();
        yib_close_debug_file(&yib_ctx);

		log_printf( 1 , 1 , "FMT:%s" , "kvm_handle_io\n");
#if 0		
		pid = fork();
		if(pid == 0){ // sub
				memset(msg , 0 , 55);
				sprintf(msg , "pid:%d qemu_ram_alloc \n", pid);
				log_thread_func(msg);
		}
		else {
			printf("sub process:%d \n",pid);
			log_thread_init();
		}
#else
		log_thread_init();
#endif
//		daemon(0,0);
//		while(!cond){
//				sleep(4);
//		}
		pthread_exit(&cond);
		printf("pthread_exit()\n");
		return 1;
}


int main(){

	
	yib_shm_init();
#if defined(__MAIN_LIST__)
	return main_list();
#elif defined(__MAIN_FIFO__)
	return main_fifo();
#else
	return 0;
#endif

}