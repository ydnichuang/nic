#include "basic.h"
#include <netinet/in.h>
#include <infiniband/driver.h>
#include <infiniband/verbs.h>
#include <util/symver.h>
#include "yib-drv-cmd-abi.h"
#include "yib.h"
#include "ib.h"
#include "queue.h"


#include "hw/swtest.h"

static void set_yib_qpx_ops(struct ibv_qp_ex *qpx);

static inline int ipv6_addr_v4mapped(const struct in6_addr *a)
{
        return IN6_IS_ADDR_V4MAPPED(a);
}

typedef typeof(((struct yib_av *)0)->sgid_addr) sockaddr_union_t;

static inline int rdma_gid2ip(sockaddr_union_t *out, union ibv_gid *gid)
{
        if (ipv6_addr_v4mapped((struct in6_addr *)gid)) {
                memset(&out->_sockaddr_in, 0, sizeof(out->_sockaddr_in));
                memcpy(&out->_sockaddr_in.sin_addr.s_addr, gid->raw + 12, 4);
        } else {
                memset(&out->_sockaddr_in6, 0, sizeof(out->_sockaddr_in6));
                out->_sockaddr_in6.sin6_family = AF_INET6;
                memcpy(&out->_sockaddr_in6.sin6_addr.s6_addr, gid->raw, 16);
        }
        return 0;
}

static int yib_u_query_port(struct ibv_context *context, uint8_t port,
			struct ibv_port_attr *attr)
{
	struct ibv_query_port cmd;

	memset(attr, 0, sizeof(struct ibv_port_attr));
	return ibv_cmd_query_port(context, port, attr, &cmd, sizeof(cmd));
}

static struct ibv_pd *yib_u_alloc_pd(struct ibv_context *context)
{
	struct yib_alloc_pd_resp resp = {};
	struct ibv_alloc_pd cmd = {};
	struct yib_pd *pd;
	struct yib_context *ctx = to_yib_ctx(context);

	pd = (struct yib_pd *)malloc(sizeof(struct yib_pd));
	if(!pd) {
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_PD , "alloc pd mem failed\n");
		return NULL;
	}

	memset(pd, 0, sizeof(*pd));

	if (ibv_cmd_alloc_pd(context, &pd->ibv_pd, &cmd, sizeof(cmd),
				&resp.ibv_resp, sizeof(resp))) {
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_PD , "alloc pd cmd failed\n");
		YIBfree(pd);
		return NULL;
	}

	pd->pdn = resp.pdn;
	return &pd->ibv_pd;
}

static int yib_u_free_pd(struct ibv_pd *ibpd)
{
	int ret;
	struct yib_context *ctx = to_yib_ctx(ibpd->context);
	struct yib_pd *pd = to_yib_pd(ibpd);
	ret = ibv_cmd_dealloc_pd(ibpd);
	if (ret) {
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_PD , "dealloc pd cmd failed\n");
		return ret;
	}

	YIBfree(pd);
	return ret;
}

static struct ibv_mr *yib_u_reg_mr(struct ibv_pd *pd, void *addr, size_t length,
				uint64_t hca_va, int access)
{
	struct yib_context *context = to_yib_ctx(pd->context);
	struct ib_uverbs_reg_mr_resp resp = {};
	FILE *fp = context->dbg_fp;
	struct ibv_reg_mr cmd;
	struct yib_mr *ymr = NULL;
	int ret;

	if(!addr) {
		YIB_LOGm_ERR(fp, YIB_MSG_MR , "MR addr is NULL!\n");
		return NULL;
	}

	if(!length) {
		YIB_LOGm_ERR(fp, YIB_MSG_MR , "MR length is 0!\n");
		return NULL;
	}

	YIB_LOGm_DBG(fp, YIB_MSG_MR,
		"staring to register memory region, addr:%lx, length:%d\n",
		(uintptr_t)addr, (int)length);

	ymr = (struct yib_mr *)malloc(sizeof(struct yib_mr));
	if (!ymr) {
		YIB_LOGm_ERR(fp, YIB_MSG_MR , "alloc mem for mr failed\n");
		return NULL;
	}

	memset(ymr, 0, sizeof(*ymr));

	ret = ibv_cmd_reg_mr(pd, addr, length, hca_va, access, &ymr->vmr,
				&cmd, sizeof(cmd), &resp, sizeof(resp));
	if (ret) {
		YIB_LOGm_ERR(fp, YIB_MSG_MR ,"failed to register memory region, ret:%d\n", ret);
		YIBfree(ymr);
		return NULL;
	}

	ret = context->hw_ops->hw_mr_init(context, ymr);
	if(ret) {
		YIB_LOGm_ERR(fp, YIB_MSG_MR ,"hw failed to register memory region, ret:%d\n", ret);	
		ret = ibv_cmd_dereg_mr(&ymr->vmr);
		return NULL;
	}
	
	return &ymr->vmr.ibv_mr;
}


static int yib_u_dereg_mr(struct verbs_mr *vmr)
{
	struct yib_context *context = to_yib_ctx(vmr->ibv_mr.context);
	struct yib_mr *ymr = to_yib_mr(&vmr->ibv_mr);
	FILE *fp = context->dbg_fp;
	int ret;

	YIB_LOGm_DBG(fp, YIB_MSG_MR, "starting to deregister memory region\n");

	ret = ibv_cmd_dereg_mr(vmr);
	if (ret) {
		YIB_LOGm_ERR(fp,YIB_MSG_MR, "failed to deregister memory region, ret:%d\n", ret);
		return ret;
	}
	ret = context->hw_ops->hw_mr_uninit(context, ymr);
	if(ret){
		YIB_LOGm_ERR(fp,YIB_MSG_MR, "hw failed to deregister memory region, ret:%d\n", ret);
		return ret;
	}
	YIBfree(ymr);
	return ret;
}

static struct ibv_ah *yib_u_create_ah(struct ibv_pd *pd,
					struct ibv_ah_attr *attr)
{
        int err;
        struct yib_ah *ah;
        struct yib_av *av;
        union ibv_gid sgid;
        struct yib_create_ah_resp resp = {};
		struct yib_context *ctx = to_yib_ctx(pd->context);

        err = ibv_query_gid(pd->context, attr->port_num, attr->grh.sgid_index,
                            &sgid);
        if (err) {
                YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_AH , "Failed to query sgid.\n");
                return NULL;
        }

        ah = malloc(sizeof(*ah));
        if (ah == NULL) {
				YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_AH , "alloc ah mem failed\n");
                return NULL;
		}

        av = &ah->av;
        av->port_num = attr->port_num;
        memcpy(&av->grh, &attr->grh, sizeof(attr->grh));
        av->network_type =
                ipv6_addr_v4mapped((struct in6_addr *)attr->grh.dgid.raw) ?
                YIB_NETWORK_TYPE_IPV4 : YIB_NETWORK_TYPE_IPV6;

        rdma_gid2ip(&av->sgid_addr, &sgid);
        rdma_gid2ip(&av->dgid_addr, &attr->grh.dgid);
        if (ibv_resolve_eth_l2_from_gid(pd->context, attr, av->dmac, NULL)) {
				YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_AH , "alloc resolve dmac gid failed\n");
                YIBfree(ah);
                return NULL;
        }

        memset(&resp, 0, sizeof(resp));
        if (ibv_cmd_create_ah(pd, &ah->ibv_ah, attr, &resp.ibv_resp, sizeof(resp))) {
				YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_AH , "create ah cmd failed\n");
                YIBfree(ah);
                return NULL;
        }

		ah->ah_num = resp.ah_num;
		memcpy(ah->av.smac , resp.smac , 6 );// 1
		return &ah->ibv_ah;
}

static int yib_u_destroy_ah(struct ibv_ah *ibah)
{
	struct yib_ah *ah = to_yib_ah(ibah);	
	struct yib_context *ctx = to_yib_ctx(ibah->context);
	int ret;

	ret = ibv_cmd_destroy_ah(&ah->ibv_ah);
	if (!ret)
		YIBfree(ah);
	else {
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_AH , "destroh ah failed ret=%d\n", ret);
	}

	return ret;
}

static struct ibv_cq *yib_u_create_cq(struct ibv_context *context, int cqe,
				    struct ibv_comp_channel *channel,
				    int comp_vector)
{
	struct yib_create_cq		cmd = {};
	struct yib_create_cq_resp	resp = {};
	struct yib_cq 	*cq;
	int	ret;
    struct yib_context *ctx = to_yib_ctx(context);
	struct swtest_hw_ctx* hw_ctx = (struct swtest_hw_ctx*)(ctx->hw_priv);

	cq = calloc(1, sizeof(struct yib_cq));
	if(!cq) {
		goto yib_cq_err;
	}
	memset(cq, 0, sizeof(*cq));
	cq->ctx = ctx;
	
	if (pthread_spin_init(&cq->lock, PTHREAD_PROCESS_PRIVATE))
		goto yib_cq_err;

	ret = yib_roce_alloc_dma_buf(&cq->buf_v, &cqe, ctx->hw_caps.cqe_isize);
	if (ret) {
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_CQ , "create cq dma buf failed\n");
		goto buf_err;
	}
	cq->cqe = cq->ibv_cq.cqe = cqe;

	ret = ibv_cmd_create_cq(context, cqe, channel, comp_vector,
				&cq->ibv_cq, &cmd.ibv_cmd, sizeof(cmd),
				&resp.ibv_resp, sizeof(resp));
	if (ret) {
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_CQ ,"create cq cmd failed\n");
		goto buf_err;
	}	
	
	cq->cq_id = resp.cqid;

#if defined(__MMAP__)
	cq->cqinfo.info = (struct yib_queue_info *)(hw_ctx->resource.cq_base + (cq->cq_id * sizeof(struct yib_queue_info)));
#else
	cq->cqinfo.info = malloc(sizeof(struct yib_queue_info));
#endif

	ret = ctx->hw_ops->hw_cq_init(ctx , cq);
	if( ret ){
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_CQ ,"hw create cq  failed , ret %d \n",ret);
		goto ibv_cq_err;
	}

	return &cq->ibv_cq;

ibv_cq_err:
	ibv_cmd_destroy_cq(&cq->ibv_cq);
buf_err:
	yib_roce_free_buf(&cq->buf_v);
yib_cq_err:
	YIBfree(cq);

	return NULL;
}

static int yib_u_destroy_cq(struct ibv_cq *ibcq)
{
	struct yib_context *ctx = to_yib_ctx(ibcq->context);
	struct yib_cq *cq = to_yib_cq(ibcq);
	FILE *fp = ctx->dbg_fp;
	int ret;

	ret = ibv_cmd_destroy_cq(ibcq);
	if (ret) {
 		if (ret < 0) 
			YIB_LOGm_ERR(fp, YIB_MSG_CQ ,"failed to destroy cq ret=%d\n", ret);
        return ret;
	}
	yib_roce_free_buf(&cq->buf_v);
	YIBfree(cq);
	return ret;
}




//设置队列深度,保证偶数和4096对齐
static int yib_roce_update_qp_params(struct ibv_qp_init_attr_ex *attr,
				   struct yib_qp *qp,
				   struct yib_context *ctx,
				   char *err_msg)
{
	u32 rqe_cnt; 
	u32 sqe_cnt;

//	u32 page_size = ctx->wqe_12kb? (4096ul*3):(4096ul);
	u32 page_size = 4096ul;//wqe buf 按照4096和2的n次幂对齐

	qp->vqp.qp.qp_type = attr->qp_type;
	if (attr->cap.max_send_sge > ctx->hw_caps.max_sge) {
		sprintf(err_msg , "%s", "send sge is two big");
		return -EINVAL;
	}
	
	if (attr->cap.max_send_wr == 0) {
		attr->cap.max_send_wr = 128;
	}
	if (attr->cap.max_send_wr) {
		sqe_cnt = attr->cap.max_send_wr;
		sqe_cnt = os_align_any_up(sqe_cnt * ctx->hw_caps.wqe_isize, page_size) / ctx->hw_caps.wqe_isize;
		sqe_cnt = numTo2n2((sqe_cnt * ctx->hw_caps.wqe_isize) / page_size);   
		sqe_cnt = (sqe_cnt * page_size) / ctx->hw_caps.wqe_isize;
		if (sqe_cnt > ctx->hw_caps.max_sge) {
			sprintf(err_msg ,"send sqe is two big:%d", sqe_cnt);
			return -EINVAL;	
		}
		attr->cap.max_send_wr = sqe_cnt;
		qp->sq.cnt = sqe_cnt;
	} else {
		sprintf(err_msg , "%s", "send wr is zero\n");
		return -EINVAL;
	}

	if (attr->recv_cq == NULL || attr->send_cq == NULL) {
		sprintf(err_msg , "%s", "cq is not provide\n");
		return -EINVAL;
	}		

	if (attr->srq) {
		//todo 
		qp->rq.is_srq = true;
		return -EINVAL;
	} 

	if (attr->cap.max_recv_sge > ctx->hw_caps.max_sge) {
		sprintf(err_msg , "%s", "send sge is two big");
		return -EINVAL;
	}
	if (attr->cap.max_recv_wr == 0) {
		attr->cap.max_recv_wr = 128;
	}
	if (attr->cap.max_recv_wr) {
		rqe_cnt = attr->cap.max_recv_wr;
		rqe_cnt = os_align_any_up(rqe_cnt * ctx->hw_caps.rqe_isize, page_size) / ctx->hw_caps.rqe_isize;
		rqe_cnt = numTo2n2((rqe_cnt * ctx->hw_caps.rqe_isize) / page_size);   
		rqe_cnt = (rqe_cnt * page_size) / ctx->hw_caps.rqe_isize; 

		if (rqe_cnt > ctx->hw_caps.max_rqe) {
			sprintf(err_msg , "recv rqe is two big:%d", rqe_cnt);
			return -EINVAL;	
		}
		attr->cap.max_recv_wr = rqe_cnt;
		qp->rq.cnt = rqe_cnt;
	} else {
		sprintf(err_msg , "%s", "recv wr is zero\n");
		return -EINVAL;
	}

	return 0;
}

static void yib_qp_free_bufs(struct yib_context *context, struct yib_qp *qp)
{
	if (qp == NULL)
		return;

	if (qp->rq.nvme_off) {
		yib_roce_free_buf(&qp->rq.buf_nvme);
	}

	if (!qp->is_srq)
		yib_roce_free_buf(&qp->rq.buf_v);
	yib_roce_free_buf(&qp->sq.buf_v);
	
	
/* 	if (qp->capture) {
		yib_ummap_vaddr(qp->capture, 4);
		qp->capture = NULL;
	} */


	YIBfree(qp);
}




int yib_qp_type_check(enum ibv_qp_type type){

	switch(type){
		case IBV_QPT_RC:
			return 0;
		case IBV_QPT_UD:
			return 0;
		default:
			return -1;
	}
	return -1;
}


int get_qp_info(struct yib_context *ctx , struct yib_qp *qp , struct ibv_qp_init_attr_ex attr){

	struct swtest_hw_ctx* hw_ctx = (struct swtest_hw_ctx*)(ctx->hw_priv);

#if defined(__MMAP__)
		qp->sq.sq_info->info = (struct yib_queue_info *)(hw_ctx->resource.sq_base + (qp->sq.qid * sizeof(struct yib_queue_info)));
		if(!attr->srq)
			qp->rq.rq_info->info = (struct yib_queue_info *)(hw_ctx->resource.rq_base + (qp->rq.qid * sizeof(struct yib_queue_info)));			
#else
		qp->sq.sq_info->info = malloc(sizeof(struct yib_queue_info));
		if(!qp->sq.sq_info->info){
				return -1;
		}
		memset(qp->sq.sq_info->info , 0 , sizeof(struct yib_queue_info));	
		if(!attr->srq) {
			qp->rq.rq_info->info = malloc(sizeof(struct yib_queue_info));
			if(!qp->rq.rq_info->info){
				return -2;
			}
			memset(qp->sq.sq_info->info , 0 , sizeof(struct yib_queue_info));
		}
#endif

	return 0;

}

// 1.wqe size 2.
// qp类型检测 RC , UD
// attr->cap 计算出sq : depth, max_inline, sg
// 判断srq 还是 rq模式
//如果是rq模式, 根据attr->cap  计算 rq: depth, sg
//分配sq , rq内存
//调用内核
//处理内核resp
//queue_info赋值
//硬件私有初始化
//sw_cmd 分配内存

static struct ibv_qp *yib_u_create_qp_ex(struct ibv_context *ibv_ctx, struct ibv_qp_init_attr_ex *attr)
{
	struct yib_context *ctx = to_yib_ctx(ibv_ctx);
 	struct yib_create_qp_ex_resp resp = {};

	//struct yib_cq *send_cq, *recv_cq;
	struct yib_create_qp_ex cmd = {};
	FILE *fp = ctx->dbg_fp;
	struct yib_qp *qp;
	int ret = 0;
	int page_size = 4096ul;

	int wqe_isize , rqe_isize;
	int max_send_sge , max_recv_sge;
	int inline_size = attr->cap.max_inline_data;
	char err_msg[128];
	
	struct swtest_hw_ctx* hw_ctx = (struct swtest_hw_ctx*)(ctx->hw_priv);
	

	if( yib_qp_type_check(attr->qp_type) ){
		YIB_LOGm_ERR(fp, YIB_MSG_QP," create qp type err :%u \n",attr->qp_type);
		return NULL;
	}

	qp = calloc(1, sizeof(*qp));
	if (!qp) {
		YIB_LOGm_ERR(fp, YIB_MSG_QP, "alloc mem for qp faield\n");
		YIBfree(qp);
		return -ENOMEM;
//		goto err;
	}
	memset(qp, 0, sizeof(*qp));

	// sq malloc
	qp->sq.sw_cmd = malloc(sizeof(struct yib_sw_cmd));
	if(qp->sq.sw_cmd){
		goto mem_err;
	}
	memset(qp->sq.sw_cmd , 0 , sizeof(struct yib_sw_cmd));
	if(!attr->srq) {
		qp->rq.sw_cmd = (struct yib_sw_cmd *)malloc(sizeof(struct yib_sw_cmd));
		if(qp->rq.sw_cmd){
			goto mem_err;
		}
		memset(qp->rq.sw_cmd , 0 , sizeof(struct yib_sw_cmd));
	}	
	
	if (pthread_spin_init(&qp->sq.lock, PTHREAD_PROCESS_PRIVATE)) {
		ret = -ENOMEM;
		YIB_LOGm_ERR(fp, YIB_MSG_QP,"sq pthread lock init error \n");
		goto err;
	}
	if (pthread_spin_init(&qp->rq.lock, PTHREAD_PROCESS_PRIVATE)) {
		ret = -ENOMEM;
		YIB_LOGm_ERR(fp, YIB_MSG_QP,"sq pthread lock init error \n");
		goto err;				
	}

	// init qp with qp_init_attr
	max_send_sge = attr->cap.max_send_sge;
	max_recv_sge = attr->cap.max_recv_sge;
	wqe_isize = ctx->hw_ops->get_sq_item_size(attr->qp_type , &inline_size , &max_send_sge);
	//inline 由内核决定	
	// wqe,rqe 的大小不在是定值,根据用户输入的sge数量和inline动态调整. 硬件定义大小和用户数量
	if(attr->srq == NULL)
		rqe_isize = ctx->hw_ops->get_rq_item_size(attr->qp_type , &max_recv_sge);

	ctx->hw_caps.rqe_isize = rqe_isize;
	ctx->hw_caps.wqe_isize = wqe_isize;
	YIB_LOGm_DBG(fp, YIB_MSG_QP,"sqe:%d  rqe:%d  \n",wqe_isize , rqe_isize);

	// init sq buffer
	ret = yib_roce_update_qp_params(attr, qp, ctx ,err_msg);//队列深度2的n次方和4096对齐
	if( ret ) {
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_QP ,"SQ Error status err_msg:%s  sqe:%d  rqe:%d  \n", ret , err_msg ,wqe_isize , rqe_isize);			
		goto err;
	}
	YIB_LOGm_DBG(fp, YIB_MSG_QP,"swr:%d sqcnt:%d  rwr:%d  rqcnt:%d \n",attr->cap.max_send_wr ,qp->sq.cnt , attr->cap.max_recv_wr , qp->rq.cnt);

	ret = yib_roce_alloc_buf(&qp->sq.buf_v, attr->cap.max_send_wr * wqe_isize , page_size);
	if (ret) {
		YIB_LOGm_ERR(fp, YIB_MSG_QP, "alloc buf for qp sq failed ret=%d\n", ret);
		goto err;
	}
	cmd.sq_va = (uintptr_t)qp->sq.buf_v.buf;
	cmd.nvme_off = ctx->nvme_off;

	
	// init rq buffer
	if (attr->srq) {
		qp->srq = to_yib_srq(attr->srq);
		qp->is_srq = true;
	} else {
		qp->rq.parent = qp;						// srq/rq指向指向srq rq->parent = srq;
		ret = yib_roce_alloc_buf(&qp->rq.buf_v, attr->cap.max_recv_wr * rqe_isize, page_size);
		if (ret) {
			YIB_LOGm_ERR(fp, YIB_MSG_QP,"alloc buf for qp rq failed ret=%d\n", ret);
			ret = -ENOMEM;
			goto qp_buf_err;
		}
		qp->rq.ctx= ctx;
		cmd.rq_va = (uintptr_t)qp->rq.buf_v.buf;
		qp->rq.nvme_off = ctx->nvme_off;
	}



	ret = ibv_cmd_create_qp_ex2(ibv_ctx, &qp->vqp, attr, &cmd.ibv_cmd, sizeof(cmd), &resp.ibv_resp, sizeof(resp));
	if (ret) {
		YIB_LOGm_ERR(fp, YIB_MSG_QP,"ibv_cmd_create_qp_ex2 failed!\n");
		goto qp_resp_err;
	}

	// init sq,rq with IB response 
	qp->sq.ctx		= ctx;
	qp->sq.max_inline = resp.max_inline_data;
	qp->qp_state 	= IBV_QPS_RESET;	
	qp->sqsig 		= attr->sq_sig_all;	
	qp->sq.qid 		= qp->qpn = resp.qpid;
	qp->ctx 		= qp->sq.ctx = ctx;
	
	attr->cap.max_inline_data = resp.max_inline_data;
	YIB_LOGm_DBG(fp, YIB_MSG_QP,"resp qpid:%d inline:%d  max_send_wr:%d  max_recv_wr:%d \n",resp.qpid , resp.max_inline_data , resp.max_send_wr , resp.max_recv_wr );

		// sq , rq info
	ret = get_qp_info(ctx  , qp , attr);// 依赖qpid
	if(ret){
		goto qp_info_err;
	}


	ret = ctx->hw_ops->hw_qp_init(ctx , qp);
	if( ret || !qp->sq.sw_cmd){
		YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_QP ,"SQ Error status hw_init:%d, sw_cmd:0x%lx  \n", ret , qp->sq.sw_cmd );
		goto sq_hw_init_err;
	}

	// rq malloc
	if(!attr->srq) { // normal rq
		qp->rq.qid		= resp.rqid;
		ret = ctx->hw_ops->hw_rq_init(ctx , qp);		
//		hw_rq_init 回调需要分配 rq_hw_priv
		if(ret || !qp->rq.sw_cmd ){
			YIB_LOGm_ERR(ctx->dbg_fp, YIB_MSG_QP ,"RQ Error status hw_init:%d, sw_cmd:0x%lx \n", ret , qp->rq.sw_cmd );
			goto rq_hw_init_err;
		}
	}


	if(attr->comp_mask & IBV_QP_INIT_ATTR_SEND_OPS_FLAGS){
		set_yib_qpx_ops(&qp->vqp.qp_ex);
		qp->vqp.comp_mask |= VERBS_QP_EX;
	}

	return &qp->vqp.qp;


	
rq_hw_init_err:
	if(qp->qpn){
		ibv_cmd_destroy_qp(qp);
		qp->qpn = 0;
	}
	ctx->hw_ops->hw_rq_uninit(ctx , qp);

sq_hw_init_err:
	if(qp->qpn){
		ibv_cmd_destroy_qp(qp);
		qp->qpn = 0;
	}
	ctx->hw_ops->hw_qp_uninit(ctx , qp);

qp_resp_err:
//	ibv_cmd_destroy_qp(qp);

qp_info_err:
	if(qp->qpn){
		ibv_cmd_destroy_qp(qp);
		qp->qpn = 0;
	}

qp_buf_err:	
	if( qp->rq.buf_v.buf )
		yib_roce_free_buf(&qp->rq.buf_v);
	if( qp->sq.buf_v.buf )
		yib_roce_free_buf(&qp->sq.buf_v);

mem_err:
	if(qp->rq.sw_cmd) 
		YIBfree(qp->rq.sw_cmd);
	if(qp->sq.sw_cmd) 
		YIBfree(qp->sq.sw_cmd);
err:
	if (ret < 0)
		ret = -ret;
	errno = ret;
	return NULL;	
}

static struct ibv_qp *yib_u_create_qp(struct ibv_pd *ibvpd, struct ibv_qp_init_attr *attr)
{
	struct ibv_qp_init_attr_ex attr_ex = {};
	memcpy(&attr_ex, attr, sizeof(*attr));
	attr_ex.comp_mask = IBV_QP_INIT_ATTR_PD;
	attr_ex.pd = ibvpd;

	return yib_u_create_qp_ex(ibvpd->context, &attr_ex);
}

static int yib_u_destroy_qp(struct ibv_qp *ibqp)
{
	struct yib_context *ctx = to_yib_ctx(ibqp->context);
	struct yib_qp *qp = to_yib_qp(ibqp);
	FILE *fp = ctx->dbg_fp;
	int ret;

	YIB_LOGm_DBG(fp , YIB_MSG_QP, "starting to destroy userspace qp\n");

	ret = ibv_cmd_destroy_qp(ibqp);
	if (ret < 0) {
		YIB_LOGm_ERR(fp , YIB_MSG_QP, "failed to destroy\n");
		goto end;
	}

	ret = ctx->hw_ops->hw_qp_uninit(ctx , qp);
	if(ret){
		YIB_LOGm_ERR(fp , YIB_MSG_QP, "hw uninit failed to destroy qp \n");
	}
	yib_qp_free_bufs(ctx, qp);
end:
	return ret;
}


#if  defined(__QP__)


static int cq_wait_and_copy_cqe(struct yib_context *yctx, struct yib_cq *ycq, u8* buf, int new_cnt)
{

        bool is_spec_cqe = false;
        int timeout = 10000;
	u32 idx = 0;
        u8 *item;
        u8 *item2;
	u32 new_idx = 0;

	new_idx =  ycq->ci;
	yib_advance_q_internal(&new_idx, 1, new_cnt);
	idx = new_idx;
        do {
                item = cq_head(ycq,  yctx->cqe_isize);
                if (item == NULL) { //队列为空
                        usleep(10*1000);
                        timeout--;
                        if (timeout == 0) {
                                return -ETIMEDOUT;
                        }
                        continue;
                }
                is_spec_cqe = yctx->is_resize_cqe(item);
                if (is_spec_cqe == false) {
                        item2 = buf + (yctx->cqe_isize * q_get_val(new_idx));
                        memcpy(item2, item, yctx->cqe_isize);
                        cq_advance_ci(ycq);
			yib_advance_q_internal(&new_idx, 1, new_cnt);
                        //yctx->cq_ci_db_update(ycq);
                } //硬件保证新的cq中的pi,ci的初始化，特殊的cqe不出现在新的cq中�? 
        } while(is_spec_cqe == false);
	
	//ycq->ci = idx;
	//cq_advance_ci(ycq);
	//yctx->cq_ci_db_update(ycq);
	ycq->ci = idx;

        return true;
}


static int yib_u_resize_cq(struct ibv_cq *ibcq, int cqe)
{
        struct yib_context *yctx= to_yib_ctx(ibcq->context);
	struct yib_cq *cq = to_yib_cq(ibcq);
	struct yib_roce_buf	buf_v;	
	struct yib_resize_cq		cmd = {};
	int ret;
	struct ib_uverbs_resize_cq_resp resp = {};

	cqe = align(cqe * yctx->cqe_isize, 4096ul)/yctx->cqe_isize;
	if (cqe <= cq->cnt) {
		yib_err(yctx->dbg_fp, "new cqe is smaller than old\n");
		return -EINVAL;
	}

	pthread_spin_lock(&cq->lock);
	ret = yib_roce_alloc_dma_buf(&buf_v, &cqe, yctx->cqe_isize);
	if (ret) {
		yib_err(yctx->dbg_fp, "new cqe alloc buf failed\n");
		pthread_spin_unlock(&cq->lock);
		return -ENOMEM;
	}
	cmd.cq_va = (uintptr_t)buf_v.buf;
	cmd.stage = 0;
	ret = ibv_cmd_resize_cq(ibcq, cqe, &cmd.ibv_cmd, sizeof(cmd),
				&resp, sizeof(resp));
	if (ret) {
		yib_err(yctx->dbg_fp, "kernel mode resize cq failed=%d\n", ret);
		goto out_buf;
	}
	cq_wait_and_copy_cqe(yctx, cq, buf_v.buf, cqe);	
	cmd.cq_va = (uintptr_t)buf_v.buf;
	cmd.stage = 1;
	ret = ibv_cmd_resize_cq(ibcq, cqe, &cmd.ibv_cmd, sizeof(cmd),
				&resp, sizeof(resp));
	if (ret) {
		yib_err(yctx->dbg_fp, "kernel mode resize cq twice failed=%d\n", ret);
	}					

out_buf:
	yib_roce_free_buf(&buf_v);
	pthread_spin_unlock(&cq->lock);
	return ret;
}


static int yib_u_notify_cq(struct ibv_cq *ibcq, int solicited)
{
        struct yib_context *context = to_yib_ctx(ibcq->context);
	struct yib_cq *cq = to_yib_cq(ibcq);

        context->notify_cq(cq, solicited);
	return 0;
}


static void yib_u_cq_event(struct ibv_cq *cq)
{
}

void yib_free_qp_wr_ids(struct yib_wr_id_buf * wr_id_buf, struct yib_context *context)
{
	if (context->sw_wrid == false)
		return;

	if (wr_id_buf != NULL) {
		if (wr_id_buf->rq_wr_id_buf) {
			free(wr_id_buf->rq_wr_id_buf);
			wr_id_buf->rq_wr_id_buf = NULL;
		}
		if (wr_id_buf->sq_wr_id_buf) {
			free(wr_id_buf->sq_wr_id_buf);
			wr_id_buf->sq_wr_id_buf = NULL;
		}		
	}
}

//#else

static int yib_query_qp(struct ibv_qp *ibqp, struct ibv_qp_attr *attr,
			int attr_mask, struct ibv_qp_init_attr *init_attr)
{
	struct ibv_query_qp cmd = {};

	return ibv_cmd_query_qp(ibqp, attr, attr_mask, init_attr,
				&cmd, sizeof(cmd));
}

/*static int yib_qp_sqd_change(struct yib_qp *qp, struct yib_context *context)
{
	if (qp->qp_state == IBV_QPS_SQD && attr->qp_state == IBV_QPS_RTS) {
		if (qp->sq.swpi != qp->sq.pi) {
			qp->sq.pi = qp->sq.swpi;
			mmio_wc_start();
			context->sq_pi_db_update(&qp->sq);
                	mmio_flush_writes();
			
		}
	} else if (attr->qp_state == IBV_QPS_SQD) {
		qp->sq.swpi = qp->sq.pi; 
	}
}*/

static int yib_u_modify_qp(struct ibv_qp *ibqp, struct ibv_qp_attr *attr,
				   int attr_mask)
{
	struct yib_context *context = to_yib_ctx(ibqp->context);
	struct ibv_modify_qp cmd = {};
	FILE *fp = context->dbg_fp;
	struct yib_qp *qp = to_yib_qp(ibqp);
	int ret;

	if (attr_mask & IBV_QP_STATE) {
		pthread_spin_lock(&qp->sq.lock);
	}
	ret = ibv_cmd_modify_qp(ibqp, attr, attr_mask, &cmd, sizeof(cmd));
	if (ret) {
		yib_err(fp, "QP Modify: Failed command. ret=%d\n", ret);
		goto end;
	}

	if (attr_mask & IBV_QP_STATE) {
		//yib_qp_sqd_change(qp, context);
		if(attr->qp_state == IBV_QPS_RESET) {
			qp->sq.swpi = qp->sq.pi = 0;
			if (qp->rq.is_srq == false)
				qp->rq.pi = 0;
		}
		qp->qp_state = attr->qp_state;
	}

end:	
	if (attr_mask & IBV_QP_STATE) {
		pthread_spin_unlock(&qp->sq.lock);
	}	
	return ret;
}

#include "io.c"

void set_yib_qpx_ops(struct ibv_qp_ex *qpx)
{
	qpx->wr_start = yib_wr_start;
	qpx->wr_send = yib_wr_send;
	qpx->wr_send_imm = yib_wr_send_imm;
	qpx->wr_send_inv = yib_wr_send_inv;
	qpx->wr_complete = yib_wr_complete;
	qpx->wr_set_sge = yib_wr_set_sge;
	qpx->wr_set_sge_list = yib_wr_set_sge_list;
	qpx->wr_rdma_read = yib_wr_rdma_read;
	qpx->wr_rdma_write = yib_wr_rdma_write;
	qpx->wr_rdma_write_imm = yib_wr_rdma_write_imm;
	qpx->wr_set_inline_data = yib_wr_set_inline_data;
	qpx->wr_set_inline_data_list = yib_wr_set_inline_data_list;
	qpx->wr_abort = yib_wr_abort;
}


const struct verbs_context_ops yib_uops = {
		.query_device_ex	= yib_u_query_device,
		.query_port		= yib_u_query_port,

		.alloc_pd		= yib_u_alloc_pd,
		.dealloc_pd		= yib_u_free_pd,

		.reg_mr			= yib_u_reg_mr,
		.dereg_mr		= yib_u_dereg_mr,

		.create_ah              = yib_u_create_ah,
		.destroy_ah             = yib_u_destroy_ah,   

		//以上原则上流程不变,只是resp可能调整了

		.create_cq		= yib_u_create_cq,
		.destroy_cq		= yib_u_destroy_cq,    
		.req_notify_cq	        = yib_u_notify_cq, //ibv_cmd_req_notify_cq,
		.poll_cq		= yib_u_poll_cq,
		.cq_event               = yib_u_cq_event,
		//.resize_cq              = yib_u_resize_cq,

		.create_qp		= yib_u_create_qp,
		.destroy_qp		= yib_u_destroy_qp,   
		.query_qp		= yib_query_qp,     
		.modify_qp		= yib_u_modify_qp,

		.post_send		= yib_u_post_send,
		.post_recv		= yib_u_post_recv,

		//.free_context		= yib_free_context,		
		.free_context		= yib_dealloc_context,
		.create_qp_ex = yib_u_create_qp_ex,
};
#endif
