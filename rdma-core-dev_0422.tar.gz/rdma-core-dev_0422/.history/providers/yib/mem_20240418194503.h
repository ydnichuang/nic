#ifndef _YIB_MEM_H
#define _YIB_MEM_H

#include <stdlib.h>
#include <stdio.h>


/* static void inline yib_free(void *ptr , char *func , int line) {
		
		if(ptr) {
			free(ptr);
//			ptr = NULL;
		}
			
} */

#define YIBfree(ptr) 							\
do{ 										\
	if(ptr) { 								\
		free(ptr) ; 						\
		ptr = NULL ; 						\
	} 										\
}while(0)

#define YIBmalloc(size) 						\
do { 											\
		malloc(size);							\
}while(0)



#endif


