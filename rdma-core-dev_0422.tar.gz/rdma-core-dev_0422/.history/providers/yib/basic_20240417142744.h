#ifndef YIB_BASIC_H
#define YIB_BASIC_H

#include <stdint.h>
#include <stdarg.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/mman.h>
#include <pthread.h>
#include <string.h>
#include <sched.h>
#include <sys/param.h>
#include <util/util.h>
#include <util/mmio.h>
#include <util/udma_barrier.h>

#include ""


typedef unsigned long long u64;
typedef unsigned int   u32;
typedef unsigned char u8;

#define yib_ilog32(n)		ilog32((n) - 1)

enum yrdma_host_type {
	YRDMA_TYPE_K2RRO	= 0,
	YRDMA_TYPE_SWIFT2100R	= 1,
        YRDMA_TYPE_SWTEST       = 0xFE,
	YRDMA_TYPE_UNKNOW       = 0xFF,
};

#define u64_lsb(a) ((u32)((a) & 0xFFFFFFFF))
#define u64_msb(a) ((u32)((a) >> 32))

struct yib_roce_buf {
	void			*buf;
	unsigned int	length;
	int q_depth;// 队列深度
};

int yib_roce_alloc_buf(struct yib_roce_buf *buf, unsigned int size,
		       int page_size);
unsigned int numTo2n2(unsigned int x);//一个整数 向2的n次方向上取整

void yib_roce_free_buf(struct yib_roce_buf *buf);

typedef unsigned long long u64;
enum {
	YIB_DBG_QP		= 1 << 0,
	YIB_DBG_CQ		= 1 << 1,
	YIB_DBG_QP_SEND	= 1 << 2,
	YIB_DBG_QP_SEND_ERR	= 1 << 3,
	YIB_DBG_CQ_CQE		= 1 << 4,
	YIB_DBG_CONFIG		= 1 << 5,
	YIB_DBG_INIT		= 1 << 6,
	YIB_DBG_RECEIVE		= 1 << 7,
};
extern void yib_open_debug_file(FILE **dbg_fp, u64 id);
extern void yib_close_debug_file(FILE *dbg_fp);
extern void dbg_mem_addr(u64 vaddr, u64  *paddr);

extern u32 yib_debug_mask;
#ifdef YIB_DEBUG
#define yib_dbg(fp, mask, format, arg...)				\
do {									\
	if (mask & yib_debug_mask) {					\
		int tmp = errno;					\
		fprintf(fp, "%s:%d: " format, __func__, __LINE__, ##arg);	\
		errno = tmp;						\
	}								\
} while (0)
#else
static inline void yib_dbg(FILE *fp, uint32_t mask, const char *fmt, ...)
	__attribute__((format(printf, 3, 4)));
static inline void yib_dbg(FILE *fp, uint32_t mask, const char *fmt, ...)
{
}
#endif

#define yib_info(fp, mask, format, arg...)				\
do {									\
	if (mask & yib_debug_mask) {					\
		int tmp = errno;					\
		fprintf(fp, "%s:%d: " format, __func__, __LINE__, ##arg);	\
		errno = tmp;						\
	}								\
} while (0)

__attribute__((format(printf, 2, 3)))
static inline void yib_err(FILE *fp, const char *fmt, ...)
{
	va_list args;

	if (!fp)
		return;
	va_start(args, fmt);
	vfprintf(fp, fmt, args);
	va_end(args);
}

#endif
