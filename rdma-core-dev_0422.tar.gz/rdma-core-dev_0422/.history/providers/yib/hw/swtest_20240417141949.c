
#include "basic.h"
#include "yib.h"
#include "ib.h"




//typedef int (*init)(void *);
//struct yib_hw_ctx_ops //硬件无关的抽象操作,所i有硬件都对应此结构

//硬件相关实现

	int swtest_hw_context_alloc(void  * ctx) {
		struct yib_context yib_ctx = ctx;
	
		struct swtest_hw_ctx *hw_ctx = malloc(sizeof (struct swtest_hw_ctx));
		ctx->hw_priv = hw_ctx;
		return 0;// hw_ctx;
	}	// swtest_hw_context_alloc(){ return &yib_2100r_hw_ctx;}
	
	int    swtest_hw_context_dealloc(void *) {
		return 0;	
	};

	int swtest_hw_global_map_reg(struct yib_context *){
		
		return 0;
	}//映射regi寄存器

	int swtest_hw_global_unmap_reg(struct yib_context *){ 
		return 0;
	}	

//硬件相关的初始化函数
	int swtest_hw_cq_init(struct yib_context * ctx, struct yib_cq* ){
			return 0;
	}		
	int swtest_hw_qp_init(struct yib_context * ctx, struct yib_qp* ){ return 0;}
	int swtest_hw_rq_init(struct yib_context * ctx, struct yib_rq* ){ return 0;}
	int swtest_hw_cq_uninit(struct yib_context * ctx, struct yib_cq* ){return 0;}
	int swtest_hw_qp_uninit(struct yib_context * ctx, struct yib_qp* ){return 0;}	
	int swtest_hw_rq_uninit(struct yib_context * ctx, struct yib_rq* ){ return 0; //srq,rq 
	}

//	int (*get_sq_item_size)(enum qp_type , int is_inline  , int sge_num);	
//	int (*get_rq_item_size)(enum qp_type , int is_inline  , int sge_num);//qp_type rc,ud 

	int swtest_fill_rqe(struct yib_context * ctx, struct yib_rq *rq, const void *os_wq, u8 *buf, u32 length) { 
		return 0;
	}
	int swtest_fill_wqe(struct yib_context * ctx, struct yib_qp *qp, const void *os_wq, u8 *buf, u32 length,  u32 mask) { 
		return 0;
	}
	//qp_cache是否使用，由底层的情况决定，当底层硬件有能力在cq中返回qp地址信息时不使用， 否则底层硬件可返回qpn(这时需要使用qp_cache)
	void swtest_fill_cqe(struct yib_context * ctx, struct yib_cq *cq, struct yib_qp **qp_cache, void *os_cq, u8 *buf) { 
		return ; 
	} 
	int swtest__fill_cqe(struct yib_context * ctx, struct yib_cq *cq, void *os_cq){ 
		return 0;
	}//返回0表示处理成功，小于0表示不保序

	bool swtest_check_sq_full(struct yib_context *, struct yib_sq *sq){ return 0;}
	bool swtest_check_rq_full(struct yib_context *, struct yib_rq *rq){ return 0;}
	bool swtest_check_srq_full(struct yib_context *, struct yib_srq *srq, int *pos){ return 0;}
	bool swtest_check_cq_empty(struct yib_context *, struct yib_cq *cq){ return 0;}
	//bool (*is_resize_cq)(u8 *buf);

	int swtest_get_sq_item_size(int *inline_len, int *max_sg, bool is_ud){ return 0;}//inline_len和max_sg为输入输出参数
	int swtest_get_rq_item_size(int *max_sg){ return 0;}

	//db update
	void swtest_sq_pi_db_update(struct yib_context *, struct yib_sq *sq, int io_cnt){ return ;}
	void swtest_rq_pi_db_update(struct yib_context *, struct yib_rq *rq, int io_cnt){ return ;}
	void swtest_srq_pi_db_update(struct yib_context *, struct yib_srq *srq, int pos){ return ;}
	void swtest_cq_ci_db_update(struct yib_context *, struct yib_cq *cq, int poll_cnt){ return ;}

	void swtest_rq_post_db_ext(struct yib_context *, struct yib_rq *rq, int io_cnt){ return ;}//ext结尾的函数指针可以为空

	
 

	/*new api support*/
	void swtest_wr_send(struct yib_qp *qp){ return ;}
	void swtest_wr_rdma_read(struct yib_qp *qp, uint32_t rkey, uint64_t remote_addr){ return ;}
	void swtest_wr_rdma_write(struct yib_qp *qp, uint32_t rkey,uint64_t remote_addr){ return ;}
	void swtest_wr_rdma_write_imm(struct yib_qp *qp, uint32_t rkey,uint64_t remote_addr, __be32 imm_data){ return ;}
	void swtest_wr_send_imm(struct yib_qp *qp, __be32 imm_data){ return ;}
	void swtest_wr_send_inv(struct yib_qp *qp, uint32_t invalidate_rkey){ return ;}
	void swtest_wr_set_inline_data(struct yib_qp *qp, void *addr,
				   size_t length){ retur ;}
	void swtest_wr_set_inline_data_list(struct yib_qp *qp, size_t num_buf,
				const struct ibv_data_buf *buf_list){ return ;}

	void swtest_wr_set_sge(struct yib_qp* qp, uint32_t lkey, uint64_t addr, uint32_t length){ return ;}
	void swtest_wr_set_sge_list(struct yib_qp *qp, uint32_t num_sge, const struct ibv_sge *list){ return ;}


struct swtest_hw_ctx  swt_hw_ctx;


struct yib_hw_ctx_ops swtest_hw_ctx_ops {

	.hw_context_alloc= swtest_hw_context_alloc;	
	// swtest_hw_context_alloc(){ return &yib_2100r_hw_ctx;}
	.hw_context_dealloc=  swtest_hw_context_dealloc;

	.hw_global_map_reg= swtest_hw_global_map_reg; //映射regi寄存器
	.hw_global_unmap_reg= swtest_hw_global_unmap_reg;

//硬件相关的初始化函数
	.hw_cq_init = swtest_hw_cq_init;
	.hw_qp_init = swtest_hw_qp_init;
	.hw_rq_init = swtest_hw_rq_init;
	.hw_cq_uninit = swtest_hw_cq_uninit;
	.hw_qp_uninit = swtest_hw_qp_uninit;	
	.hw_rq_uninit = swtest_hw_rq_uninit;//srq,rq


	int cqe_isize;
	.fill_rqe = swtest_fill_rqe;
	.fill_wqe = swtest_fill_wqe;
	//qp_cache是否使用，由底层的情况决定，当底层硬件有能力在cq中返回qp地址信息时不使用， 否则底层硬件可返回qpn(这时需要使用qp_cache)
	.fill_cqe = swtest_fill_cqe;
	.sw_fill_cqe = swtest_sw_fill_cqe;//返回0表示处理成功，小于0表示不保序

	.check_sq_full = swtest_check_sq_full;
	.check_rq_full = swtest_check_rq_full;
	.check_srq_full = swtest_check_srq_full;
	.check_cq_empty = swtest_check_cq_empty;
	//bool (*is_resize_cq)(u8 *buf);

	.get_sq_item_size = swtest_get_sq_item_size;//inline_len和max_sg为输入输出参数
	.get_rq_item_size = swtest_get_rq_item_size;

	//db update
	.sq_pi_db_update = swtest_sq_pi_db_update;
	.rq_pi_db_update = swtest_rq_pi_db_update;
	.srq_pi_db_update = swtest_srq_pi_db_update;
	.cq_ci_db_update = swtest_cq_ci_db_update;

	.rq_post_db_ext = swtest_rq_post_db_ext;//ext结尾的函数指针可以为空

	
#endif 	 

	/*new api support*/
	.wr_send = swtest_wr_send;
	.wr_rdma_read = swtest_wr_rdma_read;
	.wr_rdma_write = swtest_wr_rdma_write;
	.wr_rdma_write_imm = swtest_wr_rdma_write_imm;
	.wr_send_imm = swtest_wr_send_imm;
	.wr_send_inv = swtest_wr_send_inv;
	.wr_set_inline_data = swtest_wr_set_inline_data;	
	.wr_set_inline_data_list = swtest_wr_set_inline_data_list;

	.wr_set_sge = swtest_wr_set_sge;
	.wr_set_sge_list = swtest_wr_set_sge_list;
};





