



enum hw_chip_type {
	SWTEST = 0, SW2100R=1
};

struct yib_hw_comn_ctx {
		enum hw_chip_type chip_type;
		void *chip;
};

struct swtest_hw_ctx   {
//	enum hw_chip_type chip;
    struct yib_hw_comn_ctx hw_com_ctx;
	int reg;
} ;

struct yib_hw_ctx_ops swtest_hw_ctx_ops ;


