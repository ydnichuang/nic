#ifndef __TYPE_DEFS_H__ 
#define __TYPE_DEFS_H__

#include <sys/types.h>


typedef uint8_t  u8;
typedef uint32_t u32;
typedef uint64_t u64;
//typedef _Bool  bool;

//typedef uint32_t int;
typedef __be32 uint32_t;
//typedef uint64_t;



#endif