#include "basic.h"
#include <netinet/in.h>
#include <infiniband/driver.h>
#include <infiniband/verbs.h>
#include <util/symver.h>
#include "yib-abi.h"
#include "yib.h"
#include "ib.h"
#include "queue.h"
#include "sw2100r.h"

static inline u32 net_addr2_le32(u8 * dat)
{
	return (dat[0] << 8 | dat[1] << 16 | dat[2] << 24 | dat[3]);
}

inline static void xqe_writel(u32 val,  void *buf, int index)
{
        mmio_write32(buf + index *4, val);
}

inline static u32 xqe_readl(void *buf, int index)
{
        return mmio_read32(buf + index*4);
}

int r2100_set_capture(struct yib_qp *qp, bool enable)
{
	return -1;
}

bool r2100_is_resize_cqe(u8 *buf)
{
       u32 tmp1 = xqe_readl(buf, 1);
       if ((tmp1 & 0xFF) == 0xc) {
                return true;
       }
       return false;
}

void r2100_fill_cqe(struct yib_cq *cq,  struct ibv_wc *wc, u8 *buf)
{
        int qid = 0;
        __u16 wr_id = 0;
        struct yib_wr_id_buf * qpbuf = NULL;

        u32 tmp3 = xqe_readl(buf, 0);
        u32 tmp2 = xqe_readl(buf, 1);
        u32 tmp1 = xqe_readl(buf, 2);
        u32 tmp0 = xqe_readl(buf, 3);
        wc->wc_flags = 0;
        switch (tmp1 & 0xFF) {
                case 0x00:
                        wc->opcode = IBV_WC_RDMA_WRITE;
                        break;
                case 0x01:
                        wc->opcode = IBV_WC_RDMA_WRITE;
                        wc->imm_data = be32toh(tmp3);
                        wc->wc_flags |= IBV_WC_WITH_IMM;
                        break;
                case 0x02:
                        wc->opcode = IBV_WC_SEND;
                        break;
                case 0x03:
                        wc->opcode = IBV_WC_SEND;
                        wc->imm_data = be32toh(tmp3);
                        wc->wc_flags |= IBV_WC_WITH_IMM;
                        break;
                case 0x04:
                        wc->opcode = IBV_WC_SEND;
                        wc->invalidated_rkey = tmp3;
                        wc->wc_flags |= IBV_WC_WITH_INV;
                        break;
                case 0x5:
                        wc->opcode = IBV_WC_RDMA_READ;
                        break;
                case 0x6:
                        wc->opcode = IBV_WC_RECV;
                        break;
                case 0x7:
                        wc->opcode = IBV_WC_RECV;
                        wc->imm_data = be32toh(tmp3);
                        wc->wc_flags |= IBV_WC_WITH_IMM;                        
                        break;
                case 0x8:
                        wc->opcode = IBV_WC_RECV_RDMA_WITH_IMM;
                        wc->imm_data = be32toh(tmp3);
                        wc->wc_flags |= IBV_WC_WITH_IMM;                        
                        break;
                case 0xa:
                        wc->opcode = IBV_WC_LOCAL_INV;
			break;                        
                default:
                        break;
        }


        qid = (tmp1 & (0x03FFFF00)) >> 8;  
        qid = yib_get_qp_entry_idx(cq->ctx, qid);
        wc->byte_len = tmp2;
        wr_id = ((tmp1 & 0xFC000000) >> 26) | ((tmp0 & 0x3FF)<<6);
        qpbuf = cq->ctx->qp_array[qid];
        if (qpbuf == NULL || qid >= YIB_MAX_QP) {
                wc->wr_id = wr_id;
                yib_err(cq->ctx->dbg_fp, "get qp failed for id=%d\n", wr_id);
                wc->status = IBV_WC_BAD_RESP_ERR;
                goto end;
                
        } else {
                if (wr_id & BIT(15))
                        wc->wr_id  = qpbuf->rq_wr_id_buf[wr_id & 0x7FFF];
                else
                        wc->wr_id  = qpbuf->sq_wr_id_buf[wr_id & 0x7FFF]; 
                //wc->port_num = yqp->attr.port_num;
        }          
        
	wc->qp_num = qid;

        if (qid == 1) {
                wc->pkey_index = 0;
                wc->src_qp = 1;
                wc->wc_flags |= IBV_WC_GRH; 
        }

        wc->status = tmp0 >> 28;
        if (wc->status == 0x2)
            wc->status = 0x5;  //Hardware set flush error with 0x2, but real value is 0x5
end:        
        memset(buf, 0, 16);
}

int r2100_fill_wqe(struct yib_qp *qp, struct ibv_send_wr *wr, u8 *buf, u32 length, u32 mask)
{
	u32 tmp = 0;

        memset(buf, 0, 96);
        if ((wr->send_flags & IBV_SEND_SIGNALED) || (qp->sqsig))
                tmp |= BIT(18);
        
        if (wr->send_flags & IBV_SEND_SOLICITED) tmp |= BIT(16);
        
        if (wr->send_flags & IBV_SEND_FENCE) tmp |= BIT(19);

        if (wr->send_flags & IBV_SEND_INLINE) tmp |= BIT(23);

        if (mask & WR_ATOMIC_MASK)
                return -EINVAL;

        if (qp->ctx->qp_array[qp->qpn]->sq_wr_id_buf != NULL) {
                u32 index = q_get_val(qp->sq.pi);
                u64 *wrid = &qp->ctx->qp_array[qp->qpn]->sq_wr_id_buf[index];
                *wrid = wr->wr_id;
                tmp |= index & 0x7FFF;
        } else {
                return -EINVAL;
        }        
        xqe_writel(tmp, buf, 0);

        switch (wr->opcode) {
	        case IBV_WR_RDMA_WRITE: 
                        tmp = 0;
                        break;
	        case IBV_WR_RDMA_WRITE_WITH_IMM: 
                        xqe_writel(htobe32(wr->imm_data), buf, 6);
                        tmp = 1;
                        break;
	        case IBV_WR_SEND:
                        tmp = 2;
                        break; 
	        case IBV_WR_SEND_WITH_IMM: 
                        xqe_writel(htobe32(wr->imm_data), buf, 6);
                        tmp = 3;
                        break;
                case IBV_WR_SEND_WITH_INV: 
                        xqe_writel(wr->invalidate_rkey, buf, 6);
                        tmp = 4;
                        break;
	        case IBV_WR_RDMA_READ: 
                        tmp = 5;
                        break;
	        case IBV_WR_LOCAL_INV: 
                        xqe_writel(wr->invalidate_rkey, buf, 6);
                        tmp = 0xa;
                        break;
                default:
                        return -EINVAL;
        }

 
        if (!(wr->send_flags & IBV_SEND_INLINE)) {
                tmp |= (wr->num_sge << 8);
        }
        if (length == 0 && (mask & (WR_SEND_MASK | WR_READ_MASK | WR_WRITE_MASK)) ) {
                tmp |= (1 << 8);
        }
        xqe_writel(tmp, buf, 1);

        if (mask & WR_READ_OR_WRITE_MASK) {
                xqe_writel(wr->wr.rdma.rkey, buf, 2);
                xqe_writel(u64_lsb(wr->wr.rdma.remote_addr), buf, 4);
                xqe_writel(u64_msb(wr->wr.rdma.remote_addr), buf, 5);                
        }
        xqe_writel(length, buf, 3);

        if (!(wr->send_flags & IBV_SEND_INLINE)) {
                int i = 0;
                while (length > 0) {
                        if (i > 4) {
                                return -EINVAL;
                        }
                        length -=  (length > wr->sg_list[i].length)? wr->sg_list[i].length:length;
                        xqe_writel(u64_lsb(wr->sg_list[i].addr), buf, (8 + i*4 + 2));
                        xqe_writel(u64_msb(wr->sg_list[i].addr), buf, (8 + i*4 + 3));
                        xqe_writel(wr->sg_list[i].length,  buf,  (8 + i*4 + 1));
                        xqe_writel(wr->sg_list[i].lkey,    buf,  (8 + i*4));
                        i++;
                }
        } else {
		u8 *pos = buf + 8*4;
		int i = 0;
                int len = 0;
               
		while (length > 0) {
                        if ((len + wr->sg_list[i].length) >= (96)) 
				return -EINVAL;
			memcpy(pos, (void*)wr->sg_list[i].addr, wr->sg_list[i].length);
			length -=  (length > wr->sg_list[i].length)? wr->sg_list[i].length:length;
			pos += wr->sg_list[i].length;
			len += wr->sg_list[i].length;
                }
        }
        return 0;
}

int r2100_fill_rqe(struct yib_context * ctx, struct yib_rq *rq, struct ibv_recv_wr *wr, u8 *buf, u32 length)
{
     	u32 tmp = wr->wr_id;
        int i;

        memset(buf, 0, 96);

        if (ctx->qp_array[rq->qid]->rq_wr_id_buf != NULL) {
                if (rq->nvme_off == false) {
                        u32 index = q_get_val(rq->pi & 0x7FFFFFFFF);
                        u64 *wrid = &ctx->qp_array[rq->qid]->rq_wr_id_buf[index];
                        *wrid = wr->wr_id;
                        tmp = BIT(15) | (index & 0x7FFF); // index  | BIT(15); --> rqe header
                } else {
                        tmp = wr->wr_id;
                }
                xqe_writel(tmp, buf, 0);
        } else {
                return -EINVAL;
        }        

        tmp = 0;
        if (length == 0) {
                tmp |= (1 << 8);
                xqe_writel((1 << 8) | 0x06, buf, 1);
        } else {
                xqe_writel((wr->num_sge << 8) | 0x06, buf, 1);
        }
        xqe_writel(length, buf, 3); //OPCODE
        if (wr->num_sge > 5)
                return -EINVAL;
  
        for (i = 0; i < wr->num_sge; i++) {
                xqe_writel(u64_lsb(wr->sg_list[i].addr), buf, (8 + i*4 + 2));
                xqe_writel(u64_msb(wr->sg_list[i].addr), buf, (8 + i*4 + 3));
                xqe_writel(wr->sg_list[i].length,  buf, (8 + i*4 + 1));
                xqe_writel(wr->sg_list[i].lkey,    buf, (8 + i*4 ));
        }
        return 0;
}

void r2100_cq_ci_db_update(struct yib_cq *cq)
{
        u32 idx = q_get_val(cq->ci);
	u32 c = q_get_carrier(cq->ci);
	mmio_write32(cq->ci_db, (idx << 16) | yib_get_cqc_index(cq->ctx, cq->cqid) | (c<<15));
}

void r2100_sq_pi_db_update(struct yib_sq *sq)
{
        u32 idx = q_get_val(sq->pi);
	u32 c = q_get_carrier(sq->pi);
	mmio_write32(sq->pi_db, (idx << 16) | yib_get_qpc_index(sq->ctx,sq->qid) | (c<<15));
}

void r2100_rq_pi_db_update(struct yib_rq *rq)
{
        u32 idx = q_get_val(rq->pi);
	u32 c = q_get_carrier(rq->pi);
	mmio_write32(rq->pi_db, (idx << 16) | yib_get_qpc_index(rq->ctx,rq->qid) | (c<<15));
}

void r2100_notify_cq(struct yib_cq *cq, int solicated)
{
        if (solicated)
	        mmio_write32(cq->cq_event, (0x5<<18) | yib_get_cqc_index(cq->ctx, cq->cqid));
	else 
		mmio_write32(cq->cq_event, (0x6<<18)| yib_get_cqc_index(cq->ctx, cq->cqid));
}

//new api
// static inline void r2100_wr_set_wr_id(struct yib_qp* qp)
// {
//     qp->sq.wr_id_buf[qp->curr_index] = qp->vqp.qp_ex.wr_id;
// }

//NOTE after this call, wqe should be update by "read-update-write"
static void r2100_wr_fill_wqe_comm(struct yib_qp *qp, int ibv_opc, u32 imm_data, u32 invalidate_rkey, 
                                        u32 r_key, u64 r_addr)
{
    u32 tmp = 0;
    u32 send_flags = qp->vqp.qp_ex.wr_flags;
    memset(qp->wqe, 0, qp->ctx->wqe_isize);
    if ((send_flags & IBV_SEND_SIGNALED) || (qp->sqsig))
            tmp |= BIT(18);
    
    if (send_flags & IBV_SEND_SOLICITED) tmp |= BIT(16);
    
    if (send_flags & IBV_SEND_FENCE) tmp |= BIT(19);

    if (send_flags & IBV_SEND_INLINE) tmp |= BIT(23);

    uint32_t index = q_get_val(qp->curr_index);
    qp->ctx->qp_array[qp->qpn]->sq_wr_id_buf[index] = qp->vqp.qp_ex.wr_id;
    tmp |= index & 0x7fff;
    xqe_writel(tmp, qp->wqe, 0);

    switch (ibv_opc) {
        case IBV_WR_RDMA_WRITE: 
            tmp = 0;
            break;
        case IBV_WR_RDMA_WRITE_WITH_IMM: 
            xqe_writel(htobe32(imm_data), qp->wqe, 6);
            tmp = 1;
            break;
        case IBV_WR_SEND:
            tmp = 2;
            break; 
        case IBV_WR_SEND_WITH_IMM: 
            xqe_writel(htobe32(imm_data), qp->wqe, 6);
            tmp = 3;
            break;
        case IBV_WR_SEND_WITH_INV: 
            xqe_writel(invalidate_rkey, qp->wqe, 6);
            tmp = 4;
            break;
        case IBV_WR_RDMA_READ: 
            tmp = 5;
            break;
        case IBV_WR_LOCAL_INV: 
            xqe_writel(invalidate_rkey, qp->wqe, 6);
            tmp = 0xa;
            break;
        default:
            qp->err = EINVAL;
            return;
    
        }

    xqe_writel(tmp, qp->wqe, 1);

    if (ibv_opc == IBV_WR_RDMA_READ ||
            ibv_opc == IBV_WR_RDMA_WRITE) {
        xqe_writel(r_key, qp->wqe, 2);
        xqe_writel(u64_lsb(r_addr), qp->wqe, 4);
        xqe_writel(u64_msb(r_addr), qp->wqe, 5);                
    }
}

void r2100_wr_send(struct yib_qp *qp)
{
    r2100_wr_fill_wqe_comm(qp, IBV_WR_SEND, 0, 0, 0, 0);
}

void r2100_wr_send_imm(struct yib_qp *qp, __be32 imm_data)
{
    r2100_wr_fill_wqe_comm(qp, IBV_WR_SEND_WITH_IMM, imm_data, 0, 0, 0);
}
void r2100_wr_send_inv(struct yib_qp *qp, uint32_t invalidate_rkey)
{
    r2100_wr_fill_wqe_comm(qp, IBV_WR_SEND_WITH_INV, 0, invalidate_rkey, 0, 0);
}
void r2100_wr_rdma_read(struct yib_qp *qp, uint32_t rkey, uint64_t remote_addr)
{
    r2100_wr_fill_wqe_comm(qp, IBV_WR_RDMA_READ, 0, 0, rkey, remote_addr);
}

void r2100_wr_rdma_write(struct yib_qp *qp, uint32_t rkey,uint64_t remote_addr)
{
    r2100_wr_fill_wqe_comm(qp, IBV_WR_RDMA_WRITE, 0, 0, rkey, remote_addr);
}

void r2100_wr_rdma_write_imm(struct yib_qp *qp, uint32_t rkey,
                uint64_t remote_addr, __be32 imm_data)
{
    r2100_wr_fill_wqe_comm(qp, IBV_WR_RDMA_WRITE_WITH_IMM, imm_data, 0, rkey, remote_addr);
}

void r2100_wr_set_inline_data(struct yib_qp *qp, void *addr,size_t length)
{

    u8 *pos = qp->wqe + 8*4;

    if(unlikely(length > qp->sq.max_inline)) {
        qp->err = EINVAL;
        return;
    }
    memcpy(pos, addr, length);

    xqe_writel(length, qp->wqe, 3);
}

void r2100_wr_set_inline_data_list(struct yib_qp *qp, size_t num_buf,
				const struct ibv_data_buf *buf_list)
{
    u32 length = 0;
    u8 *pos = qp->wqe + 8*4;
    for (size_t i = 0; i < num_buf; i++){
        if((length + buf_list->length > qp->sq.max_inline)) {
            qp->err = EINVAL;
            return;
        }
        memcpy(pos, buf_list->addr, buf_list->length);
        length += buf_list->length;
        buf_list++;
        pos += buf_list->length;
    }

    xqe_writel(length, qp->wqe, 3);    
}

void r2100_wr_set_sge(struct yib_qp* qp, uint32_t lkey, uint64_t addr, uint32_t length)
{
    u32 tmp = length;
    xqe_writel(tmp, qp->wqe, 3);
    
    tmp = xqe_readl(qp->wqe, 1);
    tmp |= (u32)0x01 << 8;
    xqe_writel(tmp, qp->wqe, 1);

    xqe_writel(lkey, qp->wqe, 8);
    xqe_writel(length, qp->wqe, 9);
    xqe_writel(u64_lsb(addr), qp->wqe, 10);
    xqe_writel(u64_msb(addr), qp->wqe, 11);
}

void r2100_wr_set_sge_list(struct yib_qp *qp, uint32_t num_sge, const struct ibv_sge *list) 
{
    u32 length = 0;
    u32 tmp;
    if(num_sge > 4) {
        qp->err = EINVAL;
        return;
    }

    for (uint32_t i = 0; i < num_sge; ++i){
        length += list[i].length;
    }

    tmp = length;
    xqe_writel(tmp, qp->wqe, 3);

    tmp = xqe_readl(qp->wqe, 1);
    tmp |= num_sge << 8;
    xqe_writel(tmp, qp->wqe, 1);

    for (uint32_t i = 0; i < num_sge; ++i){
        xqe_writel(list[i].lkey, qp->wqe, (8 + i*4));
        xqe_writel(list[i].length, qp->wqe, (8 + i*4 + 1));
        xqe_writel(u64_lsb(list[i].addr), qp->wqe, (8 + i*4 + 2));
        xqe_writel(u64_msb(list[i].addr), qp->wqe, (8 + i*4 + 3));
    }
    
}
