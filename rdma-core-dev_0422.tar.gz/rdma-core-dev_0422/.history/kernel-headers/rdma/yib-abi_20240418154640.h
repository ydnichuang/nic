#ifndef RDMA_USER_YIB_H
#define RDMA_USER_YIB_H

#include <linux/types.h>
#include <linux/socket.h>
#include <linux/in.h>
#include <linux/in6.h>

enum {
	YIB_NETWORK_TYPE_IPV4 = 1,
	YIB_NETWORK_TYPE_IPV6 = 2,
};

union yib_gid {
	__u8	raw[16];
	struct {
		__be64	subnet_prefix;
		__be64	interface_id;
	} global;
};

struct yib_global_route {
	union yib_gid	dgid;
	__u32		flow_label;
	__u8		sgid_index;
	__u8		hop_limit;
	__u8		traffic_class;
};

struct yib_av {
	__u8			port_num;
	/* From RXE_NETWORK_TYPE_* */
	__u8			network_type;
	__u8			smac[6];
	struct yib_global_route	grh;
	union {
		struct sockaddr_in	_sockaddr_in;
		struct sockaddr_in6	_sockaddr_in6;
	} sgid_addr, dgid_addr;
};

//这个文件是用户接态口的信息

struct yib_ib_alloc_pd_resp {
	__u32 pdn;
};

struct yib_ib_create_ah_resp {
	__u32 ah_num;
	__u32 reserved;
};

struct yib_ib_create_cq { 
	__aligned_u64 cq_va;
	__u32 nvme_off;
};

struct yib_ib_create_srq { 
	__aligned_u64 srq_va;
	__u32 nvme_off; //该srq是否使用nvme_off
};

struct yib_ib_create_qp { 
	__aligned_u64 sq_va;
	__aligned_u64 rq_va;
	__u32 nvme_off;
	__u32 reserved;
};

struct yib_ib_modify_qp {
	__u32	max_burst_sz;
	__u16	typical_pkt_sz;
	__u16	reserved;
};


//response

struct yib_ib_create_cq_resp {
	__u32	cqid;
	__u32	isize;
	__u32	max_cqe;
	__u32	reserved;
};

struct yib_ib_create_qp_resp {
	__aligned_u64 capture_pa;
	__aligned_u64 nvme_rq_rqe_pa;
	__u32 qpid;
	__u32 rqid;
	__u32 max_send_wr;
	__u32 max_recv_wr;
	__u32 max_send_sge;
	__u32 max_recv_sge;
	__u32 max_inline_data;
	__u32 send_isize;
	__u32 recv_isize;
}; //rq对srq时无效

struct yib_ib_create_srq_resp {
	__u32 srqid;
	__u32 max_wr;
	__u32 max_sge;
	__u32 isize;
}; //rq对srq时无效

struct yib_ib_alloc_uctx_resp {
	__u32  bar_offset; //rdma寄存器相对于 bar0的偏移
	__u32  bar_map_len;
	__u32  chip_type;
	__u32  chip_subtype;
	__u32  reserved;
};


typedef enum
{
	YIB_MMAP_TYPE_REG = 0,
	YIB_MMAP_TYPE_CQ,
	YIB_MMAP_TYPE_SQ,
	YIB_MMAP_TYPE_RQ,
	YIB_MMAP_TYPE_RSV1 = 4,
	YIB_MMAP_TYPE_RSV2,
	YIB_MMAP_TYPE_RSV3,
	YIB_MMAP_TYPE_RSV4,
	YIB_MMAP_TYPE_HW1 = 8,
	YIB_MMAP_TYPE_HW2,
	YIB_MMAP_TYPE_HW3,
	YIB_MMAP_TYPE_HW4,
	YIB_MMAP_TYPE_HW5,
	YIB_MMAP_TYPE_HW6,
	YIB_MMAP_TYPE_HW7,
	YIB_MMAP_TYPE_HW8,
}yib_mmap_t;

struct yib_ib_modify_srq {
	__u32 generate;
	__u32 reserved;
};

#if 1


struct yib_alloc_ucontext_resp {
	__u32  bar_offset; //rdma寄存器相对于 bar0的偏移
	__u32  bar_map_len;
	__u32  chip_type;
	__u32  chip_subtype;
	__u32  reserved;
};


struct yib_create_cq_resp {
	__u32	cqid;
	__u32	isize;
	__u32	max_cqe;
	__u32	reserved;
};

struct yib_alloc_pd_resp {
	__u32 pdn;
};

struct yib_create_ah_resp {
	__u32 ah_num;
	__u8  smac[6];
	__u32 reserved;
};

#endif

#endif
